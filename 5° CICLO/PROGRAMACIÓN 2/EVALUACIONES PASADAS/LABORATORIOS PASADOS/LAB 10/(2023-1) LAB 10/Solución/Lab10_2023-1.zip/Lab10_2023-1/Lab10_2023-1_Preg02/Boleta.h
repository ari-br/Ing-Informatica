/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Boleta.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 07:52 PM
 */

#ifndef BOLETA_H
#define BOLETA_H

#include "Alumno.h"


class Boleta {
public:
    Boleta();
    Boleta(const Boleta& orig);
    virtual ~Boleta();
    void lee(ifstream &arch);
    int devolverCodigo();
    void imprime(ofstream &arch);
    bool mismaEscala(int esc);
    void actualiza(double prec);
private:
    Alumno *pboleta;
};

#endif /* BOLETA_H */

