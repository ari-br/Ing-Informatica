/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Semipresencial.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 07:47 PM
 */

#ifndef SEMIPRESENCIAL_H
#define SEMIPRESENCIAL_H

#include "Alumno.h"


class Semipresencial:public Alumno {
public:
    Semipresencial();
    Semipresencial(const Semipresencial& orig);
    virtual ~Semipresencial();
    void SetTotal(double total);
    double GetTotal() const;
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void lee(ifstream &arch,int cod,char *nomb,int esc,double cred); //Método polimórfico
    void imprime(ofstream &arch,char *lic); //Método polimórfico
    void actualizaTotal(double subTotal); //Método polimórfico
private:
    double descuento;
    double total;
};

#endif /* SEMIPRESENCIAL_H */

