/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Tesoreria.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 08:01 PM
 */

#ifndef TESORERIA_H
#define TESORERIA_H

#include <fstream>
using namespace std;
#include "Arbol.h"


class Tesoreria {
public:
    Tesoreria();
    Tesoreria(const Tesoreria& orig);
    virtual ~Tesoreria();
    void cargaalumnos();
    void actualizaboleta();
    void imprimeboleta();
private:
    Arbol aboleta;
    void imprimirLinea(ofstream &arch,char c);
    void AperturaIf(ifstream &arch,const char *nomb);
    void AperturaOf(ofstream &arch,const char *nomb);
};

#endif /* TESORERIA_H */

