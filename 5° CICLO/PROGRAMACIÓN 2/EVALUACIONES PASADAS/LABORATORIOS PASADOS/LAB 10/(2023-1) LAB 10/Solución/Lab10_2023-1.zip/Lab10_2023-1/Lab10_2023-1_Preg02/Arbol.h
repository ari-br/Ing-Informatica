/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Arbol.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 07:55 PM
 */

#ifndef ARBOL_H
#define ARBOL_H

#include "Nodo.h"
#include "Escala.h"


class Arbol {
public:
    Arbol();
    Arbol(const Arbol& orig);
    virtual ~Arbol();
    void insertar(Nodo *nodo);
    void recorreEnOrden(ofstream &arch);
    void actualiza(int esc,double prec);
private:
    Nodo *raiz;
    Escala lescala[10];
    Nodo *insertar(Nodo *nodo,Boleta &bol);
    int compara(Boleta &a,Boleta &b);
    void recorreEnOrden(ofstream &arch,Nodo *nodo);
    void actualiza(Nodo *nodo,int esc,double prec);
};

#endif /* ARBOL_H */

