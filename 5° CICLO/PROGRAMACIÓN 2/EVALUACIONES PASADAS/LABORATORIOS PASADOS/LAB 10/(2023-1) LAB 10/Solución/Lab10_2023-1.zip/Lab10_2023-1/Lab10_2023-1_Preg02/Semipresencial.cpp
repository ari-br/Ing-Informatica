/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Semipresencial.cpp
 * Author: Ariana
 * 
 * Created on 16 de noviembre de 2024, 07:47 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Semipresencial.h"

Semipresencial::Semipresencial() {
    descuento=0;
    total=0;
}

Semipresencial::Semipresencial(const Semipresencial& orig) {
}

Semipresencial::~Semipresencial() {
}

void Semipresencial::SetTotal(double total) {
    this->total = total;
}

double Semipresencial::GetTotal() const {
    return total;
}

void Semipresencial::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Semipresencial::GetDescuento() const {
    return descuento;
}

void Semipresencial::lee(ifstream &arch,int cod,char *nomb,int esc,double cred){
    arch>>descuento;
    Alumno::lee(arch,cod,nomb,esc,cred);
}

void Semipresencial::imprime(ofstream &arch,char *lic){
    Alumno::imprime(arch,nullptr);
}

void Semipresencial::actualizaTotal(double subTotal){
    total=subTotal*descuento/100;
    subTotal-=total;
    Alumno::actualizaTotal(subTotal);
}