/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Nodo.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 07:53 PM
 */

#ifndef NODO_H
#define NODO_H

#include "Boleta.h"


class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Arbol;
    void lee(ifstream &arch);
    void imprime(ofstream &arch);
    bool mismaEscala(int esc);
    void actualiza(double prec);
private:
    Boleta dboleta;
    Nodo *izq;
    Nodo *der;
};

#endif /* NODO_H */

