/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Virtual.cpp
 * Author: Ariana
 * 
 * Created on 16 de noviembre de 2024, 07:49 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "Virtual.h"

Virtual::Virtual() {
    licencia=nullptr;
    total=0;
}

Virtual::Virtual(const Virtual& orig) {
}

Virtual::~Virtual() {
    if(licencia!=nullptr) delete licencia;
}

void Virtual::SetTotal(double total) {
    this->total = total;
}

double Virtual::GetTotal() const {
    return total;
}

void Virtual::SetLicencia(char *cad){
    if(licencia!=nullptr) delete licencia;
    licencia=new char[strlen(cad)+1];
    strcpy(licencia,cad);
}

void Virtual::GetLicencia(char *cad) const{
    if(licencia!=nullptr)
        strcpy(cad,licencia);
}

void Virtual::lee(ifstream &arch,int cod,char *nomb,int esc,double cred){
    char lic[20];
    arch.getline(lic,20);
    SetLicencia(lic);
    Alumno::lee(arch,cod,nomb,esc,cred);
}

void Virtual::imprime(ofstream &arch,char *lic){
    char cad[120];
    GetLicencia(cad);
    Alumno::imprime(arch,cad);
}