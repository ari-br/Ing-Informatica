/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Alumno.cpp
 * Author: Ariana
 * 
 * Created on 16 de noviembre de 2024, 07:39 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "Alumno.h"

Alumno::Alumno() {
    codigo=0;
    nombre=nullptr;
    escala=0;
    creditos=0;
    total=0;
}

Alumno::Alumno(const Alumno& orig) {
}

Alumno::~Alumno() {
    if(nombre!=nullptr) delete nombre;
}

void Alumno::SetTotal(double total) {
    this->total = total;
}

double Alumno::GetTotal() const {
    return total;
}

void Alumno::SetCreditos(double creditos) {
    this->creditos = creditos;
}

double Alumno::GetCreditos() const {
    return creditos;
}

void Alumno::SetEscala(int escala) {
    this->escala = escala;
}

int Alumno::GetEscala() const {
    return escala;
}

void Alumno::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Alumno::GetCodigo() const {
    return codigo;
}

void Alumno::SetNombre(char *cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Alumno::GetNombre(char *cad) const{
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Alumno::lee(ifstream &arch,int cod,char *nomb,int esc,double cred){
    codigo=cod;
    SetNombre(nomb);
    escala=esc;
    creditos=cred;
}

void Alumno::imprime(ofstream &arch,char *lic){
    char cad[100];
    GetNombre(cad);
    arch<<left<<setw(20)<<codigo<<setw(40)<<cad<<right<<setw(3)<<escala
        <<setw(12)<<creditos;
    
    if(lic!=nullptr)
        arch<<setw(12)<<lic<<setw(11)<<total<<endl;
    else
        arch<<setw(23)<<total<<endl;
}