/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Arbol.cpp
 * Author: Ariana
 * 
 * Created on 16 de noviembre de 2024, 07:55 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Arbol.h"

Arbol::Arbol() {
    raiz=nullptr;
}

Arbol::Arbol(const Arbol& orig) {
}

Arbol::~Arbol() {
    if(raiz!=nullptr) delete raiz;
}

void Arbol::insertar(Nodo *nodo){
    raiz=insertar(raiz,nodo->dboleta);
}

Nodo *Arbol::insertar(Nodo *nodo,Boleta &bol){
    if(nodo==nullptr){
        Nodo *nuevoNodo=new Nodo;
        nuevoNodo->dboleta=bol;
        return nuevoNodo;
    }
    
    if(compara(bol,nodo->dboleta)==-1)
        nodo->izq=insertar(nodo->izq,bol);
    else
        if(compara(bol,nodo->dboleta)==1)
            nodo->der=insertar(nodo->der,bol);
        else
            cout<<"El alumno ya está en el árbol"<<endl;
    
    return nodo;
}

int Arbol::compara(Boleta &a,Boleta &b){
    if(a.devolverCodigo()<b.devolverCodigo()) return -1;
    if(a.devolverCodigo()>b.devolverCodigo()) return 1;
    return 0;
}

void Arbol::recorreEnOrden(ofstream &arch){
    recorreEnOrden(arch,raiz);
}

void Arbol::recorreEnOrden(ofstream &arch,Nodo *nodo){
    if(nodo!=nullptr){
        recorreEnOrden(arch,nodo->izq);
        nodo->imprime(arch);
        recorreEnOrden(arch,nodo->der);
    }
}