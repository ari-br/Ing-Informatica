/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Presencial.cpp
 * Author: Ariana
 * 
 * Created on 16 de noviembre de 2024, 07:45 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Presencial.h"

Presencial::Presencial() {
    recargo=0;
    total=0;
}

Presencial::Presencial(const Presencial& orig) {
}

Presencial::~Presencial() {
}

void Presencial::SetTotal(double total) {
    this->total = total;
}

double Presencial::GetTotal() const {
    return total;
}

void Presencial::SetRecargo(double recargo) {
    this->recargo = recargo;
}

double Presencial::GetRecargo() const {
    return recargo;
}

void Presencial::lee(ifstream &arch,int cod,char *nomb,int esc,double cred){
    arch>>recargo;
    Alumno::lee(arch,cod,nomb,esc,cred);
}

void Presencial::imprime(ofstream &arch,char *lic){
    Alumno::imprime(arch,nullptr);
}