/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Presencial.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 07:45 PM
 */

#ifndef PRESENCIAL_H
#define PRESENCIAL_H

#include "Alumno.h"


class Presencial:public Alumno {
public:
    Presencial();
    Presencial(const Presencial& orig);
    virtual ~Presencial();
    void SetTotal(double total);
    double GetTotal() const;
    void SetRecargo(double recargo);
    double GetRecargo() const;
    void lee(ifstream &arch,int cod,char *nomb,int esc,double cred); //Método polimórfico
    void imprime(ofstream &arch,char *lic); //Método polimórfico
private:
    double recargo;
    double total;
};

#endif /* PRESENCIAL_H */

