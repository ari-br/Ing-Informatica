/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Tesoreria.cpp
 * Author: Ariana
 * 
 * Created on 16 de noviembre de 2024, 08:01 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Tesoreria.h"

Tesoreria::Tesoreria() {
}

Tesoreria::Tesoreria(const Tesoreria& orig) {
}

Tesoreria::~Tesoreria() {
}

void Tesoreria::cargaalumnos(){
    ifstream arch("Alumnos.csv",ios::in);
    AperturaIf(arch,"Alumnos.csv");
    
    while(1){
        Nodo *nodo=new Nodo;
        nodo->lee(arch);
        if(arch.eof()) break;
        aboleta.insertar(nodo);
    }
}

void Tesoreria::actualizaboleta(){
    
}

void Tesoreria::imprimeboleta(){
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    
    arch<<setprecision(2)<<fixed;
    arch<<left<<setw(20)<<"Codigo"<<setw(40)<<"Nombre"<<setw(10)<<"Escala"
        <<setw(9)<<"Cred."<<setw(12)<<"Licencia"<<"Total"<<endl;
    imprimirLinea(arch,'=');
    
    aboleta.recorreEnOrden(arch);
}

void Tesoreria::imprimirLinea(ofstream &arch,char c){
    for (int i = 0; i < 100; i++) arch<<c;
    arch<<endl;
}

void Tesoreria::AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void Tesoreria::AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}