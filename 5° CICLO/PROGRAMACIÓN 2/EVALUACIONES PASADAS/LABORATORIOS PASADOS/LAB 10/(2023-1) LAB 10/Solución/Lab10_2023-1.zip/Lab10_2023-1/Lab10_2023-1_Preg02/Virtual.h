/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Virtual.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 07:49 PM
 */

#ifndef VIRTUAL_H
#define VIRTUAL_H

#include "Alumno.h"


class Virtual:public Alumno {
public:
    Virtual();
    Virtual(const Virtual& orig);
    virtual ~Virtual();
    void SetTotal(double total);
    double GetTotal() const;
    void SetLicencia(char *);
    void GetLicencia(char *) const;
    void lee(ifstream &arch,int cod,char *nomb,int esc,double cred); //Método polimórfico
    void imprime(ofstream &arch,char *lic); //Método polimórfico
    void actualizaTotal(double subTotal); //Método polimórfico
private:
    char *licencia;
    double total;
};

#endif /* VIRTUAL_H */

