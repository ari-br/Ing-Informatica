/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Nodo.cpp
 * Author: Ariana
 * 
 * Created on 16 de noviembre de 2024, 07:53 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Nodo.h"

Nodo::Nodo() {
    izq=nullptr;
    der=nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
    if(izq!=nullptr) delete izq;
    if(der!=nullptr) delete der;
}

void Nodo::lee(ifstream &arch){
    dboleta.lee(arch);
}

void Nodo::imprime(ofstream &arch){
    dboleta.imprime(arch);
}

bool Nodo::mismaEscala(int esc){
    return dboleta.mismaEscala(esc);
}

void Nodo::actualiza(double prec){
    dboleta.actualiza(prec);
}
