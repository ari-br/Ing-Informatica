/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 09:35 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Tesoreria.h"
/*
 * 
 */
int main(int argc, char** argv) {
    Tesoreria ABoleta;
    
    ABoleta.cargaalumnos();
    ABoleta.actualizaboleta();
    ABoleta.imprimeboleta();
    
    return 0;
}

