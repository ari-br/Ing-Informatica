/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Alumno.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 07:39 PM
 */

#ifndef ALUMNO_H
#define ALUMNO_H

class Alumno {
public:
    Alumno();
    Alumno(const Alumno& orig);
    virtual ~Alumno();
    void SetTotal(double total);
    double GetTotal() const;
    void SetCreditos(double creditos);
    double GetCreditos() const;
    void SetEscala(int escala);
    int GetEscala() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void SetNombre(char *);
    void GetNombre(char *) const;
    virtual void lee(ifstream &arch,int cod,char *nomb,int esc,double cred); //Método polimórfico
    virtual void imprime(ofstream &arch,char *lic); //Método polimórfico
    virtual void actualizaTotal(double subTotal); //Método polimórfico
private:
    int codigo;
    char *nombre;
    int escala;
    double creditos;
    double total;
};

#endif /* ALUMNO_H */

