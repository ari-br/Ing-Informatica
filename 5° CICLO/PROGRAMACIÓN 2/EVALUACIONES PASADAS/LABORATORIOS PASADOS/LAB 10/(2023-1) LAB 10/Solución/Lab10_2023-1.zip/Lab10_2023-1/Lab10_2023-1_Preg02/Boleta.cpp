/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Boleta.cpp
 * Author: Ariana
 * 
 * Created on 16 de noviembre de 2024, 07:52 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Boleta.h"
#include "Presencial.h"
#include "Semipresencial.h"
#include "Virtual.h"

Boleta::Boleta() {
    pboleta=nullptr;
}

Boleta::Boleta(const Boleta& orig) {
}

Boleta::~Boleta() {
    if(pboleta!=nullptr) delete pboleta;
}

void Boleta::lee(ifstream &arch){
    char tipo,nomb[100],c;
    int cod,esc;
    double cred;
    
    arch>>tipo;
    if(arch.eof()) return;
    arch>>c>>cod>>c;
    arch.getline(nomb,100,',');
    arch>>esc>>c>>cred>>c;
    
    if(tipo=='P') pboleta=new Presencial;
    if(tipo=='S') pboleta=new Semipresencial;
    if(tipo=='V') pboleta=new Virtual;
    
    pboleta->lee(arch,cod,nomb,esc,cred);
}

int Boleta::devolverCodigo(){
    return pboleta->GetCodigo();
}

void Boleta::imprime(ofstream &arch){
    pboleta->imprime(arch,nullptr);
}

bool Boleta::mismaEscala(int esc){
    return pboleta->GetEscala()==esc;
}

void Boleta::actualiza(double prec){
    double subTotal=prec*pboleta->GetCreditos();
    pboleta->actualizaTotal(subTotal);
}