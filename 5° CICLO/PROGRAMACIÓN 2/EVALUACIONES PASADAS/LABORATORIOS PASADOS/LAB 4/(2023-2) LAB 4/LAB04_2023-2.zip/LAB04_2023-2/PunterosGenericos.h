/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   PunterosGenericos.h
 * Author: Ariana
 *
 * Created on 1 de octubre de 2024, 07:09 PM
 */

#ifndef PUNTEROSGENERICOS_H
#define PUNTEROSGENERICOS_H

void cargaproductos(void *&productos);
void *leerProducto(ifstream &arch);
void imprimeproductos(void *productos);
void imprimeRegProd(ofstream &arch,void *productos);

void cargaclientes(void *&clientes);
void *leerCliente(ifstream &arch);
void imprimeclientes(void *clientes);
void imprimeRegCli(ofstream &arch,void *clientes);

void cargapedidos(void *productos,void *&clientes);
char *leerPedido(ifstream &arch,int *&dni,int *&cant);
bool requiereLinea(char *codigo,void *productos,double &precio);
int buscarCliente(int *dni,void *clientes,double total,bool &cuentaLinea);
void *crearRegistro(char *codigo,int *cant,double *total);
void agregarProducto(void *registro,bool reducirLinea,void *&pedidos,
        int &cantPed,void *&clientes,double total);
void cargarPedidosEnClientes(void *&clientes,void **pedidos,int *cantPed);
void cargarPedido(void *&registro,void *pedidos,int cantPed);
void imprimerepfinal(void *clientes);

void imprimereporte(void *clientes);
void imprimeRegistro(ofstream &arch,void *clientes);
void imprimePedidos(ofstream &arch,void *pedidos);


char *leerCadenaExacta(ifstream &arch,int max,char c);
void imprimirLinea(ofstream &arch,int max,char c);
void AperturaIf(ifstream &arch,const char *nomb);
void AperturaOf(ofstream &arch,const char *nomb);

#endif /* PUNTEROSGENERICOS_H */
