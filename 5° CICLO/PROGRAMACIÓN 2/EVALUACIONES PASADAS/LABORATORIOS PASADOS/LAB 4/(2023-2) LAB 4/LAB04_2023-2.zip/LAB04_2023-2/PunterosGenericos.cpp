/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   PunterosGenericos.cpp
 * Author: Ariana
 * 
 * Created on 1 de octubre de 2024, 07:09 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
#include <complex>
using namespace std;
#include "PunterosGenericos.h"

void imprimereporte(void *clientes){
    ofstream arch ("ReporteDePedidos.txt",ios::out);
    AperturaOf(arch,"ReporteDePedidos.txt");
    arch<<fixed<<setprecision(2);
    
    void **lClientes=(void**)clientes;
    for (int i = 0; lClientes[i]; i++){
        imprimirLinea(arch,100,'=');
        arch<<left<<setw(20)<<"DNI"<<setw(55)<<"Nombre"<<"Credito"<<endl;
        imprimeRegistro(arch,lClientes[i]);
        arch<<endl;
    }
}

void imprimeRegistro(ofstream &arch,void *clientes){
    void **lClientes=(void**)clientes;
    int *dni=(int*)lClientes[0];
    char *nombre=(char*)lClientes[1];
    double *linea=(double*)lClientes[3];
    
    arch<<left<<setw(20)<<*dni<<setw(50)<<nombre<<right<<setw(12)<<*linea<<endl;
    imprimirLinea(arch,100,'-');
    arch<<"Pedidos atendidos:"<<endl;
    imprimirLinea(arch,100,'-');
    arch<<left<<setw(10)<<"Codigo"<<setw(10)<<"Cantidad"<<"Total"<<endl;
    imprimirLinea(arch,100,'-');
    imprimePedidos(arch,lClientes[2]);
}

void imprimePedidos(ofstream &arch,void *pedidos){
    void **lpedidos=(void**)pedidos;
    for (int i = 0; lpedidos[i]; i++) {
        void **regPed=(void**)lpedidos[i];
        char *codigo=(char*)regPed[0];
        int *cant=(int*)regPed[1];
        double *total=(double*)regPed[2];
        arch<<left<<setw(10)<<codigo<<setw(10)<<*cant<<*total<<endl;
    }
}

void imprimerepfinal(void *clientes){
    ofstream arch ("ReporteFinal.txt",ios::out);
    AperturaOf(arch,"ReporteFinal.txt");
    arch<<fixed<<setprecision(2);
    
    void **lClientes=(void**)clientes;
    for (int i = 0; lClientes[i]; i++){
        imprimeRegCli(arch,lClientes[i]);
    }
}

void cargapedidos(void *productos,void *&clientes){
    ifstream arch ("Pedidos2.csv",ios::in);
    AperturaIf(arch,"Pedidos2.csv");
    
    char *codigo;
    int *dni,*cant,posCli,cantPed[200]{0};
    double *total,precio;
    void *registro,*pedidos[200];
    while(1){
        bool reducirLinea=false,cuentaLinea=false,agregaProd=true;
        codigo=leerPedido(arch,dni,cant);
        if(arch.eof()) break;
        if(requiereLinea(codigo,productos,precio)) reducirLinea=true;
        total=new double;
        *total=precio*(*cant);
        posCli=buscarCliente(dni,clientes,*total,cuentaLinea);
        registro=crearRegistro(codigo,cant,total);
        if(reducirLinea) if(!cuentaLinea) agregaProd=false;
        void**lclientes=(void**)clientes; 
        if(agregaProd) agregarProducto(registro,reducirLinea,pedidos[posCli],
                cantPed[posCli],lclientes[posCli],*total);
        clientes=lclientes;
    }
    //Cargar pedidos
    cargarPedidosEnClientes(clientes,pedidos,cantPed);
    imprimerepfinal(clientes);
}

void cargarPedidosEnClientes(void *&clientes,void **pedidos,int *cantPed){
    void **lClientes=(void **)clientes;
    for (int i = 0; lClientes[i]; i++) {
        void **registro=(void**)lClientes[i];
        cargarPedido(registro[2],pedidos[i],cantPed[i]);
    }
    clientes=lClientes;
}

void cargarPedido(void *&registro,void *pedidos,int cantPed){
    void**lRegistro=new void*[cantPed+1];
    void**lPedidos=(void**)pedidos;
    for (int i = 0; i < cantPed; i++) lRegistro[i]=lPedidos[i];
    lRegistro[cantPed]=nullptr;
    registro=lRegistro;
}

void agregarProducto(void *registro,bool reducirLinea,void *&pedidos,
        int &cantPed,void *&clientes,double total){
    void **lPedidos=(void**)pedidos;
    if(cantPed==0) lPedidos=new void*[200];
    lPedidos[cantPed]=registro;
    void**lclientes=(void**)clientes;
    double *linea=(double*)lclientes[3];
    if(reducirLinea) *linea-=total;
    pedidos=lPedidos;
    clientes=lclientes;
    cantPed++;
}

void *crearRegistro(char *codigo,int *cant,double *total){
    void **registro;
    registro=new void*[3];
    registro[0]=codigo;
    registro[1]=cant;
    registro[2]=total;
    
    return registro;
}

int buscarCliente(int *dni,void *clientes,double total,bool &cuentaLinea){
    void **lClientes=(void**)clientes;
    
    for (int i = 0; lClientes[i]; i++) {
        void **registro=(void**)lClientes[i];
        int *dniReg=(int*)registro[0];
        if(*dniReg==*dni){
            double *linea=(double*)registro[3];
            cuentaLinea=(*linea)>=total;
            return i;
        }
    }
}

bool requiereLinea(char *codigo,void *productos,double &precio){
    void **lProductos=(void**)productos;
    
    for (int i = 0; lProductos[i]; i++) {
        void **registro=(void**)lProductos[i];
        char *codReg=(char*)registro[0];
        if(strcmp(codigo,codReg)==0){
            char *tipo=(char*)registro[3];
            precio=*(double*)registro[2];
            if(*tipo=='S') return true;
            return false;
        }
    } 
}

char *leerPedido(ifstream &arch,int *&dni,int *&cant){
    char c,*codigo;
    codigo=leerCadenaExacta(arch,10,',');
    if(arch.eof()) return nullptr;
    dni=new int;
    cant=new int;
    arch>>*dni>>c>>*cant;
    arch.get();
    
    return codigo;
}

void imprimeproductos(void *productos){
    ofstream arch ("ReporteProductos.txt",ios::out);
    AperturaOf(arch,"ReporteProductos.txt");
    arch<<fixed<<setprecision(2);
    
    void **lProductos=(void**)productos;
    for (int i = 0; lProductos[i]; i++) {
        imprimeRegProd(arch,lProductos[i]);
    }    
}

void imprimeRegProd(ofstream &arch,void *productos){
    void **lProductos=(void**)productos;
    char *codigo=(char*)lProductos[0];
    char *descripcion=(char*)lProductos[1];
    double *precio=(double*)lProductos[2];
    char *tipo=(char*)lProductos[3];
    
    arch<<left<<setw(12)<<codigo<<setw(60)<<descripcion<<setw(10)<<*precio
        <<*tipo<<endl;
}

void cargaproductos(void *&productos){
    ifstream arch ("Productos2.csv",ios::in);
    AperturaIf(arch,"Productos2.csv");
    
    //1. Declarar buffers
    void *buffer[200],**lProductos;
    //2. Leer archivo
    int i=0;
    while(1){
        buffer[i]=leerProducto(arch);
        if(arch.eof()) break;
        i++;
    }
    //3. Cargar arreglos
    lProductos=new void*[i+1];
    for (int k = 0; k <= i; k++)  lProductos[k]=buffer[k];
    productos=lProductos;
    imprimeproductos(productos);
}

void *leerProducto(ifstream &arch){
    void **registro;
    char *codigo,*descripcion,*tipo,c;
    double *precio;
    
    codigo=leerCadenaExacta(arch,10,',');
    if(arch.eof()) return nullptr;
    descripcion=leerCadenaExacta(arch,100,',');
    precio=new double;
    tipo=new char;
    arch>>*precio>>c>>*tipo;
    arch.get();
    
    registro=new void*[4];
    registro[0]=codigo;
    registro[1]=descripcion;
    registro[2]=precio;
    registro[3]=tipo;
    
    return registro; 
}

void imprimeclientes(void *clientes){
    ofstream arch ("ReporteClientes.txt",ios::out);
    AperturaOf(arch,"ReporteClientes.txt");
    arch<<fixed<<setprecision(2);
    
    void **lClientes=(void**)clientes;
    for (int i = 0; lClientes[i]; i++) {
        imprimeRegCli(arch,lClientes[i]);
    }
}

void imprimeRegCli(ofstream &arch,void *clientes){
    void **lClientes=(void**)clientes;
    int *dni=(int*)lClientes[0];
    char *nombre=(char*)lClientes[1];
    double *linea=(double*)lClientes[3];
    
    arch<<left<<setw(12)<<*dni<<setw(50)<<nombre<<*linea<<endl;
}

void cargaclientes(void *&clientes){
    ifstream arch ("Clientes2.csv",ios::in);
    AperturaIf(arch,"Clientes2.csv");
    
    //1. Declarar buffers
    void *buffer[200],**lClientes;
    //2. Leer archivo
    int i=0;
    while(1){
        buffer[i]=leerCliente(arch);
        if(arch.eof()) break;
        i++;
    }
    //3. Cargar arreglos
    lClientes=new void*[i];
    for (int k = 0; k <= i; k++) lClientes[k]=buffer[k];
    clientes=lClientes;
    imprimeclientes(clientes);
}

void *leerCliente(ifstream &arch){
    void **registro;
    int *dni,telefono;
    double *linea;
    char *nombre,c;
    
    dni=new int;
    arch>>*dni>>c;
    if(arch.eof()) return nullptr;
    nombre=leerCadenaExacta(arch,100,',');
    linea=new double;
    arch>>telefono>>c>>*linea;
    
    registro=new void*[4];
    registro[0]=dni;
    registro[1]=nombre;
    registro[2]=nullptr;
    registro[3]=linea;
    
    return registro;
}


char *leerCadenaExacta(ifstream &arch,int max,char c){
    char *pt,buffer[200];
    arch.getline(buffer,max,c);
    if(arch.eof()) return nullptr;
    pt=new char[strlen(buffer)+1];
    strcpy(pt,buffer);
    return pt;
}

void imprimirLinea(ofstream &arch,int max,char c){
    for (int i = 0; i < max; i++) arch<<c;
    arch<<endl;
}

void AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}