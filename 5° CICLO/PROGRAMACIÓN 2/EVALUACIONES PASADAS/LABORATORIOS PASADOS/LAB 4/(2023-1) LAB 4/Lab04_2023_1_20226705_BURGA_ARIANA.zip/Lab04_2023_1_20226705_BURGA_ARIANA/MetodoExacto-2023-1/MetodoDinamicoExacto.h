/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   MetodoDinamicoExacto.h
 * Author: Ariana Burga
 * Código: 20226705
 * Created on 13 de septiembre de 2024, 00:36 AM
 */

#ifndef METODODINAMICOEXACTO_H
#define METODODINAMICOEXACTO_H

void lecturaAlumnos(const char *nomb,int *&alumno_Codigo,char **&alumno_Nombre,
        char *&alumno_Modalidad,int *&alumno_Porcentaje,int *&alumno_Escala);
char *leerAlumno(ifstream &arch,int &cod,int &porc,int &esc,char &mod);
void cargarArreglos(int *&alumno_Codigo,char **&alumno_Nombre,
        char *&alumno_Modalidad,int *&alumno_Porcentaje,int *&alumno_Escala,
        int *buffCod,char **buffNomb,char *buffMod,int *buffPorc,
        int *buffEsc,int cantAlum);

void pruebaLecturaAlumnos(const char *nomb,int *alumno_Codigo,
        char **alumno_Nombre,char *alumno_Modalidad,int *alumno_Porcentaje,
        int *alumno_Escala);
void imprimirModalidad(ofstream &arch,char mod,int porc);

void lecturaCursos(const char *nomb,int *alumno_Codigo,int *alumno_Escala,
        char **&curso_Nombre,double *&curso_Credito,int **&curso_Alumnos);
void completarBuffers(int codAlum,char *nombCur,double cred,char **buffNomb,
        double *buffCred,int **buffCurAlum,int *alumno_Codigo,
        int *alumno_Escala,int &cantCur,int *cantAlumCur);
int buscarCurso(char *nombCur,char **buffNomb,int cantCur);
int buscarAlumno(int codAlum,int *alumno_Codigo);
void cargarArreglos(char **&curso_Nombre,double *&curso_Credito,
        int **&curso_Alumnos,char **buffNomb,double *buffCred,int **buffCurAlum,
        int cantCur,int *cantAlumCur);
void completarAlumnosPorCurso(int *curso_Alumnos,int *buffCurAlum,int cantAlum);

void pruebaDeLecturaCursos(const char *nomb,char **curso_Nombre,
        double *curso_Credito,int **curso_Alumnos);
void imprimirAlumnos(ofstream &arch,int *curso_Alumnos);

void reporteDeRecaudacionPorModalidad(const char *nomb,int *alumno_Codigo,
        char *alumno_Modalidad,int *alumno_Porcentaje,char **alumno_Nombre,
        int *alumno_Escala,char **curso_Nombre,double *curso_Credito,
        int **curso_Alumnos);
void imprimirEncCurso(ofstream &arch,char *nombre,double cred);
void imprimirAlumnosPorCurso(ofstream &arch,int *curso_Alumnos,
        int *alumno_Codigo,char *alumno_Modalidad,int *alumno_Porcentaje,
        char **alumno_Nombre,int *alumno_Escala,double &totalRepPres,
        double &totalRepSem,double &totalRepVir,double cred);
void imprimirPagos(ofstream &arch,char mod,int porc,int esc,double cred,
        double &totalPres,double &totalSem,double &totalVir);
void leerEscalas(double *escalas);
void imprimirResumen(ofstream &arch,double totalRepPres,double totalRepSem,
        double totalRepVir,double totalRepRec);

void imprimirNro(ofstream &arch,int i);
char *leerCadenaExacta(ifstream &arch,int max,char c);
void imprimirLinea(ofstream &arch,int max,char c);
void AperturaIf(ifstream &arch,const char *nomb);
void AperturaOf(ofstream &arch,const char *nomb);

#endif /* METODODINAMICOEXACTO_H */
