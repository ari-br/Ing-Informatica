/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   MetodoDinamicoExacto.cpp
 * Author: Ariana Burga
 * Código: 20226705
 * Created on 13 de septiembre de 2024, 00:36 AM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "MetodoDinamicoExacto.h"
#define NO_ENCONTRADO -1

void reporteDeRecaudacionPorModalidad(const char *nomb,int *alumno_Codigo,
        char *alumno_Modalidad,int *alumno_Porcentaje,char **alumno_Nombre,
        int *alumno_Escala,char **curso_Nombre,double *curso_Credito,
        int **curso_Alumnos){
    ofstream arch(nomb,ios::out);
    AperturaOf(arch,nomb);
    double totalRepPres=0,totalRepSem=0,totalRepVir=0,totalRepRec=0;
    arch<<fixed<<setprecision(2);
    arch<<right<<setw(60)<<"ENTIDAD EDUCATIVA LP1"<<endl;
    arch<<right<<setw(58)<<"LISTADOS DE CLASE"<<endl;
    for (int i = 0; curso_Nombre[i]!=nullptr; i++) {
        imprimirLinea(arch,110,'=');
        imprimirNro(arch,i+1);
        imprimirEncCurso(arch,curso_Nombre[i],curso_Credito[i]);
        imprimirAlumnosPorCurso(arch,curso_Alumnos[i],alumno_Codigo,
            alumno_Modalidad,alumno_Porcentaje,alumno_Nombre,alumno_Escala,
            totalRepPres,totalRepSem,totalRepVir,curso_Credito[i]);
    }
    imprimirResumen(arch,totalRepPres,totalRepSem,totalRepVir,totalRepRec);
}

void imprimirResumen(ofstream &arch,double totalRepPres,double totalRepSem,
        double totalRepVir,double totalRepRec){
    imprimirLinea(arch,110,'=');
    arch<<"RECAUDACIÓN TOTAL POR MODALIDAD DE ESTUDIO:"<<right<<setw(30)
            <<totalRepPres<<setw(20)<<totalRepSem<<setw(12)<<totalRepVir<<endl;
    imprimirLinea(arch,110,'-');    
    totalRepRec+=totalRepPres+totalRepSem+totalRepVir;
    arch<<"TOTAL GENERAL RECAUDADO:"<<right<<setw(81)<<totalRepRec<<endl;
    imprimirLinea(arch,110,'=');
}

void imprimirAlumnosPorCurso(ofstream &arch,int *curso_Alumnos,
        int *alumno_Codigo,char *alumno_Modalidad,int *alumno_Porcentaje,
        char **alumno_Nombre,int *alumno_Escala,double &totalRepPres,
        double &totalRepSem,double &totalRepVir,double cred){
    int posAlum;
    double totalPres=0,totalSem=0,totalVir=0;
    for (int i = 0; curso_Alumnos[2*i]!=0; i++) {
        imprimirNro(arch,i+1);
        arch<<left<<setw(6)<<curso_Alumnos[2*i]<<setw(44);
        posAlum=buscarAlumno(curso_Alumnos[2*i],alumno_Codigo);
        arch<<alumno_Nombre[posAlum]<<curso_Alumnos[(2*i)+1];
        imprimirPagos(arch,alumno_Modalidad[posAlum],alumno_Porcentaje[posAlum],
                alumno_Escala[posAlum],cred,totalPres,totalSem,totalVir);
        arch<<endl;
    }
    imprimirLinea(arch,110,'=');
    arch<<"RECAUDACIÓN POR MODALIDAD DE ESTUDIO:"<<right<<setw(36)
            <<totalPres<<setw(20)<<totalSem<<setw(12)<<totalRepVir<<endl;
    imprimirLinea(arch,110,'-');
    arch<<"TOTAL GENERAL RECAUDADO:"<<right<<setw(81)<<totalPres+totalSem
            +totalVir<<endl;
    totalRepPres+=totalPres;
    totalRepSem+=totalSem;
    totalRepVir+=totalVir;
}

void imprimirPagos(ofstream &arch,char mod,int porc,int esc,double cred,
        double &totalPres,double &totalSem,double &totalVir){
    double escalas[6];
    leerEscalas(escalas);
    double pago;
    if(mod=='V'){
        pago=escalas[esc-1]*cred;
        arch<<right<<setw(49)<<pago;
        totalVir+=pago;
    }else{
        if(mod=='S'){
            pago=escalas[esc-1]*cred*porc/100;
            arch<<right<<setw(37)<<pago;
            totalSem+=pago;
        }else{
            pago=escalas[esc-1]*cred;
            arch<<right<<setw(17)<<pago;
            totalPres+=pago;
        }
    }
}

void leerEscalas(double *escalas){
    ifstream arch("escalas.csv",ios::in);
    AperturaIf(arch,"escalas.csv");
    char esc[3];
    int i=4;
    while(1){
        arch.getline(esc,3,',');
        if(arch.eof()) break;
        arch>>escalas[i];
        arch.get();
        i--;
    }
}

void imprimirEncCurso(ofstream &arch,char *nombre,double cred){
    arch<<left<<setw(8)<<" "<<setw(20)<<"Curso:"<<setw(50)<<nombre
        <<"Creditos:"<<right<<setw(5)<<cred<<endl;
    imprimirLinea(arch,110,'-');
    arch<<"ALUMNOS Matriculados"<<endl;
    imprimirLinea(arch,110,'-');
    arch<<right<<setw(85)<<"PAGOS"<<endl;
    arch<<left<<setw(3)<<" "<<setw(10)<<"CODIGO"<<setw(40)<<"NOMBRE"<<setw(10)
        <<"ESCALA"<<setw(15)<<"PRESENCIAL"<<setw(20)<<"SEMI PRESENCIAL"
        <<"VIRTUAL"<<endl;
    imprimirLinea(arch,110,'-');
}

void pruebaDeLecturaCursos(const char *nomb,char **curso_Nombre,
        double *curso_Credito,int **curso_Alumnos){
    ofstream arch(nomb,ios::out);
    AperturaOf(arch,nomb);
    arch<<fixed<<setprecision(2);
    for (int i = 0; curso_Nombre[i]!=nullptr; i++) {
        imprimirLinea(arch,100,'=');
        imprimirNro(arch,i+1);
        arch<<left<<setw(8)<<" "<<setw(20)<<"Curso:"<<setw(50)<<curso_Nombre[i]
            <<"Creditos:"<<right<<setw(5)<<curso_Credito[i]<<endl;
        imprimirLinea(arch,100,'-');
        arch<<"ALUMNOS Matriculados"<<endl;
        imprimirLinea(arch,100,'-');
        imprimirAlumnos(arch,curso_Alumnos[i]);
        arch<<endl;
    }    
}

void imprimirAlumnos(ofstream &arch,int *curso_Alumnos){    
    for (int i = 0; curso_Alumnos[2*i]!=0; i++) {
        arch<<left<<setw(6)<<curso_Alumnos[2*i]<<curso_Alumnos[(2*i)+1]<<endl;
    }
}

void lecturaCursos(const char *nomb,int *alumno_Codigo,int *alumno_Escala,
        char **&curso_Nombre,double *&curso_Credito,int **&curso_Alumnos){
    ifstream arch(nomb,ios::in);
    AperturaIf(arch,nomb);
    //1. Declarar buffers
    char *buffNomb[150]{},c,*nombCur;
    double buffCred[150]{},cred;
    int *buffCurAlum[150]{},cantCur=0,cantAlumCur[150]{},codAlum;
    //2. Leer archivo
    while(1){
        arch>>codAlum>>c;
        if(arch.eof()) break;
        nombCur=leerCadenaExacta(arch,100,',');
        arch>>cred;
        completarBuffers(codAlum,nombCur,cred,buffNomb,buffCred,buffCurAlum,
            alumno_Codigo,alumno_Escala,cantCur,cantAlumCur);
    }
    //3. Cargar arreglos
    cargarArreglos(curso_Nombre,curso_Credito,curso_Alumnos,buffNomb,
            buffCred,buffCurAlum,cantCur,cantAlumCur);    
}

void cargarArreglos(char **&curso_Nombre,double *&curso_Credito,
        int **&curso_Alumnos,char **buffNomb,double *buffCred,int **buffCurAlum,
        int cantCur,int *cantAlumCur){
    curso_Nombre=new char*[cantCur+1];
    curso_Credito=new double[cantCur];
    curso_Alumnos=new int*[cantCur];
    for (int i = 0; i < cantCur; i++) {
        curso_Nombre[i]=buffNomb[i];
        curso_Credito[i]=buffCred[i];
        curso_Alumnos[i]=new int[(cantAlumCur[i]*2)+1];
        completarAlumnosPorCurso(curso_Alumnos[i],buffCurAlum[i],cantAlumCur[i]);
    }
    curso_Nombre[cantCur]=nullptr;
}

void completarAlumnosPorCurso(int *curso_Alumnos,int *buffCurAlum,int cantAlum){
    for (int i = 0; i < cantAlum; i++) {
        curso_Alumnos[2*i]=buffCurAlum[2*i];
        curso_Alumnos[(2*i)+1]=buffCurAlum[(2*i)+1];
    }
    curso_Alumnos[2*cantAlum]=0;
}

void completarBuffers(int codAlum,char *nombCur,double cred,char **buffNomb,
        double *buffCred,int **buffCurAlum,int *alumno_Codigo,
        int *alumno_Escala,int &cantCur,int *cantAlumCur){
    int posCur,*auxAlum,posAlumno;
    posCur=buscarCurso(nombCur,buffNomb,cantCur);
    if(posCur==NO_ENCONTRADO){
        buffNomb[cantCur]=nombCur;
        buffCred[cantCur]=cred;
        buffCurAlum[cantCur]=new int[150];
        posCur=cantCur;
        cantCur++;
    }
    posAlumno=buscarAlumno(codAlum,alumno_Codigo);
    auxAlum=buffCurAlum[posCur];
    auxAlum[cantAlumCur[posCur]*2]=codAlum;
    auxAlum[(cantAlumCur[posCur]*2)+1]=alumno_Escala[posAlumno];
    cantAlumCur[posCur]++;
}

int buscarAlumno(int codAlum,int *alumno_Codigo){
    for (int i = 0; alumno_Codigo[i]!=0; i++) {
        if(alumno_Codigo[i]==codAlum) return i;
    }
}

int buscarCurso(char *nombCur,char **buffNomb,int cantCur){
    for (int i = 0; i < cantCur; i++) {
        if(strcmp(nombCur,buffNomb[i])==0) return i;
    }

    return NO_ENCONTRADO;
}

void pruebaLecturaAlumnos(const char *nomb,int *alumno_Codigo,
        char **alumno_Nombre,char *alumno_Modalidad,int *alumno_Porcentaje,
        int *alumno_Escala){
    ofstream arch(nomb,ios::out);
    AperturaOf(arch,nomb);
    arch<<fixed<<setprecision(2);
    arch<<left<<setw(3)<<" "<<setw(10)<<"CODIGO"<<setw(40)<<"NOMBRE"<<setw(10)
        <<"ESCALA"<<setw(15)<<"MODALIDAD"<<endl;
    imprimirLinea(arch,75,'-');
    for (int i = 0; alumno_Codigo[i]!=0; i++) {
        imprimirNro(arch,i+1);
        arch<<left<<setw(7)<<alumno_Codigo[i]<<setw(42)<<alumno_Nombre[i]<<right
            <<setw(3)<<alumno_Escala[i]<<setw(11);
        imprimirModalidad(arch,alumno_Modalidad[i],alumno_Porcentaje[i]);
        arch<<endl;
    }
}

void imprimirModalidad(ofstream &arch,char mod,int porc){
    if(mod!='V' && mod!='S'){
        mod='P';
    }
    arch<<mod;
    if(mod=='S') arch<<setw(6)<<porc<<" (PORCENTAJE)";
}

void imprimirNro(ofstream &arch,int i){
    arch<<right<<setfill('0')<<setw(2)<<i<<setfill(' ')<<left<<setw(3)<<")";
}


void lecturaAlumnos(const char *nomb,int *&alumno_Codigo,char **&alumno_Nombre,
        char *&alumno_Modalidad,int *&alumno_Porcentaje,int *&alumno_Escala){
    ifstream arch(nomb,ios::in);
    AperturaIf(arch,nomb);
    //1. Declarar buffers
    int buffCod[100]{},buffPorc[100]{},buffEsc[100]{},cantAlum=0;
    char buffMod[100]{},*buffNomb[100]{};
    //2. Leer archivo
    while(1){
        buffNomb[cantAlum]=leerAlumno(arch,buffCod[cantAlum],buffPorc[cantAlum],
                buffEsc[cantAlum],buffMod[cantAlum]);
        if(arch.eof()) break;
        cantAlum++;
    }
    //3. Cargar arreglos
    cargarArreglos(alumno_Codigo,alumno_Nombre,alumno_Modalidad,
            alumno_Porcentaje,alumno_Escala,buffCod,buffNomb,buffMod,buffPorc,
            buffEsc,cantAlum);
}

void cargarArreglos(int *&alumno_Codigo,char **&alumno_Nombre,
        char *&alumno_Modalidad,int *&alumno_Porcentaje,int *&alumno_Escala,
        int *buffCod,char **buffNomb,char *buffMod,int *buffPorc,
        int *buffEsc,int cantAlum){
    alumno_Codigo=new int[cantAlum+1];
    alumno_Nombre=new char *[cantAlum+1];
    alumno_Modalidad=new char[cantAlum];
    alumno_Porcentaje=new int[cantAlum];
    alumno_Escala=new int[cantAlum];
    for (int i = 0; i < cantAlum; i++) {
        alumno_Codigo[i]=buffCod[i];
        alumno_Nombre[i]=buffNomb[i];
        alumno_Modalidad[i]=buffMod[i];
        alumno_Porcentaje[i]=buffPorc[i];
        alumno_Escala[i]=buffEsc[i];
    }
    alumno_Codigo[cantAlum]=0;
    alumno_Nombre[cantAlum]=nullptr;    
}

char *leerAlumno(ifstream &arch,int &cod,int &porc,int &esc,char &mod){
    char *nomb,c;
    arch>>cod>>c;
    if(arch.eof()) return nullptr;
    nomb=leerCadenaExacta(arch,150,',');
    arch>>mod;
    esc=0;
    if(mod=='V'){
        arch>>c>>esc;
    }else{
        if(mod=='S'){
            arch>>c>>porc>>c>>esc;
        }else{
            esc=mod-48;//Código ASCII
            mod=0;
        }
    }
    return nomb;
}

char *leerCadenaExacta(ifstream &arch,int max,char c){
    char *pt,buffer[150];
    arch.getline(buffer,max,c);
    if(arch.eof()) return nullptr;
    pt=new char[strlen(buffer)+1];
    strcpy(pt,buffer);
    return pt;
}

void imprimirLinea(ofstream &arch,int max,char c){
    for (int i = 0; i < max; i++) arch<<c;
    arch<<endl;
}

void AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}