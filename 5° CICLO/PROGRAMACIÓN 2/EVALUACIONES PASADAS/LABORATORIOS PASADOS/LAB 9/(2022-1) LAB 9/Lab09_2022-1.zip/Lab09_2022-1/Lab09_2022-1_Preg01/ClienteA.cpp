/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   ClienteA.cpp
 * Author: Ariana
 * 
 * Created on 11 de noviembre de 2024, 07:32 PM
 */

#include "ClienteA.h"

ClienteA::ClienteA() {
    descuento=0;
}

ClienteA::ClienteA(const ClienteA& orig) {
}

ClienteA::~ClienteA() {
}

void ClienteA::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double ClienteA::GetDescuento() const {
    return descuento;
}

void ClienteA::lee(ifstream &arch,char cat){
    char c;
    arch>>descuento>>c;
    Cliente::lee(arch,cat);
}

void ClienteA::imprime(ofstream &arch,double desc,double flet){
    Cliente::imprime(arch,descuento,0);
}