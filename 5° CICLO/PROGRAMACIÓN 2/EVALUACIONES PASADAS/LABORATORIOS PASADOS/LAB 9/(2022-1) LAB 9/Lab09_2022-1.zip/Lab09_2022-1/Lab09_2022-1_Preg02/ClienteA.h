/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   ClienteA.h
 * Author: Ariana
 *
 * Created on 11 de noviembre de 2024, 07:32 PM
 */

#ifndef CLIENTEA_H
#define CLIENTEA_H

#include "Cliente.h"


class ClienteA:public Cliente {
public:
    ClienteA();
    ClienteA(const ClienteA& orig);
    virtual ~ClienteA();
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void lee(ifstream &,char); //Método polimórfico
    void imprime(ofstream &,double,double); //Método polimórfico
    void calcula(double); //Método polimórfico
private:
    double descuento;
};

#endif /* CLIENTEA_H */

