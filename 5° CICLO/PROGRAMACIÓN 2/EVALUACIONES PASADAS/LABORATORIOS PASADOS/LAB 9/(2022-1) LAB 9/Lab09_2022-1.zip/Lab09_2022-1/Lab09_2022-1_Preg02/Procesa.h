/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Procesa.h
 * Author: Ariana
 *
 * Created on 11 de noviembre de 2024, 07:40 PM
 */

#ifndef PROCESA_H
#define PROCESA_H

#include "Pedido.h"
#include "Deudor.h"


class Procesa {
public:
    Procesa();
    Procesa(const Procesa& orig);
    virtual ~Procesa();
    void carga();
    void actualiza();
    void muestra();
private:
    Pedido lpedidos[200];
    Deudor ldeudor[25];
    void cargaPedidos();
    void cargaClientes();
    void imprimeLinea(ofstream &arch,char c);
    void AperturaIf(ifstream &arch,const char *nomb);
    void AperturaOf(ofstream &arch,const char *nomb);
};

#endif /* PROCESA_H */

