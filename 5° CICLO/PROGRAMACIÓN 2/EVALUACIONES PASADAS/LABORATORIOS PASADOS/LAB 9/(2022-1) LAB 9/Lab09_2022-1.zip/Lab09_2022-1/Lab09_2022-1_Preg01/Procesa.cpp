/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Procesa.cpp
 * Author: Ariana
 * 
 * Created on 11 de noviembre de 2024, 07:40 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Procesa.h"

Procesa::Procesa() {
}

Procesa::Procesa(const Procesa& orig) {
}

Procesa::~Procesa() {
}

void Procesa::carga(){
    //Pedidos
    cargaPedidos();
    //Clientes
    cargaClientes();
}

void Procesa::cargaPedidos(){
    ifstream arch("pedidos4.csv",ios::in);
    AperturaIf(arch,"pedidos4.csv");
    
    for (int i = 0; 1; i++) {
        arch>>lpedidos[i];
        if(arch.eof()) break;
    }
}

void Procesa::cargaClientes(){
    ifstream arch("clientes3.csv",ios::in);
    AperturaIf(arch,"clientes3.csv");
    
    for (int i = 0; 1; i++) {
        ldeudor[i].lee(arch);
        if(arch.eof()) break;
    }
}

void Procesa::muestra(){
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    
    arch<<right<<setw(48)<<"REPORTE DE DEUDAS"<<endl;
    imprimeLinea(arch,'=');
    
    for (int i = 0; ldeudor[i].existe(); i++) {
        ldeudor[i].imprime(arch);
        arch<<endl;
    }
}

void Procesa::imprimeLinea(ofstream &arch,char c){
    for (int i = 0; i < 80; i++) arch<<c;
    arch<<endl;
}

void Procesa::AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void Procesa::AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}