/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Deudor.h
 * Author: Ariana
 *
 * Created on 11 de noviembre de 2024, 07:38 PM
 */

#ifndef DEUDOR_H
#define DEUDOR_H

#include "Cliente.h"


class Deudor {
public:
    Deudor();
    Deudor(const Deudor& orig);
    virtual ~Deudor();
    void lee(ifstream &);
    bool existe();
    void imprime(ofstream &);
private:
    Cliente *Cdeudor;
};

#endif /* DEUDOR_H */

