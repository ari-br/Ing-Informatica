/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Deudor.cpp
 * Author: Ariana
 * 
 * Created on 11 de noviembre de 2024, 07:38 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
using namespace std;
#include "Deudor.h"
#include "ClienteA.h"
#include "ClienteB.h"
#include "ClienteC.h"

Deudor::Deudor() {
    Cdeudor=nullptr;
}

Deudor::Deudor(const Deudor& orig) {
}

Deudor::~Deudor() {
    if(Cdeudor!=nullptr) delete Cdeudor;
}

void Deudor::lee(ifstream &arch){
    char c,cat; //categoría
    
    arch>>cat;
    if(arch.eof()) return;
    arch>>c;
    if(cat=='A') Cdeudor=new ClienteA;
    if(cat=='B') Cdeudor=new ClienteB;
    if(cat=='C') Cdeudor=new ClienteC;
    
    Cdeudor->lee(arch,cat);
}

bool Deudor::existe(){
    return Cdeudor!=nullptr;
}

void Deudor::imprime(ofstream &arch){
    Cdeudor->imprime(arch,0,0);
}

int Deudor::devolverDni(){
    return Cdeudor->GetDni();
}

void Deudor::actualiza(double total){
    Cdeudor->calcula(total);
}