/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Cliente.h
 * Author: Ariana
 *
 * Created on 11 de noviembre de 2024, 07:18 PM
 */

#ifndef CLIENTE_H
#define CLIENTE_H

#include <fstream>
#include <iostream>
#include <iomanip>
using namespace std;

class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    void SetTotalped(double totalped);
    double GetTotalped() const;
    void SetCantped(int cantped);
    int GetCantped() const;
    void SetCategoria(char categoria);
    char GetCategoria() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetNombre(char *);
    void GetNombre(char *) const;
    virtual void lee(ifstream &,char); //Método polimórfico
    virtual void imprime(ofstream &,double,double); //Método polimórfico
    virtual void calcula(double); //Método polimórfico
private:
    int dni;
    char categoria;
    char *nombre;
    int cantped;
    double totalped;
    void imprimeLinea(ofstream &arch,char c);
};

#endif /* CLIENTE_H */

