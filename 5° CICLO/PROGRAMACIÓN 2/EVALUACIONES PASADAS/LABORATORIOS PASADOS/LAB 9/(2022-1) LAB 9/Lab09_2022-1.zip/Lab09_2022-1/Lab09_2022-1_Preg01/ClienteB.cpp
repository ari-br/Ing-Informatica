/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   ClienteB.cpp
 * Author: Ariana
 * 
 * Created on 11 de noviembre de 2024, 07:33 PM
 */

#include "ClienteB.h"

ClienteB::ClienteB() {
    descuento=0;
    flete=0;
}

ClienteB::ClienteB(const ClienteB& orig) {
}

ClienteB::~ClienteB() {
}

void ClienteB::SetFlete(double flete) {
    this->flete = flete;
}

double ClienteB::GetFlete() const {
    return flete;
}

void ClienteB::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double ClienteB::GetDescuento() const {
    return descuento;
}

void ClienteB::lee(ifstream &arch,char cat){
    char c;
    arch>>descuento>>c>>flete>>c;
    Cliente::lee(arch,cat);
}

void ClienteB::imprime(ofstream &arch,double desc,double flet){
    Cliente::imprime(arch,descuento,flete);
}