/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   ClienteC.cpp
 * Author: Ariana
 * 
 * Created on 11 de noviembre de 2024, 07:34 PM
 */

#include "ClienteC.h"

ClienteC::ClienteC() {
    flete=0;
}

ClienteC::ClienteC(const ClienteC& orig) {
}

ClienteC::~ClienteC() {
}

void ClienteC::SetFlete(double flete) {
    this->flete = flete;
}

double ClienteC::GetFlete() const {
    return flete;
}

void ClienteC::lee(ifstream &arch,char cat){
    char c;
    arch>>flete>>c;
    Cliente::lee(arch,cat);
}

void ClienteC::imprime(ofstream &arch,double desc,double flet){
    Cliente::imprime(arch,0,flete);
}

void ClienteC::calcula(double total){
    cout<<total<<endl;
    total+=(total*(flete/100));
    Cliente::calcula(total);
}