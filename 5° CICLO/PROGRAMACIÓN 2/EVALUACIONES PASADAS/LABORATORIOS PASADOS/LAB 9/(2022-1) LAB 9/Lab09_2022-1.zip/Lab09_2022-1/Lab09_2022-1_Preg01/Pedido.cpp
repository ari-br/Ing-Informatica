/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Pedido.cpp
 * Author: Ariana
 * 
 * Created on 11 de noviembre de 2024, 07:37 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Pedido.h"

Pedido::Pedido() {
    codigo=0;
    cantidad=0;
    dni=0;
    fecha=0;
    total=0;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
}

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

ifstream &operator >>(ifstream &arch,Pedido &f){
    int codigo,cant,dni,dd,mm,aa,fecha;
    double total;
    char c;
    arch>>codigo>>c;
    if(!arch.eof()){
        f.SetCodigo(codigo);
        arch>>cant>>c>>total>>c>>dni>>c>>dd>>c>>mm>>c>>aa;
        f.SetCantidad(cant);
        f.SetTotal(total);
        f.SetDni(dni);
        fecha=(aa*10000)+(mm*100)+dd;
        f.SetFecha(fecha);
    }
    return arch;
}