/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Cliente.cpp
 * Author: Ariana
 * 
 * Created on 11 de noviembre de 2024, 07:18 PM
 */

#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
using namespace std;
#include "Cliente.h"

Cliente::Cliente() {
    dni=0;
    nombre=nullptr;
    cantped=0;
    totalped=0;
}

Cliente::Cliente(const Cliente& orig) {
}

Cliente::~Cliente() {
    if(nombre!=nullptr) delete nombre;
}

void Cliente::SetTotalped(double totalped) {
    this->totalped = totalped;
}

double Cliente::GetTotalped() const {
    return totalped;
}

void Cliente::SetCantped(int cantped) {
    this->cantped = cantped;
}

int Cliente::GetCantped() const {
    return cantped;
}

void Cliente::SetCategoria(char categoria) {
    this->categoria = categoria;
}

char Cliente::GetCategoria() const {
    return categoria;
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

void Cliente::SetNombre(char *cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Cliente::GetNombre(char *cad) const{
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Cliente::lee(ifstream &arch,char cat){
    char c,cad[100];
    arch>>dni>>c;
    arch.getline(cad,100);
    SetNombre(cad);
    categoria=cat;
}

void Cliente::imprime(ofstream &arch,double desc,double flet){
    char cad[100];
    GetNombre(cad);
    arch<<left<<setw(10)<<dni<<cad<<endl;
    imprimeLinea(arch,'-');
    
    if(categoria=='A')
        arch<<"Descuento: "<<desc<<"%"<<endl;
    if(categoria=='B')
        arch<<"Descuento: "<<desc<<left<<setw(4)<<"%"<<"Flete: "<<flet<<"%"<<endl;
    if(categoria=='C')
        arch<<"Flete: "<<flet<<"%"<<endl;
    
    arch<<"Total: "<<totalped<<endl;
    arch<<"Cantidad de Pedidos: "<<cantped<<endl;
}

void Cliente::calcula(double total){
    totalped+=total;
    cantped++;
}

void Cliente::imprimeLinea(ofstream &arch,char c){
    for (int i = 0; i < 60; i++) arch<<c;
    arch<<endl;
}