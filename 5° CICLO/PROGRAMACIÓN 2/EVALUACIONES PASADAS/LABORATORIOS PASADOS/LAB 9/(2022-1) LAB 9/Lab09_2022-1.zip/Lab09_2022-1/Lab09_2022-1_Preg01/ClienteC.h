/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   ClienteC.h
 * Author: Ariana
 *
 * Created on 11 de noviembre de 2024, 07:34 PM
 */

#ifndef CLIENTEC_H
#define CLIENTEC_H

#include "Cliente.h"


class ClienteC:public Cliente {
public:
    ClienteC();
    ClienteC(const ClienteC& orig);
    virtual ~ClienteC();
    void SetFlete(double flete);
    double GetFlete() const;
    void lee(ifstream &,char); //Método polimórfico
    void imprime(ofstream &,double,double); //Método polimórfico
private:
    double flete;
};

#endif /* CLIENTEC_H */

