/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   PlatoFondo.h
 * Author: roxan
 *
 * Created on 15 de noviembre de 2024, 08:02 PM
 */

#ifndef PLATOFONDO_H
#define PLATOFONDO_H

#include "Producto.h"


class PlatoFondo:public Producto {
public:
    PlatoFondo();
    PlatoFondo(const PlatoFondo& orig);
    virtual ~PlatoFondo();
    
    void lee(ifstream &);
    void imprime(ofstream &);
    void actualiza(int &,double &);
    
private:
    
    int *proteina;

};

#endif /* PLATOFONDO_H */

