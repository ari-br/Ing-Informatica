/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   PlatoFondo.cpp
 * Author: roxan
 * 
 * Created on 15 de noviembre de 2024, 08:02 PM
 */

#include "PlatoFondo.h"

PlatoFondo::PlatoFondo() {
    
    proteina = nullptr;
}

PlatoFondo::PlatoFondo(const PlatoFondo& orig) {
}

PlatoFondo::~PlatoFondo() {
}

void PlatoFondo::lee(ifstream& arch){
    
    Producto::lee(arch);
    if(proteina==nullptr){
        proteina = new int[4];
    }
    int estado;
    char c;
    arch>>estado>>c;
    proteina[0]=estado;
    arch>>estado>>c;
    proteina[1]=estado;
    arch>>estado>>c;
    proteina[2]=estado;
    arch>>estado;
    proteina[3]=estado;
    
    
    
}

void PlatoFondo::imprime(ofstream& arch){
    
    Producto::imprime(arch);
    arch<<"Proteinas: [ ";
    for(int i=0;i<4;i++){
        if(proteina[i]){
            
            if(i==0){
                arch<<" Pollo ";
            }else if(i==1){
                arch<<" Carne ";
            }else if(i==2){
                arch<<" Pescado ";
            }else{
                arch<<" Lacteos ";
            }
            
        }
    }
    
    arch<<" ]"<<endl<<endl;
    
}

void PlatoFondo::actualiza(int &tiempoPrep,double &precioPrep){
    
    Producto::actualiza(tiempoPrep,precioPrep);
    tiempoPrep=20;
    
}

