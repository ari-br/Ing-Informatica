
#include <cstring>

#include "Producto.h"

#include <fstream>

using namespace std;

Producto::Producto() {
    
    nombre=nullptr;
    precio=0;
    
}

Producto::Producto(const Producto& orig) {
}

Producto::~Producto() {
}

void Producto::SetPrecio(double precio) {
    this->precio = precio;
}

double Producto::GetPrecio() const {
    return precio;
}

void Producto::GetNombre(char* cadena){
    
    if(nombre!=nullptr) strcpy(cadena,nombre);
    
}

void Producto::SetNombre(char* cadena){
    
    if(nombre!=nullptr) delete nombre;
    nombre = new char [strlen(cadena)+1];
    strcpy(nombre,cadena);
}
//
void Producto::lee(ifstream& arch){
    
    char nombre[120],c;
    double precioProd;
    
    arch.getline(nombre,120,',');
    arch>>precioProd;
    arch>>c;
    
    SetNombre(nombre);
    SetPrecio(precioProd);
    
    
}

void Producto::imprime(ofstream& arch){
    
    char nombre[120];
    GetNombre(nombre);
    arch<<"Nombre: "<<nombre<<endl;
    arch<<"Precio: "<<GetPrecio()<<endl;
    
    
}

void Producto::actualiza(int&tiempoPrepind, double&precioPed){
    
    precioPed = GetPrecio();
    
}