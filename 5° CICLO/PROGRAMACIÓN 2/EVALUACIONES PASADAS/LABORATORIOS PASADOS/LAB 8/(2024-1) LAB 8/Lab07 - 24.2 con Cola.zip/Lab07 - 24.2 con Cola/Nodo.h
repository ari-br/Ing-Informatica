/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Nodo.h
 * Author: roxan
 *
 * Created on 15 de noviembre de 2024, 08:08 PM
 */

#ifndef NODO_H
#define NODO_H

#include "Producto.h"


class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    
    friend class Lista;
    
private:
    
    class Producto *lproducto; //Este es el polimorfico xD
    class Nodo *sig;
    
    void generaMemoria(char );
    void leeBypass(ifstream &);
    void imprimeBypassNodo(ofstream &);
    void actualizaBypass(int &,double &);

};

#endif /* NODO_H */

