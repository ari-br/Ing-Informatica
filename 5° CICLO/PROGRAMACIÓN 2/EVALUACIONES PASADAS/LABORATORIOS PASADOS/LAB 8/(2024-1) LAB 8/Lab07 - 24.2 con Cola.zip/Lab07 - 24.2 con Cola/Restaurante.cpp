/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Restaurante.cpp
 * Author: roxan
 * 
 * Created on 15 de noviembre de 2024, 08:07 PM
 */

#include "Restaurante.h"
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>

using namespace std;

Restaurante::Restaurante() {
    
    cantidad_comandas=0;
    
}

Restaurante::Restaurante(const Restaurante& orig) {
}

Restaurante::~Restaurante() {
}

void Restaurante::carga(){
    
    ifstream archAten("atenciones.csv",ios::in);
    if(not archAten.is_open()){
        cout<<"El archivo con el nombre de atenciones.csv no se pudo abrir";
        exit(1);
    }
    
    int idcomanda,ha,ma,hs,ms;
    char c;
    
    while(true){
        
        archAten>>idcomanda;
        if(archAten.eof()) break;
        archAten>>c>>ha>>c>>ma>>c>>hs>>c>>ms;
        
        //No se repiten creo xD
        
        comandas[cantidad_comandas].SetHora_atencion(ha*100+ma);
        comandas[cantidad_comandas].SetHora_servicio(hs*100+ms);
        comandas[cantidad_comandas].SetId(idcomanda);
        
        cantidad_comandas++;
    }
    
    
    
}

void Restaurante::llena(){
    
    ifstream archComan("comandas.csv",ios::in);
    if(not archComan.is_open()){
        cout<<"El archivo con  el nombre de comandas.csv no se pyudo abrir";
        exit(1);
    }
    
    
    int idComandBusc;
    char tipoComanda;
    
    while(true){
        
        archComan>>idComandBusc;
        if(archComan.eof()) break;
        archComan.get();
        archComan>>tipoComanda;
        archComan.get();

        //Se busca a la comanda:
        
        for(int i=0;i<cantidad_comandas;i++){
            
            if(idComandBusc==comandas[i].GetId()){
                comandas[i].listaBypass(archComan,tipoComanda);
            }
            
            
            
        }
        
        
        
        
    }
    
    
    
}

/*
    int id;
    int hora_atencion;
    int hora_servicio;
    int tiempo_preparacion;
    double total;
    char *estado;
 
 */

void Restaurante::muestra(){
    
    ofstream archRep("ReporteRestaurante.txt",ios::out);
    if(not archRep.is_open()){
        cout<<"El archivo con el nombre de reporterestaurante.txt no se pudo abrir";
        exit(1);
    }
    
    archRep<<"REPORTE DEL RESTAURANTE: "<<endl;
    imprimeLinea(archRep,80,'=');
    archRep<<fixed<<setprecision(2);
    int tiempoPrep;
    char estado[60];
    
    for(int i=0;i<cantidad_comandas;i++){
        if(i!=0) imprimeLinea(archRep,80,'-');
        
        archRep<<"Id: "<<comandas[i].GetId()<<endl;
        archRep<<"Tiempo de preparacion estimado: "<<comandas[i].GetTiempo_preparacion()<<" minutos"<<endl;
        tiempoPrep = (comandas[i].GetHora_servicio()-comandas[i].GetHora_atencion());
        archRep<<"Tiempo transcurrido entre atencion y servicio: "<<tiempoPrep<<" minutos"<<endl;
        archRep<<"Total: "<<comandas[i].GetTotal()<<endl;
        comandas[i].GetEstado(estado);
        archRep<<"Estado: "<<estado<<endl;
        
        //Pendiente el estado:
        
        imprimeLinea(archRep,80,'-');
        
        archRep<<"Pedidos: "<<endl;
        comandas[i].impremeBypass(archRep);
        
    }
    
    
}

void Restaurante::imprimeLinea(ofstream  &arch,int numMax,char caracter){
    
    for(int i=0;i<numMax;i++){
        arch<<caracter;
    }
    
    arch<<endl;
}

void Restaurante::actualizar_comandas(){
    
    
    //Recorrera cada comanda y cada lista de productos y actualizara de manera polimorfica xD
    
    for(int i=0;i<cantidad_comandas;i++){
        
        comandas[i].actualizaBypass();
        
    }
    
    
}

