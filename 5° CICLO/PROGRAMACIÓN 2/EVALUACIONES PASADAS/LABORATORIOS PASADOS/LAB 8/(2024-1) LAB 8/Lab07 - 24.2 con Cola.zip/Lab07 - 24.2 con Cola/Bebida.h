/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Bebida.h
 * Author: roxan
 *
 * Created on 15 de noviembre de 2024, 07:59 PM
 */

#ifndef BEBIDA_H
#define BEBIDA_H

#include "Producto.h"


class Bebida:public Producto {
public:
    Bebida();
    Bebida(const Bebida& orig);
    virtual ~Bebida();
    void GetTamano(char *cadena);
    void SetTamano(char *cadena);
    
    void lee(ifstream &);
    void imprime(ofstream &);
    void actualiza(int &,double &);
    
private:
    
    char *tamano;

};

#endif /* BEBIDA_H */

