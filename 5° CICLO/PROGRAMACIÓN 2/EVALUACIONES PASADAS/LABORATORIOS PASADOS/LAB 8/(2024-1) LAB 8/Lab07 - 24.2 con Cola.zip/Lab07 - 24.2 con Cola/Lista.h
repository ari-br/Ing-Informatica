/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Lista.h
 * Author: roxan
 *
 * Created on 15 de noviembre de 2024, 08:08 PM
 */

#ifndef LISTA_H
#define LISTA_H

#include "Nodo.h"

class Lista {
public:
    Lista();
    Lista(const Lista& orig);
    virtual ~Lista();
    
    void creaEncolaNodo(ifstream &,char );
    void impreDatos(ofstream &);
    void recorreComandActualiz(int &,double &);
    
private:
    
    Nodo *ini;
    Nodo *fin;
    

};

#endif /* LISTA_H */

