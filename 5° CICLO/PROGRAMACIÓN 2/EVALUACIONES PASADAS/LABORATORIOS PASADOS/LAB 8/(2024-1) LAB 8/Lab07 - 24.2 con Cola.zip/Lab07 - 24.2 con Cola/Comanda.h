/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Comanda.h
 * Author: roxan
 *
 * Created on 15 de noviembre de 2024, 08:03 PM
 */

#ifndef COMANDA_H
#define COMANDA_H

#include "Lista.h"

#include <fstream>
using namespace std;


class Comanda {
public:
    Comanda();
    Comanda(const Comanda& orig);
    virtual ~Comanda();
    void SetTotal(double total);
    double GetTotal() const;
    void SetTiempo_preparacion(int tiempo_preparacion);
    int GetTiempo_preparacion() const;
    void SetHora_servicio(int hora_servicio);
    int GetHora_servicio() const;
    void SetHora_atencion(int hora_atencion);
    int GetHora_atencion() const;
    void SetId(int id);
    int GetId() const;
    void GetEstado(char *cadena);
    void SetEstado(char *cadena);
    
    //Metodos Bypass:
    
    void listaBypass(ifstream &,char );
    void impremeBypass(ofstream &);
    void actualizaBypass();
    
private:
    
    //Aqui va una cola de productos de la comanda:
    
    Lista Llista; 
    
    //Aqui los datos genericos de la comanda XD
    
    int id;
    int hora_atencion;
    int hora_servicio;
    int tiempo_preparacion;
    double total;
    char *estado;
    
    
    

};

#endif /* COMANDA_H */

