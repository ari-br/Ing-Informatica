/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Comanda.cpp
 * Author: roxan
 * 
 * Created on 15 de noviembre de 2024, 08:03 PM
 */

#include "Comanda.h"
#include <iostream>
#include <cstring>

using namespace std;

Comanda::Comanda() {
    
    
    id=0;
    hora_atencion=0;
    hora_servicio=0;
    tiempo_preparacion=0;
    total=0;
    estado=nullptr;
    
}

Comanda::Comanda(const Comanda& orig) {
}

Comanda::~Comanda() {
}

void Comanda::SetTotal(double total) {
    this->total = total;
}

double Comanda::GetTotal() const {
    return total;
}

void Comanda::SetTiempo_preparacion(int tiempo_preparacion) {
    this->tiempo_preparacion = tiempo_preparacion;
}

int Comanda::GetTiempo_preparacion() const {
    return tiempo_preparacion;
}

void Comanda::SetHora_servicio(int hora_servicio) {
    this->hora_servicio = hora_servicio;
}

int Comanda::GetHora_servicio() const {
    return hora_servicio;
}

void Comanda::SetHora_atencion(int hora_atencion) {
    this->hora_atencion = hora_atencion;
}

int Comanda::GetHora_atencion() const {
    return hora_atencion;
}

void Comanda::SetId(int id) {
    this->id = id;
}

int Comanda::GetId() const {
    return id;
}

void Comanda::GetEstado(char* cadena){
    
    if(estado!=nullptr) strcpy(cadena,estado);
    
}

void Comanda::SetEstado(char* cadena){
    
    if(estado!=nullptr) delete estado;
    estado = new char [strlen(cadena)+1];
    strcpy(estado,cadena);
}

void Comanda::listaBypass(ifstream &arch,char tipoComa){
    
    Llista.creaEncolaNodo(arch,tipoComa);
    
}

void Comanda::impremeBypass(ofstream& arch){
    
    Llista.impreDatos(arch);
    
}

void Comanda::actualizaBypass(){
    
    //Se envian como referencia para calcular lo ncesario adentro XD, segun eso se actualiza la comanda 
    
    int tiempoPrep=0;
    double totalComanda=0;
    
    Llista.recorreComandActualiz(tiempoPrep,totalComanda);
    
    SetTiempo_preparacion(tiempoPrep);
    SetTotal(totalComanda);
    
    if(tiempoPrep>(GetHora_servicio()-GetHora_atencion())){
        SetEstado("ATENDIDA CON RETRASO");
    }else{
        SetEstado("ATENDIDA");
    }
    
}
