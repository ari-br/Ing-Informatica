/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Restaurante.h
 * Author: roxan
 *
 * Created on 15 de noviembre de 2024, 08:07 PM
 */

#ifndef RESTAURANTE_H
#define RESTAURANTE_H

#include "Comanda.h"


class Restaurante {
public:
    Restaurante();
    Restaurante(const Restaurante& orig);
    virtual ~Restaurante();
    
    void carga();
    void llena();
    
    void muestra();
    void actualizar_comandas();
    
    void imprimeLinea(ofstream  &arch,int numMax,char caracter);
    
private:
    
    class Comanda comandas[55];
    int cantidad_comandas;

};

#endif /* RESTAURANTE_H */

