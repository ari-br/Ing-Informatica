/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Nodo.cpp
 * Author: roxan
 * 
 * Created on 15 de noviembre de 2024, 08:08 PM
 */

#include "Nodo.h"
#include "Bebida.h"
#include "Entrada.h"
#include "PlatoFondo.h"

Nodo::Nodo() {
    
    lproducto=nullptr; //Este es el polimorfico xD
    sig=nullptr;
    
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
}

void Nodo::generaMemoria(char tipo){
    
    if(tipo=='B'){
        lproducto = new Bebida;
    }else if(tipo=='E'){
        lproducto = new Entrada;
    }else{
        lproducto = new PlatoFondo;
    }
    
}


void Nodo::leeBypass(ifstream& arch){
    lproducto->lee(arch);
}

void Nodo::imprimeBypassNodo(ofstream& arch){
    
    lproducto->imprime(arch);
    
}

void Nodo::actualizaBypass(int &tiempoPed,double &totalPed){
    
    lproducto->actualiza(tiempoPed,totalPed);
    
}

