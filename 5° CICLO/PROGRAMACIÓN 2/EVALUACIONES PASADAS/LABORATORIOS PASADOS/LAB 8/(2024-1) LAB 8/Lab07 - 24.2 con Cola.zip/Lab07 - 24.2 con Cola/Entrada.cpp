/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Entrada.cpp
 * Author: roxan
 * 
 * Created on 15 de noviembre de 2024, 08:00 PM
 */

#include <cstring>

#include "Entrada.h"

Entrada::Entrada() {
}

Entrada::Entrada(const Entrada& orig) {
}

Entrada::~Entrada() {
}

void Entrada::SetPicante(bool picante) {
    this->picante = picante;
}

bool Entrada::IsPicante() const {
    return picante;
}

void Entrada::lee(ifstream& arch){
    
    Producto::lee(arch);
    char cad[120];
    arch.getline(cad,120,'\n');
    if(strcmp(cad,"picante")==0){
        picante=true;
    }else{
        picante=false;
    }
    
    
}

void Entrada::imprime(ofstream& arch){
    
    Producto::imprime(arch);
    arch<<"Picante: ";
    if(picante){
        arch<<"Picante";
    }else{
        arch<<"Sin Picante";
    }
    
    arch<<endl<<endl;
}

void Entrada::actualiza(int &tiempoPrep,double &precioPrep){
    
    Producto::actualiza(tiempoPrep,precioPrep);
    tiempoPrep=15;
    
}
