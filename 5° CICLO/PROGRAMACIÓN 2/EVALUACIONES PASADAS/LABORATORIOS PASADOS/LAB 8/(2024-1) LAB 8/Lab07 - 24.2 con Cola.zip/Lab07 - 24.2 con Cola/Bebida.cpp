/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Bebida.cpp
 * Author: roxan
 * 
 * Created on 15 de noviembre de 2024, 07:59 PM
 */

#include "Bebida.h"
#include <cstring>

Bebida::Bebida() {
    
    tamano=nullptr;
}

Bebida::Bebida(const Bebida& orig) {
}

Bebida::~Bebida() {
}

void Bebida::GetTamano(char* cadena){
    
    if(tamano!=nullptr) strcpy(cadena,tamano);
    
}

void Bebida::SetTamano(char* cadena){
    
    if(tamano!=nullptr) delete tamano;
    tamano = new char [strlen(cadena)+1];
    strcpy(tamano,cadena);
}

void Bebida::lee(ifstream& arch){
    
    Producto::lee(arch);
    char tamano[120];
    arch.getline(tamano,120,'\n');
    SetTamano(tamano);
    
    
}

void Bebida::imprime(ofstream& arch){
    
    Producto::imprime(arch);
    char tamanos[120];
    GetTamano(tamanos);
    arch<<"Tamano: "<<tamanos<<endl<<endl;
    
}

void Bebida::actualiza(int &tiempoPrep,double &precioPrep){
    
    Producto::actualiza(tiempoPrep,precioPrep);
    tiempoPrep=10;
    
}


