/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Lista.cpp
 * Author: roxan
 * 
 * Created on 15 de noviembre de 2024, 08:08 PM
 */

#include "Lista.h"

Lista::Lista() {
    
    ini=nullptr;
    fin=nullptr;
    
}

Lista::Lista(const Lista& orig) {
}

Lista::~Lista() {
}

void Lista::creaEncolaNodo(ifstream& arch,char tipoProd){
    
    //Aqui se crea el nodo y se encola y todo eso xD
    
    Nodo *nuevo,*aux; //Nodo auxiliar
    nuevo = new Nodo;
    
    //Se le debe dar memoria y luego leer a nuevo.
    
    nuevo->generaMemoria(tipoProd);
    nuevo->leeBypass(arch);
    
    //Ahora se usa la pseudo cola xD
    
    if(ini==nullptr){
        ini=nuevo;
        fin=nuevo;
    }else{
        aux =fin;
        aux->sig=nuevo;
        fin = nuevo;
    }
    
    
}

void Lista::impreDatos(ofstream& arch){
    
    Nodo *rec=ini;
    
    while(rec){

        rec->imprimeBypassNodo(arch);
        rec=rec->sig;
    }
    
    
}

void Lista::recorreComandActualiz(int& tiempPrepTot, double& totalComan){
    
    
    Nodo *rec=ini;
    int tiempPedInd; //tiempo de pedido individual
    double totalPedInd; //Total de pedido individual
    
    while(rec){
        
        rec->actualizaBypass(tiempPedInd,totalPedInd);
        
        totalComan+=totalPedInd;
        tiempPrepTot+=tiempPedInd;
        
        rec=rec->sig;
    }
    
    
}

