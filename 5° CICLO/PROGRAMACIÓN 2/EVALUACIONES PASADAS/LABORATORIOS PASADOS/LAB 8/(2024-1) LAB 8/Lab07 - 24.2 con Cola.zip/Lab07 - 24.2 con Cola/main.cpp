
/* 
 * File:   main.cpp
 * Author: Zzzzavala
 *
 * Created on 15 de noviembre de 2024, 07:52 PM
 */

#include <iostream>
#include <iomanip> 
#include <cstring>
#include <fstream>

#include "Restaurante.h"

using namespace std;


int main(int argc, char** argv) {
    
    Restaurante rest;
    
    rest.carga(); //Cargar las atenciones a el arreglo de comandas
    rest.llena();
    rest.actualizar_comandas();
    rest.muestra();
    
    

    return 0;
}

