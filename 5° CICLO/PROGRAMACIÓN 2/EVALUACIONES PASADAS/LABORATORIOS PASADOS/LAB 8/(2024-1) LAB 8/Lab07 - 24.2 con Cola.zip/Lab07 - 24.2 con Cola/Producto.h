/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Producto.h
 * Author: roxan
 *
 * Created on 15 de noviembre de 2024, 07:57 PM
 */

#ifndef PRODUCTO_H
#define PRODUCTO_H

#include <iostream>
#include <fstream>

using namespace std;

class Producto {
public:
    Producto();
    Producto(const Producto& orig);
    virtual ~Producto();
    void SetPrecio(double precio);
    double GetPrecio() const;
    void GetNombre(char *cadena);
    void SetNombre(char *cadena);
    
    //Polimorfismo:
    
    virtual void lee(ifstream &);
    virtual void imprime(ofstream &);
    virtual void actualiza(int &,double &);
    
private:
    
    char *nombre;
    double precio;

};

#endif /* PRODUCTO_H */

