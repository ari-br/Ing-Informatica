/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Estante.h
 * Author: Ariana
 *
 * Created on 13 de noviembre de 2024, 03:45 PM
 */

#ifndef ESTANTE_H
#define ESTANTE_H

#include "Lista.h"


class Estante {
public:
    Estante();
    Estante(const Estante& orig);
    virtual ~Estante();
    void SetCapacidad(double capacidad);
    double GetCapacidad() const;
    void SetId(int id);
    int GetId() const;
    void SetClase(char clase);
    char GetClase() const;
    bool tieneCapacidad(double);
    void cargarNodo(Nodo *,double);
    void actualiza();
    void imprimirLibros(ofstream &);
private:
    char clase;
    int id;
    double capacidad;
    Lista Llibros;
};

ifstream &operator >>(ifstream &,Estante &);

#endif /* ESTANTE_H */

