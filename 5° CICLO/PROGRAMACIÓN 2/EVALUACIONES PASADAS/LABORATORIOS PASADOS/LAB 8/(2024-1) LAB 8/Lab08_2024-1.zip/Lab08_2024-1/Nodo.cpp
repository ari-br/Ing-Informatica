/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Nodo.cpp
 * Author: Ariana
 * 
 * Created on 13 de noviembre de 2024, 03:32 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Nodo.h"
#include "Novela.h"
#include "Enciclopedia.h"
#include "Revista.h"

Nodo::Nodo() {
    plibro=nullptr;
    sig=nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
    if(plibro!=nullptr) delete plibro;
    if(sig!=nullptr) delete sig;
}

void Nodo::lee(ifstream &arch){
    char tipo,cad[100],c;
    int pag;
    double peso;
    
    arch>>tipo;
    if(arch.eof()) return;
    arch.get();
    arch.getline(cad,100,',');
    arch>>pag>>c>>peso>>c;
    
    if(tipo=='N') plibro=new Novela;
    if(tipo=='E') plibro=new Enciclopedia;
    if(tipo=='R') plibro=new Revista;
    
    plibro->lee(arch,cad,pag,peso);
}

double Nodo::devolverPeso(){
    return plibro->GetPeso();
}

void Nodo::actualiza(){
    int vig=0;
    plibro->actualiza(0,vig);
}

void Nodo::imprime(ofstream &arch){
    plibro->imprime(arch,' ',nullptr,0,0,0,0,0);
}