/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Libro.cpp
 * Author: Ariana
 * 
 * Created on 13 de noviembre de 2024, 03:15 PM
 */

#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Libro.h"

Libro::Libro() {
    nombre=nullptr;
    paginas=0;
    peso=0;
}

Libro::Libro(const Libro& orig) {
}

Libro::~Libro() {
    if(nombre!=nullptr) delete nombre;
}

void Libro::SetPeso(double peso) {
    this->peso = peso;
}

double Libro::GetPeso() const {
    return peso;
}

void Libro::SetPaginas(int paginas) {
    this->paginas = paginas;
}

int Libro::GetPaginas() const {
    return paginas;
}

void Libro::SetNombre(char *cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Libro::GetNombre(char *cad) const{
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Libro::lee(ifstream &arch,char *cad,int pag,double pes){
    SetNombre(cad);
    paginas=pag;
    peso=pes;
}

void Libro::actualiza(int anio,int &vig){
    if(anio<=2020 and vig==1) vig=0;
}

void Libro::imprime(ofstream &arch,char categoria,char *aut,int SKU,int anio,
        int vig,int issn,int num){
    char cad[100];
    GetNombre(cad);
    arch<<"Titulo: "<<cad<<endl;
    arch<<"Peso: "<<peso<<endl;
    if(categoria=='N')
        arch<<"Autor: "<<aut<<endl;
    if(categoria=='E')
        arch<<left<<"SKU: "<<setw(10)<<SKU<<"Año: "<<setw(10)<<anio
            <<"Vigencia: "<<vig<<endl;
    if(categoria=='R')
        arch<<left<<"ISSN: "<<setw(12)<<issn<<"Año: "<<setw(8)<<anio
            <<"Numero: "<<setw(5)<<num<<"Vigencia: "<<vig<<endl;
    arch<<endl;
}