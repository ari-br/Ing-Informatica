/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Libro.h
 * Author: Ariana
 *
 * Created on 13 de noviembre de 2024, 03:15 PM
 */

#ifndef LIBRO_H
#define LIBRO_H

class Libro {
public:
    Libro();
    Libro(const Libro& orig);
    virtual ~Libro();
    void SetPeso(double peso);
    double GetPeso() const;
    void SetPaginas(int paginas);
    int GetPaginas() const;
    void SetNombre(char *);
    void GetNombre(char *) const;
    virtual void lee(ifstream &,char *,int,double); //Método polimórfico
    virtual void imprime(ofstream &arch,char categoria,char *aut,int SKU,int anio,
        int vig,int issn,int num); //Método polimórfico
    virtual void actualiza(int anio,int &vig); //Método polimórfico
private:
    char *nombre;
    int paginas;
    double peso;
};

#endif /* LIBRO_H */

