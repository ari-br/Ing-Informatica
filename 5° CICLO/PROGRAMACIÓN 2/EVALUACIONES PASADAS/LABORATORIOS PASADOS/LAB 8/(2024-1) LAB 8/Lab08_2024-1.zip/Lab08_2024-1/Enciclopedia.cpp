/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Enciclopedia.cpp
 * Author: Ariana
 * 
 * Created on 13 de noviembre de 2024, 03:18 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Enciclopedia.h"

Enciclopedia::Enciclopedia() {
    sku=0;
    anho=0;
    vigencia=1;
}

Enciclopedia::Enciclopedia(const Enciclopedia& orig) {
}

Enciclopedia::~Enciclopedia() {
}

void Enciclopedia::SetVigencia(int vigencia) {
    this->vigencia = vigencia;
}

int Enciclopedia::GetVigencia() const {
    return vigencia;
}

void Enciclopedia::SetAnho(int anho) {
    this->anho = anho;
}

int Enciclopedia::GetAnho() const {
    return anho;
}

void Enciclopedia::SetSku(int sku) {
    this->sku = sku;
}

int Enciclopedia::GetSku() const {
    return sku;
}

void Enciclopedia::lee(ifstream &arch,char *cad,int pag,double pes){
    char c;
    arch>>sku>>c>>anho;
    Libro::lee(arch,cad,pag,pes);
}

void Enciclopedia::actualiza(int anio,int &vig){
    Libro::actualiza(anho,vigencia);
}

void Enciclopedia::imprime(ofstream &arch,char categoria,char *aut,int SKU,int anio,
        int vig,int issn,int num){
    Libro::imprime(arch,'E',nullptr,sku,anho,vigencia,0,0);
}