/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Biblioteca.cpp
 * Author: Ariana
 * 
 * Created on 13 de noviembre de 2024, 03:43 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Biblioteca.h"

Biblioteca::Biblioteca() {
}

Biblioteca::Biblioteca(const Biblioteca& orig) {
}

Biblioteca::~Biblioteca() {
}

void Biblioteca::carga(){
    ifstream arch("Estantes2.csv",ios::in);
    AperturaIf(arch,"Estantes2.csv");
    
    for (int i = 0; 1; i++) {
        arch>>AEstantes[i];
        if(arch.eof()) break;
    }
}

void Biblioteca::llena(){
    ifstream arch("Libros3.csv",ios::in);
    AperturaIf(arch,"Libros3.csv");
    
    int i=0;
    while(1){
        Nodo *nodo=new Nodo;
        nodo->lee(arch);
        if(arch.eof() or AEstantes[i].GetId()==0) break;
        if(!AEstantes[i].tieneCapacidad(nodo->devolverPeso())) i++;
        AEstantes[i].cargarNodo(nodo,nodo->devolverPeso());
    }
}

void Biblioteca::baja(){
    for (int i = 0; AEstantes[i].GetId(); i++)
        AEstantes[i].actualiza();
}

void Biblioteca::muestra(){
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    
    arch<<"Estantes:"<<endl;
    imprimirLinea(arch,'=');
    arch<<endl;
    
    for (int i = 0; AEstantes[i].GetId(); i++)
        imprimirEstantes(arch,AEstantes[i]);
}

void Biblioteca::imprimirEstantes(ofstream &arch,Estante &estante){
    arch<<"Id: "<<estante.GetId()<<endl;
    arch<<"Tipo: ";
    if(estante.GetClase()=='H') arch<<"Horizontal"<<endl;
    if(estante.GetClase()=='V') arch<<"Vertical"<<endl;
    arch<<"Capacidad: "<<estante.GetCapacidad()<<endl;
    arch<<"Libros Contenidos:"<<endl;
    imprimirLinea(arch,'=');
    estante.imprimirLibros(arch);
    imprimirLinea(arch,'=');
    arch<<endl;
}

void Biblioteca::imprimirLinea(ofstream &arch,char c){
    for (int i = 0; i < 70; i++) arch<<c;
    arch<<endl;
}

void Biblioteca::AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void Biblioteca::AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}