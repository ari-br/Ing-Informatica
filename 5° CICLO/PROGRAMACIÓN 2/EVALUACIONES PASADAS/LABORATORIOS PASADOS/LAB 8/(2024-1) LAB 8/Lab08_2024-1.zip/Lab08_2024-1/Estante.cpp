/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Estante.cpp
 * Author: Ariana
 * 
 * Created on 13 de noviembre de 2024, 03:45 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Estante.h"

Estante::Estante() {
    id=0;
    capacidad=0;
}

Estante::Estante(const Estante& orig) {
}

Estante::~Estante() {
}

void Estante::SetCapacidad(double capacidad) {
    this->capacidad = capacidad;
}

double Estante::GetCapacidad() const {
    return capacidad;
}

void Estante::SetId(int id) {
    this->id = id;
}

int Estante::GetId() const {
    return id;
}

void Estante::SetClase(char clase) {
    this->clase = clase;
}

char Estante::GetClase() const {
    return clase;
}

bool Estante::tieneCapacidad(double pesoLib){
    return capacidad>=(Llibros.GetPeso()+pesoLib);
}

void Estante::cargarNodo(Nodo *nodo,double pesoLib){
    Llibros.cargarNodo(nodo);
    Llibros.SetPeso(Llibros.GetPeso()+pesoLib);
}

void Estante::actualiza(){
    Llibros.actualiza();
}

void Estante::imprimirLibros(ofstream &arch){
    Llibros.imprime(arch);
}

ifstream &operator >>(ifstream &arch,Estante &f){
    char c;
    int id;
    double capacidad;
    
    arch>>c;
    if(!arch.eof()){
        f.SetClase(c);
        arch>>c>>id>>c>>capacidad;
        f.SetId(id);
        f.SetCapacidad(capacidad);
    }
    return arch;
}