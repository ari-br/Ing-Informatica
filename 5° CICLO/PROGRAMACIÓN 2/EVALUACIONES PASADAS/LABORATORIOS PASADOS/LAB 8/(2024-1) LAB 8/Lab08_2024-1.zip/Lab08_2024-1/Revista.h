/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Revista.h
 * Author: Ariana
 *
 * Created on 13 de noviembre de 2024, 03:28 PM
 */

#ifndef REVISTA_H
#define REVISTA_H

#include "Libro.h"


class Revista:public Libro {
public:
    Revista();
    Revista(const Revista& orig);
    virtual ~Revista();
    void SetVigencia(int vigencia);
    int GetVigencia() const;
    void SetNumero(int numero);
    int GetNumero() const;
    void SetAnho(int anho);
    int GetAnho() const;
    void SetISSN(int ISSN);
    int GetISSN() const;
    void lee(ifstream &,char *,int,double); //Método polimórfico
    void imprime(ofstream &arch,char categoria,char *aut,int SKU,int anio,
        int vig,int issn,int num); //Método polimórfico
    void actualiza(int anio,int &vig); //Método polimórfico
private:
    int ISSN;
    int anho;
    int numero;
    int vigencia;
};

#endif /* REVISTA_H */

