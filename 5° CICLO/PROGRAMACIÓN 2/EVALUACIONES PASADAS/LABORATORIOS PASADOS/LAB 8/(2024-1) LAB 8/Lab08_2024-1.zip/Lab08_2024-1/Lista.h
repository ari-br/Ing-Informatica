/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Lista.h
 * Author: Ariana
 *
 * Created on 13 de noviembre de 2024, 03:36 PM
 */

#ifndef LISTA_H
#define LISTA_H

#include "Nodo.h"


class Lista {
public:
    Lista();
    Lista(const Lista& orig);
    virtual ~Lista();
    void SetPeso(double peso);
    double GetPeso() const;
    void cargarNodo(Nodo *);
    Nodo *devolverUltimoNodo();
    void actualiza();
    void imprime(ofstream &);
private:
    double peso;
    Nodo *ini;
};

#endif /* LISTA_H */

