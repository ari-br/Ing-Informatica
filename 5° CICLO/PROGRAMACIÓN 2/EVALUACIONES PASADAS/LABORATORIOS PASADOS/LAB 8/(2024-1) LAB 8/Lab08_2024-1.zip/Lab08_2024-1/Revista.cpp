/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Revista.cpp
 * Author: Ariana
 * 
 * Created on 13 de noviembre de 2024, 03:28 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Revista.h"

Revista::Revista() {
    ISSN=0;
    anho=0;
    numero=0;
    vigencia=1;
}

Revista::Revista(const Revista& orig) {
}

Revista::~Revista() {
}

void Revista::SetVigencia(int vigencia) {
    this->vigencia = vigencia;
}

int Revista::GetVigencia() const {
    return vigencia;
}

void Revista::SetNumero(int numero) {
    this->numero = numero;
}

int Revista::GetNumero() const {
    return numero;
}

void Revista::SetAnho(int anho) {
    this->anho = anho;
}

int Revista::GetAnho() const {
    return anho;
}

void Revista::SetISSN(int ISSN) {
    this->ISSN = ISSN;
}

int Revista::GetISSN() const {
    return ISSN;
}

void Revista::lee(ifstream &arch,char *cad,int pag,double pes){
    char c;
    arch>>ISSN>>c>>anho>>c>>numero;
    Libro::lee(arch,cad,pag,pes);
}

void Revista::actualiza(int anio,int &vig){
    Libro::actualiza(anho,vigencia);
}

void Revista::imprime(ofstream &arch,char categoria,char *aut,int SKU,int anio,
        int vig,int issn,int num){
    Libro::imprime(arch,'R',nullptr,0,anho,vigencia,ISSN,numero);
}