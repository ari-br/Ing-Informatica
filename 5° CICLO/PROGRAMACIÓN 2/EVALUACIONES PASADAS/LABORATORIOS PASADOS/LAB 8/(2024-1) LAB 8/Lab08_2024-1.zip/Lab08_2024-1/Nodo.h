/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Nodo.h
 * Author: Ariana
 *
 * Created on 13 de noviembre de 2024, 03:32 PM
 */

#ifndef NODO_H
#define NODO_H

#include "Libro.h"


class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Lista; //NO OLVIDAR
    void lee(ifstream &);
    double devolverPeso();
    void actualiza();
    void imprime(ofstream &);
private:
    Libro *plibro;
    Nodo *sig;
};

#endif /* NODO_H */

