/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Lista.cpp
 * Author: Ariana
 * 
 * Created on 13 de noviembre de 2024, 03:36 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Lista.h"

Lista::Lista() {
    peso=0;
    ini=nullptr;
}

Lista::Lista(const Lista& orig) {
}

Lista::~Lista() {
//    if(ini!=nullptr) delete ini;
}

void Lista::SetPeso(double peso) {
    this->peso = peso;
}

double Lista::GetPeso() const {
    return peso;
}

void Lista::cargarNodo(Nodo *nodo){
    Nodo *ultimoNodo=devolverUltimoNodo();
    
    if(ini==nullptr)
        ini=nodo;
    else
        ultimoNodo->sig=nodo;
}

Nodo *Lista::devolverUltimoNodo(){
    Nodo *ultimoNodo=nullptr;
    Nodo *recorrido=ini;
    while(recorrido!=nullptr){
        ultimoNodo=recorrido;
        recorrido=recorrido->sig;
    }
    return ultimoNodo;
}

void  Lista::actualiza(){
    Nodo *recorrido=ini;
    while(recorrido!=nullptr){
        recorrido->actualiza();
        recorrido=recorrido->sig;
    }
}

void Lista::imprime(ofstream &arch){
    Nodo *recorrido=ini;
    while(recorrido!=nullptr){
        recorrido->imprime(arch);
        recorrido=recorrido->sig;
    }
}