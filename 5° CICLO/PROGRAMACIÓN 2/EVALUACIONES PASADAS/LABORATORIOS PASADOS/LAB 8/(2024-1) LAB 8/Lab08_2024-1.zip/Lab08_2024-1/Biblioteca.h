/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Biblioteca.h
 * Author: Ariana
 *
 * Created on 13 de noviembre de 2024, 03:43 PM
 */

#ifndef BIBLIOTECA_H
#define BIBLIOTECA_H

#include "Estante.h"


class Biblioteca {
public:
    Biblioteca();
    Biblioteca(const Biblioteca& orig);
    virtual ~Biblioteca();
    void carga();
    void llena();
    void baja();
    void muestra();
private:
    Estante AEstantes[10];
    void imprimirEstantes(ofstream &,Estante &);
    void imprimirLinea(ofstream &,char);
    void AperturaIf(ifstream &,const char *);
    void AperturaOf(ofstream &,const char *);
};

#endif /* BIBLIOTECA_H */

