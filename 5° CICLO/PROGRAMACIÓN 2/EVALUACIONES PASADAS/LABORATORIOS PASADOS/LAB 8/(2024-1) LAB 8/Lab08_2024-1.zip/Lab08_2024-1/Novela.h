/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Novela.h
 * Author: Ariana
 *
 * Created on 13 de noviembre de 2024, 03:24 PM
 */

#ifndef NOVELA_H
#define NOVELA_H

#include "Libro.h"


class Novela:public Libro {
public:
    Novela();
    Novela(const Novela& orig);
    virtual ~Novela();
    void SetAutor(char *);
    void GetAutor(char *) const;
    void lee(ifstream &,char *,int,double); //Método polimórfico
    void imprime(ofstream &arch,char categoria,char *aut,int SKU,int anio,
        int vig,int issn,int num); //Método polimórfico
    void actualiza(int anio,int &vig); //Método polimórfico
private:
    char *autor;
};

#endif /* NOVELA_H */

