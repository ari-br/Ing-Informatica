/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Novela.cpp
 * Author: Ariana
 * 
 * Created on 13 de noviembre de 2024, 03:24 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "Novela.h"

Novela::Novela() {
    autor=nullptr;
}

Novela::Novela(const Novela& orig) {
}

Novela::~Novela() {
    if(autor!=nullptr) delete autor;
}

void Novela::SetAutor(char *cad){
    if(autor!=nullptr) delete autor;
    autor=new char[strlen(cad)+1];
    strcpy(autor,cad);
}

void Novela::GetAutor(char *cad) const{
    if(autor!=nullptr)
        strcpy(cad,autor);
}

void Novela::lee(ifstream &arch,char *cad,int pag,double pes){
    char aut[100];
    arch.getline(aut,100);
    SetAutor(aut);
    Libro::lee(arch,cad,pag,pes);
}

void Novela::actualiza(int anio,int &vig){
    int vige=0;
    Libro::actualiza(0,vige);
}

void Novela::imprime(ofstream &arch,char categoria,char *aut,int SKU,int anio,
        int vig,int issn,int num){
    Libro::imprime(arch,'N',autor,0,0,0,0,0);
}