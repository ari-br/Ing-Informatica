/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   nota.cpp
 * Author: Ariana
 * 
 * Created on 30 de octubre de 2024, 09:17 AM
 */

#include <cstring>
using namespace std;
#include "nota.h"

nota::nota() {
    codcurso=nullptr;
    ciclo=0;
    Nota=0;
}

nota::nota(const nota& orig) {
}

nota::~nota() {
    if(codcurso!=nullptr) delete codcurso;
}

void nota::SetNota(int Nota) {
    this->Nota = Nota;
}

int nota::GetNota() const {
    return Nota;
}

void nota::SetCiclo(int ciclo) {
    this->ciclo = ciclo;
}

int nota::GetCiclo() const {
    return ciclo;
}

void nota::SetCodcurso(char *cad){
    if(codcurso!=nullptr) delete codcurso;
    codcurso=new char[strlen(cad)+1];
    strcpy(codcurso,cad);
}

void nota::GetCodcurso(char *cad){
    if(codcurso!=nullptr)
        strcpy(cad,codcurso);
}



