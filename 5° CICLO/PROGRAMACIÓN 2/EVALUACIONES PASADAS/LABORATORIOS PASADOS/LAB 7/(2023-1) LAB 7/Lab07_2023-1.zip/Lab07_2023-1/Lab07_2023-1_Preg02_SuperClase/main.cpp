/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 30 de octubre de 2024, 03:43 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "alumno.h"
#include "nota.h"
#include "alumnonota.h"
#include "universidad.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    universidad u;
    
    u.cargaralumnos();
    u.carganotas();
    u.actualizanotas();
    u.imprimealumnos();
    
    return 0;
}

