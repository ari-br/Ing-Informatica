/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   alumononota.h
 * Author: Ariana
 *
 * Created on 30 de octubre de 2024, 09:12 AM
 */

#ifndef ALUMONONOTA_H
#define ALUMONONOTA_H
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "nota.h"

class alumnonota {
public:
    alumnonota();
    alumnonota(const alumnonota& orig);
    virtual ~alumnonota();
    void SetNota(int Nota);
    int GetNota() const;
    void SetCiclo(int ciclo);
    int GetCiclo() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void SetCodcurso(char *cad);
    void GetCodcurso(char *cad);
    void operator &(nota&)const;
private:
    int codigo;
    char *codcurso;
    int ciclo;
    int Nota;
};

ifstream &operator >>(ifstream &,alumnonota &);

#endif /* ALUMONONOTA_H */

