/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   alumononota.cpp
 * Author: Ariana
 * 
 * Created on 30 de octubre de 2024, 09:12 AM
 */

#include <cstring>
#include <fstream>
#include <iostream>
using namespace std;
#include "alumnonota.h"
#include "nota.h"

alumnonota::alumnonota() {
    codigo=0;
    codcurso=nullptr;
    ciclo=0;
    Nota=0;
}

alumnonota::alumnonota(const alumnonota& orig) {
}

alumnonota::~alumnonota() {
    if(codcurso!=nullptr) delete codcurso;
}

void alumnonota::SetNota(int Nota) {
    this->Nota = Nota;
}

int alumnonota::GetNota() const {
    return Nota;
}

void alumnonota::SetCiclo(int ciclo) {
    this->ciclo = ciclo;
}

int alumnonota::GetCiclo() const {
    return ciclo;
}

void alumnonota::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int alumnonota::GetCodigo() const {
    return codigo;
}

void alumnonota::SetCodcurso(char *cad){
    if(codcurso!=nullptr) delete codcurso;
    codcurso=new char[strlen(cad)+1];
    strcpy(codcurso,cad);
}

void alumnonota::GetCodcurso(char *cad){
    if(codcurso!=nullptr)
        strcpy(cad,codcurso);
}

void alumnonota::operator &(nota&n) const{
//    cout<<codcurso<<" "<<ciclo<<" "<<Nota<<endl;
    n.SetCodcurso(codcurso);
    n.SetCiclo(ciclo);
    n.SetNota(Nota);
}

ifstream &operator >>(ifstream &arch,alumnonota &f){
    int cod,ciclo,nota;
    char c,cad[100];
    arch>>cod>>c;
    if(!arch.eof()){
        arch.getline(cad,100,',');
        arch>>ciclo>>c>>nota;
        f.SetCodigo(cod);
        f.SetCodcurso(cad);
        f.SetCiclo(ciclo);
        f.SetNota(nota);
    }
    return arch;
}

