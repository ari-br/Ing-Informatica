/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   universidad.h
 * Author: Ariana
 *
 * Created on 30 de octubre de 2024, 03:48 PM
 */

#ifndef UNIVERSIDAD_H
#define UNIVERSIDAD_H

#include "alumno.h"
#include "alumnonota.h"

class universidad {
public:
    universidad();
    universidad(const universidad& orig);
    virtual ~universidad();
    void cargaralumnos();
    void carganotas();
    void actualizanotas();
    void imprimealumnos();
private:
    alumno lalumnos[100];
    alumnonota lnotas[200];
    void actualizarcursos(int ,int &,int &,int &);
    void AperturaIf(ifstream&,const char*);
    void AperturaOf(ofstream&,const char*);
};

#endif /* UNIVERSIDAD_H */

