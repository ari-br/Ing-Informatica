/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   alumno.cpp
 * Author: Ariana
 * 
 * Created on 30 de octubre de 2024, 09:22 AM
 */

#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "alumno.h"

alumno::alumno() {
    codigo=0;
    nombre=nullptr;
    numcursos=0;
    numaprobados=0;
    numprimera=0;
    numsegunda=0;
    numtercera=0;
}

alumno::alumno(const alumno& orig) {
}

alumno::~alumno() {
    if(nombre!=nullptr) delete nombre;
}

void alumno::SetNumtercera(int numtercera) {
    this->numtercera = numtercera;
}

int alumno::GetNumtercera() const {
    return numtercera;
}

void alumno::SetNumsegunda(int numsegunda) {
    this->numsegunda = numsegunda;
}

int alumno::GetNumsegunda() const {
    return numsegunda;
}

void alumno::SetNumprimera(int numprimera) {
    this->numprimera = numprimera;
}

int alumno::GetNumprimera() const {
    return numprimera;
}

void alumno::SetNumaprobados(int numaprobados) {
    this->numaprobados = numaprobados;
}

int alumno::GetNumaprobados() const {
    return numaprobados;
}

void alumno::SetNumcursos(int numcursos) {
    this->numcursos = numcursos;
}

int alumno::GetNumcursos() const {
    return numcursos;
}

void alumno::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int alumno::GetCodigo() const {
    return codigo;
}

void alumno::SetNombre(char *cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void alumno::GetNombre(char *cad){
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void alumno::ordenacursos(){
    for (int i = 0; i < numcursos-1; i++) {
        for (int k = i+1; k < numcursos; k++) {
            if(lnotas[i].GetCiclo()>lnotas[k].GetCiclo()){
                nota aux;
                aux=lnotas[i];
                lnotas[i]=lnotas[k];
                lnotas[k]=aux;
            }
        }
    }
}

void alumno::operator +=(nota&n){
    char cad[20];
    n.GetCodcurso(cad);
    lnotas[numcursos].SetCodcurso(cad);
    lnotas[numcursos].SetCiclo(n.GetCiclo());
    lnotas[numcursos].SetNota(n.GetNota());
    numcursos++;
}

ifstream &operator >>(ifstream &arch,alumno &f){
    int cod;
    char c,cad[100]{};
    arch>>cod>>c;
    if(!arch.eof()){
        arch.getline(cad,100,',');
        f.SetCodigo(cod);
        f.SetNombre(cad);
        arch.getline(cad,100);
    }
    return arch;
}

ofstream &operator <<(ofstream &arch,alumno &f){
    arch<<"Codigo del Alumno: "<<f.GetCodigo()<<endl;
    char cad[100];
    f.GetNombre(cad);
    arch<<"Nombre del Alumno: "<<cad<<endl;
    arch<<"Detalle de Cursos:"<<endl;
    arch<<left<<setw(10)<<"Cursados"<<setw(12)<<"Aprobados"<<setw(10)<<"1era vez"
        <<setw(10)<<"2da vez"<<setw(10)<<"3era vez"<<endl;
    arch<<right<<setw(5)<<f.GetNumcursos()<<setw(10)<<f.GetNumaprobados()
        <<setw(12)<<f.GetNumprimera()<<setw(10)<<f.GetNumsegunda()<<setw(10)
        <<f.GetNumtercera()<<endl;
    arch<<endl;
    return arch;
}
