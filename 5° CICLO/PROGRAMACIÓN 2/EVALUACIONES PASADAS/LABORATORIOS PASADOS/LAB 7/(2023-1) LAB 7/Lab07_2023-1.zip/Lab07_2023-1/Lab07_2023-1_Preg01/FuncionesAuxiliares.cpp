/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   FuncionesAuxiliares.cpp
 * Author: Ariana
 * 
 * Created on 30 de octubre de 2024, 09:43 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "alumno.h"
#include "nota.h"
#include "alumnonota.h"
#include "FuncionesAuxiliares.h"


void AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se puede abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se puede abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}