/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   nota.h
 * Author: Ariana
 *
 * Created on 30 de octubre de 2024, 09:17 AM
 */

#ifndef NOTA_H
#define NOTA_H

class nota {
public:
    nota();
    nota(const nota& orig);
    virtual ~nota();
    void SetNota(int Nota);
    int GetNota() const;
    void SetCiclo(int ciclo);
    int GetCiclo() const;
    void SetCodcurso(char *cad);
    void GetCodcurso(char *cad);
private:
    char *codcurso;
    int ciclo;
    int Nota;
};

#endif /* NOTA_H */

