/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   alumno.h
 * Author: Ariana
 *
 * Created on 30 de octubre de 2024, 09:22 AM
 */

#ifndef ALUMNO_H
#define ALUMNO_H

#include "nota.h"

class alumno {
public:
    alumno();
    alumno(const alumno& orig);
    virtual ~alumno();
    void SetNumtercera(int numtercera);
    int GetNumtercera() const;
    void SetNumsegunda(int numsegunda);
    int GetNumsegunda() const;
    void SetNumprimera(int numprimera);
    int GetNumprimera() const;
    void SetNumaprobados(int numaprobados);
    int GetNumaprobados() const;
    void SetNumcursos(int numcursos);
    int GetNumcursos() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void SetNombre(char *cad);
    void GetNombre(char *cad);
    void operator +=(nota&);
private:
    int codigo;
    char *nombre;
    int numcursos;
    int numaprobados;
    int numprimera;
    int numsegunda;
    int numtercera;
    nota lnotas[100];
};

ifstream &operator >>(ifstream &,alumno &);
ofstream &operator <<(ofstream &,alumno &);

#endif /* ALUMNO_H */

