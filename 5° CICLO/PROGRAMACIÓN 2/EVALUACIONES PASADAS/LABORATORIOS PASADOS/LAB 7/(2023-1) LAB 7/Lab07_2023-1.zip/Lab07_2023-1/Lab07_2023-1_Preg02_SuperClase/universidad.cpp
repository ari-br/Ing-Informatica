/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   universidad.cpp
 * Author: Ariana
 * 
 * Created on 30 de octubre de 2024, 03:48 PM
 */
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "universidad.h"

universidad::universidad() {
}

universidad::universidad(const universidad& orig) {
}

universidad::~universidad() {
}

void universidad::cargaralumnos(){
    ifstream arch("Alumnos.csv",ios::in);
    AperturaIf(arch,"Alumnos.csv");
    
    for (int i = 0; 1; i++) {
        arch>>lalumnos[i];
        if(arch.eof()) break;
    }
}

void universidad::carganotas(){
    ifstream arch("Notas.csv",ios::in);
    AperturaIf(arch,"Notas.csv");
    
    for (int i = 0; 1; i++) {
        arch>>lnotas[i];
        if(arch.eof()) break;
    }
}

void universidad::actualizarcursos(int num,int &primera,int &segunda,int &tercera){
    
}

void universidad::actualizanotas(){
    for (int i = 0; lalumnos[i].GetCodigo(); i++) {
        for (int k = 0; lnotas[k].GetCodigo(); k++) {
            if(lalumnos[i].GetCodigo()==lnotas[k].GetCodigo()){
                nota aux;
                lnotas[k]&aux;
                lalumnos[i]+=aux;
                int aprob=lalumnos[i].GetNumaprobados();
                if(aux.GetNota()>10) aprob++;
                lalumnos[i].SetNumaprobados(aprob);
            }
            lalumnos[i].ordenacursos();
            int primera=lalumnos[i].GetNumprimera();
            int segunda=lalumnos[i].GetNumsegunda();
            int tercera=lalumnos[i].GetNumtercera();
            actualizarcursos(primera,segunda,tercera);
            lalumnos[i].SetNumprimera(primera);
            lalumnos[i].SetNumsegunda(segunda);
            lalumnos[i].SetNumtercera(tercera);
        }
    }
}

void universidad::imprimealumnos(){
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    
    for (int i = 0; lalumnos[i].GetCodigo(); i++) {
        arch<<lalumnos[i];
    }
}

void universidad::AperturaIf(ifstream&arch,const char*nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void universidad::AperturaOf(ofstream&arch,const char*nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}