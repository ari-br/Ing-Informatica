/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Novela.cpp
 * Author: Ariana
 * 
 * Created on 6 de noviembre de 2024, 11:59 PM
 */

#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Novela.h"

Novela::Novela() {
    tipo=nullptr;
    peso=0;
}

Novela::Novela(const Novela& orig) {
    tipo=nullptr;
    *this=orig;
}

Novela::~Novela() {
    if(tipo!=nullptr) delete tipo;
}

void Novela::SetPeso(double peso) {
    this->peso = peso;
}

double Novela::GetPeso() const {
    return peso;
}

void Novela::SetTipo(char *cad){
    if(tipo!=nullptr) delete tipo;
    tipo=new char[strlen(cad)+1];
    strcpy(tipo,cad);
}

void Novela::GetTipo(char *cad) const{
    if(tipo!=nullptr)
        strcpy(cad,tipo);
}

void Novela::operator =(const Novela &f){
    peso=f.GetPeso();
    SetAlto(f.GetAlto());
    SetAncho(f.GetAncho());
    SetPeso(f.GetPeso());
    char cad[100];
    f.GetNombre(cad);
    SetNombre(cad);
    f.GetCodigo(cad);
    SetCodigo(cad);
    f.GetTipo(cad);
    SetTipo(cad);
}

void Novela::llena(Novela f){
    peso=f.GetPeso();
    SetAlto(f.GetAlto());
    SetAncho(f.GetAncho());
    SetPeso(f.GetPeso());
    char cad[100];
    f.GetNombre(cad);
    SetNombre(cad);
    f.GetCodigo(cad);
    SetCodigo(cad);
    f.GetTipo(cad);
    SetTipo(cad);
}

ifstream &operator >>(ifstream &arch,Novela &f){
    char cad[100],c;
    int ancho,alto,volumen;
    double peso;
    
    arch.getline(cad,10,',');
    if(!arch.eof()){
        f.SetCodigo(cad);
        arch.getline(cad,100,',');
        f.SetNombre(cad);
        arch>>ancho>>c>>alto>>c;
        arch.getline(cad,20,',');
        f.SetTipo(cad);
        arch>>peso;
        f.SetAncho(ancho);
        f.SetAlto(alto);
        f.SetPeso(peso);
    }
    return arch;
}