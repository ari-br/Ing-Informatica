/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Novela.h
 * Author: Ariana
 *
 * Created on 6 de noviembre de 2024, 11:59 PM
 */

#ifndef NOVELA_H
#define NOVELA_H

#include <fstream>
using namespace std;
#include "Libro.h"

class Novela:public Libro {
public:
    Novela();
    Novela(const Novela& orig);
    virtual ~Novela();
    void SetPeso(double peso);
    double GetPeso() const;
    void SetTipo(char *);
    void GetTipo(char *) const;
    void llena(Novela);
    void operator =(const Novela &);
private:
    char *tipo;
    double peso;
};

ifstream &operator >>(ifstream &,Novela &);

#endif /* NOVELA_H */

