/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   EstanteHorizontal.cpp
 * Author: Ariana
 * 
 * Created on 7 de noviembre de 2024, 12:20 AM
 */

#include "EstanteHorizontal.h"

EstanteHorizontal::EstanteHorizontal() {
    novelas=nullptr;
    cantidad_novelas=0;
}

EstanteHorizontal::EstanteHorizontal(const EstanteHorizontal& orig) {
    novelas=nullptr;
    *this=orig;
}

EstanteHorizontal::~EstanteHorizontal() {
    if(novelas!=nullptr) delete[] novelas;
}

void EstanteHorizontal::SetCantidad_novelas(int cantidad_novelas) {
    this->cantidad_novelas = cantidad_novelas;
}

int EstanteHorizontal::GetCantidad_novelas() const {
    return cantidad_novelas;
}

void EstanteHorizontal::operator =(const EstanteHorizontal &f){
    SetPesoSoportado(f.GetPesoSoportado());
    SetAltura(f.GetAltura());
    SetAnchura(f.GetAnchura());
    char cad[100];
    f.GetCodigo(cad);
    SetCodigo(cad);
}

void EstanteHorizontal::llena(EstanteHorizontal f){
    SetPesoSoportado(f.GetPesoSoportado());
    SetAltura(f.GetAltura());
    SetAnchura(f.GetAnchura());
    char cad[100];
    f.GetCodigo(cad);
    SetCodigo(cad);
    crearEspacios(f.GetAltura(),f.GetAnchura(),'H');
}

ifstream &operator >>(ifstream &arch,EstanteHorizontal &f){
    char cad[10],c;
    int ancho,alto;
    double peso;
    
    arch.getline(cad,10,',');
    if(!arch.eof()){
        f.SetCodigo(cad);
        arch>>ancho>>c>>alto>>c>>peso;
        f.SetAnchura(ancho);
        f.SetAltura(alto);
        f.SetPesoSoportado(peso);
    }
    return arch;
}