/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Libro.cpp
 * Author: Ariana
 * 
 * Created on 6 de noviembre de 2024, 09:38 PM
 */

#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Libro.h"

Libro::Libro() {
    codigo=nullptr;
    nombre=nullptr;
    ancho=0;
    alto=0;
    peso=0;
    colocado=false;
}

Libro::Libro(const Libro& orig) {
}

Libro::~Libro() {
    if(codigo!=nullptr) delete codigo;
    if(nombre!=nullptr) delete nombre;
}

void Libro::SetColocado(bool colocado) {
    this->colocado = colocado;
}

bool Libro::IsColocado() const {
    return colocado;
}

void Libro::SetPeso(double peso) {
    this->peso = peso;
}

double Libro::GetPeso() const {
    return peso;
}

void Libro::SetAlto(int alto) {
    this->alto = alto;
}

int Libro::GetAlto() const {
    return alto;
}

void Libro::SetAncho(int ancho) {
    this->ancho = ancho;
}

int Libro::GetAncho() const {
    return ancho;
}

void Libro::SetCodigo(char *cad){
    if(codigo!=nullptr) delete codigo;
    codigo=new char[strlen(cad)+1];
    strcpy(codigo,cad);
}

void Libro::GetCodigo(char *cad) const{
    if(codigo!=nullptr)
        strcpy(cad,codigo);
}

void Libro::SetNombre(char *cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Libro::GetNombre(char *cad) const{
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

