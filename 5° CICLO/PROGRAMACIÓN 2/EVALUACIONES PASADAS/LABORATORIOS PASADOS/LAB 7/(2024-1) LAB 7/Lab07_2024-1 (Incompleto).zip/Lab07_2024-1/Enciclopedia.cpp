/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Enciclopedia.cpp
 * Author: Ariana
 * 
 * Created on 6 de noviembre de 2024, 09:44 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Enciclopedia.h"

Enciclopedia::Enciclopedia() {
    volumen=0;
    peso=0;
}

Enciclopedia::Enciclopedia(const Enciclopedia& orig) {
    *this=orig;
}

Enciclopedia::~Enciclopedia() {
}

void Enciclopedia::SetPeso(double peso) {
    this->peso = peso;
}

double Enciclopedia::GetPeso() const {
    return peso;
}

void Enciclopedia::SetVolumen(int volumen) {
    this->volumen = volumen;
}

int Enciclopedia::GetVolumen() const {
    return volumen;
}

void Enciclopedia::operator =(const Enciclopedia &f){
    volumen=f.GetVolumen();
    peso=f.GetPeso();
    SetAlto(f.GetAlto());
    SetAncho(f.GetAncho());
    SetPeso(f.GetPeso());
    char cad[100];
    f.GetNombre(cad);
    SetNombre(cad);
    f.GetCodigo(cad);
    SetCodigo(cad);
}

void Enciclopedia::llena(Enciclopedia f){
    volumen=f.GetVolumen();
    peso=f.GetPeso();
    SetAlto(f.GetAlto());
    SetAncho(f.GetAncho());
    SetPeso(f.GetPeso());
    char cad[100];
    f.GetNombre(cad);
    SetNombre(cad);
    f.GetCodigo(cad);
    SetCodigo(cad);
}

ifstream &operator >>(ifstream &arch,Enciclopedia &f){
    char cad[100],c;
    int ancho,alto,volumen;
    double peso;
    
    arch.getline(cad,10,',');
    if(!arch.eof()){
        f.SetCodigo(cad);
        arch.getline(cad,100,',');
        f.SetNombre(cad);
        arch>>ancho>>c>>alto>>c>>volumen>>c>>peso;
        f.SetAncho(ancho);
        f.SetAlto(alto);
        f.SetVolumen(volumen);
        f.SetPeso(peso);
    }
    return arch;
}