/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   EstanteHorizontal.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 12:20 AM
 */

#ifndef ESTANTEHORIZONTAL_H
#define ESTANTEHORIZONTAL_H

#include "Novela.h"
#include "Estante.h"


class EstanteHorizontal:public Estante {
public:
    EstanteHorizontal();
    EstanteHorizontal(const EstanteHorizontal& orig);
    virtual ~EstanteHorizontal();
    void SetCantidad_novelas(int cantidad_novelas);
    int GetCantidad_novelas() const;
    void llena(EstanteHorizontal);
    void operator =(const EstanteHorizontal &);
private:
    Novela *novelas;
    int cantidad_novelas;
};

ifstream &operator >>(ifstream &,EstanteHorizontal &);

#endif /* ESTANTEHORIZONTAL_H */

