/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Estante.cpp
 * Author: Ariana
 * 
 * Created on 7 de noviembre de 2024, 12:08 AM
 */

#include <cstring>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Estante.h"

Estante::Estante() {
    codigo=nullptr;
    anchura=0;
    altura=0;
    espacios=nullptr;
    pesoSoportado=0;
    pesoActual=0;
}

Estante::Estante(const Estante& orig) {
}

Estante::~Estante() {
    if(codigo!=nullptr) delete codigo;
    if(espacios!=nullptr) delete[] espacios;
}

void Estante::SetPesoActual(double pesoActual) {
    this->pesoActual = pesoActual;
}

double Estante::GetPesoActual() const {
    return pesoActual;
}

void Estante::SetPesoSoportado(double pesoSoportado) {
    this->pesoSoportado = pesoSoportado;
}

double Estante::GetPesoSoportado() const {
    return pesoSoportado;
}

void Estante::SetAltura(int altura) {
    this->altura = altura;
}

int Estante::GetAltura() const {
    return altura;
}

void Estante::SetAnchura(int anchura) {
    this->anchura = anchura;
}

int Estante::GetAnchura() const {
    return anchura;
}

void Estante::SetCodigo(char *cad){
    if(codigo!=nullptr) delete codigo;
    codigo=new char[strlen(cad)+1];
    strcpy(codigo,cad);
}

void Estante::GetCodigo(char *cad) const{
    if(codigo!=nullptr)
        strcpy(cad,codigo);
}

void Estante::crearEspacios(int ancho,int alto,char tipo){
    espacios=new Espacio[ancho*alto];
    int anc=0,alt=0;
    if(tipo=='H'){
        for (int i = 0; i < ancho*alto; i++) {
            if(alt==alto){
                alt=0;
                anc++;
            }
            espacios[i].SetPosx(anc);
            espacios[i].SetPosy(alt);
            alt++;
        }
    }
    if(tipo=='V'){
        for (int i = 0; i < ancho*alto; i++) {
            if(alt==alto){
                alt=0;
                anc++;
            }
            espacios[i].SetPosx(alt);
            espacios[i].SetPosy(anc);
            alt++;
        }
    }
}

void Estante::contarEspacios(int &hor,int &vert,int anchura,int altura,char tipo){
    if(espacios!=nullptr){
//        if(tipo=='H'){
//            for (int i = 0; 1; i++) {
//                if(espacios[i].GetPosy()==0){
//                    if(espacios[i].GetContenido()=='V') break;
//                    if(espacios[i].GetContenido()=='O') hor++;
//                }
//            }
//        }
        if(tipo=='V'){
            for (int i = 0; 1; i++) {
                if(espacios[i].GetPosy()==0 and 
                        espacios[i].GetContenido()=='V') break;
                if(espacios[i].GetPosx()==anchura-1){
                    if(espacios[i].GetContenido()=='V') break;
                    if(espacios[i].GetContenido()=='O') vert++;
                }
            }
        }
    }
}

void Estante::imprimirEstante(ofstream &arch,int anchura,int altura,char tipo){
    int x,y;
    for (int i = 0; i < altura; i++) {
        for (int k = 0; k < anchura; k++) {
            arch<<"[ ";
            if(estaOcupado(i,k)) arch<<"*";
            arch<<" ]";
        }
        arch<<endl;
    }
}

bool estaOcupado(int x,int y){
    
}