/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Estante.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 12:08 AM
 */

#ifndef ESTANTE_H
#define ESTANTE_H

#include "Espacio.h"


class Estante {
public:
    Estante();
    Estante(const Estante& orig);
    virtual ~Estante();
    void SetPesoActual(double pesoActual);
    double GetPesoActual() const;
    void SetPesoSoportado(double pesoSoportado);
    double GetPesoSoportado() const;
    void SetAltura(int altura);
    int GetAltura() const;
    void SetAnchura(int anchura);
    int GetAnchura() const;
    void SetCodigo(char *);
    void GetCodigo(char *) const;
    void crearEspacios(int ancho,int alto,char tipo);
    void contarEspacios(int &hor,int &vert,int anchura,int altura,char tipo);
    void imprimirEstante(ofstream &arch,int anchura,int altura,char tipo);
private:
    char *codigo;
    int anchura;
    int altura;
    Espacio *espacios; //Memoria dinámica
    double pesoSoportado;
    double pesoActual;
};

#endif /* ESTANTE_H */

