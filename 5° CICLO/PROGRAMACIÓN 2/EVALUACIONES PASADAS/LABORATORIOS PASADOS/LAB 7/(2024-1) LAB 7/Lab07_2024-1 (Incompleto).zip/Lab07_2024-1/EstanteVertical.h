/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   EstanteVertical.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 12:17 AM
 */

#ifndef ESTANTEVERTICAL_H
#define ESTANTEVERTICAL_H

#include "Novela.h"
#include "Estante.h"


class EstanteVertical:public Estante {
public:
    EstanteVertical();
    EstanteVertical(const EstanteVertical& orig);
    virtual ~EstanteVertical();
    void SetCantidad_enciclopedias(int cantidad_enciclopedias);
    int GetCantidad_enciclopedias() const;
    void llena(EstanteVertical);
    void operator =(const EstanteVertical &);
    int devolverEspaciosRest(int,int);
    void imprimirEstanteVertical(ofstream &);
private:
    Novela *novelas;
    int cantidad_enciclopedias;
};

ifstream &operator >>(ifstream &,EstanteVertical &);

#endif /* ESTANTEVERTICAL_H */

