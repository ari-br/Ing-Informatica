/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Biblioteca.cpp
 * Author: Ariana
 * 
 * Created on 7 de noviembre de 2024, 12:21 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Biblioteca.h"

Biblioteca::Biblioteca() {
    estantesVerticales=nullptr;
    cantidad_estantes_verticales=0;
    estantesHorizontales=nullptr; 
    cantidad_estantes_horizontales=0;
    enciclopedias=nullptr;
    cantidad_total_enciclopedias=0;
    novelas=nullptr;
    cantidad_total_novelas=0;
}

Biblioteca::Biblioteca(const Biblioteca& orig) {
}

Biblioteca::~Biblioteca() {
    if(estantesVerticales!=nullptr) delete[] estantesVerticales;
    if(estantesHorizontales!=nullptr) delete[] estantesHorizontales;
    if(enciclopedias!=nullptr) delete[] enciclopedias;
    if(novelas!=nullptr) delete[] novelas;
}

void Biblioteca::SetCantidad_total_novelas(int cantidad_total_novelas) {
    this->cantidad_total_novelas = cantidad_total_novelas;
}

int Biblioteca::GetCantidad_total_novelas() const {
    return cantidad_total_novelas;
}

void Biblioteca::SetCantidad_total_enciclopedias(int cantidad_total_enciclopedias) {
    this->cantidad_total_enciclopedias = cantidad_total_enciclopedias;
}

int Biblioteca::GetCantidad_total_enciclopedias() const {
    return cantidad_total_enciclopedias;
}

void Biblioteca::SetCantidad_estantes_horizontales(int cantidad_estantes_horizontales) {
    this->cantidad_estantes_horizontales = cantidad_estantes_horizontales;
}

int Biblioteca::GetCantidad_estantes_horizontales() const {
    return cantidad_estantes_horizontales;
}

void Biblioteca::SetCantidad_estantes_verticales(int cantidad_estantes_verticales) {
    this->cantidad_estantes_verticales = cantidad_estantes_verticales;
}

int Biblioteca::GetCantidad_estantes_verticales() const {
    return cantidad_estantes_verticales;
}

void Biblioteca::cargar_libros(){
    ifstream arch("libros2.csv",ios::in);
    AperturaIf(arch,"libros2.csv");
    char tipo,c;
    Enciclopedia buffEnc[10];
    Novela buffNov[10];
    while(1){
        arch>>tipo>>c;
        if(arch.eof()) break;
        arch.get();
        cargarTipoLibro(arch,tipo,buffEnc,buffNov);
        arch.get();
    }
    enciclopedias=new Enciclopedia[cantidad_total_enciclopedias+1];
    novelas=new Novela[cantidad_total_novelas+1];
    for (int i = 0; i < cantidad_total_enciclopedias; i++)
        enciclopedias[i].llena(buffEnc[i]);
    for (int i = 0; i < cantidad_total_novelas; i++)
        novelas[i].llena(buffNov[i]);
}

void Biblioteca::cargarTipoLibro(ifstream &arch,char tipo,Enciclopedia *buffEnc,Novela *buffNov){
    if(tipo=='E'){
        arch>>buffEnc[cantidad_total_enciclopedias];
        cantidad_total_enciclopedias++;
    }
    if(tipo=='N'){
        arch>>buffNov[cantidad_total_novelas];
        cantidad_total_novelas++;
    }
}

void Biblioteca::cargar_estantes(){
    ifstream arch("estantes2.csv",ios::in);
    AperturaIf(arch,"estantes2.csv");
    char tipo,c;
    EstanteHorizontal buffHor[10];
    EstanteVertical buffVer[10];
    while(1){
        arch>>tipo>>c;
        if(arch.eof()) break;
        arch.get();
        cargarTipoEstante(arch,tipo,buffHor,buffVer);
        arch.get();
    }
    estantesHorizontales=new EstanteHorizontal[cantidad_estantes_horizontales+1];
    estantesVerticales=new EstanteVertical[cantidad_estantes_verticales+1];
    for (int i = 0; i < cantidad_estantes_horizontales; i++)
        estantesHorizontales[i].llena(buffHor[i]);
    for (int i = 0; i < cantidad_estantes_verticales; i++)
        estantesVerticales[i].llena(buffVer[i]);
}

void Biblioteca::cargarTipoEstante(ifstream &arch,char tipo,
        EstanteHorizontal *buffHor,EstanteVertical *buffVer){
    if(tipo=='H'){
        arch>>buffHor[cantidad_estantes_horizontales];
        cantidad_estantes_horizontales++;
    }
    if(tipo=='V'){
        arch>>buffVer[cantidad_estantes_verticales];
        cantidad_estantes_verticales++;
    }
}

void Biblioteca::posicionar_libros(){
    //Estantes verticales
    posicionar_enciclopedias();
    //Estantes horizontales
    posicionar_novelas();
}

void Biblioteca::posicionar_enciclopedias(){
    int espaciosRest,ancho,alto,cant;
    double pesoSop,pesoAct;
    for (int i = 0; i < cantidad_estantes_verticales; i++) {
        alto=estantesVerticales[i].GetAltura();
        ancho=estantesVerticales[i].GetAnchura();
        pesoSop=estantesVerticales[i].GetPesoSoportado();
        espaciosRest=estantesVerticales[i].
        devolverEspaciosRest(alto,ancho);
        cout<<espaciosRest<<endl;
        for (int k = 0; k < cantidad_total_enciclopedias; k++) {
            pesoAct=estantesVerticales[i].GetPesoActual();
            cant=estantesVerticales[i].GetCantidad_enciclopedias();
            if(espaciosRest>=enciclopedias[k].GetAlto() and
                ancho>=enciclopedias[k].GetAncho() and 
                pesoSop>=enciclopedias[k].GetPeso()+pesoAct){
                
                pesoAct+=enciclopedias[k].GetPeso();
                estantesVerticales[i].SetPesoActual(pesoAct);
                cant++;
                estantesVerticales[i].SetCantidad_enciclopedias(cant);
            }
        }
    }
}

void Biblioteca::posicionar_novelas(){
    for (int i = 0; i < cantidad_estantes_horizontales; i++) {
        for (int k = 0; k < cantidad_total_novelas; k++) {
            
        }
    }
}

void Biblioteca::mostrar_datos(){
    ofstream arch("ReporteEstantes.txt",ios::out);
    AperturaOf(arch,"ReporteEstantes.txt");
    arch<<setprecision(2)<<fixed;
    imprimirLinea(arch,61,'=');
    arch<<setw(10)<<" "<<"Informacion del posicionamiento de Libros"<<endl;
    arch<<setw(14)<<" "<<"en los estantes de la Biblioteca"<<endl;
    imprimirLinea(arch,61,'=');
    arch<<"Cantidad de estantes: "<<cantidad_estantes_horizontales+cantidad_estantes_verticales<<endl;
    char cod[10];
    
    for (int i = 0; i < cantidad_estantes_verticales; i++) {
        imprimirLinea(arch,61,'-');
        estantesVerticales[i].GetCodigo(cod);
        imprimirEstante(arch,cod,estantesVerticales[i].GetAnchura(),
            estantesVerticales[i].GetAltura(),'V',
            estantesVerticales[i].GetCantidad_enciclopedias(),
            estantesVerticales[i].GetPesoSoportado(),
            estantesVerticales[i].GetPesoActual());
        estantesVerticales[i].imprimirEstanteVertical(arch);
    }

}

void Biblioteca::imprimirEstante(ofstream &arch,char *cod,int anchura,
        int altura,char tipo,int cant,double pesoSop,double pesoTotal){
    arch<<"Codigo Estante: "<<left<<setw(15)<<cod<<"Cantidad de libros: "<<cant
        <<endl;
    arch<<"Altura x Anchura: "<<left<<altura<<" x "<<setw(9)<<anchura
        <<"Peso Maximo:"<<right<<setw(6)<<pesoSop<<" Kg"<<endl;
     arch<<"Altura x Anchura: "<<left<<setw(13);
    if(tipo=='V') arch<<"Vertical";
    if(tipo=='H') arch<<"Horizontal";
    arch<<"Peso Total:"<<right<<setw(6)<<pesoTotal<<" Kg"<<endl;
    imprimirLinea(arch,61,'-');
    arch<<endl;
}

void Biblioteca::imprimirLinea(ofstream &arch,int max,char c){
    for (int i = 0; i < max; i++) arch<<c;
    arch<<endl;
}

void Biblioteca::AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void Biblioteca::AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}