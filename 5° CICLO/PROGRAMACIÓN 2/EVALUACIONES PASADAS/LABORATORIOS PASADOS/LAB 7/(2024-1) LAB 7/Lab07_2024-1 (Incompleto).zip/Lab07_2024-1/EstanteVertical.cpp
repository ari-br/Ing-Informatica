/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   EstanteVertical.cpp
 * Author: Ariana
 * 
 * Created on 7 de noviembre de 2024, 12:17 AM
 */
#include <iostream>
using namespace std;
#include "EstanteVertical.h"

EstanteVertical::EstanteVertical() {
    novelas=nullptr;
    cantidad_enciclopedias=0;
}

EstanteVertical::EstanteVertical(const EstanteVertical& orig) {
    novelas=nullptr;
    *this=orig;
}

EstanteVertical::~EstanteVertical() {
    if(novelas!=nullptr) delete[] novelas;
}

void EstanteVertical::SetCantidad_enciclopedias(int cantidad_enciclopedias) {
    this->cantidad_enciclopedias = cantidad_enciclopedias;
}

int EstanteVertical::GetCantidad_enciclopedias() const {
    return cantidad_enciclopedias;
}

int EstanteVertical::devolverEspaciosRest(int altura,int ancho){
    int espRest=0,hor=0,ver=0;
    contarEspacios(hor,ver,ancho,altura,'V');
    cout<<ver<<" "<<altura<<endl;
    espRest=altura-ver;
    return espRest;
}

void EstanteVertical::imprimirEstanteVertical(ofstream &arch){
    imprimirEstante(arch,GetAnchura(),GetAltura(),'V');
}

void EstanteVertical::operator =(const EstanteVertical &f){
    SetPesoSoportado(f.GetPesoSoportado());
    SetAltura(f.GetAltura());
    SetAnchura(f.GetAnchura());
    char cad[100];
    f.GetCodigo(cad);
    SetCodigo(cad);
}

void EstanteVertical::llena(EstanteVertical f){
    SetPesoSoportado(f.GetPesoSoportado());
    SetAltura(f.GetAltura());
    SetAnchura(f.GetAnchura());
    char cad[100];
    f.GetCodigo(cad);
    SetCodigo(cad);
    crearEspacios(f.GetAltura(),f.GetAnchura(),'V');
}

ifstream &operator >>(ifstream &arch,EstanteVertical &f){
    char cad[10],c;
    int ancho,alto;
    double peso;
    
    arch.getline(cad,10,',');
    if(!arch.eof()){
        f.SetCodigo(cad);
        arch>>ancho>>c>>alto>>c>>peso;
        f.SetAnchura(ancho);
        f.SetAltura(alto);
        f.SetPesoSoportado(peso);
    }
    return arch;
}

