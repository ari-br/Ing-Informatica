/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Biblioteca.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 12:21 AM
 */

#ifndef BIBLIOTECA_H
#define BIBLIOTECA_H

#include "EstanteVertical.h"
#include "EstanteHorizontal.h"
#include "Enciclopedia.h"
#include "Novela.h"


class Biblioteca {
public:
    Biblioteca();
    Biblioteca(const Biblioteca& orig);
    virtual ~Biblioteca();
    void SetCantidad_total_novelas(int cantidad_total_novelas);
    int GetCantidad_total_novelas() const;
    void SetCantidad_total_enciclopedias(int cantidad_total_enciclopedias);
    int GetCantidad_total_enciclopedias() const;
    void SetCantidad_estantes_horizontales(int cantidad_estantes_horizontales);
    int GetCantidad_estantes_horizontales() const;
    void SetCantidad_estantes_verticales(int cantidad_estantes_verticales);
    int GetCantidad_estantes_verticales() const;
    void cargar_libros();
    void cargar_estantes();
    void posicionar_libros();
    void mostrar_datos();
private:
    EstanteVertical *estantesVerticales; //Memoria dinámica exacta
    int cantidad_estantes_verticales;
    EstanteHorizontal *estantesHorizontales; //Memoria dinámica exacta
    int cantidad_estantes_horizontales;
    Enciclopedia *enciclopedias; //Memoria dinámica exacta
    int cantidad_total_enciclopedias;
    Novela *novelas; //Memoria dinámica exacta
    int cantidad_total_novelas;
    void cargarTipoLibro(ifstream &,char,Enciclopedia *,Novela *);
    void cargarTipoEstante(ifstream &,char,EstanteHorizontal *,
            EstanteVertical *);
    void posicionar_enciclopedias();
    void posicionar_novelas();
    void imprimirEstante(ofstream &arch,char *cod,int anchura,int altura,char tipo,int cant,
        double pesoSop,double pesoTotal);
    void imprimirLinea(ofstream &,int,char);
    void AperturaIf(ifstream &,const char *);
    void AperturaOf(ofstream &,const char *);
};

#endif /* BIBLIOTECA_H */

