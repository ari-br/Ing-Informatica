/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Enciclopedia.h
 * Author: Ariana
 *
 * Created on 6 de noviembre de 2024, 09:44 PM
 */

#ifndef ENCICLOPEDIA_H
#define ENCICLOPEDIA_H

#include <fstream>
using namespace std;
#include "Libro.h"

class Enciclopedia:public Libro {
public:
    Enciclopedia();
    Enciclopedia(const Enciclopedia& orig);
    virtual ~Enciclopedia();
    void SetPeso(double peso);
    double GetPeso() const;
    void SetVolumen(int volumen);
    int GetVolumen() const;
    void operator =(const Enciclopedia &);
    void llena(Enciclopedia );
private:
    int volumen;
    double peso;
};

ifstream &operator >>(ifstream &,Enciclopedia &);


#endif /* ENCICLOPEDIA_H */

