/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   PrioridadMedia.cpp
 * Author: Ariana
 * 
 * Created on 7 de noviembre de 2024, 07:57 AM
 */

#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "PrioridadMedia.h"

PrioridadMedia::PrioridadMedia() {
    descripcion=nullptr;
    nueva_fecha_entrega=0;
}

PrioridadMedia::PrioridadMedia(const PrioridadMedia& orig) {
    descripcion=nullptr;
    *this=orig;
}

PrioridadMedia::~PrioridadMedia() {
    if(descripcion!=nullptr) delete descripcion;
}

void PrioridadMedia::SetNueva_fecha_entrega(int nueva_fecha_entrega) {
    this->nueva_fecha_entrega = nueva_fecha_entrega;
}

int PrioridadMedia::GetNueva_fecha_entrega() const {
    return nueva_fecha_entrega;
}

void PrioridadMedia::SetDescripcion(char *cad){
    if(descripcion!=nullptr) delete descripcion;
    descripcion=new char[strlen(cad)+1];
    strcpy(descripcion,cad);
}

void PrioridadMedia::GetDescripcion(char *cad) const{
    if(descripcion!=nullptr)
        strcpy(cad,descripcion);
}

void PrioridadMedia::operator =(const PrioridadMedia &f){
    char cad[10];
    SetNueva_fecha_entrega(f.GetNueva_fecha_entrega());
    f.GetCodido(cad);
    SetCodido(cad);
    SetDni_cliente(f.GetDni_cliente());
    SetSubtotal(f.GetSubtotal());
    SetFecha(f.GetFecha());
    SetEstado(f.GetEstado());
    SetTotal(f.GetTotal());
}

void PrioridadMedia::llena(PrioridadMedia f){
    char cad[10];
    SetNueva_fecha_entrega(f.GetNueva_fecha_entrega());
    f.GetCodido(cad);
    SetCodido(cad);
    SetDni_cliente(f.GetDni_cliente());
    SetSubtotal(f.GetSubtotal());
    SetFecha(f.GetFecha());
    SetEstado(f.GetEstado());
    SetTotal(f.GetTotal());
}

bool PrioridadMedia::tieneDescripcion(){
    if(descripcion!=nullptr) return true;
    return false;
}

ifstream &operator >>(ifstream &arch,PrioridadMedia &f){
    char cad[10],c;
    int codCli,dd,mm,aa,fecha,estado;
    double subtotal;
    arch.getline(cad,10,',');
    if(!arch.eof()){
        arch>>codCli>>c>>subtotal>>c>>aa>>c>>mm>>c>>dd>>c>>estado;
        fecha=(aa*10000)+(mm*100)+dd;
        f.SetCodido(cad);
        f.SetDni_cliente(codCli);
        f.SetSubtotal(subtotal);
        f.SetFecha(fecha);
        f.SetEstado(estado);
    }
    return arch;
}

ofstream &operator <<(ofstream &arch,PrioridadMedia &f){
    char cad[100];
    int dd,mm,aa;
    f.GetCodido(cad);
    dd=f.GetFecha()%100;
    mm=(f.GetFecha()/100)%100;
    aa=f.GetFecha()/10000;
    
    arch<<left<<setw(10)<<cad<<setw(14)<<f.GetDni_cliente()<<setfill('0')
        <<right<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<aa<<setfill(' ')<<setw(10)
        <<" ";
    
    dd=f.GetNueva_fecha_entrega()%100;
    mm=(f.GetNueva_fecha_entrega()/100)%100;
    aa=f.GetNueva_fecha_entrega()/10000;
    arch<<setfill('0')<<right<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<setw(4)<<aa
        <<setfill(' ')<<setw(11)<<f.GetEstado()<<setw(16)<<f.GetTotal()<<setw(5)<<" ";
    
    if(f.tieneDescripcion()){
        f.GetDescripcion(cad);
        arch<<cad;
    }
    arch<<endl;
    
    return arch;
}

