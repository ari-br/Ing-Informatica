/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Almacen.cpp
 * Author: Ariana
 * 
 * Created on 7 de noviembre de 2024, 08:08 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Almacen.h"

Almacen::Almacen() {
    ordenesPriAlta=nullptr;
    cantPriAlta=0;
    ordenesPriMedia=nullptr;
    cantPriMedia=0;
    ordenesPriBaja=nullptr;
    cantPriBaja=0;
}

Almacen::Almacen(const Almacen& orig) {
}

Almacen::~Almacen() {
    if(ordenesPriAlta!=nullptr) delete[] ordenesPriAlta;
    if(ordenesPriMedia!=nullptr) delete[] ordenesPriMedia;
    if(ordenesPriBaja!=nullptr) delete[] ordenesPriBaja;
}

void Almacen::SetCantPriBaja(int cantPriBaja) {
    this->cantPriBaja = cantPriBaja;
}

int Almacen::GetCantPriBaja() const {
    return cantPriBaja;
}

void Almacen::SetCantPriMedia(int cantPriMedia) {
    this->cantPriMedia = cantPriMedia;
}

int Almacen::GetCantPriMedia() const {
    return cantPriMedia;
}

void Almacen::SetCantPriAlta(int cantPriAlta) {
    this->cantPriAlta = cantPriAlta;
}

int Almacen::GetCantPriAlta() const {
    return cantPriAlta;
}

void Almacen::cargar_pedidos(){
    ifstream arch("Pedidos.csv",ios::in);
    AperturaIf(arch,"Pedidos.csv");
    
    PrioridadAlta buffAlta[600];
    PrioridadMedia buffMedia[600];
    PrioridadBaja buffBaja[600];
    char tipo,c;
    while(1){
        arch>>tipo>>c;
        if(arch.eof()) break;
        cargarPedidoPrioridad(arch,tipo,buffAlta,buffMedia,buffBaja);
    }
    ordenesPriAlta=new PrioridadAlta[cantPriAlta+1];
    ordenesPriMedia=new PrioridadMedia[cantPriMedia+1];
    ordenesPriBaja=new PrioridadBaja[cantPriBaja+1];
    cargarPrioridades(ordenesPriAlta,ordenesPriMedia,ordenesPriBaja,
        buffAlta,buffMedia,buffBaja);
}

void Almacen::cargarPrioridades(PrioridadAlta *ordenesPriAlta,
        PrioridadMedia *ordenesPriMedia,PrioridadBaja *ordenesPriBaja,
        PrioridadAlta *buffAlta,PrioridadMedia *buffMedia,
        PrioridadBaja *buffBaja){
    for (int i = 0; i < cantPriAlta; i++)
        ordenesPriAlta[i].llena(buffAlta[i]);
    for (int i = 0; i < cantPriMedia; i++)
        ordenesPriMedia[i].llena(buffMedia[i]);
    for (int i = 0; i < cantPriBaja; i++)
        ordenesPriBaja[i].llena(buffBaja[i]);
}

void Almacen::cargarPedidoPrioridad(ifstream &arch,char tipo,PrioridadAlta *buffAlta,
    PrioridadMedia *buffMedia,PrioridadBaja *buffBaja){
    if(tipo=='A'){
        arch>>buffAlta[cantPriAlta];
        cantPriAlta++;
    }
    if(tipo=='M'){
        arch>>buffMedia[cantPriMedia];
        cantPriMedia++;
    }
    if(tipo=='B'){
        arch>>buffBaja[cantPriBaja];
        cantPriBaja++;
    }
}

void Almacen::actualizar_pedidos(){
    for (int i = 0; i < cantPriAlta; i++)
        ordenesPriAlta[i].actualiza();
    for (int i = 0; i < cantPriMedia; i++)
        ordenesPriMedia[i].actualiza();
    for (int i = 0; i < cantPriBaja; i++)
        ordenesPriBaja[i].actualiza();
}

void Almacen::imprimir_ordenes_venta(){
    ofstream arch("ReporteOrdenes.txt",ios::out);
    AperturaOf(arch,"ReporteOrdenes.txt");
    arch<<setprecision(2)<<fixed;
    arch<<right<<setw(70)<<"ORDENES DE VENTA"<<endl;
    imprimirLinea(arch,120,'=');
    
    arch<<"Prioridad: ALTA"<<endl;
    imprimirLinea(arch,120,'-');
    imprimirEncOrdenes(arch,'A');
    for (int i = 0; i < cantPriAlta; i++) arch<<ordenesPriAlta[i];
    imprimirLinea(arch,120,'=');
    
    arch<<"Prioridad: MEDIA"<<endl;
    imprimirLinea(arch,120,'-');
    imprimirEncOrdenes(arch,'M');
    for (int i = 0; i < cantPriMedia; i++) arch<<ordenesPriMedia[i];
    imprimirLinea(arch,120,'=');
    
    arch<<"Prioridad: BAJA"<<endl;
    imprimirLinea(arch,120,'-');
    imprimirEncOrdenes(arch,'B');
    for (int i = 0; i < cantPriBaja; i++) arch<<ordenesPriBaja[i];
    imprimirLinea(arch,120,'=');
}

void Almacen::imprimirEncOrdenes(ofstream &arch,char pri){
    arch<<left<<setw(10)<<"Codigo"<<setw(11)<<"DNI";
    
    if(pri=='A'){
        arch<<setw(30)<<"Fecha de Pedido y Entrega"<<setw(15)<<"Subtotal"
            <<setw(15)<<"Recargo"<<"Total";
    }
    if(pri=='M'){
        arch<<setw(20)<<"Fecha de Pedido"<<setw(20)<<"Fecha de Entrega"
            <<setw(15)<<"Estado"<<setw(10)<<"Total"
            <<"Descripcion";
    }
    if(pri=='B'){
        arch<<setw(20)<<"Fecha de Pedido"<<setw(21)<<"Fecha de Entrega"
            <<"Total";;
    }
    arch<<endl;
    imprimirLinea(arch,120,'-');
}

void Almacen::imprimirLinea(ofstream &arch,int max,char c){
    for (int i = 0; i < max; i++) arch<<c;
    arch<<endl;
}

void Almacen::AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void Almacen::AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}