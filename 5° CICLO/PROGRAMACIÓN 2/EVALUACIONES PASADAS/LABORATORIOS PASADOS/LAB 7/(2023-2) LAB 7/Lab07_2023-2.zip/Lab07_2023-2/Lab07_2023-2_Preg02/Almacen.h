/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Almacen.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 08:08 AM
 */

#ifndef ALMACEN_H
#define ALMACEN_H

#include "PrioridadAlta.h"
#include "PrioridadMedia.h"
#include "PrioridadBaja.h"


class Almacen {
public:
    Almacen();
    Almacen(const Almacen& orig);
    virtual ~Almacen();
    void SetCantPriBaja(int cantPriBaja);
    int GetCantPriBaja() const;
    void SetCantPriMedia(int cantPriMedia);
    int GetCantPriMedia() const;
    void SetCantPriAlta(int cantPriAlta);
    int GetCantPriAlta() const;
    void cargar_pedidos();
    void actualizar_pedidos();
    void imprimir_ordenes_venta();
private:
    PrioridadAlta *ordenesPriAlta;      //Memoria dinámica exacta
    int cantPriAlta;
    PrioridadMedia *ordenesPriMedia;    //Memoria dinámica exacta
    int cantPriMedia;
    PrioridadBaja *ordenesPriBaja;      //Memoria dinámica exacta
    int cantPriBaja;
    void cargarPedidoPrioridad(ifstream &,char,PrioridadAlta *,PrioridadMedia *,
    PrioridadBaja *);
    void cargarPrioridades(PrioridadAlta *,PrioridadMedia *,PrioridadBaja *,
    PrioridadAlta *,PrioridadMedia *,PrioridadBaja *);
    void imprimirEncOrdenes(ofstream &,char);
    void imprimirLinea(ofstream &,int,char);
    void AperturaIf(ifstream &,const char *);
    void AperturaOf(ofstream &,const char *);
};

#endif /* ALMACEN_H */

