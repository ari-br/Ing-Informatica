/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   PrioridadBaja.cpp
 * Author: Ariana
 * 
 * Created on 7 de noviembre de 2024, 08:01 AM
 */
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "PrioridadBaja.h"

PrioridadBaja::PrioridadBaja() {
    dias_espera=0;
    nueva_fecha_entrega=0;
}

PrioridadBaja::PrioridadBaja(const PrioridadBaja& orig) {
    *this=orig;
}

PrioridadBaja::~PrioridadBaja() {
}

void PrioridadBaja::SetNueva_fecha_entrega(int nueva_fecha_entrega) {
    this->nueva_fecha_entrega = nueva_fecha_entrega;
}

int PrioridadBaja::GetNueva_fecha_entrega() const {
    return nueva_fecha_entrega;
}

void PrioridadBaja::SetDias_espera(int dias_espera) {
    this->dias_espera = dias_espera;
}

int PrioridadBaja::GetDias_espera() const {
    return dias_espera;
}

void PrioridadBaja::operator =(const PrioridadBaja &f){
    char cad[10];
    SetNueva_fecha_entrega(f.GetNueva_fecha_entrega());
    SetDias_espera(f.GetDias_espera());
    f.GetCodido(cad);
    SetCodido(cad);
    SetDni_cliente(f.GetDni_cliente());
    SetSubtotal(f.GetSubtotal());
    SetFecha(f.GetFecha());
    SetEstado(f.GetEstado());
    SetTotal(f.GetTotal());
}

void PrioridadBaja::llena(PrioridadBaja f){
    char cad[10];
    SetNueva_fecha_entrega(f.GetNueva_fecha_entrega());
    SetDias_espera(f.GetDias_espera());
    f.GetCodido(cad);
    SetCodido(cad);
    SetDni_cliente(f.GetDni_cliente());
    SetSubtotal(f.GetSubtotal());
    SetFecha(f.GetFecha());
    SetEstado(f.GetEstado());
    SetTotal(f.GetTotal());
}

ifstream &operator >>(ifstream &arch,PrioridadBaja &f){
    char cad[10],c;
    int codCli,dd,mm,aa,fecha,dias;
    double subtotal;
    arch.getline(cad,10,',');
    if(!arch.eof()){
        arch>>codCli>>c>>subtotal>>c>>aa>>c>>mm>>c>>dd>>c>>dias;
        fecha=(aa*10000)+(mm*100)+dd;
        f.SetCodido(cad);
        f.SetDni_cliente(codCli);
        f.SetSubtotal(subtotal);
        f.SetFecha(fecha);
        f.SetDias_espera(dias);
    }
    return arch;
}

ofstream &operator <<(ofstream &arch,PrioridadBaja &f){
    char cad[100];
    int dd,mm,aa;
    f.GetCodido(cad);
    dd=f.GetFecha()%100;
    mm=(f.GetFecha()/100)%100;
    aa=f.GetFecha()/10000;
    
    arch<<left<<setw(10)<<cad<<setw(14)<<f.GetDni_cliente()<<setfill('0')
        <<right<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<aa<<setfill(' ')<<setw(10)
        <<" ";
    
    dd=f.GetNueva_fecha_entrega()%100;
    mm=(f.GetNueva_fecha_entrega()/100)%100;
    aa=f.GetNueva_fecha_entrega()/10000;
    arch<<setfill('0')<<right<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<setw(4)<<aa
        <<setfill(' ')<<setw(13)<<f.GetTotal()<<endl;
    
    return arch;
}