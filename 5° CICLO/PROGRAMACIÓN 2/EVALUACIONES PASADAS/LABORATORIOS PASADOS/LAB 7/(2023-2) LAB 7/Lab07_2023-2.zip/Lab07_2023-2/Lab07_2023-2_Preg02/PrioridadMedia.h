/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   PrioridadMedia.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 07:57 AM
 */

#ifndef PRIORIDADMEDIA_H
#define PRIORIDADMEDIA_H

#include "Pedido.h"


class PrioridadMedia:public Pedido {
public:
    PrioridadMedia();
    PrioridadMedia(const PrioridadMedia& orig);
    virtual ~PrioridadMedia();
    void SetNueva_fecha_entrega(int nueva_fecha_entrega);
    int GetNueva_fecha_entrega() const;
    void SetDescripcion(char *cad);
    void GetDescripcion(char *cad) const;
    void operator =(const PrioridadMedia &);
    void llena(PrioridadMedia);
    bool tieneDescripcion();
    void actualiza();
private:
    char *descripcion;
    int nueva_fecha_entrega;
};

ifstream &operator >>(ifstream &,PrioridadMedia &);
ofstream &operator <<(ofstream &,PrioridadMedia &);

#endif /* PRIORIDADMEDIA_H */

