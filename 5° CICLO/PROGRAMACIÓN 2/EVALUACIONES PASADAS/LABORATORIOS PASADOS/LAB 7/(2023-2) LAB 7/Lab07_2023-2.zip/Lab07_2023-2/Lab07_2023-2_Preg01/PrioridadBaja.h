/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   PrioridadBaja.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 08:01 AM
 */

#ifndef PRIORIDADBAJA_H
#define PRIORIDADBAJA_H

#include "Pedido.h"


class PrioridadBaja:public Pedido {
public:
    PrioridadBaja();
    PrioridadBaja(const PrioridadBaja& orig);
    virtual ~PrioridadBaja();
    void SetNueva_fecha_entrega(int nueva_fecha_entrega);
    int GetNueva_fecha_entrega() const;
    void SetDias_espera(int dias_espera);
    int GetDias_espera() const;
    void operator =(const PrioridadBaja &);
    void llena(PrioridadBaja);
private:
    int dias_espera;
    int nueva_fecha_entrega;
};

ifstream &operator >>(ifstream &,PrioridadBaja &);
ofstream &operator <<(ofstream &,PrioridadBaja &);

#endif /* PRIORIDADBAJA_H */

