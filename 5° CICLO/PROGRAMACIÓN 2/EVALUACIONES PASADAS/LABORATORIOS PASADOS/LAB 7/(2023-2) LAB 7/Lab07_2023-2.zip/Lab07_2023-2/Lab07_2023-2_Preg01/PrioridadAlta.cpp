/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   PrioridadAlta.cpp
 * Author: Ariana
 * 
 * Created on 7 de noviembre de 2024, 07:54 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "PrioridadAlta.h"

PrioridadAlta::PrioridadAlta() {
    recargo=0;
    total=0;
}

PrioridadAlta::PrioridadAlta(const PrioridadAlta& orig) {
    *this=orig;
}

PrioridadAlta::~PrioridadAlta() {
}

void PrioridadAlta::SetTotal(double total) {
    this->total = total;
}

double PrioridadAlta::GetTotal() const {
    return total;
}

void PrioridadAlta::SetRecargo(double recargo) {
    this->recargo = recargo;
}

double PrioridadAlta::GetRecargo() const {
    return recargo;
}

void PrioridadAlta::operator =(const PrioridadAlta &f){
    char cad[10];
    recargo=f.GetRecargo();
    total=f.GetTotal();
    f.GetCodido(cad);
    SetCodido(cad);
    SetDni_cliente(f.GetDni_cliente());
    SetSubtotal(f.GetSubtotal());
    SetFecha(f.GetFecha());
    SetEstado(f.GetEstado());
    SetTotal(f.GetTotal());
}

void PrioridadAlta::llena(PrioridadAlta f){
    char cad[10];
    recargo=f.GetRecargo();
    total=f.GetTotal();
    f.GetCodido(cad);
    SetCodido(cad);
    SetDni_cliente(f.GetDni_cliente());
    SetSubtotal(f.GetSubtotal());
    SetFecha(f.GetFecha());
    SetEstado(f.GetEstado());
    SetTotal(f.GetTotal());
}

ifstream &operator >>(ifstream &arch,PrioridadAlta &f){
    char cad[10],c;
    int codCli,dd,mm,aa,fecha,recargo;
    double subtotal;
    arch.getline(cad,10,',');
    if(!arch.eof()){
        arch>>codCli>>c>>subtotal>>c>>aa>>c>>mm>>c>>dd>>c>>recargo;
        fecha=(aa*10000)+(mm*100)+dd;
        f.SetCodido(cad);
        f.SetDni_cliente(codCli);
        f.SetSubtotal(subtotal);
        f.SetFecha(fecha);
        f.SetRecargo(recargo);
    }
    return arch;
}

ofstream &operator <<(ofstream &arch,PrioridadAlta &f){
    char cad[10];
    int dd,mm,aa;
    f.GetCodido(cad);
    dd=f.GetFecha()%100;
    mm=(f.GetFecha()/100)%100;
    aa=f.GetFecha()/10000;
    
    arch<<left<<setw(10)<<cad<<setw(18)<<f.GetDni_cliente()<<setfill('0')
        <<right<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<aa<<setfill(' ')<<setw(21)
        <<f.GetSubtotal()<<setw(13)<<f.GetRecargo()<<"%"
        <<right<<setw(13)<<f.GetTotal()<<endl;
    
    return arch;
}