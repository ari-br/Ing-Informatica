/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   PrioridadAlta.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 07:54 AM
 */

#ifndef PRIORIDADALTA_H
#define PRIORIDADALTA_H

#include "Pedido.h"


class PrioridadAlta:public Pedido {
public:
    PrioridadAlta();
    PrioridadAlta(const PrioridadAlta& orig);
    virtual ~PrioridadAlta();
    void SetTotal(double total);
    double GetTotal() const;
    void SetRecargo(double recargo);
    double GetRecargo() const;
    void operator =(const PrioridadAlta &);
    void llena(PrioridadAlta);
private:
    double recargo;
    double total;
};

ifstream &operator >>(ifstream &,PrioridadAlta &);
ofstream &operator <<(ofstream &,PrioridadAlta &);

#endif /* PRIORIDADALTA_H */

