/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Pedido.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 07:37 AM
 */

#ifndef PEDIDO_H
#define PEDIDO_H

class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetTotal(double total);
    double GetTotal() const;
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetSubtotal(double subtotal);
    double GetSubtotal() const;
    void SetDni_cliente(int dni_cliente);
    int GetDni_cliente() const;
    void SetCodido(char *cad);
    void GetCodido(char *cad) const;
    void SetEstado(int estado);
    int GetEstado() const;
private:
    char *codigo;
    int dni_cliente;
    double subtotal;
    int fecha;
    int estado;
    double total;
};

#endif /* PEDIDO_H */

