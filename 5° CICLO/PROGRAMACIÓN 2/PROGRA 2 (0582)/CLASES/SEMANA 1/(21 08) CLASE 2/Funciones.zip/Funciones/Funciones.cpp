/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones.cpp
 * Author: cueva.r
 * 
 * Created on 21 de agosto de 2024, 10:12 AM
 */

#include "Funciones.h"
#include "Estructura.h"

double promedio(int a, int b, int c){
    
    return (double)(a+b+c)/3;
}

double promedio(strnotas nota){
    double prom=0;
    for(int i=0;i<nota.n;i++){
        prom+=nota.lab[i];
    }
    return prom/nota.n;
}
