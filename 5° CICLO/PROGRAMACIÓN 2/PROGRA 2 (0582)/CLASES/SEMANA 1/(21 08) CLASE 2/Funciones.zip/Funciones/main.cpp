/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 20 de agosto de 2024, 11:14 AM
 */

#include <iostream>
#include "sobrecarga.h"
#include "Estructura.h"
#include "Funciones.h"

using namespace std;

int main(int argc, char** argv) {
    
    strnotas notas={{10,10,5,8,9},5};
    strnotas notas2={{20,20,15,20,20},5};
    
    cout << notas << notas2 << endl;
    notas*=2;
    cout << notas;
    
    cout << promedio(10,8,15) << endl;
    cout << promedio(notas);
    
    return 0;
}

