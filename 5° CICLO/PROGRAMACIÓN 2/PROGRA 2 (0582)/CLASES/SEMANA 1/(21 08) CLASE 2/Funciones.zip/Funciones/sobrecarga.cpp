/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   sobrecarga.cpp
 * Author: cueva.r
 * 
 * Created on 20 de agosto de 2024, 11:29 AM
 */
#include <iomanip>
#include <iostream>
#include "sobrecarga.h"
#include "Estructura.h"

using namespace std;

ostream & operator <<(ostream &out,strnotas &nota){
    for(int i=0;i<nota.n;i++)
        out << setw(5)<< nota.lab[i];
        
    out << endl;
    return out;
} 

void operator*=(strnotas &nota,int inc){
    
    for(int i=0;i<nota.n;i++)
        nota.lab[i]+=inc;    
    
}



