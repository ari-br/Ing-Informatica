/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   sobrecarga.h
 * Author: cueva.r
 *
 * Created on 20 de agosto de 2024, 11:29 AM
 */

#ifndef SOBRECARGA_H
#define SOBRECARGA_H
#include <iostream>
#include "Estructura.h"

using namespace std;

    ostream & operator <<(ostream &,strnotas &);
    void operator*=(strnotas &nota,int inc);
  
    
    
#endif /* SOBRECARGA_H */
