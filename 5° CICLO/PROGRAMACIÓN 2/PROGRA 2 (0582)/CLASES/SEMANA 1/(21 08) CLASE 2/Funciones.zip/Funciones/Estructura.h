/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Estructura.h
 * Author: cueva.r
 *
 * Created on 20 de agosto de 2024, 11:16 AM
 */

#ifndef ESTRUCTURA_H
#define ESTRUCTURA_H

struct strnotas{
    int lab[10];
    int n;
};


#endif /* ESTRUCTURA_H */

