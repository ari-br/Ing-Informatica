/* 
 * File:   Cliente.cpp
 * Author: cueva.r
 * 
 * Created on 22 de octubre de 2024, 10:29 AM
 */
#include <iostream>
#include <fstream>
#include <cstring>
#include "Cliente.h"

using namespace std;


Cliente::Cliente() {
    dni=0;
    nombre=nullptr; 
}

Cliente::Cliente(const Cliente& orig) {
}

Cliente::~Cliente() {
}

void Cliente::SetCategoria(char categoria) {
    this->categoria = categoria;
}

char Cliente::GetCategoria() const {
    return categoria;
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

void Cliente::SetNombre(char*cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}
void Cliente::GetNombre(char* cad){
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

/*
 71984468,IPARRAGUIRRE VILLEGAS NICOLAS EDILBERTO,A
29847168,ALDAVE ZEVALLOS ROSARIO,A
 */

ifstream &operator>>(ifstream &arch,Cliente &f){
    char cad[100],c;
    int coddni;
    
    arch >> coddni;
    if(!arch.eof()){
        arch.get();
        f.SetDni(coddni);
        arch.getline(cad,100,',');
        f.SetNombre(cad);
        arch >> c;
        f.SetCategoria(c);
    }
    return arch;
}