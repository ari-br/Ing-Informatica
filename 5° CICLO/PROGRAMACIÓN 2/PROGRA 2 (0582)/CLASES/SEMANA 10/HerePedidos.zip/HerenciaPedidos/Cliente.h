/* 
 * File:   Cliente.h
 * Author: cueva.r
 *
 * Created on 22 de octubre de 2024, 10:29 AM
 */

#ifndef CLIENTE_H
#define CLIENTE_H
#include <fstream>

using namespace std;

class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    void SetCategoria(char categoria);
    char GetCategoria() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetNombre(char*);
    void GetNombre(char*);
    
private:
    int dni;
    char categoria;
    char *nombre;
    
    
};
ifstream &operator>>(ifstream&,Cliente &);
#endif /* CLIENTE_H */

