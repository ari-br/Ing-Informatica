/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 22 de octubre de 2024, 10:28 AM
 */


#include "Tienda.h"

using namespace std;

int main(int argc, char** argv) {
    Tienda tien;
    
    tien.carga();
    tien.actualiza(20);
    tien.muestra();

    return 0;
}

