/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tienda.cpp
 * Author: cueva.r
 * 
 * Created on 22 de octubre de 2024, 10:55 AM
 */
#include <iostream>
#include <fstream>
#include <cstring>
#include "Tienda.h"

using namespace std;

Tienda::Tienda() {
}

Tienda::Tienda(const Tienda& orig) {
}

Tienda::~Tienda() {
}

void Tienda::carga(){
    int i=0;
    ifstream arch("pedidos3.csv",ios::in);
    if(!arch){
        cout <<"No se puede abrir el archivo de pedidos";
        exit(1);
    }
    while(1){
        arch >> lpedido[i];
        if(arch.eof())break;
        i++;
    }
    cargaclientes();
}

void Tienda::cargaclientes(){
    int i=0;
    ifstream arch("clientes2.csv",ios::in);
    if(!arch){
        cout <<"No se puede abrir el archivo de clientes";
        exit(1);
    }   
    while(1){
        arch >> lcliente[i];
        if(arch.eof()) break;
        i++;
    }
}


void Tienda::muestra(){
    int i=0;
    ofstream arch("reporte.txt",ios::out);
    if(!arch){
        cout <<"No se puede abrir el archivo de reporte";
        exit(1);
    }  
    while(lpedido[i].GetDni()){
        arch << lpedido[i];
        i++;
    }
}




void Tienda::actualiza(int cantidad){
    char tipo;
    for(int i=0;lpedido[i].GetDni();i++){
        if(lpedido[i].GetCodprod()/100000==4 
                and lpedido[i].GetStock()>=cantidad){
            tipo=buscatipocliente(lpedido[i].GetDni());
            lpedido[i].actualizadescuento(tipo);
        }
    }
}

char Tienda::buscatipocliente(int dni){
    
    for(int i=0;lcliente[i].GetDni();i++)
        if(dni==lcliente[i].GetDni())
            return lcliente[i].GetCategoria();
}

