/* 
 * File:   Tienda.h
 * Author: cueva.r
 *
 * Created on 22 de octubre de 2024, 10:55 AM
 */

#ifndef TIENDA_H
#define TIENDA_H

#include "Pedido.h"
#include "Cliente.h"

class Tienda {
public:
    Tienda();
    Tienda(const Tienda& orig);
    virtual ~Tienda();
    void carga();
    void muestra();
    void actualiza(int );
private:
    Pedido lpedido[200];
    Cliente lcliente[100];
    
    void cargaclientes();
    char buscatipocliente(int );
};

#endif /* TIENDA_H */

