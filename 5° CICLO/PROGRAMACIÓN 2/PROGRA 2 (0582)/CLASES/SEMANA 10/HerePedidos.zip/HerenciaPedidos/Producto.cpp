/* 
 * File:   Producto.cpp
 * Author: cueva.r
 * 
 * Created on 22 de octubre de 2024, 10:30 AM
 */
#include <iostream>
#include <fstream>
#include <cstring>
#include "Producto.h"

using namespace std;

Producto::Producto() {
    codprod=0;
    nombre=nullptr;
    precio=0;
    stock=0;
}

Producto::Producto(const Producto& orig) {
}

Producto::~Producto() {
}

void Producto::SetStock(int stock) {
    this->stock = stock;
}

int Producto::GetStock() const {
    return stock;
}

void Producto::SetPrecio(double precio) {
    this->precio = precio;
}

double Producto::GetPrecio() const {
    return precio;
}

void Producto::SetCodprod(int codprod) {
    this->codprod = codprod;
}

int Producto::GetCodprod() const {
    return codprod;
}

void Producto::SetNombre(char*cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}
void Producto::GetNombre(char* cad){
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}
/*
459032,GELATINA DANY LIMON 125GR,5.38,24
422763,GALLETAS SUAVICREMAS FRESA 158GR,13.85,14
 */
void Producto::leeproducto(int codigo){
    ifstream arch("productos3.csv",ios::in);
    if(!arch){
        cout <<"No se puede abrir el archivo de productos";
        exit(1);
    }
    int codp,sto;
    char cad[100],c;
    double prec;
    while(1){
       arch >> codp; 
       if(arch.eof()) break;
       arch.get();
       arch.getline(cad,100,',');
       arch >> prec >> c >> sto;
       if(codp==codigo){
           SetCodprod(codp);
           SetNombre(cad);
           SetPrecio(prec);
           SetStock(sto);
           break;
       }
    }
}