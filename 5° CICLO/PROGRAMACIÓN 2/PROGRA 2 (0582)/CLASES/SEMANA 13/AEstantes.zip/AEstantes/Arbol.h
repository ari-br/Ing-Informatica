

/* 
 * File:   Arbol.h
 * Author: cueva
 *
 * Created on 19 de junio de 2024, 03:03 PM
 */

#ifndef ARBOL_H
#define ARBOL_H

#include "NEstante.h"


class Arbol {
public:
    Arbol();
    Arbol(const Arbol& orig);
    virtual ~Arbol();
    void leer(ifstream&,ifstream&);
    void imprimearbol(ofstream &);
    void valida(ofstream&,double);
private:
    void inserta(NEstante*&);
    void enorden(ofstream&,NEstante*&);
    NEstante *raiz;
};

#endif /* ARBOL_H */

