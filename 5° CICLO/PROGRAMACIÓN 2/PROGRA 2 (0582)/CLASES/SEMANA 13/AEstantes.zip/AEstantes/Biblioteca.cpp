/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Biblioteca.cpp
 * Author: cueva
 * 
 * Created on 12 de junio de 2024, 10:59 PM
 */
#include <fstream>
#include "Biblioteca.h"
#include "Novela.h"
#include "Revista.h"
#include "Enciclopedia.h"
#include <iostream>

using namespace std;


Biblioteca::Biblioteca() {
}

Biblioteca::Biblioteca(const Biblioteca& orig) {
}

Biblioteca::~Biblioteca() {
}

void Biblioteca::carga(){
    ifstream arch("Estantes3.csv",ios::in);
    if(!arch){
        cout <<"No se puede abrir el archivo pedidos";
        exit(1);
    }
    ifstream alib("Libros31.csv",ios::in);
    if(!alib){
        cout <<"No se puede abrir el archivo libros";
        exit(1);
    }    
    
    while(1){
        AEstante.leer(arch,alib);
        if(arch.eof())break;
    }
}

void Biblioteca::muestra(){
    ofstream arch("reporte.txt",ios::out);
    if(!arch){
        cout <<"No se puede abrir el reporte";
        exit(1);
    }
    
    AEstante.imprimearbol(arch);
    
}

void Biblioteca::prueba(double peso){
    ofstream repo("valida.txt",ios::out);
    if(!repo){
        cout <<"No se puede abrir el reporte";
        exit(1);
    }
    AEstante.valida(repo,peso);
    
}


