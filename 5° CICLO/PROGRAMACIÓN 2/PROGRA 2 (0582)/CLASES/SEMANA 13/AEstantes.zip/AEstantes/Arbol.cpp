/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Arbol.cpp
 * Author: cueva
 * 
 * Created on 19 de junio de 2024, 03:03 PM
 */

#include "Arbol.h"


Arbol::Arbol() {
    raiz = nullptr;
}

Arbol::Arbol(const Arbol& orig) {
}

Arbol::~Arbol() {
}

void Arbol::inserta(NEstante*&naux) {
    if (raiz == nullptr) {
        raiz = naux;
    } else {
        NEstante *rec;
        rec = raiz;
        while (rec) {
            if (rec->disponible < naux->disponible)
                if (rec->der == nullptr) {
                    rec->der = naux;
                    break;
                } else
                    rec = rec->der;
            else
                if (rec->izq == nullptr) {
                rec->izq = naux;
                break;
            } else
                rec = rec->izq;
        }
    }
}

void Arbol::leer(ifstream&arch, ifstream &alib) {
    NEstante *naux;
    naux = new NEstante;
    naux->generaestante(arch);
    for (int i = 0; i < 10; i++) {
        naux->leerlibros(alib);
    }
    inserta(naux);

}

void Arbol::imprimearbol(ofstream&arch) {
    enorden(arch, raiz);

}

void Arbol::enorden(ofstream &arch, NEstante*&parbol) {
    if (parbol == nullptr) return;
    enorden(arch, parbol->izq);
    parbol->imprimirlibros(arch);
    enorden(arch, parbol->der);

}

void Arbol::valida(ofstream&repo, double peso) {
    NEstante *rec;
    rec = raiz;
    while (rec) {
        if(rec->disponible>=peso){
            repo<<"Si hay espacio"<<endl;
            rec->imprimirlibros(repo);
            break;
        }    
        if (rec->disponible < peso)
            rec = rec->der;
    }
    if(rec==nullptr)
        repo <<"No hay espacio";
}

