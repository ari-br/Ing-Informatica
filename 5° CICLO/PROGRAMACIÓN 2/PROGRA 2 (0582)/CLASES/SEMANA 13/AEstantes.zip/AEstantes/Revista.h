/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Revista.h
 * Author: cueva
 *
 * Created on 12 de junio de 2024, 10:38 PM
 */

#ifndef REVISTA_H
#define REVISTA_H
#include <fstream>

#include "Libro.h"

using namespace std;

class Revista: public Libro {
public:
    Revista();
    Revista(const Revista& orig);
    virtual ~Revista();
    void SetNumero(int numero);
    int GetNumero() const;
    void SetAnho(int anho);
    int GetAnho() const;
    void SetISSN(int ISSN);
    int GetISSN() const;
    void lee(ifstream&);
    void imprime(ofstream&);
private:
    int ISSN;
    int anho;
    int numero;
};

#endif /* REVISTA_H */

