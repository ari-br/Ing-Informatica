/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Novela.cpp
 * Author: cueva
 * 
 * Created on 12 de junio de 2024, 10:43 PM
 */
#include <cstring>
#include "Novela.h"
#include "Libro.h"

Novela::Novela() {
    autor=nullptr;
}

Novela::Novela(const Novela& orig) {
}

Novela::~Novela() {
    if(autor!=nullptr)
        delete autor;
}

void Novela::SetAutor(char*cad){
    if(autor!=nullptr) delete autor;
    autor = new char[strlen(cad)+1];
    strcpy(autor,cad);
}

void Novela::GetAutor(char* cad)const{
    if(autor!=nullptr)
        strcpy(cad,autor);
}

void Novela::lee(ifstream &arch){
    char cad[100];
    
    Libro::lee(arch);
    arch.getline(cad,100);
    SetAutor(cad);
    
}

void Novela::imprime(ofstream&arch){
    char cad[100];
    Libro::imprime(arch);
    GetAutor(cad);
    arch << "Autor:" << cad << endl <<endl;
    
}