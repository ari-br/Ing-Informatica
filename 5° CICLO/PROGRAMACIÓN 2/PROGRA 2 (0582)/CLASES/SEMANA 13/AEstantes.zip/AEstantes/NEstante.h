/* 
 * File:   NEstante.h
 * Author: cueva
 *
 * Created on 19 de junio de 2024, 03:09 PM
 */

#ifndef NESTANTE_H
#define NESTANTE_H
#include <vector>
#include "NLibro.h"

using namespace std;

class NEstante {
public:
    NEstante();
    NEstante(const NEstante& orig);
    virtual ~NEstante();
    void SetCapacidad(double capacidad);
    double GetCapacidad() const;
    void SetId(int id);
    int GetId() const;
    void SetDisponible(double disponible);
    double GetDisponible() const;
    void leerlibros(ifstream &);
    void imprimirlibros(ofstream&);
    void generaestante(ifstream&);
    
    friend class Arbol;
        
private:
    int id;
    double capacidad;
    double disponible;
    NEstante *izq;
    NEstante *der;
    vector<NLibro> vlibros;
};

#endif /* NESTANTE_H */

