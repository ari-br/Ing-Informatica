/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NLibro.cpp
 * Author: cueva
 * 
 * Created on 19 de junio de 2024, 03:14 PM
 */

#include "NLibro.h"
#include "Novela.h"
#include "Revista.h"
#include "Enciclopedia.h"

NLibro::NLibro() {
    plibro = nullptr;
}

NLibro::NLibro(const NLibro& orig) {
    this->plibro = orig.plibro;
}

NLibro::~NLibro() {
}

void NLibro::leer(ifstream&arch) {
    char tipo;
    arch >> tipo;
    if (arch.eof())return;
    arch.get();
    if (tipo == 'N')
        plibro = new Novela;
    if (tipo == 'R')
        plibro = new Revista;
    if (tipo == 'E')
        plibro = new Enciclopedia;
    plibro->lee(arch);
}

double NLibro::getpeso(){
    return plibro->GetPeso();
}

void NLibro::imprimir(ofstream&arch){
    plibro->imprime(arch);    
}