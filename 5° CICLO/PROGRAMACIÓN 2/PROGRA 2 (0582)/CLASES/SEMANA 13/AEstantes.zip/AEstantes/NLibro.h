/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NLibro.h
 * Author: cueva
 *
 * Created on 19 de junio de 2024, 03:14 PM
 */

#ifndef NLIBRO_H
#define NLIBRO_H

#include "Libro.h"


class NLibro {
public:
    NLibro();
    NLibro(const NLibro& orig);
    virtual ~NLibro();
    void leer(ifstream &);
    void imprimir(ofstream &);
    double getpeso();
private:
    Libro *plibro;
};

#endif /* NLIBRO_H */

