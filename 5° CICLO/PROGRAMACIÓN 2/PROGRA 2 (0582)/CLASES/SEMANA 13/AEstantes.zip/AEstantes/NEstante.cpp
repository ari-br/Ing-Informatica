/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NEstante.cpp
 * Author: cueva
 * 
 * Created on 19 de junio de 2024, 03:09 PM
 */

#include "NEstante.h"

NEstante::NEstante() {
    id=0;
    capacidad=0;
    disponible=0;
    izq=nullptr;
    der=nullptr;
}

NEstante::NEstante(const NEstante& orig) {
}

NEstante::~NEstante() {
}

void NEstante::SetCapacidad(double capacidad) {
    this->capacidad = capacidad;
}

double NEstante::GetCapacidad() const {
    return capacidad;
}

void NEstante::SetId(int id) {
    this->id = id;
}

int NEstante::GetId() const {
    return id;
}

void NEstante::SetDisponible(double disponible) {
    this->disponible = disponible;
}

double NEstante::GetDisponible() const {
    return disponible;
}

void NEstante::generaestante(ifstream&arch){
    arch >> id;
    if(arch.eof()) return;
    arch.get();
    arch >> capacidad;
    disponible = capacidad;
}

void NEstante::leerlibros(ifstream&arch){
    NLibro naux;
    
    naux.leer(arch);
    disponible-= naux.getpeso();
    vlibros.push_back(naux);
    
}

void NEstante::imprimirlibros(ofstream&arch){
    arch <<"Estantes: "<< id<<endl;
    arch << "Capacidad: " << capacidad << "     Disponible:" << disponible << endl;
    for(int i=0;i<vlibros.size();i++)
        vlibros[i].imprimir(arch);
}