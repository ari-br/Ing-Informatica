/* 
 * File:   main.cpp
 * Author: cueva
 *
 * Created on 12 de noviembre de 2024, 10:27 AM
 */

#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

void muestra(vector<int>vnotas){
    for(int i=0;i<vnotas.size();i++)
        cout << vnotas[i]<<" ";
    cout << endl;
}

bool cmp(int a,int b){
    return a>b;
}

void procesa(int *notas,int n){
    vector <int> vnotas;
    
    for(int i=0;i<n;i++)
        vnotas.push_back(notas[i]);
    muestra(vnotas);
    vnotas.insert(vnotas.begin()+2,20);
    muestra(vnotas);
    vnotas.erase(vnotas.begin()+3);
    muestra(vnotas);
    sort(vnotas.begin(),vnotas.end(),cmp);
    muestra(vnotas);
    vnotas.clear();
    cout << vnotas.size();
}


int main(int argc, char** argv) {
    int notas[]={15,14,6,19,20,15};
    int n=sizeof(notas)/sizeof(notas[0]);
    
    procesa(notas,n);
    
    return 0;
}

