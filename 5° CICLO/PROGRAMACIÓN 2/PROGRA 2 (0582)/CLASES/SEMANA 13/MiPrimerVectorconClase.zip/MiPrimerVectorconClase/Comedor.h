/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Comedor.h
 * Author: cueva
 *
 * Created on 12 de noviembre de 2024, 11:01 AM
 */

#ifndef COMEDOR_H
#define COMEDOR_H
#include <vector>
#include "Cliente.h"

using namespace std;

class Comedor {
public:
    Comedor();
    Comedor(const Comedor& orig);
    virtual ~Comedor();
    void carga();
    void muestra();
private:
    vector<Cliente> vcliente;
    
};

#endif /* COMEDOR_H */

