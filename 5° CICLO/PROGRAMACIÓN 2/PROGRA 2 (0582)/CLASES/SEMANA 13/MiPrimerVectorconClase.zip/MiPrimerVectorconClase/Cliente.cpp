/* 
 * File:   Cliente.cpp
 * Author: cueva
 * 
 * Created on 12 de noviembre de 2024, 10:57 AM
 */
#include <fstream>
#include <iomanip>
#include <iostream>
#include <cstring>
#include "Cliente.h"

Cliente::Cliente() {
    dni=0;
    nombre=nullptr;    
}

Cliente::Cliente(const Cliente& orig) {
    nombre=nullptr;
    *this = orig;
}

Cliente::~Cliente() {
    if(nombre!=nullptr) delete nombre;
}

void Cliente::SetCategoria(char categoria) {
    this->categoria = categoria;
}

char Cliente::GetCategoria() const {
    return categoria;
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

void Cliente::SetNombre(char*cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}
void Cliente::GetNombre(char* cad)const{
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}
void Cliente::operator =(const Cliente&clie){
    char cad[100];
    
    nombre = nullptr;
    dni = clie.dni;
    categoria = clie.categoria;
    clie.GetNombre(cad);
    SetNombre(cad);    
}

bool Cliente::operator <(const Cliente&clie){
    if(categoria<clie.categoria)
        return true;
    if(categoria==clie.categoria and
            dni<clie.dni)
        return true;
    return false;
}


/*
71984468,IPARRAGUIRRE VILLEGAS NICOLAS EDILBERTO,A
29847168,ALDAVE ZEVALLOS ROSARIO,A
79475585,RETTO ARCA ANNIE MAGDA,C
 */
ifstream &operator >> (ifstream &arch,Cliente&f){
    int dni;
    char cad[100],c;
    
    arch >> dni;
    if(!arch.eof()){
        f.SetDni(dni);
        arch.get();
        arch.getline(cad,100,',');
        f.SetNombre(cad);
        arch >> c;
        f.SetCategoria(c);
    }
    return arch;
}

ofstream &operator << (ofstream &arch,Cliente&f){
    char cad[100],c;
    
    arch << setw(10)<< f.GetDni() << setw(5)<< f.GetCategoria();
    f.GetNombre(cad);
    arch <<setw(50)<< cad << endl;
            
    return arch;
}