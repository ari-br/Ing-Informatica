
/* 
 * File:   Cliente.h
 * Author: cueva
 *
 * Created on 12 de noviembre de 2024, 10:57 AM
 */

#ifndef CLIENTE_H
#define CLIENTE_H
#include <fstream>

using namespace std;

class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    void SetCategoria(char categoria);
    char GetCategoria() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetNombre(char*);
    void GetNombre(char*)const;
    void operator = (const Cliente&);
    bool operator < (const Cliente&);
private:
    int dni;
    char *nombre;
    char categoria;
    
};
ifstream &operator >> (ifstream &arch,Cliente&);
ofstream &operator << (ofstream &arch,Cliente&);

#endif /* CLIENTE_H */

