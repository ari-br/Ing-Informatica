/* 
 * File:   Comedor.cpp
 * Author: cueva
 * 
 * Created on 12 de noviembre de 2024, 11:01 AM
 */
#include <fstream>
#include <algorithm>
#include <iostream>
#include "Comedor.h"

using namespace std;

Comedor::Comedor() {
}

Comedor::Comedor(const Comedor& orig) {
}

Comedor::~Comedor() {
}

void Comedor::carga(){
    Cliente aux;
    ifstream arch("clientes2.csv",ios::in);
    if(not arch){
        cout <<"No se puede abrir clientes";
        exit(1);
    }
    while(1){
        arch >> aux;        
        if(arch.eof()) break; 
        vcliente.push_back(aux);
    }
}

void Comedor::muestra(){
    ofstream arch("reporte.txt",ios::out);
    if(not arch){
        cout <<"No se puede abrir reportes";
        exit(1);
    }
   sort(vcliente.begin(),vcliente.end());
   for(int i=0;i<vcliente.size();i++)
        arch << vcliente[i];
    
}