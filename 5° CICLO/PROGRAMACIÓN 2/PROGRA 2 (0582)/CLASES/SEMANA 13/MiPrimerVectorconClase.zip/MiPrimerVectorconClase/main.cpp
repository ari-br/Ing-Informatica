/* 
 * File:   main.cpp
 * Author: cueva
 *
 * Created on 12 de noviembre de 2024, 10:55 AM
 */

#include "Comedor.h"


using namespace std;

int main(int argc, char** argv) {
    Comedor com;

    com.carga();
    com.muestra();
    
    return 0;
}

