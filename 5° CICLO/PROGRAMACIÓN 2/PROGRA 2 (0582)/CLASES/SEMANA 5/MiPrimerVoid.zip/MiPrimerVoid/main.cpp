/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 18 de septiembre de 2024, 02:18 PM
 */

#include "PunterosGenericos.h"

using namespace std;

int main(int argc, char** argv) {
    void *productos,*clientes;
    
    cargaproductos(productos);
    cargaclientes(clientes);
    cargapedidos(productos,clientes);
    
    
    return 0;
}

