/* 
 * File:   PunterosGenericos.cpp
 * Author: cueva.r
 * 
 * Created on 18 de septiembre de 2024, 02:22 PM
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
#include "PunterosGenericos.h"
#define MAX 200

using namespace std;
/*
JXD-139,50375303,6
CRU-009,50375303,5
 */
void cargapedidos(void *productos,void *clientes){
    char *codigo,c,estado;
    int *dni,*cantidad,pos,numped[200]{0};
    double credito,precio;
    
    void**lclientes=(void**)clientes;
    ifstream arch("Pedidos2.csv",ios::in);
    if(!arch){
        cout <<"No se puede abrir el archivo de pedidos";
        exit(1);
    }
    while(1){
        codigo=leercadena(arch,10,',');
        if(arch.eof())break;
        dni=new int;
        cantidad=new int;
        arch>>*dni>>c>>*cantidad;
        arch.get();
        pos=buscarcliente(*dni,clientes,credito);
        precio=buscaproducto(codigo,productos,estado);
        if(estado=='N' or credito-precio*(*cantidad)>=0){
            void**reg=(void**)lclientes[pos];
            if(numped[pos]==0)
                reg[2]=new void*[100];
            double *cred=(double*)reg[3];   
            if(estado=='S')
                *cred-=precio*(*cantidad);
            void **lped=(void**)reg[2];
            void**regped=new void*[3];
            regped[0]=codigo;
            regped[1]=cantidad;
            double *total;
            total=new double;
            *total=*cantidad*precio;
            regped[2]=total;
            lped[numped[pos]]=regped;
            lped[numped[pos]+1]=nullptr;
            numped[pos]++;
        }
    }
}

double buscaproducto(char *codigo,void *productos,
        char &estado){
    char *cod,*tipo;
    double *precio;
    
    void **lprod=(void**)productos;
    for(int i=0;lprod[i]!=nullptr;i++){
        void **reg=(void**)lprod[i];
        cod =(char*)reg[0];
        if(strcmp(cod,codigo)==0){
            precio=(double*)reg[2];
            tipo=(char*)reg[3];
            estado=*tipo;
            return *precio;
        }
    }
}

int buscarcliente(int dni,void *clientes,double&cred){
    void **lclientes=(void**)clientes;
    int *pdni;
    double *linea;
    for(int i=0;lclientes[i]!=nullptr;i++){
        void**reg=(void**)lclientes[i];
        pdni = (int*)reg[0];
        if(*pdni==dni){
            linea=(double*)reg[3];
            cred=*linea;
            return i;
        }
    }
}

void cargaclientes(void *&clientes){
    int i=0;
    void *buffer[200],**lclientes;
    ifstream arch("Clientes2.csv",ios::in);
    if(!arch){
        cout <<"No se puede abrir el archivo de clientes";
        exit(1);
    }
    while(1){
        buffer[i]=leecliente(arch);
        if(arch.eof()) break;
        i++;
    }
    lclientes=new void*[i+1];
    for(int j=0;j<=i;j++)
        lclientes[j]=buffer[j];
    clientes = lclientes;
}
/*
79464412,PORTUGAL RAFFO ALEXANDER,3902394,10000
16552775,YALLICO PAREDES LOURDES CARMELA,960176666,20000*/
void *leecliente(ifstream &arch){
    int dni,*pdni,telefono;
    char *nombre,c;
    double *linea;
    void **registro;
    
    arch >> dni;
    if(arch.eof()) return nullptr;
    pdni = new int;
    *pdni = dni;
    arch.get();
    nombre = leercadena(arch,200,',');
    linea = new double;
    arch >> telefono >> c >> *linea;
    registro = new void*[4];
    registro[0] = pdni;
    registro[1] = nombre;
    registro[2] = nullptr;
    registro[3] = linea;
    
    return registro;
}


void cargaproductos(void *&productos){
    void *buffer[200],**lproductos;
    int i=0;
    ifstream arch("Productos2.csv",ios::in);
    if(!arch){
        cout <<"No se puede leer el archivo productos";
        exit(1);
    }
    while(1){
        buffer[i]=leeproductos(arch);
        if(arch.eof()) break;
        i++;
    }
    lproductos=new void*[i+1];
    for(int j=0;j<=i;j++)
        lproductos[j]=buffer[j];
    productos=lproductos;
    imprimeproductos(productos);
}
/*
BIT-434,Campana Extractora modelo Glass,375.09,S
SSE-115,Refrigeradora  CoolStyle 311N Steel,3243.58,S 
*/
void* leeproductos(ifstream &arch){
    char *codigo,*nombre,*tipo,c;
    double *precio;
    void **registro;
    
    codigo = leercadena(arch,10,',');
    if(arch.eof()) return nullptr;
    nombre = leercadena(arch,150,',');
    precio= new double;
    tipo = new char;
    arch >> *precio >> c >> *tipo;
    arch.get();
    registro = new void*[4];
    registro[0] = codigo;
    registro[1] = nombre;
    registro[2] = precio;
    registro[3] = tipo;
    
    return registro;
}

char *leercadena(ifstream &arch,int max,char carsep){
    char buff[MAX],*cad;
    
    arch.getline(buff,max,carsep);
    if(arch.eof()) return nullptr;
    cad = new char[strlen(buff)+1];
    strcpy(cad,buff);
    return cad;
}

void imprimeproductos(void*productos){
    void**laux =(void**)productos;
    
    ofstream arch("RepProductos.txt",ios::out);
    if(!arch){
        cout <<"No se puede leer el archivo Reporte de productos";
        exit(1);
    }
    for(int i=0;laux[i]!=nullptr;i++)
        imprimeregistro(arch,laux[i]);
}
void imprimeregistro(ofstream &arch,void*registro){
    void**laux=(void**)registro;
    char *codigo,*nombre,*tipo;
    double *precio;
    
    codigo = (char*)laux[0];
    nombre = (char*)laux[1];
    precio = (double*)laux[2];
    tipo = (char*)laux[3];
    
    arch<<setw(10)<<codigo<<setw(100)<<nombre;
    arch<<setw(10)<<*precio<<setw(4)<<*tipo<<endl; 
}
