/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PunterosGenericos.h
 * Author: cueva.r
 *
 * Created on 18 de septiembre de 2024, 02:22 PM
 */

#ifndef PUNTEROSGENERICOS_H
#define PUNTEROSGENERICOS_H
#include <fstream>
using namespace std;

    void cargaproductos(void *&productos);
    void* leeproductos(ifstream &arch);
    char *leercadena(ifstream &arch,int max,char carsep);
    void imprimeregistro(ofstream &arch,void*registro);
    void imprimeproductos(void*productos);
    void *leecliente(ifstream &arch);
    void cargaclientes(void *&clientes);
    void cargapedidos(void *productos,void *clientes);
    double buscaproducto(char *codigo,void *productos,
        char &estado);
    int buscarcliente(int dni,void *clientes,double&cred);
#endif /* PUNTEROSGENERICOS_H */
