/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AsignacionDinamicaMemoriaExacta.cpp
 * Author: cueva.r
 * 
 * Created on 28 de agosto de 2024, 10:36 AM
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
#define MAX 100
#include "AsignacionDinamicaMemoriaExacta.h"

using namespace std;


/*
BIT-434,Campana Extractora modelo Glass,375.09,10
SSE-115,Refrigeradora  CoolStyle 311N Steel,3243.58,23
NMV-644,Lavadora Automatica,3272.48,5
 */
void lecturaDeProductos(const char*nom,
        char ***&productos,int *&stock,double *&precios){
    int buffstock[200],i=0;
    double buffprecio[200];
    char cad[100],c,**buffproductos[200];
    
    ifstream arch(nom,ios::in);
    if(!arch){
        cout <<"No se puede abrir el archivo de productos";
        exit(1);
    }
    while(1){
        buffproductos[i]=leeproductos(arch);
        if(arch.eof()) break;
        arch >> buffprecio[i] >> c >>buffstock[i];
        arch.get();
        i++;
    }
    productos = new char**[i+1];
    stock = new int[i];
    precios = new double[i+1];
    
    for (int j = 0; j < i;j++) {
        stock[j] = buffstock[j];
        precios[j] = buffprecio[j];
        productos[j] = buffproductos[j];
    }
    productos[i] = buffproductos[i];
}

char **leeproductos(ifstream &arch){
    char *cad,**dupla;
    cad=leercadena(arch,10,',');
    if(arch.eof()) return nullptr;
    dupla = new char*[2];
    dupla[0]=cad;
    dupla[1]=leercadena(arch,100,',');
    
    return dupla;
}

char *leercadena(ifstream &arch,int max,char carsep){
    char buff[MAX],*cad;
    
    arch.getline(buff,max,carsep);
    if(arch.eof()) return nullptr;
    cad = new char[strlen(buff)+1];
    strcpy(cad,buff);
    return cad;
}

void pruebaDeLecturaDeProductos(const char*nom,
        char ***productos,int *stock,double *precios){
    ofstream arch(nom,ios::out);
    if(!arch){
        cout <<"No se puede abrir el archivo de reporte";
        exit(1);
    }  
    for(int i=0;productos[i]!=nullptr;i++){
        char **aux;
        aux = productos[i];
        arch << setw(10) << aux[0] <<setw(50)<< aux[1]<< endl;
        arch << setw(10)<< stock[i] << 
                fixed << setprecision(2)<<setw(10)<<precios[i] << endl;
        arch << endl;        
    }
    
}
/*
JXD-139,50375303,6,24/08/2023
CRU-009,50375303,5,3/09/2023
*/
void lecturaDePedidos(const char*nom,int *&fechaPedidos,
        char ***&codigoPedidos,int ***&dniCantPedidos){
    char *codigo,c,**buffcodigo[600];
    int dni,cant,dd,mm,aa,fecha,indice,cont=0,buffecha[600];
    int **buffcant[600],cantped[600];
    ifstream arch(nom,ios::in);
    if(!arch){
        cout <<"No se puede abrir el archivo de pedidos";
        exit(1);
    }   
    while(1){
        codigo=leercadena(arch,10,',');
        if(arch.eof()) break;
        arch >> dni>>c>>cant>>c>>dd>>c>>mm>>c>>aa;
        arch.get();
        fecha=aa*10000+mm*100+dd;
        indice=buscafecha(buffecha,fecha,cont);
        if(indice==-1)agregarfecha(buffecha,buffcodigo,buffcant,fecha,cont,
                indice,cantped);
        agregarpedido(dni,cant,codigo,buffcodigo[indice],buffcant[indice],
                cantped[indice]);
    }
    llenaarreglos(fechaPedidos,codigoPedidos,dniCantPedidos,
            buffecha,buffcodigo,buffcant,cantped,cont);

}

void llenaarreglos(int *&fechaPedidos,char ***&codigoPedidos,int ***&dniCantPedidos,
            int *buffecha,char ***buffcodigo,int ***buffcant,int *cantped,int cont){

    fechaPedidos = new int[cont+1];
    codigoPedidos = new char**[cont];
    dniCantPedidos = new int**[cont];
    
    for(int i=0;i<cont;i++){
        fechaPedidos[i] = buffecha[i];
        codigoPedidos[i] = new char*[cantped[i]+1];
        dniCantPedidos[i] = new int*[cantped[i]+1];
        llenasubnivel(codigoPedidos[i],dniCantPedidos[i],
                buffcodigo[i],buffcant[i],cantped[i]);
    }
    fechaPedidos[cont]=0;
}
void llenasubnivel(char **codigoPedidos,int **dniCantPedidos,
                char **buffcodigo,int **buffcant,int cantped){
    
    for(int i=0;i<cantped;i++){
        codigoPedidos[i]=buffcodigo[i];
        dniCantPedidos[i]=buffcant[i];
    }
    codigoPedidos[cantped]=nullptr;
    
}


void agregarpedido(int dni,int cant,char *codigo,char **buffcodigo,
        int **buffcant,int &cantped){
    int *aux;
    buffcodigo[cantped] = codigo;
    buffcant[cantped]=new int[2];
    aux = buffcant[cantped];
    aux[0] = dni;
    aux[1] = cant;
    cantped++;
}

void agregarfecha(int *buffecha,char ***buffcodigo,int ***buffcant,
        int fecha,int &cont,int &indice,int *cantped){
    
    buffecha[cont] = fecha;
    buffcodigo[cont] = new char*[200];
    buffcant[cont] = new int*[200];
    cantped[cont] = 0;
    indice=cont;
    cont++;
    
}

int buscafecha(int *buff,int fecha, int cont){  
    for(int i=0;i<cont;i++)
        if(buff[i]==fecha) return i;
    return -1;
}


void pruebaDeLecturaDePedidos(const char *nom, int *fechaPedidos, char ***codigoPedidos, int ***dniCantPedidos)
{
    ofstream arch (nom, ios::out);
    if(not arch.is_open()){
        cout << "ERROR: no se abrió " << nom;
        exit(1);
    }
    char **auxCodigos;
    int **auxDni, *auxDniCant;
    for(int i=0; fechaPedidos[i] != 0; i++){
        arch << fechaPedidos[i] << endl;
        auxCodigos = codigoPedidos[i];
        auxDni = dniCantPedidos[i];
        for(int j=0; auxCodigos[j] != nullptr; j++){
            auxDniCant = auxDni[j];
            arch << setw(10) << auxCodigos[j] << setw(15) << auxDniCant[0] << " " 
                 << auxDniCant[1] << endl;
        }
        arch << endl;    
    }
}
