/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AsignacionDinamicaMemoriaExacta.h
 * Author: cueva.r
 *
 * Created on 28 de agosto de 2024, 10:36 AM
 */

#ifndef ASIGNACIONDINAMICAMEMORIAEXACTA_H
#define ASIGNACIONDINAMICAMEMORIAEXACTA_H
#include <fstream>
using namespace std;

    void lecturaDeProductos(const char*,
        char ***&,int *&,double *&);
    void pruebaDeLecturaDeProductos(const char*nom,
        char ***productos,int *stock,double *precios);
    char **leeproductos(ifstream &);
    char *leercadena(ifstream &arch,int max,char carsep);
    void pruebaDeLecturaDePedidos(const char *, int *, char ***, int ***);
    void agregarfecha(int *,char ***,int ***,int ,int &,int &,int *);
    int buscafecha(int *buff,int fecha, int cont);
    void agregarpedido(int dni,int cant,char *codigo,char **buffcodigo,
        int **buffcant,int &cantped);
    void lecturaDePedidos(const char*,int *&,char ***&,int ***&);
    void llenaarreglos(int *&fechaPedidos,char ***&codigoPedidos,int ***&dniCantPedidos,
            int *buffecha,char ***buffcodigo,int ***buffcant,int *cantped,int cont);
    void llenasubnivel(char **codigoPedidos,int **dniCantPedidos,
                char **buffcodigo,int **buffcant,int cantped);
#endif /* ASIGNACIONDINAMICAMEMORIAEXACTA_H */
