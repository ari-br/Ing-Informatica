/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Procesa.cpp
 * Author: cueva.r
 * 
 * Created on 19 de noviembre de 2024, 10:14 AM
 */
#include <iostream>
#include <fstream>
#include <iomanip>
#include <iterator>
#include "Procesa.h"
#include "PedidoEspecial.h"
#include "PedidoUsual.h"
#include "PedidoEventual.h"

using namespace std;

Procesa::Procesa() {
}

Procesa::Procesa(const Procesa& orig) {
}

Procesa::~Procesa() {
}
void Procesa::reservamem(int codigo, Pedido* &ped){
    
    if(codigo<400000)
        ped=new PedidoEspecial;
    if(codigo>=400000 and codigo<600000)
        ped= new PedidoUsual;
    if(codigo>=600000)
        ped=new PedidoEventual;
}


/*
118050,10,PAPAYA,8,8,79475585,16/12/2019
118050,10,PAPAYA,5,5,79475585,30/04/2020
 */
void Procesa::carga(){
    int codigo;
    Pedido *aux;
    ifstream arch("pedidos5.csv",ios::in);
    if(!arch){
        cout << "No se pudo abrir las Pedidos";
        exit(1);    }   
    while(1){
        arch >> codigo;
        if(arch.eof()) break;
        arch.get();
        reservamem(codigo,aux);
        aux->lee(codigo,arch);
        lped.push_back(aux);      
    }
}

void Procesa::muestra(){
    Pedido *aux;
    ofstream arch("reporte.txt",ios::out);
    if(!arch){
        cout << "No se pudo abrir las Reportes";
        exit(1);    }     
    for(list<Pedido*>::iterator it=lped.begin();
            it!=lped.end();it++){
        aux=*it;
        aux->imprime(arch,0,0);
    }
}
