/* 
 * File:   Procesa.h
 * Author: cueva.r
 *
 * Created on 19 de noviembre de 2024, 10:14 AM
 */

#ifndef PROCESA_H
#define PROCESA_H
#include <list>
#include "Pedido.h"

using namespace std;

class Procesa {
public:
    Procesa();
    Procesa(const Procesa& orig);
    virtual ~Procesa();
    void carga();
    void muestra();
private:
    list<Pedido*> lped;
    void reservamem(int,Pedido*&);    
};

#endif /* PROCESA_H */

