/* 
 * File:   Pedido.h
 * Author: cueva.r
 *
 * Created on 5 de noviembre de 2024, 11:29 AM
 */

#ifndef PEDIDO_H
#define PEDIDO_H
#include <fstream>

using namespace std;

class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetTotal(double total);
    double GetTotal() const;
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void SetNombre(char*);
    void GetNombre(char*);
    virtual void lee(int,ifstream &);
    virtual void imprime(ofstream &,double ,double );
    
private:
    int codigo;
    char * nombre;
    int cantidad;
    int dni;
    int fecha;
    double total;
};

#endif /* PEDIDO_H */

