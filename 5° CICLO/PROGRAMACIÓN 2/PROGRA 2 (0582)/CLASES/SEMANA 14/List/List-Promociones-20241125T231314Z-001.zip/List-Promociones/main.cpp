
#include "Procesa.h"
/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 19 de noviembre de 2024, 08:55 AM
 */

using namespace std;

int main(int argc, char** argv) {
    Procesa pro;
    
    pro.carga();
    pro.muestra();

    return 0;
}

