/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Promociones.cpp
 * Author: Ariana
 * 
 * Created on 22 de noviembre de 2024, 12:22 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Promociones.h"

Promociones::Promociones() {
}

Promociones::Promociones(const Promociones& orig) {
}

Promociones::~Promociones() {
}

void Promociones::leepedidos(){
    ifstream arch("pedidos5.csv",ios::in);
    AperturaIf(arch,"pedidos5.csv");
    int cod;
    Unidad unid;
    while(1){
        arch>>cod;
        if(arch.eof()) break;
        arch.get();
        unid.lee(cod,arch);
        Lpedidos.cargar(unid);
    }
}

void Promociones::actualizapedidos(){
    ifstream arch("promocion.csv",ios::in);
    AperturaIf(arch,"promocion.csv");
    
    int dni,fecha,dd,mm,aa;
    char c;
    while(1){
        arch>>dni;
        if(arch.eof()) break;
        arch>>c>>dd>>c>>mm>>c>>aa;
        fecha=(aa*10000)+(mm*100)+dd;
        Lpedidos.actualiza(dni,fecha);
    }
}

void Promociones::imprimepedidos(){
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    arch<<setprecision(2)<<fixed;
    arch<<right<<setw(39)<<"REPORTE DE PROMOCIONES"<<endl;
    imprimirLinea(arch,'=');
    
    Lpedidos.imprimir(arch);
}

void Promociones::imprimirLinea(ofstream &arch,char c){
    for (int i = 0; i < 60; i++) arch<<c;
    arch<<endl;
}

void Promociones::AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void Promociones::AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}
