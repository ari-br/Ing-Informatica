/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   PedidoEspecial.h
 * Author: Ariana
 *
 * Created on 22 de noviembre de 2024, 12:12 AM
 */

#ifndef PEDIDOESPECIAL_H
#define PEDIDOESPECIAL_H

#include "Pedido.h"


class PedidoEspecial:public Pedido {
public:
    PedidoEspecial();
    PedidoEspecial(const PedidoEspecial& orig);
    virtual ~PedidoEspecial();
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void lee(int cod,ifstream &arch); //Método polimórfico
    void imprime(int desc,int flet,ofstream &arch); //Método polimórfico
    void actualizar(); //Método polimórfico
private:
    double descuento;
};

#endif /* PEDIDOESPECIAL_H */

