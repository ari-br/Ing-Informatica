/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 22 de noviembre de 2024, 01:36 AM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Promociones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    Promociones pro;
    
    pro.leepedidos();
    pro.actualizapedidos();
    pro.imprimepedidos();
    
    return 0;
}

