/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Lista.h
 * Author: Ariana
 *
 * Created on 22 de noviembre de 2024, 12:20 AM
 */

#ifndef LISTA_H
#define LISTA_H

#include "Nodo.h"


class Lista {
public:
    Lista();
    Lista(const Lista& orig);
    virtual ~Lista();
    void cargar(Unidad &unidad);
    void imprimir(ofstream &arch);
    void actualiza(int dni,int fecha);
private:
    Nodo *lini;
    Nodo *lfin;
};

#endif /* LISTA_H */

