/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   PedidoEventual.h
 * Author: Ariana
 *
 * Created on 22 de noviembre de 2024, 12:17 AM
 */

#ifndef PEDIDOEVENTUAL_H
#define PEDIDOEVENTUAL_H

#include "Pedido.h"


class PedidoEventual:public Pedido {
public:
    PedidoEventual();
    PedidoEventual(const PedidoEventual& orig);
    virtual ~PedidoEventual();
    void SetFlete(double flete);
    double GetFlete() const;
    void lee(int cod,ifstream &arch); //Método polimórfico
    void imprime(int desc,int flet,ofstream &arch); //Método polimórfico
    void actualizar(); //Método polimórfico
private:
    double flete;
};

#endif /* PEDIDOEVENTUAL_H */

