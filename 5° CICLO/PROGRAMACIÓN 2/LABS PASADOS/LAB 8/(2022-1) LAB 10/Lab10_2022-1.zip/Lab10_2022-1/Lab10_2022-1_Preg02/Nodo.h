/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Nodo.h
 * Author: Ariana
 *
 * Created on 22 de noviembre de 2024, 12:18 AM
 */

#ifndef NODO_H
#define NODO_H

#include "Unidad.h"


class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Lista;
    bool compara(Unidad &unidad);
    void imprimir(ofstream &arch);
    void actualiza(int dni,int fecha);
private:
    Unidad unid;
    Nodo *sig;
    Nodo *ant;
};

#endif /* NODO_H */

