/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   PedidoEventual.cpp
 * Author: Ariana
 * 
 * Created on 22 de noviembre de 2024, 12:17 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "PedidoEventual.h"

PedidoEventual::PedidoEventual() {
    flete=0;
}

PedidoEventual::PedidoEventual(const PedidoEventual& orig) {
}

PedidoEventual::~PedidoEventual() {
}

void PedidoEventual::SetFlete(double flete) {
    this->flete = flete;
}

double PedidoEventual::GetFlete() const {
    return flete;
}

void PedidoEventual::lee(int cod,ifstream &arch){
    char c;
    arch>>flete>>c;
    Pedido::lee(cod,arch);
}

void PedidoEventual::imprime(int desc,int flet,ofstream &arch){
    Pedido::imprime(0,flete,arch);
    arch<<"Flete:"<<right<<setw(15)<<flete<<"%"<<endl;
}

void PedidoEventual::actualizar(){
    flete=0;
}