/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Unidad.cpp
 * Author: Ariana
 * 
 * Created on 22 de noviembre de 2024, 12:18 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Unidad.h"
#include "PedidoEspecial.h"
#include "PedidoUsual.h"
#include "PedidoEventual.h"

Unidad::Unidad() {
    ped=nullptr;
}

Unidad::Unidad(const Unidad& orig) {
}

Unidad::~Unidad() {
}

void Unidad::lee(int cod,ifstream &arch){
    if(cod<400000)
        ped=new PedidoEspecial;
    else
        if(400000<=cod and cod<600000)
            ped=new PedidoUsual;
        else
            ped=new PedidoEventual;
    ped->lee(cod,arch);
}

int Unidad::devolverDNI(){
    return ped->GetDni();
}

int Unidad::devolverFecha(){
    return ped->GetFecha();
}

void Unidad::imprimir(ofstream &arch){
    ped->imprime(0,0,arch);
    arch<<endl;
}

void Unidad::actualizar(){
    ped->actualizar();
}