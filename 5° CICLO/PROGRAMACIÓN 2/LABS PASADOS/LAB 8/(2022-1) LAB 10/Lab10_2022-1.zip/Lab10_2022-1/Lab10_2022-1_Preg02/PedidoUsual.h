/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   PedidoUsual.h
 * Author: Ariana
 *
 * Created on 22 de noviembre de 2024, 12:15 AM
 */

#ifndef PEDIDOUSUAL_H
#define PEDIDOUSUAL_H

#include "Pedido.h"


class PedidoUsual:public Pedido {
public:
    PedidoUsual();
    PedidoUsual(const PedidoUsual& orig);
    virtual ~PedidoUsual();
    void SetFlete(double flete);
    double GetFlete() const;
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void lee(int cod,ifstream &arch); //Método polimórfico
    void imprime(int desc,int flet,ofstream &arch); //Método polimórfico
    void actualizar(); //Método polimórfico
private:
    double descuento;
    double flete;
};

#endif /* PEDIDOUSUAL_H */

