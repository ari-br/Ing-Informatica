/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   PedidoEspecial.cpp
 * Author: Ariana
 * 
 * Created on 22 de noviembre de 2024, 12:12 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "PedidoEspecial.h"

PedidoEspecial::PedidoEspecial() {
    descuento=0;
}

PedidoEspecial::PedidoEspecial(const PedidoEspecial& orig) {
}

PedidoEspecial::~PedidoEspecial() {
}

void PedidoEspecial::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double PedidoEspecial::GetDescuento() const {
    return descuento;
}

void PedidoEspecial::lee(int cod,ifstream &arch){
    char c;
    arch>>descuento>>c;
    Pedido::lee(cod,arch);
}

void PedidoEspecial::imprime(int desc,int flet,ofstream &arch){
    Pedido::imprime(descuento,0,arch);
    arch<<"Descuento:"<<right<<setw(11)<<descuento<<"%"<<endl;
}