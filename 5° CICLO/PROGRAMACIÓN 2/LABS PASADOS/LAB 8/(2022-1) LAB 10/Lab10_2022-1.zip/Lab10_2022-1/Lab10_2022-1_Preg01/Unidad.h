/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Unidad.h
 * Author: Ariana
 *
 * Created on 22 de noviembre de 2024, 12:18 AM
 */

#ifndef UNIDAD_H
#define UNIDAD_H

#include "Pedido.h"


class Unidad {
public:
    Unidad();
    Unidad(const Unidad& orig);
    virtual ~Unidad();
    void lee(int cod,ifstream &arch);
    int devolverDNI();
    int devolverFecha();
    void imprimir(ofstream &arch);
private:
    Pedido *ped;
};

#endif /* UNIDAD_H */

