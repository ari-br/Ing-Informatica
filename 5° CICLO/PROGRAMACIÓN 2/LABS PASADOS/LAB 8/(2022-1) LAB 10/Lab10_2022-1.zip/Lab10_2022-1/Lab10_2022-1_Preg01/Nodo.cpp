/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Nodo.cpp
 * Author: Ariana
 * 
 * Created on 22 de noviembre de 2024, 12:18 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Nodo.h"

Nodo::Nodo() {
    sig=nullptr;
    ant=nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
}

bool Nodo::compara(Unidad &unidad){
    if(unid.devolverDNI()>unidad.devolverDNI())
        return true;
    else
        if(unid.devolverDNI()==unidad.devolverDNI() and 
                unid.devolverFecha()>unidad.devolverFecha())
            return true;
    return false;
}

void Nodo::imprimir(ofstream &arch){
    unid.imprimir(arch);
}