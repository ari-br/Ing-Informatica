/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Pedido.cpp
 * Author: Ariana
 * 
 * Created on 21 de noviembre de 2024, 09:00 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "Pedido.h"

Pedido::Pedido() {
    codigo=0;
    nombre=nullptr;
    cantidad=0;
    dni=0;
    fecha=0;
    total=0;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
    if(nombre!=nullptr) delete nombre;
}

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

void Pedido::SetNombre(char *cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Pedido::GetNombre(char *cad) const{
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Pedido::lee(int cod,ifstream &arch){
    codigo=cod;
    char cad[100],c;
    int dd,mm,aa,fechaPed;
    arch.getline(cad,100,',');
    SetNombre(cad);
    arch>>cantidad>>c>>total>>c>>dni>>c>>dd>>c>>mm>>c>>aa;
    fechaPed=(aa*10000)+(mm*100)+dd;
    fecha=fechaPed;
}

void Pedido::devolverFecha(int &dd,int &mm,int &aa){
    aa=fecha/10000;
    mm=(fecha/100)%100;
    dd=fecha%100;
}

void Pedido::imprime(int desc,int flet,ofstream &arch){
    char cad[100];
    int dd,mm,aa;
    devolverFecha(dd,mm,aa);
    GetNombre(cad);
    arch<<right<<setfill('0')<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<setw(4)<<aa
        <<setfill(' ')<<endl;
    arch<<left<<setw(12)<<codigo<<cad<<endl;
    arch<<"DNI:"<<right<<setw(18)<<dni<<endl;
    total=total-(total*desc/100)+(total*flet/100);
    arch<<"Monto Total:"<<right<<setw(10)<<total<<endl;
}