/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Lista.cpp
 * Author: Ariana
 * 
 * Created on 22 de noviembre de 2024, 12:20 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Lista.h"

Lista::Lista() {
    lini=nullptr;
    lfin=nullptr;
}

Lista::Lista(const Lista& orig) {
}

Lista::~Lista() {
}

void Lista::cargar(Unidad &unidad){
    Nodo *nuevoNodo=new Nodo;
    nuevoNodo->unid=unidad;
    Nodo *rec=lini,*anterior=nullptr;
    
    while(rec){
        if(rec->compara(unidad)) break;
        anterior=rec;
        rec=rec->sig;
    }
    nuevoNodo->sig=rec;
    if(rec!=nullptr) rec->ant=nuevoNodo;
    if(anterior==nullptr){
        lini=nuevoNodo;
    }else{
        anterior->sig=nuevoNodo;
        nuevoNodo->ant=anterior;
    }
    lfin=nuevoNodo;
}

void Lista::imprimir(ofstream &arch){
    Nodo *rec=lini;
    while(rec){
        rec->imprimir(arch);
        rec=rec->sig;
    }
}