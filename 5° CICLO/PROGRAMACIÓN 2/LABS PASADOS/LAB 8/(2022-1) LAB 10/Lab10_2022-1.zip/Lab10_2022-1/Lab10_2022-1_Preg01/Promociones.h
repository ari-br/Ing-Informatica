/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Promociones.h
 * Author: Ariana
 *
 * Created on 22 de noviembre de 2024, 12:22 AM
 */

#ifndef PROMOCIONES_H
#define PROMOCIONES_H

#include "Lista.h"


class Promociones {
public:
    Promociones();
    Promociones(const Promociones& orig);
    virtual ~Promociones();
    void leepedidos();
    void actualizapedidos();
    void imprimepedidos();
private:
    Lista Lpedidos;
    void imprimirLinea(ofstream &arch,char c);
    void AperturaIf(ifstream &arch,const char *nomb);
    void AperturaOf(ofstream &arch,const char *nomb);
};

#endif /* PROMOCIONES_H */

