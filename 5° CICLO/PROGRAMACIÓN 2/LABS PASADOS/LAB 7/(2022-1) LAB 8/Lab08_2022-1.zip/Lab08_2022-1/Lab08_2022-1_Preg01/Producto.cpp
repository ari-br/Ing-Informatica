/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Producto.cpp
 * Author: Ariana
 * 
 * Created on 6 de noviembre de 2024, 02:34 PM
 */

#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Producto.h"

Producto::Producto() {
    codprod=0;
    nombre=nullptr;
    precio=0;
    stock=0;
}

Producto::Producto(const Producto& orig) {
}

Producto::~Producto() {
    if(nombre!=nullptr) delete nombre;
}

void Producto::SetStock(int stock) {
    this->stock = stock;
}

int Producto::GetStock() const {
    return stock;
}

void Producto::SetPrecio(double precio) {
    this->precio = precio;
}

double Producto::GetPrecio() const {
    return precio;
}

void Producto::SetCodprod(int codprod) {
    this->codprod = codprod;
}

int Producto::GetCodprod() const {
    return codprod;
}

void Producto::SetNombre(char *cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Producto::GetNombre(char *cad){
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Producto::leerProductos(int codigo){
    ifstream arch("productos3.csv",ios::in);
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<"productos3.csv"<<endl;
        exit(1);
    }
    int cod,stoc;
    char cad[100],c;
    double prec;
    while (1) {
        arch>>cod>>c;
        if(arch.eof()) break;
        arch.getline(cad,100,',');
        arch>>prec>>c>>stoc;        
        if(cod==codigo){
            SetCodprod(codigo);
            SetNombre(cad);
            SetPrecio(prec);
            SetStock(stoc);
            break;
        }
    }
}
