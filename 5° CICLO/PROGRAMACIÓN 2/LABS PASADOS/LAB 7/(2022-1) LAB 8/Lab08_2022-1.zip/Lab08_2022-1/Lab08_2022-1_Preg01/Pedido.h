/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Pedido.h
 * Author: Ariana
 *
 * Created on 6 de noviembre de 2024, 02:43 PM
 */

#ifndef PEDIDO_H
#define PEDIDO_H

#include "Producto.h"


class Pedido:public Producto { //Hereda de Producto
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetTotal(double total);
    double GetTotal() const;
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void SetObs(char *cad);
    void GetObs(char *cad);
    void operator =(Pedido &);
    void devolverFecha(int &,int &,int &);
private:
    int codigo;
    int cantidad;
    int dni;
    int fecha;
    double total;
    char *obs;
};

ifstream &operator >>(ifstream &,Pedido &);
ofstream &operator <<(ofstream &,Pedido &);

#endif /* PEDIDO_H */

