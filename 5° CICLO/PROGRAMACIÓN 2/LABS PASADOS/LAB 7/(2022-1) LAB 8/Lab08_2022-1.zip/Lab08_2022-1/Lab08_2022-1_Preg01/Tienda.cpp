/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Tienda.cpp
 * Author: Ariana
 * 
 * Created on 6 de noviembre de 2024, 03:05 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Tienda.h"

Tienda::Tienda() {
    lpedidos=nullptr;
    lclientes=nullptr;
}

Tienda::Tienda(const Tienda& orig) {
}

Tienda::~Tienda() {
    if(lpedidos!=nullptr) delete[] lpedidos;
    if(lclientes!=nullptr) delete[] lclientes;
}

void Tienda::carga(){
    //Cargar arreglo pedidos
    cargaPedidos();
    //Cargar arreglo clientes
    cargarClientes();
}

void Tienda::cargaPedidos(){
    ifstream arch("pedidos3.csv",ios::in);
    AperturaIf(arch,"pedidos3.csv");
    
    Pedido buffer[150];
    int i=0;
    for (i; 1; i++) {
        arch>>buffer[i];
        if(arch.eof()) break;
    }
    lpedidos=new Pedido[i+1];
    for (int k = 0; k < i; k++) lpedidos[k]=buffer[k];
}

void Tienda::cargarClientes(){
    ifstream arch("clientes2.csv",ios::in);
    AperturaIf(arch,"clientes2.csv");
    
    Cliente buffer[50];
    int i=0;
    for (i; 1; i++) {
        arch>>buffer[i];
        if(arch.eof()) break;
    }
    lclientes=new Cliente[i+1];
    for (int k = 0; k < i; k++) lclientes[k]=buffer[k];
}

void Tienda::actualiza(int cantidad){
    
}

void Tienda::muestra(){
    //Mostrar pedidos
    mostrarPedidos();
    //Mostrar clientes, solo para probar si se cargaron de forma correcta
//    mostrarClientes();
}

void Tienda::mostrarPedidos(){
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    arch<<setprecision(2)<<fixed;
    arch<<left<<setw(12)<<"Fecha"<<setw(8)<<"Codigo"<<setw(50)
        <<"Descripcion del Prod"<<setw(8)<<"Cant."<<setw(11)<<"Precio"
        <<setw(8)<<"Total"<<"Observaciones"<<endl;
    imprimirLinea(arch,135,'=');
    for (int i = 0; lpedidos[i].GetCodigo(); i++) {
        arch<<lpedidos[i];
    }
}

void Tienda::mostrarClientes(){
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    arch<<"CLIENTES"<<endl;
    imprimirLinea(arch,70,'=');
    arch<<left<<setw(2)<<" "<<setw(11)<<"DNI"<<setw(45)<<"NOMBRE"<<"CATEGORIA"<<endl;
    imprimirLinea(arch,70,'-');
    for (int i = 0; lclientes[i].GetDni(); i++) {
        arch<<lclientes[i];
    }
}

void Tienda::imprimirLinea(ofstream &arch,int max,char c){
    for (int i = 0; i < max; i++) arch<<c;
    arch<<endl;
}

void Tienda::AperturaIf(ifstream &arch,const char* nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void Tienda::AperturaOf(ofstream &arch,const char* nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}