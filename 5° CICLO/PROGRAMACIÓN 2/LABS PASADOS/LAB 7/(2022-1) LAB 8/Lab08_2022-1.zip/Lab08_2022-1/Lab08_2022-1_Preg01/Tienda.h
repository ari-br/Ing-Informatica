/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Tienda.h
 * Author: Ariana
 *
 * Created on 6 de noviembre de 2024, 03:05 PM
 */

#ifndef TIENDA_H
#define TIENDA_H

#include "Pedido.h"
#include "Cliente.h"


class Tienda {
public:
    Tienda();
    Tienda(const Tienda& orig);
    virtual ~Tienda();
    void carga();
    void muestra();
    void actualiza(int);
private:
    Pedido *lpedidos; //Arreglo con memoria dinámica exacta
    Cliente *lclientes; //Arreglo con memoria dinámica exacta
    void cargaPedidos();
    void cargarClientes();
    void mostrarPedidos();
    void mostrarClientes();
    void imprimirLinea(ofstream &,int,char);
    void AperturaIf(ifstream &,const char*);
    void AperturaOf(ofstream &,const char*);
};

#endif /* TIENDA_H */

