/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Cliente.h
 * Author: Ariana
 *
 * Created on 6 de noviembre de 2024, 02:26 PM
 */

#ifndef CLIENTE_H
#define CLIENTE_H

class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    void SetCategoria(char categoria);
    char GetCategoria() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetNombre(char *cad);
    void GetNombre(char *cad);
    void operator =(Cliente &);
private:
    int dni;
    char categoria;
    char *nombre;
};

ifstream &operator >>(ifstream &,Cliente &);
ofstream &operator <<(ofstream &,Cliente &);

#endif /* CLIENTE_H */

