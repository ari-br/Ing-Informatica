/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Pedido.cpp
 * Author: Ariana
 * 
 * Created on 6 de noviembre de 2024, 02:43 PM
 */

#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Pedido.h"

Pedido::Pedido() {
    codigo=0;
    cantidad=0;
    dni=0;
    fecha=0;
    total=0;
    obs=nullptr;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
    if(obs!=nullptr) delete obs;
}

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

void Pedido::SetObs(char *cad){
    if(obs!=nullptr) delete obs;
    obs=new char[strlen(cad)+1];
    strcpy(obs,cad);
}

void Pedido::GetObs(char *cad){
    if(obs!=nullptr)
        strcpy(cad,obs);
}

void Pedido::devolverFecha(int &dd,int &mm,int &aa){
    aa=fecha/10000;
    mm=(fecha/100)%100;
    dd=fecha%100;
}

void Pedido::operator =(Pedido &ped){
    char cad[100];
    //Pedido
    SetCodigo(ped.GetCodigo());
    SetCantidad(ped.GetCantidad());
    SetDni(ped.GetDni());
    SetFecha(ped.GetFecha());
    SetTotal(ped.GetTotal());
    ped.GetObs(cad);
    SetObs(cad);
    //Producto
    SetCodprod(ped.GetCodprod());
    ped.GetNombre(cad);
    SetNombre(cad);
    SetPrecio(ped.GetPrecio());
    SetStock(ped.GetStock());
}

ofstream &operator <<(ofstream &arch,Pedido &f){
    int dd,mm,aa;
    f.devolverFecha(dd,mm,aa);
    char cad[100];
    f.GetNombre(cad);
    arch<<right<<setfill('0')<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<aa
        <<setfill(' ')<<setw(8)<<f.GetCodigo()<<setw(2)<<" "<<left<<setw(50)
        <<cad<<right<<setw(3)<<f.GetCantidad()<<setw(11)<<f.GetPrecio()
        <<setw(10)<<f.GetTotal()<<setw(3)<<" ";
    f.GetObs(cad);
    arch<<cad<<endl;
    return arch;
}

ifstream &operator >>(ifstream &arch,Pedido &f){
    int cod,cant,dni,dd,mm,aa,fecha;
    char c;
    arch>>cod>>c;
    if(!arch.eof()){
        f.SetCodigo(cod);
        arch>>cant>>c>>dni>>c>>dd>>c>>mm>>c>>aa;
        fecha=(aa*10000)+(mm*100)+dd;
        f.SetCantidad(cant);
        f.SetDni(dni);
        f.SetFecha(fecha);
        f.leerProductos(cod);
        f.SetTotal(f.GetPrecio()*f.GetCantidad());
        f.SetObs(" ");
    }
    return arch;
}