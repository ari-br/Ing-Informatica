/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 6 de noviembre de 2024, 02:25 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Tienda.h"
/*
 * 
 */
int main(int argc, char** argv) {
    Tienda tien;
    
    tien.carga();
    tien.actualiza(20);
    tien.muestra();
    
    return 0;
}

