/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Cliente.cpp
 * Author: Ariana
 * 
 * Created on 6 de noviembre de 2024, 02:26 PM
 */

#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Cliente.h"

Cliente::Cliente() {
    dni=0;
    nombre=nullptr;
}

Cliente::Cliente(const Cliente& orig) {
}

Cliente::~Cliente() {
    if(nombre!=nullptr) delete nombre;
}

void Cliente::SetCategoria(char categoria) {
    this->categoria = categoria;
}

char Cliente::GetCategoria() const {
    return categoria;
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

void Cliente::SetNombre(char *cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Cliente::GetNombre(char *cad){
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Cliente::operator =(Cliente &cli){
    SetDni(cli.GetDni());
    char cad[100];
    cli.GetNombre(cad);
    SetNombre(cad);
    SetCategoria(cli.GetCategoria());
}

ofstream &operator <<(ofstream &arch,Cliente &f){
    char cad[100];
    f.GetNombre(cad);
    arch<<left<<setw(13)<<f.GetDni()<<setw(49)<<cad<<f.GetCategoria()<<endl;
}

ifstream &operator >>(ifstream &arch,Cliente &f){
    int dni;
    char cad[100],c;
    arch>>dni>>c;
    if(!arch.eof()){
        f.SetDni(dni);
        arch.getline(cad,100,',');
        f.SetNombre(cad);
        arch>>c;
        f.SetCategoria(c);
    }
    return arch;
}