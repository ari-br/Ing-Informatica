/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   MetodoExactoDeMemoria.h
 * Author: Ariana Burga
 * Código: 20226705
 * Created on 12 de septiembre de 2024, 05:01 AM
 */

#ifndef METODOEXACTODEMEMORIA_H
#define METODOEXACTODEMEMORIA_H

void lecturaDeLibros(const char *nomb,char ***&libros,int **&stock);
char **leerLibro(ifstream &arch,int *&buffStock);

void pruebaDeLecturaDeLibros(const char *nomb,char ***libros,int **stock);

void atencionDePedidos(const char *nomb,char ***libros,int **stock,
        int **&pedidosClientes,char ***&pedidosLibros,bool **&pedidosAtendidos);
int buscarCliente(int dni,int **buffPedCli);
void agregarCliente(int *&buffPedCli,int dni,int &posCli,int &cantCli);
void agregarPedido(int *buffPedCli,int numPed);
void leerPedidos(ifstream &arch,char **&buffPedLib,bool *&buffPedAtend,
        char ***libros,int **stock,int &cantLib);
int buscarLibro(char ***libros,char *codLibro);
void modificarPedidoAtendido(int *stock,bool &pedAtend);
void cargarArreglos(int **&pedidosClientes,char ***&pedidosLibros,
        bool **&pedidosAtendidos,int **buffPedCli,char ***buffPedLib,
        bool **buffPedAtend,int cantCli,int cantPed,int *cantLibEnPed);
void cargarClienteNivelInterno(int *pedidosClientes,int *buffPedCli);
void cargarLibrosEnPedido(char **pedidosLibros,bool *pedidosAtendidos,
        char **buffPedLib,bool *buffPedAtend,int cantLib);

void reporteDeEntregaDePedidos(const char *nomb,int **pedidosClientes,
        char ***pedidosLibros,bool **pedidosAtendidos);
void imprimirCliente(ofstream &arch,int *pedidosClientes,char ***pedidosLibros,
        bool **pedidosAtendidos);
void imprimirPedidos(ofstream &arch,bool &flag,int numPedido,char **pedidosLibros,
                bool *pedidosAtendidos);
void imprimirObservacion(ofstream &arch,bool pedAtend);

char *leerCadenaExacta(ifstream &arch,int max,char c);
void imprimirLinea(ofstream &arch,int max,char c);
void AperturaIf(ifstream &arch,const char *nomb);
void AperturaOf(ofstream &arch,const char *nomb);

#endif /* METODOEXACTODEMEMORIA_H */
