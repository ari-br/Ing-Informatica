/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   MetodoExactoDeMemoria.cpp
 * Author: Ariana Burga
 * Código: 20226705
 * Created on 12 de septiembre de 2024, 05:01 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "MetodoExactoDeMemoria.h"
#define NO_ENCONTRADO -1

void reporteDeEntregaDePedidos(const char *nomb,int **pedidosClientes,
        char ***pedidosLibros,bool **pedidosAtendidos){
    ofstream arch(nomb,ios::out);
    AperturaOf(arch,nomb);
    arch<<fixed<<setprecision(2);
    arch<<right<<setw(50)<<"REPORTE DE ATENCIÓN DE PEDIDOS"<<endl;
    for(int i = 0; pedidosClientes[i]!=nullptr; i++){
        imprimirLinea(arch,70,'=');
        imprimirCliente(arch,pedidosClientes[i],pedidosLibros,pedidosAtendidos);
    }
}

void imprimirCliente(ofstream &arch,int *pedidosClientes,char ***pedidosLibros,
        bool **pedidosAtendidos){
    bool flag;
    int numPedido;
    arch<<"CLIENTE:"<<right<<setw(10)<<pedidosClientes[0]<<endl;
    imprimirLinea(arch,70,'=');
    for (int i = 0; i < pedidosClientes[1]; i++) {
        arch<<right<<setw(18)<<"Pedido No."<<setw(25)<<"Código del libro"
            <<setw(20)<<"Observación"<<endl;
        imprimirLinea(arch,70,'-');
        flag=true;
        numPedido=pedidosClientes[2+i];
        imprimirPedidos(arch,flag,numPedido,pedidosLibros[numPedido],
                pedidosAtendidos[numPedido]);
        imprimirLinea(arch,70,'-');
    }
}

void imprimirPedidos(ofstream &arch,bool &flag,int numPedido,char **pedidosLibros,
                bool *pedidosAtendidos){
    if(pedidosLibros[0]==nullptr)//Cuando el pedido, no tiene libros
            arch<<setw(10)<<" "<<right<<setfill('0')<<setw(6)<<numPedido
                    <<setfill(' ')<<setw(34)<<" "<<"PEDIDO SIN LIBROS"<<endl;
    for (int i = 0; pedidosLibros[i]!=nullptr; i++) {
        if(flag){
            arch<<setw(10)<<" "<<right<<setfill('0')<<setw(6)<<numPedido
                    <<setfill(' ')<<setw(21)<<pedidosLibros[i];
            flag=false;
        }else{
            arch<<right<<setw(37)<<pedidosLibros[i];
        }
        arch<<setw(13)<<" ";
        imprimirObservacion(arch,pedidosAtendidos[i]);
        arch<<endl;
    }
}

void imprimirObservacion(ofstream &arch,bool pedAtend){
    if(pedAtend){
        arch<<"ATENDIDO";
    }else{
        arch<<"NO ATENDIDO";
    }
}

void atencionDePedidos(const char *nomb,char ***libros,int **stock,
        int **&pedidosClientes,char ***&pedidosLibros,bool **&pedidosAtendidos){
    ifstream arch(nomb,ios::in);
    AperturaIf(arch,nomb);
    //1. Declarar buffers
    int *buffPedCli[200]{},numPed,dni,posCli=NO_ENCONTRADO,cantCli=0,
        cantLibEnPed[200]{},cantPed=0;
    char **buffPedLib[200]{},c;
    bool *buffPedAtend[200]{};
    //2. Leer archivo
    while(1){
        arch>>numPed;
        if(arch.eof()) break;
        arch>>c>>dni;
        if(cantCli>0) posCli=buscarCliente(dni,buffPedCli);
        if(posCli==NO_ENCONTRADO)
            agregarCliente(buffPedCli[cantCli],dni,posCli,cantCli);
        agregarPedido(buffPedCli[posCli],numPed);
        buffPedLib[numPed]=nullptr;
        if(arch.get()!='\n') leerPedidos(arch,buffPedLib[numPed],
                buffPedAtend[numPed],libros,stock,cantLibEnPed[numPed]);
        cantPed++;
    }
    //3. Cargar arreglos
    cargarArreglos(pedidosClientes,pedidosLibros,pedidosAtendidos,buffPedCli,
        buffPedLib,buffPedAtend,cantCli,cantPed,cantLibEnPed);
}

void cargarArreglos(int **&pedidosClientes,char ***&pedidosLibros,
        bool **&pedidosAtendidos,int **buffPedCli,char ***buffPedLib,
        bool **buffPedAtend,int cantCli,int cantPed,int *cantLibEnPed){
    pedidosClientes=new int*[cantCli+1];
    pedidosLibros=new char**[cantPed+2];//Los pedidos empiezan desde 0000001
    pedidosAtendidos=new bool*[cantPed+1];
    int *auxBuffPedCli;
    for (int i = 0; i < cantCli; i++) {
        auxBuffPedCli=buffPedCli[i];
        pedidosClientes[i]=new int[auxBuffPedCli[1]+2];//auxBuffPedCli[1]: cant de pedidos
        cargarClienteNivelInterno(pedidosClientes[i],buffPedCli[i]);
    }
    pedidosClientes[cantCli]=nullptr;
    for (int i = 1; i < cantPed+1; i++) {
        pedidosLibros[i]=new char*[cantLibEnPed[i]+1];
        pedidosAtendidos[i]=new bool[cantLibEnPed[i]];
        cargarLibrosEnPedido(pedidosLibros[i],pedidosAtendidos[i],buffPedLib[i],
                buffPedAtend[i],cantLibEnPed[i]);
    }
    pedidosLibros[cantPed+1]=nullptr;
}

void cargarLibrosEnPedido(char **pedidosLibros,bool *pedidosAtendidos,
        char **buffPedLib,bool *buffPedAtend,int cantLib){
    for (int i = 0; i < cantLib; i++) {
        pedidosLibros[i]=buffPedLib[i];
        pedidosAtendidos[i]=buffPedAtend[i];
    }
    pedidosLibros[cantLib]=nullptr;
}

void cargarClienteNivelInterno(int *pedidosClientes,int *buffPedCli){
    for (int i = 0; i < buffPedCli[1]+2; i++) {
        pedidosClientes[i]=buffPedCli[i];
    }
}

void leerPedidos(ifstream &arch,char **&buffPedLib,bool *&buffPedAtend,
        char ***libros,int **stock,int &cantLib){
    int posLibro;
    char codLibro[8];
    buffPedLib=new char*[20];
    buffPedAtend=new bool[20];
    while(1){
        arch>>codLibro;
        buffPedLib[cantLib]=new char[8];
        strcpy(buffPedLib[cantLib],codLibro);
        posLibro=buscarLibro(libros,codLibro);
        modificarPedidoAtendido(stock[posLibro],buffPedAtend[cantLib]);
        cantLib++;
        if(arch.get()=='\n') break;
    }
}

void modificarPedidoAtendido(int *stock,bool &pedAtend){
    if(stock[0]>0){
        pedAtend=true;
        stock[0]--;
    }else{
        pedAtend=false;
        stock[1]++;
    }
}

int buscarLibro(char ***libros,char *codLibro){
    char **auxLib;
    for (int i = 0;libros[i]!=nullptr; i++) {
        auxLib=libros[i];
        if(strcmp(auxLib[0],codLibro)==0) return i;
    }
    return NO_ENCONTRADO;
}

void agregarPedido(int *buffPedCli,int numPed){
    buffPedCli[2+buffPedCli[1]]=numPed;
    buffPedCli[1]++;
}

void agregarCliente(int *&buffPedCli,int dni,int &posCli,int &cantCli){
    buffPedCli=new int[20];
    buffPedCli[0]=dni;
    buffPedCli[1]=0; //cant de pedidos
    posCli=cantCli;
    cantCli++;
}

int buscarCliente(int dni,int **buffPedCli){
    int *auxDni;
    for (int i = 0;buffPedCli[i]!=nullptr; i++) {
        auxDni=buffPedCli[i];
        if(auxDni[0]==dni) return i;
    }
    return NO_ENCONTRADO;
}

void pruebaDeLecturaDeLibros(const char *nomb,char ***libros,int **stock){
    ofstream arch(nomb,ios::out);
    AperturaOf(arch,nomb);
    arch<<fixed<<setprecision(2);
    arch<<left<<setw(10)<<"CODIGO"<<setw(65)<<"TITULO"<<setw(45)<<"AUTOR"
        <<setw(15)<<"STOCK"<<"CANTIDAD NO ATENDIDA"<<endl;
    imprimirLinea(arch,160,'=');
    
    char **auxLibros;
    int *auxStock;
    for (int i = 0; libros[i]!=nullptr; i++) {
        auxLibros=libros[i];
        auxStock=stock[i];
        arch<<left<<setw(10)<<auxLibros[0]<<setw(65)<<auxLibros[1]<<setw(40)
            <<auxLibros[2]<<right<<setw(8)<<auxStock[0]<<setw(23)<<auxStock[1]
            <<endl;
    }    
}

void lecturaDeLibros(const char *nomb,char ***&libros,int **&stock){
    ifstream arch(nomb,ios::in);
    AperturaIf(arch,nomb);
    //1. Declarar buffers
    char **buffLibros[300];
    int *buffStock[300],i=0;
    //2. Leer archivo
    while(1){
        buffLibros[i]=leerLibro(arch,buffStock[i]);
        if(arch.eof()) break;
        i++;
    }
    //3. Cargar arreglos
    libros=new char**[i+1]; //Un espacio más para el terminador
    stock=new int*[i];
    int k;
    for(k=0;k<i;k++){
        libros[k]=buffLibros[k];
        stock[k]=buffStock[k];
    }
    libros[i]=buffLibros[i]; //terminador
}

char **leerLibro(ifstream &arch,int *&buffStock){
    char **tripleta,c;
    int *dupla,stock;
    double precio;
    
    tripleta=new char*[3];
    tripleta[0]=leerCadenaExacta(arch,10,','); //codigo;
    if(arch.eof()) return nullptr;
    tripleta[1]=leerCadenaExacta(arch,100,','); //titulo
    tripleta[2]=leerCadenaExacta(arch,100,','); //autor
    arch>>stock>>c>>precio;
    arch.get();
    
    dupla=new int[2];
    dupla[0]=stock;
    dupla[1]=0;
    buffStock=dupla;
    
    return tripleta;
}

char *leerCadenaExacta(ifstream &arch,int max,char c){
    char buffer[150],*pt;
    arch.getline(buffer,max,c);
    if(arch.eof()) return nullptr;
    pt=new char[strlen(buffer)+1];
    strcpy(pt,buffer);
    return pt;
}

void imprimirLinea(ofstream &arch,int max,char c){
    for(int i=0;i<max;i++){
        arch<<c;
    }
    arch<<endl;
}

void AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}