/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 28 de agosto de 2024, 10:35 AM
 */

#include <cstdlib>

#include "AsignacionDinamicaMemoriaExacta.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    char ***productos;
    int *stock;
    double *precios;
    
    lecturaDeProductos("productos.csv",productos,stock,precios);
    pruebaDeLecturaDeProductos("ReporteProductos.txt",productos,stock,precios);
    

    return 0;
}

