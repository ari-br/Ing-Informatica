/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AsignacionDinamicaMemoriaExacta.cpp
 * Author: cueva.r
 * 
 * Created on 28 de agosto de 2024, 10:36 AM
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
#include "AsignacionDinamicaMemoriaExacta.h"

using namespace std;


/*
BIT-434,Campana Extractora modelo Glass,375.09,10
SSE-115,Refrigeradora  CoolStyle 311N Steel,3243.58,23
NMV-644,Lavadora Automatica,3272.48,5
 */
void lecturaDeProductos(const char*nom,
        char ***&productos,int *&stock,double *&precios){
    int buffstock[200],i=0;
    double buffprecio[200];
    char cad[100],c;
    
    ifstream arch(nom,ios::in);
    if(!arch){
        cout <<"No se puede abrir el archivo de productos";
        exit(1);
    }
    while(1){
        arch.getline(cad,10,',');
        if(arch.eof())break;
        arch.getline(cad,100,',');
        arch >> buffprecio[i] >> c >>buffstock[i];
        arch.get();
        i++;
    }
    stock = new int[i];
    precios = new double[i+1];
    precios[i]=0;
    
    for (int j = 0; j < i;j++) {
        stock[j] = buffstock[j];
        precios[j] = buffprecio[j];
    }
}

void pruebaDeLecturaDeProductos(const char*nom,
        char ***productos,int *stock,double *precios){
    ofstream arch(nom,ios::out);
    if(!arch){
        cout <<"No se puede abrir el archivo de reporte";
        exit(1);
    }  
    for(int i=0;precios[i]!=0;i++){
        arch << setw(10)<< stock[i] << 
                fixed << setprecision(2)<<setw(10)<<precios[i] << endl;
        
    }
    
}