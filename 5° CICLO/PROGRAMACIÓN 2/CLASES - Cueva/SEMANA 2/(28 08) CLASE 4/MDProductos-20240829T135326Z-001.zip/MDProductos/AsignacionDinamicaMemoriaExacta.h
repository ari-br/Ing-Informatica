/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AsignacionDinamicaMemoriaExacta.h
 * Author: cueva.r
 *
 * Created on 28 de agosto de 2024, 03:15 PM
 */

#ifndef ASIGNACIONDINAMICAMEMORIAEXACTA_H
#define ASIGNACIONDINAMICAMEMORIAEXACTA_H
    void lecturaDeProductos(const char*nom,char ***&productos,
        int *&stock,double *&precios);
#endif /* ASIGNACIONDINAMICAMEMORIAEXACTA_H */
