/* 
 * File:   AsignacionDinamicaMemoriaExacta.cpp
 * Author: cueva.r
 * 
 * Created on 28 de agosto de 2024, 03:15 PM
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
#include "AsignacionDinamicaMemoriaExacta.h"

using namespace std;


/*
BIT-434,Campana Extractora modelo Glass,375.09,10
SSE-115,Refrigeradora  CoolStyle 311N Steel,3243.58,23 
 */
void lecturaDeProductos(const char*nom,char ***&productos,
        int *&stock,double *&precios){
    char cad[100],c;
    int buffstock[200],n=0;
    double buffprecios[200];
    
    ifstream arch(nom,ios::in);
    if(!arch){
        cout <<"No se abrio el archivo de productos";
        exit(1);
    }
    while(1){
        arch.getline(cad,10,',');
        if(arch.eof())break;
        arch.getline(cad,100,',');
        arch >> buffprecios[n]>>c >> buffstock[n];
        arch.get();
        n++;
    }
    stock = new int[n+1];
    precios = new double[n+1];
    precios[n]=0;
    for(int i=0;i<n;i++){
        precios[i]=buffprecios[i]; 
        stock[i]=buffstock[i];
    }

}

