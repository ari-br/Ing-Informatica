/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 28 de agosto de 2024, 03:13 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    char***productos;
    int *stock;
    double *precios;
    
    

    return 0;
}

