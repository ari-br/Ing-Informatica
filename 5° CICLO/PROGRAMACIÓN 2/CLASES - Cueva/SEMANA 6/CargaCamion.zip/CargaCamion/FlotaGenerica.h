/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FlotaGenerica.h
 * Author: cueva.r
 *
 * Created on 24 de septiembre de 2024, 10:41 AM
 */

#ifndef FLOTAGENERICA_H
#define FLOTAGENERICA_H
#include <fstream>
using namespace std;

    void cargacamiones(void *&flota,int num,double peso,
       void*(*lee)(ifstream&),double(*calcula)(void*),const char*nom);
    void push(void *&pila,void*dato,double peso);
    void *generapila();
    void muestracamiones(void *flota,int n,void(*imprime)(ofstream&,void*),
        const char*nom);
#endif /* FLOTAGENERICA_H */
