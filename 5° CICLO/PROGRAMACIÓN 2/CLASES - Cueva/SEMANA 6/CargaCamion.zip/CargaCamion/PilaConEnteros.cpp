/* 
 * File:   PilaConEnteros.cpp
 * Author: cueva.r
 * 
 * Created on 24 de septiembre de 2024, 10:59 AM
 */
#include <iostream>
#include <fstream>
#include "PilaConEnteros.h"

using namespace std;
/*
3
4
*/
void* leenumero(ifstream &arch){
    double aux,*num;
    
    arch >> aux;
    if(arch.eof()) return nullptr;
    num=new double;
    *num=aux;
    
    return num;
}

double calculanumero(void *dato){
    double *num;
    num=(double*)dato;
    return (double)*num;
}

void imprimenumero(ofstream &arch,void*dato){
    double *num;
    num = (double*)dato;
    arch << *num << endl;
}
int cmpnumero(const void*a,const void*b){
    double *peso1,*peso2;
    void **aux1=(void**)a;
    void **aux2=(void**)b;
    void **dupla1=(void**)aux1[0];
    void **dupla2=(void**)aux2[0];
    
    peso1=(double*)dupla1[1];
    peso2=(double*)dupla2[1];
            
    return *peso2-*peso1;
}