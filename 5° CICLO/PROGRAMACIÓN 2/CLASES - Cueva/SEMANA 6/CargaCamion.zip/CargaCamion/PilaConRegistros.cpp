/* 
 * File:   PilaConRegistros.cpp
 * Author: cueva
 * 
 * Created on 22 de octubre de 2022, 10:53 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "PilaConRegistros.h"

using namespace std;

/*
JXD-139,50375303,6,120
CRU-009,50375303,5,200
YYK-309,22777006,3,165
 */ 

void* leeregistro(ifstream &arch){
    int *cant,*codigo;
    char *cad, cadena[10],c;
    double *peso;
    void **registro;
   
    arch.getline(cadena,10,',');
    if(arch.eof()) return 0;
    cad = new char[strlen(cadena)+1];
    strcpy(cad,cadena);        
    codigo = new int;
    cant = new int;
    peso = new double;
    arch >> *codigo >> c >> *cant >> c >> *peso;
    arch.get();

    registro = new void*[4];
    registro[0] = cad;
    registro[1] = codigo;
    registro[2] = cant;
    registro[3] = peso;
    
    return registro;
}

int cmpregistro(const void*a,const void*b){
    void**aux1=(void **)a;
    void**aux2=(void **)b;
    void**temp1=(void**)(*aux1);
    void**temp2=(void**)(*aux2);
    
    double *num1,*num2;
    
    num1 = (double*)temp1[1];
    num2 = (double*)temp2[1];
    
    return (*num2-*num1);
}

void imprimeregistro(ofstream &arch,void* dato){
    void **aux = (void**)dato;
    int *codigo,*cant;
    char *cad;
    double *peso;
    
    cad = (char*)aux[0];
    codigo = (int*)aux[1];
    cant = (int*)aux[2];
    peso = (double*)aux[3];
    
    arch <<setw(20)<<cad<<setw(10)<<*cant<<
            setprecision(2)<< fixed<<setw(10)<<*peso<<endl;
    
}

double calcularegistro(void *dato){
    void **reg = (void**)dato;
    double *num;
    
    num = (double*)reg[3];
    return *num;
}