/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FlotaGenerica.cpp
 * Author: cueva.r
 * 
 * Created on 24 de septiembre de 2024, 10:41 AM
 */
#include <iostream>
#include <fstream>
#include "FlotaGenerica.h"

using namespace std;

void cargacamiones(void *&flota,int num,double peso,
       void*(*lee)(ifstream&),double(*calcula)(void*),const char*nom){
    void **lflota,*auxreg,*auxpila;    
    lflota=new void*[num];
    double pparcial,total=0;
    int cont=0;
    
    for(int i=0;i<num;i++)
        lflota[i]=generapila();
        
    ifstream arch(nom,ios::in);
    if(!arch){
        cout <<"No se puede abrir el archivo";
        exit(1);
    }
    while(1){
        auxreg = lee(arch);
        if(auxreg==nullptr)break;
        pparcial=calcula(auxreg);
        if(pparcial+total<=peso){
            auxpila=lflota[cont];
            push(auxpila,auxreg,pparcial);
            total+=pparcial;
        }
        else{
            cont++;
            total=0;
            if(cont==num)break;
            auxpila=lflota[cont];
            push(auxpila,auxreg,pparcial);
            total+=pparcial;
        } 
    } 
    flota=lflota;
}

void push(void *&pila,void*dato,double peso){
    void **aux=(void**)pila;
    void **nuevo;
    double *suma;
    nuevo=new void*[2];
    nuevo[0] = nullptr;
    nuevo[1] = dato;
    
    nuevo[0] = aux[0];
    aux[0] = nuevo;
    suma=(double*)aux[1];
    *suma+=peso;
}

void *generapila(){
    double *num;
    void **dupla=new void*[2];
    dupla[0]=nullptr;
    num = new double;
    *num=0;
    dupla[1]=num;
    return dupla;
}

void muestracamiones(void *flota,int n,void(*imprime)(ofstream&,void*),
        const char*nom){    
    ofstream arch(nom,ios::out);
    if(!arch){
        cout <<"No se puede abrir el archivo";
        exit(1);
    }    
    void**lflota=(void**)flota;
    for(int i=0;i<n;i++){
        void**dupla=(void**)lflota[i];
        void**aux=(void**)dupla[0];
        arch <<"Pila: "<<i+1<< endl;
        while(aux){
            imprime(arch,aux[1]);
            aux=(void**)aux[0];
        }
    }
}