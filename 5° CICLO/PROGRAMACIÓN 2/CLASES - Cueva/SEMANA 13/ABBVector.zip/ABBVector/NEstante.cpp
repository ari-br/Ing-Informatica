/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NEstante.cpp
 * Author: cueva
 * 
 * Created on 13 de noviembre de 2024, 10:32 AM
 */

#include <vector>

#include "NEstante.h"

NEstante::NEstante() {
    id=0;
    capacidad=0;
    disponible=0;
    izq=nullptr;
    der=nullptr;
}

NEstante::NEstante(const NEstante& orig) {
}

NEstante::~NEstante() {
}

void NEstante::SetDisponible(double disponible) {
    this->disponible = disponible;
}

double NEstante::GetDisponible() const {
    return disponible;
}

void NEstante::SetCapacidad(double capacidad) {
    this->capacidad = capacidad;
}

double NEstante::GetCapacidad() const {
    return capacidad;
}

void NEstante::SetId(int id) {
    this->id = id;
}

int NEstante::GetId() const {
    return id;
}
// 1,20
void NEstante::generaestante(ifstream&arch){
    arch >> id;
    if(arch.eof()) return;
    arch.get();
    arch >> capacidad;
    disponible = capacidad;
}

void NEstante::leerlibros(ifstream&arch){
    NLibro naux;
    
    
    vlibros.push_back();
    
}
