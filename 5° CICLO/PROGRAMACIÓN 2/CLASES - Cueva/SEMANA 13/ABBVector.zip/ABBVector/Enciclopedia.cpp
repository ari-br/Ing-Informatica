/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Enciclopedia.cpp
 * Author: cueva
 * 
 * Created on 10 de junio de 2024, 10:39 PM
 */

#include "Enciclopedia.h"

Enciclopedia::Enciclopedia() {
    sku=0;
    anho=0;
}

Enciclopedia::Enciclopedia(const Enciclopedia& orig) {
}

Enciclopedia::~Enciclopedia() {
}

void Enciclopedia::setAnho(int anho) {
    this->anho = anho;
}

int Enciclopedia::getAnho() const {
    return anho;
}

void Enciclopedia::setSku(int sku) {
    this->sku = sku;
}

int Enciclopedia::getSku() const {
    return sku;
}
/*
E,ENCICLOPEDIA VIDA SALVAJE DEL MUNDO,480,2,17974,2020
E,ATLAS ILUSTRADO - MATEMATICAS E INFORMATICA,252,0.5,46903,2022 
*/
void Enciclopedia::lee(ifstream &arch){
    char cad[100],c;
    
    Libro::lee(arch);
    arch >> sku >> c >> anho;
    arch.get();
    
}



void Enciclopedia::imprime(ofstream&arch){
    Libro::imprime(arch);
    arch << "SKU:" <<  sku <<"    Año: " << anho << endl<<endl;
    
}

