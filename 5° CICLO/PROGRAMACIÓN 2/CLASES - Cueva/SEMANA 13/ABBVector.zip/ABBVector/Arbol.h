/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Arbol.h
 * Author: cueva
 *
 * Created on 13 de noviembre de 2024, 10:31 AM
 */

#ifndef ARBOL_H
#define ARBOL_H

#include "NEstante.h"


class Arbol {
public:
    Arbol();
    Arbol(const Arbol& orig);
    virtual ~Arbol();
    void leer(ifstream &,ifstream &);
private:
    NEstante *raiz;
};

#endif /* ARBOL_H */

