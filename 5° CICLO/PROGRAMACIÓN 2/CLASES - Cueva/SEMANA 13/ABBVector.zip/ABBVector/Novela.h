/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Novela.h
 * Author: cueva
 *
 * Created on 12 de junio de 2024, 10:43 PM
 */

#ifndef NOVELA_H
#define NOVELA_H

#include <fstream>

#include "Libro.h"

using namespace std;

class Novela: public Libro {
public:
    Novela();
    Novela(const Novela& orig);
    virtual ~Novela();
    void SetAutor(char*);
    void GetAutor(char* )const;
    void lee(ifstream&);
    void imprime(ofstream &);
private:
    char*autor;
};

#endif /* NOVELA_H */

