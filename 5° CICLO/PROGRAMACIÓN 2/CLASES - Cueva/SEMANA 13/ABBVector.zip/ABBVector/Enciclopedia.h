/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Enciclopedia.h
 * Author: cueva
 *
 * Created on 10 de junio de 2024, 10:39 PM
 */

#ifndef ENCICLOPEDIA_H
#define ENCICLOPEDIA_H

#include "Libro.h"


class Enciclopedia: public Libro {
public:
    Enciclopedia();
    Enciclopedia(const Enciclopedia& orig);
    virtual ~Enciclopedia();
    void setAnho(int anho);
    int getAnho() const;
    void setSku(int sku);
    int getSku() const;
    
    void lee(ifstream&);
    void imprime(ofstream&);
private:
    int sku;
    int anho;
};

#endif /* ENCICLOPEDIA_H */

