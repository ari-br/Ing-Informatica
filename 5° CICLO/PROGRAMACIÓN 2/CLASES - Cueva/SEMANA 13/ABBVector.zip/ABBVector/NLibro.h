/* 
 * File:   NLibro.h
 * Author: cueva
 *
 * Created on 13 de noviembre de 2024, 10:34 AM
 */

#ifndef NLIBRO_H
#define NLIBRO_H

#include "Libro.h"
#include <fstream>

using namespace std;

class NLibro {
public:
    NLibro();
    NLibro(const NLibro& orig);
    virtual ~NLibro();
    void leer(ifstream &);
private:
    Libro *plibro;
};

#endif /* NLIBRO_H */

