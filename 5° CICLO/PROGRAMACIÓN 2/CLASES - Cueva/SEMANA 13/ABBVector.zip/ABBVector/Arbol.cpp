/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Arbol.cpp
 * Author: cueva
 * 
 * Created on 13 de noviembre de 2024, 10:31 AM
 */

#include "Arbol.h"

Arbol::Arbol() {
    raiz=nullptr;
}

Arbol::Arbol(const Arbol& orig) {
}

Arbol::~Arbol() {
}

void Arbol::leer(ifstream&arch, ifstream&alib){
    NEstante *naux;
    naux = new NEstante;
    naux->generaestante(arch);
    for(int i=0;i<10;i++)
        naux->leerlibros(alib);
    
}
