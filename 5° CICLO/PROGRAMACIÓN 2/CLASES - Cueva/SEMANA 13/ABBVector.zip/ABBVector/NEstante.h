/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NEstante.h
 * Author: cueva
 *
 * Created on 13 de noviembre de 2024, 10:32 AM
 */

#ifndef NESTANTE_H
#define NESTANTE_H

#include "NLibro.h"
#include <fstream>

using namespace std;

class NEstante {
public:
    NEstante();
    NEstante(const NEstante& orig);
    virtual ~NEstante();
    void SetDisponible(double disponible);
    double GetDisponible() const;
    void SetCapacidad(double capacidad);
    double GetCapacidad() const;
    void SetId(int id);
    int GetId() const;
    void generaestante(ifstream&);
    void leerlibros(ifstream &);
    friend class Arbol;
private:
    int id;
    double capacidad;
    double disponible;
    vector<NLibro> vlibros;
    NEstante *izq;
    NEstante *der;
};

#endif /* NESTANTE_H */

