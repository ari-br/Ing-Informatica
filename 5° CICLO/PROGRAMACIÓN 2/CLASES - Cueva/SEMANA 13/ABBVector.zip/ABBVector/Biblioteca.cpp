/* 
 * File:   Biblioteca.cpp
 * Author: cueva
 * 
 * Created on 13 de noviembre de 2024, 10:30 AM
 */
#include <fstream>
#include <cstring>
#include <iostream>
#include "Biblioteca.h"

using namespace std;

Biblioteca::Biblioteca() {
}

Biblioteca::Biblioteca(const Biblioteca& orig) {
}

Biblioteca::~Biblioteca() {
}

void Biblioteca::carga(){
    ifstream arch("Estantes3.csv",ios::in);
    if(not arch){
        cout <<"No se puede abrir el archivo de estantes";
        exit(1);
    }
    ifstream alib("Libros31.csv",ios::in);
    if(not alib){
        cout <<"No se puede abrir el archivo de libros";
        exit(1);
    }
    while(1){
        AEstante.leer(arch,alib);
        
    }
   
}
