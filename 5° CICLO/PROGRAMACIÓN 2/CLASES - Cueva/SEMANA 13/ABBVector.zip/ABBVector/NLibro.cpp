/* 
 * File:   NLibro.cpp
 * Author: cueva
 * 
 * Created on 13 de noviembre de 2024, 10:34 AM
 */

#include "NLibro.h"
#include "Novela.h"
#include "Revista.h"
#include "Enciclopedia.h"

NLibro::NLibro() {
    plibro=nullptr;
}

NLibro::NLibro(const NLibro& orig) {
}

NLibro::~NLibro() {
}
/*
N,Diamantes y pedernales,120,0.7,Jose Maria Arguedas
E,ENCICLOPEDIA SALVAT,2000,12,78323,2015
 */
void NLibro::leer(ifstream&arch){
    char tipo;
    
    arch>> tipo;
    if(arch.eof()) return;
    arch.get();
    if(tipo=='N')
        plibro = new Novela;
    if(tipo=='R')
        plibro = new Revista;
    if(tipo=='E')
        plibro = new Enciclopedia;

    
}
