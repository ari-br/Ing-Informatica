/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 11 de septiembre de 2024, 03:38 PM
 */

#include <cstdlib>

using namespace std;

int main(int argc, char** argv) {
    char***cursos,***alumnos_nom_mod;
    double *cursos_cred,escalas[5];
    int *alumnos_cod,**alumnos;
    
    cargarCursosYEscalas(cursos,cursos_cred,"Cursos.csv","Escala.csv");

    return 0;
}

