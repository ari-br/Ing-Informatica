/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Preg1_Funciones_de_cursos_y_alumnos.cpp
 * Author: cueva.r
 * 
 * Created on 11 de septiembre de 2024, 03:45 PM
 */
#include <fstream>
#include "Preg1_Funciones_de_cursos_y_alumnos.h"

using namespace std;

void cargarCursosYEscalas(char ***&cursos,double *&cursos_cred,double *escalas,
    const char*nomcur,const char*nomesc){
    
    ifstream archcur,archesc;
    AperturaDeUnArchivoDeTextosParaLeer(archcur,nomcur);
    AperturaDeUnArchivoDeTextosParaLeer(archesc,nomesc);
    
    leecursos(cursos,cursos_cred,archcur);
    //leescalas
}
void leecursos(char ***&cursos,double *&cursos_cred,ifstream &arch){
    
    
}
