/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Preg1_Funciones_de_cursos_y_alumnos.h
 * Author: cueva.r
 *
 * Created on 11 de septiembre de 2024, 03:45 PM
 */

#ifndef PREG1_FUNCIONES_DE_CURSOS_Y_ALUMNOS_H
#define PREG1_FUNCIONES_DE_CURSOS_Y_ALUMNOS_H

#endif /* PREG1_FUNCIONES_DE_CURSOS_Y_ALUMNOS_H */
