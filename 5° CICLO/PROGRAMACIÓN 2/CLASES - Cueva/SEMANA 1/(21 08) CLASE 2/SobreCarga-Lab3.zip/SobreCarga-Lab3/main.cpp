
/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 21 de agosto de 2024, 10:31 AM
 */

#include <iostream>
#include <fstream>
#include <cstring>
#include "AperturaDeArchivos.h"
#include "Estructuras.h"
#include "Sobrecarga.h"

using namespace std;

int main(int argc, char** argv) {
    ifstream archcursos;
    ofstream repo;
    StCurso cur1,acur[100];

    AperturaDeUnArchivoDeTextosParaLeer(archcursos,"Cursos.txt");
    AperturaDeUnArchivoDeTextosParaEscribir(repo,"prueba.txt");
    
    archcursos >> cur1;
    repo << cur1;
    strcpy(acur[0].codigoDelCurso,"XXXXXX");
    acur+=cur1;
    repo << acur[0];
    
    return 0;
}

