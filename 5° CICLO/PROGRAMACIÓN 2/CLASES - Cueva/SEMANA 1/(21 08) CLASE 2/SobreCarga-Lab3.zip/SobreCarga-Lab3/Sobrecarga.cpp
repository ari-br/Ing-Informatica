/* 
 * File:   Sobrecarga.cpp
 * Author: cueva.r
 * 
 * Created on 21 de agosto de 2024, 10:36 AM
 */

#include "Sobrecarga.h"
#include "Estructuras.h"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;

void operator <<(ofstream &arch,StCurso cur){
    
    arch<<setw(10)<< cur.codigoDelCurso <<setw(30)<< cur.nombreDelCurso 
            <<setprecision(2)<<fixed<<setw(10)<< cur.creditos << endl;
    arch <<setw(10)<< cur.codigoDelProfesor<<setw(50)<< cur.nombreDelProfesor << endl;
    arch << "Alumnos matriculados:" <<endl;
    for(int i=0;i<cur.numeroDeAlumnos;i++){
        arch <<setw(10)<<cur.alumnos[i]/10000 << setw(10) 
                << cur.alumnos[i]%10000 << endl;  
    }
}

void operator +=(StCurso *arrcur,StCurso cur){
    int i;
    for(i=0;strcmp(arrcur[i].codigoDelCurso,"XXXXXX")!=0;
            i++);
    arrcur[i]=cur;
    strcpy(arrcur[i+1].codigoDelCurso,"XXXXXX");
}



/*
INF263   Algoritmia   3.75   35030611   INGA_FLORES_CESAR_ADOLFO
MEC270   Procesos_De_Manufactura   4   83265244   PAIRAZAMAN_ALAMO_MOISES_MIGUEL
 */
bool operator >> (ifstream &arch,StCurso &cur){
    
    arch>>cur.codigoDelCurso;
    if(arch.eof()) return false;
    arch >> cur.nombreDelCurso >> cur.creditos >> cur.codigoDelProfesor>>
            cur.nombreDelProfesor;
    cur.numeroDeAlumnos = 0;
    cur.ingresos = 0;
    return true;
} 
