/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Sobrecarga.h
 * Author: cueva.r
 *
 * Created on 21 de agosto de 2024, 10:36 AM
 */

#ifndef SOBRECARGA_H
#define SOBRECARGA_H
#include <fstream>
#include "Estructuras.h"
using namespace std;
    void operator <<(ofstream &arch,StCurso cur);
    bool operator >> (ifstream &,StCurso &);
    void operator +=(StCurso *arrcur,StCurso cur);
#endif /* SOBRECARGA_H */
