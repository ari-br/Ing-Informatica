/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   AsignacionDinamicaMemoriaExacta.h
 * Author: Ariana Burga
 * Código: 20226705
 * Created on 12 de septiembre de 2024, 04:04 PM
 */

#ifndef ASIGNACIONDINAMICAMEMORIAEXACTA_H
#define ASIGNACIONDINAMICAMEMORIAEXACTA_H

void lecturaDeProductos(const char *nomb,char ***&productos,int *&stock,
        double *&precios);
char **leerProducto(ifstream &arch,int &stock,double &precio);
void cargarArreglos(int cantProd,char ***&productos,int *&stock,
        double *&precios,char ***buffProd,int *buffStock,double *buffPrecio);

void pruebaDeLecturaDeProductos(const char *nomb,char ***productos,int *stock,
        double *precios);

void lecturaDePedidos(const char *nomb,int *&fechaPedidos,char ***&codigoPedidos,
        int ***&dniCantPedidos);
void completarBuffers(int fecha,int *buffFecha,int &cantFechas,char *codProd,
        int dni,int cantSol,char ***buffCodPed,int ***buffDniPed,int *cantPed);
int buscarFecha(int fecha,int *buffFecha,int cantFechas);
void completarPedidos(char *codProd,int dni,int cantSol,char **buffCodPed,
        int **buffDniPed,int cantPed);
void cargarArreglos(int *&fechaPedidos,char ***&codigoPedidos,
        int ***&dniCantPedidos,int *buffFecha,char ***buffCodPed,
        int ***buffDniPed,int cantFechas,int *cantPed);
void cargarPedidos(char **codigoPedidos,char **buffCodPed,int **dniCantPedidos,
        int **buffDniPed,int cantPed);

void pruebaDeLecturaDePedidos(const char *nomb,int *fechaPedidos,
        char ***codigoPedidos,int ***dniCantPedidos);
void imprimirFecha(ofstream &arch,int fecha);
void imprimirPedidos(ofstream &arch,int **dniCantPedidos,char **codigoPedidos);

void reporteDeEnviosDePedidos(const char *nomb,char ***productos,int *stock,
        double *precios,int *fechaPedidos,char ***codigoPedidos,
        int ***dniCantPedidos);
void imprimirReportePorFecha(ofstream &arch,int fecha,int **dniCantPedidos,
        char **codigoPedidos,char ***productos,int *stock,double *precios,
        double &totalIngPer,double &totalPerdPer);
void imprimirPedidosReporte(ofstream &arch,int **dniCantPedidos,
        char **codigoPedidos,char ***productos,int *stock,double *precios,
        double &totalIngresos,double &totalPerdido);
int buscarProducto(char *cod,char ***productos);
void imprimirIngresos(ofstream &arch,int cantSol,int &stock,double precio,
        double &totalIngresos,double &totalPerdido);

char *leerCadenaExacta(ifstream &arch,int max,char c);
void imprimirLinea(ofstream &arch,int max,char c);
void AperturaIf(ifstream &arch,const char *nomb);
void AperturaOf(ofstream &arch,const char *nomb);

#endif /* ASIGNACIONDINAMICAMEMORIAEXACTA_H */
