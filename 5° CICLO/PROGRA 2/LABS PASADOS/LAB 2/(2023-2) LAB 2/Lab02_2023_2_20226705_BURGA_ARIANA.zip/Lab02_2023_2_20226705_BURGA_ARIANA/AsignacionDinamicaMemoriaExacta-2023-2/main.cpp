/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana Burga
 * Código: 20226705
 * Created on 12 de septiembre de 2024, 04:02 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "AsignacionDinamicaMemoriaExacta.h"
/*
 * 
 */
int main(int argc, char** argv) {
    char ***productos,***codigoPedidos;
    int *stock,*fechaPedidos,***dniCantPedidos;
    double *precios;
    
    lecturaDeProductos("Productos.csv",productos,stock,precios);
    pruebaDeLecturaDeProductos("ReporteDeProductos.txt",productos,stock,precios);
    
    lecturaDePedidos("Pedidos.csv",fechaPedidos,codigoPedidos,dniCantPedidos);
    pruebaDeLecturaDePedidos("ReporteDePedidos.txt",fechaPedidos,codigoPedidos,
            dniCantPedidos);
    
    reporteDeEnviosDePedidos("ReporteDeEntregaDePedidos.txt",productos,stock,
            precios,fechaPedidos,codigoPedidos,dniCantPedidos);
    
    pruebaDeLecturaDeProductos("ReporteDeProductosFinal.txt",productos,stock,
            precios);
    
    return 0;
}

