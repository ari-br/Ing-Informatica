/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   AsignacionDinamicaMemoriaExacta.cpp
 * Author: Ariana Burga
 * Código: 20226705
 * Created on 12 de septiembre de 2024, 04:04 PM
 * stop: 04:12 - 04:20
 */

#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "AsignacionDinamicaMemoriaExacta.h"
#define NO_ENCONTRADO -1

void reporteDeEnviosDePedidos(const char *nomb,char ***productos,int *stock,
        double *precios,int *fechaPedidos,char ***codigoPedidos,
        int ***dniCantPedidos){
    ofstream arch(nomb,ios::out);
    AperturaOf(arch,nomb);
    arch<<fixed<<setprecision(2);
    arch<<right<<setw(70)<<"REPORTE DE ENTREGA DE PEDIDOS"<<endl;
    imprimirLinea(arch,150,'=');
    double totalIngPer=0,totalPerdPer=0;
    for (int i = 0; fechaPedidos[i]!=0; i++) {
        imprimirReportePorFecha(arch,fechaPedidos[i],dniCantPedidos[i],
            codigoPedidos[i],productos,stock,precios,totalIngPer,totalPerdPer);        
    }
    arch<<"Resumen de ingresos:"<<endl;
    arch<<left<<setw(113)<<"Total de ingresos en el periodo:"<<right<<setw(20)
            <<totalIngPer<<endl;
    arch<<left<<setw(113)<<"Total perdido por falta de stock:"<<right<<setw(20)
            <<totalPerdPer<<endl;
    imprimirLinea(arch,150,'=');
}

void imprimirReportePorFecha(ofstream &arch,int fecha,int **dniCantPedidos,
        char **codigoPedidos,char ***productos,int *stock,double *precios,
        double &totalIngPer,double &totalPerdPer){
    double totalIngresos=0,totalPerdido=0;
    imprimirFecha(arch,fecha);
    imprimirLinea(arch,150,'=');
    arch<<left<<setw(5)<<"No."<<setw(25)<<"DNI"<<setw(57)<<"Producto"
        <<setw(20)<<"Cantidad"<<setw(13)<<"Precio"<<"Total de ingresos"
            <<endl;
    imprimirLinea(arch,150,'-');
    imprimirPedidosReporte(arch,dniCantPedidos,codigoPedidos,
            productos,stock,precios,totalIngresos,totalPerdido);
    totalIngPer+=totalIngresos;
    totalPerdPer+=totalPerdido;
    imprimirLinea(arch,150,'-');
    arch<<left<<setw(113)<<"Total ingresado:"<<right<<setw(20)<<totalIngresos
            <<endl;
    arch<<left<<setw(113)<<"Total perdido por falta de stock:"<<right<<setw(20)
            <<totalPerdido<<endl;
    imprimirLinea(arch,150,'=');
}

void imprimirPedidosReporte(ofstream &arch,int **dniCantPedidos,
        char **codigoPedidos,char ***productos,int *stock,double *precios,
        double &totalIngresos,double &totalPerdido){
    int *auxDni,posProducto;
    char **auxProd;
    
    for (int i = 0; codigoPedidos[i]!=nullptr; i++) {
        auxDni=dniCantPedidos[i];
        arch<<right<<setw(3)<<i+1<<left<<setw(2)<<")"<<setw(12)<<auxDni[0]
            <<setw(10)<<codigoPedidos[i]<<setw(60);
        posProducto=buscarProducto(codigoPedidos[i],productos);
        auxProd=productos[posProducto];
        arch<<auxProd[1];
        arch<<right<<setw(5)<<auxDni[1]<<setw(21)<<precios[posProducto];
        imprimirIngresos(arch,auxDni[1],stock[posProducto],precios[posProducto],
            totalIngresos,totalPerdido);
        arch<<endl;
    }
}

void imprimirIngresos(ofstream &arch,int cantSol,int &stock,double precio,
        double &totalIngresos,double &totalPerdido){
    double pago=precio*cantSol;
    if(stock>0 && stock>=cantSol){
        totalIngresos+=pago;
        stock-=cantSol;
        arch<<setw(20)<<pago;
    }else{
        arch<<setw(21)<<"SIN STOCK";
        totalPerdido+=pago;                
    }
}

int buscarProducto(char *cod,char ***productos){
    char **aux;
    for (int i = 0; productos[i]!=nullptr; i++) {
        aux=productos[i];
        if(strcmp(aux[0],cod)==0) return i;
    }
}

void pruebaDeLecturaDePedidos(const char *nomb,int *fechaPedidos,
        char ***codigoPedidos,int ***dniCantPedidos){
    ofstream arch(nomb,ios::out);
    AperturaOf(arch,nomb);
    arch<<fixed<<setprecision(2);
    imprimirLinea(arch,50,'=');
    for (int i = 0; fechaPedidos[i]!=0; i++) {
        imprimirFecha(arch,fechaPedidos[i]);
        imprimirLinea(arch,50,'=');
        arch<<left<<setw(12)<<"DNI"<<setw(25)<<"Producto"<<"Cantidad"<<endl;
        imprimirLinea(arch,50,'-');
        imprimirPedidos(arch,dniCantPedidos[i],codigoPedidos[i]);
        imprimirLinea(arch,50,'=');
    }
}

void imprimirPedidos(ofstream &arch,int **dniCantPedidos,char **codigoPedidos){
    int *auxDni;
    for (int i = 0; codigoPedidos[i]!=nullptr; i++) {
        auxDni=dniCantPedidos[i];
        arch<<left<<setw(12)<<auxDni[0]<<setw(25)<<codigoPedidos[i]<<right
            <<setw(5)<<auxDni[1]<<endl;
    }
}

void imprimirFecha(ofstream &arch,int fecha){
    int dd,mm,aa;
    dd=fecha%100;
    mm=(fecha/100)%100;
    aa=fecha/10000;
    arch<<"FECHA: "<<setfill('0')<<right<<setw(2)<<dd<<"/"
        <<setw(2)<<mm<<"/"<<setw(4)<<aa<<setfill(' ')<<endl;
}

void lecturaDePedidos(const char *nomb,int *&fechaPedidos,char ***&codigoPedidos,
        int ***&dniCantPedidos){
    ifstream arch(nomb,ios::in);
    AperturaIf(arch,nomb);
    //1. Declarar buffers
    int buffFecha[600]{},cantFechas=0,dni,cantSol,dd,mm,aa,fecha;
    char **buffCodPed[600]{},*codProd,c;
    int **buffDniPed[600]{},cantPed[600]{};
    //2. Leer archivo
    while(1){
        codProd=leerCadenaExacta(arch,10,',');
        if(arch.eof()) break;
        arch>>dni>>c>>cantSol>>c>>dd>>c>>mm>>c>>aa;
        arch.get();
        fecha=(aa*10000)+(mm*100)+dd;
        completarBuffers(fecha,buffFecha,cantFechas,codProd,dni,cantSol,
            buffCodPed,buffDniPed,cantPed);
    }
    //3. Cargar arreglos
    cargarArreglos(fechaPedidos,codigoPedidos,dniCantPedidos,buffFecha,
            buffCodPed,buffDniPed,cantFechas,cantPed);
}

void cargarArreglos(int *&fechaPedidos,char ***&codigoPedidos,
        int ***&dniCantPedidos,int *buffFecha,char ***buffCodPed,
        int ***buffDniPed,int cantFechas,int *cantPed){
    fechaPedidos=new int[cantFechas+1];
    codigoPedidos=new char **[cantFechas];
    dniCantPedidos=new int**[cantFechas];
    for (int i = 0; i < cantFechas; i++) {
        fechaPedidos[i]=buffFecha[i];
        codigoPedidos[i]=new char*[cantPed[i]+1];
        dniCantPedidos[i]=new int*[cantPed[i]];
        cargarPedidos(codigoPedidos[i],buffCodPed[i],dniCantPedidos[i],
                buffDniPed[i],cantPed[i]);
    }
    fechaPedidos[cantFechas]=0;
}

void cargarPedidos(char **codigoPedidos,char **buffCodPed,int **dniCantPedidos,
        int **buffDniPed,int cantPed){
    for (int i = 0; i < cantPed; i++) {
        codigoPedidos[i]=buffCodPed[i];
        dniCantPedidos[i]=buffDniPed[i];
    }
    int *aux;
    aux=buffDniPed[0];
//    cout<<aux[0]<<endl;
    codigoPedidos[cantPed]=nullptr;
}

void completarBuffers(int fecha,int *buffFecha,int &cantFechas,char *codProd,
        int dni,int cantSol,char ***buffCodPed,int ***buffDniPed,int *cantPed){
    int posFecha;    
    posFecha=buscarFecha(fecha,buffFecha,cantFechas);
    if(posFecha==NO_ENCONTRADO){
        buffFecha[cantFechas]=fecha;
        buffCodPed[cantFechas]=new char *[200];
        buffDniPed[cantFechas]=new int*[200];
        posFecha=cantFechas;
        cantFechas++;
    }
    completarPedidos(codProd,dni,cantSol,buffCodPed[posFecha],
            buffDniPed[posFecha],cantPed[posFecha]);
    cantPed[posFecha]++;//cant de pedidos por fecha
}

void completarPedidos(char *codProd,int dni,int cantSol,char **buffCodPed,
        int **buffDniPed,int cantPed){
    int *aux;
    buffDniPed[cantPed]=new int[2];
    aux=buffDniPed[cantPed];
    aux[0]=dni;
    aux[1]=cantSol;
    
    buffCodPed[cantPed]=codProd;      
}

int buscarFecha(int fecha,int *buffFecha,int cantFechas){
    for (int i = 0; i < cantFechas; i++) {
        if(fecha==buffFecha[i]) return i;
    }
    return NO_ENCONTRADO;
}

void pruebaDeLecturaDeProductos(const char *nomb,char ***productos,int *stock,
        double *precios){
    ofstream arch(nomb,ios::out);
    AperturaOf(arch,nomb);
    arch<<fixed<<setprecision(2);
    arch<<left<<setw(10)<<"CODIGO"<<setw(65)<<"DESCRIPCION"<<setw(10)<<"PRECIO"
        <<"STOCK"<<endl;
    imprimirLinea(arch,91,'=');
    char **auxProd;
    for (int i = 0; productos[i]!=nullptr; i++) {
        auxProd=productos[i];
        arch<<left<<setw(10)<<auxProd[0]<<setw(61)<<auxProd[1]<<right<<setw(10)
            <<precios[i]<<setw(8)<<stock[i]<<endl;
    }
}

void lecturaDeProductos(const char *nomb,char ***&productos,int *&stock,
        double *&precios){
    ifstream arch(nomb,ios::in);
    AperturaIf(arch,nomb);
    //1. Declarar buffers
    char **buffProd[200];
    int buffStock[200],cantProd=0;
    double buffPrecio[200];
    //2. Leer archivo
    while(1){
        buffProd[cantProd]=leerProducto(arch,buffStock[cantProd],
                buffPrecio[cantProd]);
        if(arch.eof()) break;
        cantProd++;
    }
    //3. Cargar arreglos
    cargarArreglos(cantProd,productos,stock,precios,buffProd,buffStock,
            buffPrecio);
}

void cargarArreglos(int cantProd,char ***&productos,int *&stock,
        double *&precios,char ***buffProd,int *buffStock,double *buffPrecio){
    productos=new char**[cantProd+1];
    stock=new int[cantProd];
    precios=new double[cantProd];
    for (int i = 0; i < cantProd; i++) {
        productos[i]=buffProd[i];
        stock[i]=buffStock[i];
        precios[i]=buffPrecio[i];
    }
    productos[cantProd]=nullptr;
}

char **leerProducto(ifstream &arch,int &stock,double &precio){
    char **dupla,c;
    dupla=new char*[2];
    dupla[0]=leerCadenaExacta(arch,10,','); //código
    if(arch.eof()) return nullptr; 
    dupla[1]=leerCadenaExacta(arch,100,','); //descripción
    arch>>precio>>c>>stock;
    arch.get();
    return dupla;
}

char *leerCadenaExacta(ifstream &arch,int max,char c){
    char *pt,buffer[150];
    arch.getline(buffer,max,c);
    if(arch.eof()) return nullptr;
    pt=new char[strlen(buffer)+1];
    strcpy(pt,buffer);
    return pt;
}

void imprimirLinea(ofstream &arch,int max,char c){
    for(int i=0;i<max;i++) arch<<c;
    arch<<endl;
}

void AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}