/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Bebida.h
 * Author: Ariana
 *
 * Created on 21 de noviembre de 2024, 09:18 PM
 */

#ifndef BEBIDA_H
#define BEBIDA_H

#include "Producto.h"


class Bebida:public Producto {
public:
    Bebida();
    Bebida(const Bebida& orig);
    virtual ~Bebida();
    void SetTamano(char *);
    void GetTamano(char *) const;
    void lee(ifstream &arch); //Método polimórfico
    void imprimir(ofstream &arch); //Método polimórfico
private:
    char *tamano;
};

#endif /* BEBIDA_H */

