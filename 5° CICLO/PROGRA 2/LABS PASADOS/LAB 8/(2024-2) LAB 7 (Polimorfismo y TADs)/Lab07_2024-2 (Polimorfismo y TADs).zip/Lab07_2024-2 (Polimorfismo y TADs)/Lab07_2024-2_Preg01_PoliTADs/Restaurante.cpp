/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Restaurante.cpp
 * Author: Ariana
 * 
 * Created on 21 de noviembre de 2024, 09:34 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Restaurante.h"

Restaurante::Restaurante() {
    cantidad_comandas=0;
}

Restaurante::Restaurante(const Restaurante& orig) {
}

Restaurante::~Restaurante() {
}

void Restaurante::SetCantidad_comandas(int cantidad_comandas) {
    this->cantidad_comandas = cantidad_comandas;
}

int Restaurante::GetCantidad_comandas() const {
    return cantidad_comandas;
}

void Restaurante::cargar_comandas(){
    ifstream arch("atenciones.csv",ios::in);
    AperturaIf(arch,"atenciones.csv");
    ifstream archCom("comandas.csv",ios::in);
    AperturaIf(archCom,"comandas.csv");
    
    while(1){
        arch>>comandas[cantidad_comandas];
        if(arch.eof()) break;
        comandas[cantidad_comandas].cargar(archCom);
        cantidad_comandas++;
    }
}

void Restaurante::actualizar_comandas(){
    
}

void Restaurante::imprimir_comandas(){
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    arch<<setprecision(2)<<fixed;
    arch<<right<<setw(62)<<"REPORTE DE COMANDAS"<<endl;
    
    for (int i = 0; comandas[i].GetId(); i++) {
        encabezadoComanda(arch);
        arch<<comandas[i];
        encabezadoProductos(arch);
        comandas[i].imprimir(arch);
    }
}

void Restaurante::encabezadoProductos(ofstream &arch){
    imprimirLinea(arch,'-');
    arch<<"Productos:"<<endl;
    arch<<left<<setw(25)<<"Nombre"<<setw(12)<<"Precio"<<"Especificaciones"<<endl;
    imprimirLinea(arch,'-');
}

void Restaurante::encabezadoComanda(ofstream &arch){
    imprimirLinea(arch,'=');
    arch<<left<<setw(5)<<"ID"<<setw(20)<<"Hora Atencion"<<setw(20)
        <<"Hora Servicio"<<setw(25)<<"Tiempo Preparacion"<<setw(26)<<"Total"
        <<"Estado"<<endl;
    imprimirLinea(arch,'=');
}

void Restaurante::imprimirLinea(ofstream &arch,char c){
    for (int i = 0; i < 105; i++) arch<<c;
    arch<<endl;
}

void Restaurante::AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void Restaurante::AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}
