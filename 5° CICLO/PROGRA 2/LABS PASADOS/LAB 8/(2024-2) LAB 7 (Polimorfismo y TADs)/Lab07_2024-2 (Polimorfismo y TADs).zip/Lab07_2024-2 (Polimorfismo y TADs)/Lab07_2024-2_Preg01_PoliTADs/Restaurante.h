/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Restaurante.h
 * Author: Ariana
 *
 * Created on 21 de noviembre de 2024, 09:34 PM
 */

#ifndef RESTAURANTE_H
#define RESTAURANTE_H

#include "Comanda.h"


class Restaurante {
public:
    Restaurante();
    Restaurante(const Restaurante& orig);
    virtual ~Restaurante();
    void SetCantidad_comandas(int cantidad_comandas);
    int GetCantidad_comandas() const;
    void cargar_comandas();
    void actualizar_comandas();
    void imprimir_comandas();
private:
    Comanda comandas[60];
    int cantidad_comandas;
    void encabezadoComanda(ofstream &arch);
    void encabezadoProductos(ofstream &arch);
    void imprimirLinea(ofstream &arch,char c);
    void AperturaIf(ifstream &arch,const char *nomb);
    void AperturaOf(ofstream &arch,const char *nomb);
};

#endif /* RESTAURANTE_H */

