/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   PlatoFondo.cpp
 * Author: Ariana
 * 
 * Created on 21 de noviembre de 2024, 09:22 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "PlatoFondo.h"

PlatoFondo::PlatoFondo() {
    proteina=nullptr;
}

PlatoFondo::PlatoFondo(const PlatoFondo& orig) {
}

PlatoFondo::~PlatoFondo() {
    if(proteina!=nullptr) delete proteina;
}

void PlatoFondo::lee(ifstream &arch){
    Producto::lee(arch);
    proteina=new int[4];
    char c;
    arch>>proteina[0]>>c>>proteina[1]>>c>>proteina[2]>>c>>proteina[3];
}

void PlatoFondo::imprimir(ofstream &arch){
    Producto::imprimir(arch);
    arch<<left;
    if(proteina[0]) arch<<setw(8)<<"pollo";
    if(proteina[1]) arch<<setw(8)<<"carne";
    if(proteina[2]) arch<<setw(9)<<"pescado";
    if(proteina[3]) arch<<setw(9)<<"lacteos";
    arch<<endl;
}