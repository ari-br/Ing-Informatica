/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Bebida.cpp
 * Author: Ariana
 * 
 * Created on 21 de noviembre de 2024, 09:18 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "Bebida.h"

Bebida::Bebida() {
    tamano=nullptr;
}

Bebida::Bebida(const Bebida& orig) {
}

Bebida::~Bebida() {
    if(tamano!=nullptr) delete tamano;
}

void Bebida::SetTamano(char *cad){
    if(tamano!=nullptr) delete tamano;
    tamano=new char[strlen(cad)+1];
    strcpy(tamano,cad);
}

void Bebida::GetTamano(char *cad) const{
    if(tamano!=nullptr)
        strcpy(cad,tamano);
}

void Bebida::lee(ifstream &arch){
    Producto::lee(arch);
    char cad[20];
    arch.getline(cad,20);
    SetTamano(cad);
}

void Bebida::imprimir(ofstream &arch){
    Producto::imprimir(arch);
    char cad[20];
    GetTamano(cad);
    arch<<cad<<endl;
}