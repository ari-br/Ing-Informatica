/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   ProductoComanda.h
 * Author: Ariana
 *
 * Created on 21 de noviembre de 2024, 09:27 PM
 */

#ifndef PRODUCTOCOMANDA_H
#define PRODUCTOCOMANDA_H

#include "Producto.h"


class ProductoComanda {
public:
    ProductoComanda();
    ProductoComanda(const ProductoComanda& orig);
    virtual ~ProductoComanda();
    void lee(ifstream &arch,int &cantidad_bebidas,int &cantidad_entradas,
        int &cantidad_platos_fondo,int &tiempo_preparacion);
    Producto *crearEspacio(char tipo,int &cantidad_bebidas,
        int &cantidad_entradas,int &cantidad_platos_fondo,
        int &tiempo_preparacion);
    void imprimir(ofstream &arch);
private:
    Producto *prod;
};

#endif /* PRODUCTOCOMANDA_H */

