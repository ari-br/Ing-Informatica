/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Cola.cpp
 * Author: Ariana
 * 
 * Created on 21 de noviembre de 2024, 09:26 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Cola.h"

Cola::Cola() {
    ini=nullptr;
    fin=nullptr;
}

Cola::Cola(const Cola& orig) {
}

Cola::~Cola() {
}

bool Cola::esColaVacia(){
    return ini==nullptr;
}

void Cola::encolar(const ProductoComanda &prodCom){
    Nodo *nuevoNodo=new Nodo;
    nuevoNodo->unidad=prodCom;
    
    if(esColaVacia())
        ini=nuevoNodo;
    else
        fin->sig=nuevoNodo;
    fin=nuevoNodo;
}

ProductoComanda Cola::desencolar(){
    ProductoComanda prodCom;
    Nodo *aux=ini->sig;
    prodCom=ini->unidad;
    ini=aux;
    delete aux;
    return prodCom;
}