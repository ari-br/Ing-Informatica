/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Entrada.cpp
 * Author: Ariana
 * 
 * Created on 21 de noviembre de 2024, 09:20 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "Entrada.h"

Entrada::Entrada() {
    picante=false;
}

Entrada::Entrada(const Entrada& orig) {
}

Entrada::~Entrada() {
}

void Entrada::SetPicante(bool picante) {
    this->picante = picante;
}

bool Entrada::IsPicante() const {
    return picante;
}

void Entrada::lee(ifstream &arch){
    Producto::lee(arch);
    char cad[20];
    arch.getline(cad,20);
    if(strcmp(cad,"picante")==0) picante=true;
}

void Entrada::imprimir(ofstream &arch){
    Producto::imprimir(arch);
    if(picante)
        arch<<"picante"<<endl;
    else
        arch<<"sin picante"<<endl;
}