/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Entrada.h
 * Author: Ariana
 *
 * Created on 21 de noviembre de 2024, 09:20 PM
 */

#ifndef ENTRADA_H
#define ENTRADA_H

#include "Producto.h"


class Entrada:public Producto {
public:
    Entrada();
    Entrada(const Entrada& orig);
    virtual ~Entrada();
    void SetPicante(bool picante);
    bool IsPicante() const;
    void lee(ifstream &arch); //Método polimórfico
    void imprimir(ofstream &arch); //Método polimórfico
private:
    bool picante;
};

#endif /* ENTRADA_H */

