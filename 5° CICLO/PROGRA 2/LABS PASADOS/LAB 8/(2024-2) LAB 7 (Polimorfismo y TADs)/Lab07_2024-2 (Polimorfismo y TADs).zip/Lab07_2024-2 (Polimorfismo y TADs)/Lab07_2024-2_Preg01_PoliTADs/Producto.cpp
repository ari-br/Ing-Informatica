/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Producto.cpp
 * Author: Ariana
 * 
 * Created on 21 de noviembre de 2024, 09:15 PM
 */

#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Producto.h"

Producto::Producto() {
    nombre=nullptr;
    precio=0;
}

Producto::Producto(const Producto& orig) {
}

Producto::~Producto() {
}

void Producto::SetPrecio(double precio) {
    this->precio = precio;
}

double Producto::GetPrecio() const {
    return precio;
}

void Producto::SetNombre(char *cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Producto::GetNombre(char *cad) const{
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Producto::lee(ifstream &arch){
    char cad[100],c;
    arch.getline(cad,100,',');
    arch>>precio>>c;
    SetNombre(cad);
}

void Producto::imprimir(ofstream &arch){
    char cad[100];
    GetNombre(cad);
    arch<<left<<setw(25)<<cad<<right<<setw(6)<<precio<<setw(6)<<" ";
}