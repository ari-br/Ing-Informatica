/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   PlatoFondo.h
 * Author: Ariana
 *
 * Created on 21 de noviembre de 2024, 09:22 PM
 */

#ifndef PLATOFONDO_H
#define PLATOFONDO_H

#include "Producto.h"


class PlatoFondo:public Producto {
public:
    PlatoFondo();
    PlatoFondo(const PlatoFondo& orig);
    virtual ~PlatoFondo();
    void lee(ifstream &arch); //Método polimórfico
    void imprimir(ofstream &arch); //Método polimórfico
private:
    int *proteina;
};

#endif /* PLATOFONDO_H */

