/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Producto.h
 * Author: Ariana
 *
 * Created on 21 de noviembre de 2024, 09:15 PM
 */

#ifndef PRODUCTO_H
#define PRODUCTO_H

class Producto {
public:
    Producto();
    Producto(const Producto& orig);
    virtual ~Producto();
    void SetPrecio(double precio);
    double GetPrecio() const;
    void SetNombre(char *);
    void GetNombre(char *) const;
    virtual void lee(ifstream &arch); //Método polimórfico
    virtual void imprimir(ofstream &arch); //Método polimórfico
private:
    char *nombre;
    double precio;
};

#endif /* PRODUCTO_H */

