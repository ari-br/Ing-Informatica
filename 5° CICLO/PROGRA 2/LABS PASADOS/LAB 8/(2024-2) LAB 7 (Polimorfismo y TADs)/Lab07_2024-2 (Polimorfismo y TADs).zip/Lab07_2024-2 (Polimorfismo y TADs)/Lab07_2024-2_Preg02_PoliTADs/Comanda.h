/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Comanda.h
 * Author: Ariana
 *
 * Created on 21 de noviembre de 2024, 09:24 PM
 */

#ifndef COMANDA_H
#define COMANDA_H

#include "Cola.h"


class Comanda {
public:
    Comanda();
    Comanda(const Comanda& orig);
    virtual ~Comanda();
    void SetTotal(double total);
    double GetTotal() const;
    void SetTiempo_preparacion(int tiempo_preparacion);
    int GetTiempo_preparacion() const;
    void SetHora_servicio(int hora_servicio);
    int GetHora_servicio() const;
    void SetHora_atencion(int hora_atencion);
    int GetHora_atencion() const;
    void SetCantidad_platos_fondo(int cantidad_platos_fondo);
    int GetCantidad_platos_fondo() const;
    void SetCantidad_entradas(int cantidad_entradas);
    int GetCantidad_entradas() const;
    void SetCantidad_bebidas(int cantidad_bebidas);
    int GetCantidad_bebidas() const;
    void SetId(int id);
    int GetId() const;
    void SetEstado(const char *);
    void GetEstado(char *) const;
    void cargar(ifstream &arch);
    void devolverTiempos(int &hhAt,int &mmAt,int horaAten,int &hhSe,int &mmSe,
            int horaServ);
    int calcularTiempoPreparacion(int horaAten,int horaServ);
    void imprimirEstado(ofstream &arch);
    void imprimir(ofstream &arch);
    void actualizar();
private:
    int id;
    Cola cola;
    int cantidad_bebidas;
    int cantidad_entradas;
    int cantidad_platos_fondo;
    int hora_atencion;
    int hora_servicio;
    int tiempo_preparacion;
    double total;
    char *estado;
};

ifstream &operator >>(ifstream &,Comanda &);
ofstream &operator <<(ofstream &,Comanda &);

#endif /* COMANDA_H */

