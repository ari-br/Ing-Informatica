/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Comanda.cpp
 * Author: Ariana
 * 
 * Created on 21 de noviembre de 2024, 09:24 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "Comanda.h"

Comanda::Comanda() {
    id=0;
    cantidad_bebidas=0;
    cantidad_entradas=0;
    cantidad_platos_fondo=0;
    hora_atencion=0;
    hora_servicio=0;
    tiempo_preparacion=0;
    total=0;
    estado=nullptr;
}

Comanda::Comanda(const Comanda& orig) {
}

Comanda::~Comanda() {
    if(estado!=nullptr) delete estado;
}

void Comanda::SetTotal(double total) {
    this->total = total;
}

double Comanda::GetTotal() const {
    return total;
}

void Comanda::SetTiempo_preparacion(int tiempo_preparacion) {
    this->tiempo_preparacion = tiempo_preparacion;
}

int Comanda::GetTiempo_preparacion() const {
    return tiempo_preparacion;
}

void Comanda::SetHora_servicio(int hora_servicio) {
    this->hora_servicio = hora_servicio;
}

int Comanda::GetHora_servicio() const {
    return hora_servicio;
}

void Comanda::SetHora_atencion(int hora_atencion) {
    this->hora_atencion = hora_atencion;
}

int Comanda::GetHora_atencion() const {
    return hora_atencion;
}

void Comanda::SetCantidad_platos_fondo(int cantidad_platos_fondo) {
    this->cantidad_platos_fondo = cantidad_platos_fondo;
}

int Comanda::GetCantidad_platos_fondo() const {
    return cantidad_platos_fondo;
}

void Comanda::SetCantidad_entradas(int cantidad_entradas) {
    this->cantidad_entradas = cantidad_entradas;
}

int Comanda::GetCantidad_entradas() const {
    return cantidad_entradas;
}

void Comanda::SetCantidad_bebidas(int cantidad_bebidas) {
    this->cantidad_bebidas = cantidad_bebidas;
}

int Comanda::GetCantidad_bebidas() const {
    return cantidad_bebidas;
}

void Comanda::SetId(int id) {
    this->id = id;
}

int Comanda::GetId() const {
    return id;
}

void Comanda::SetEstado(const char *cad){
    if(estado!=nullptr) delete estado;
    estado=new char[strlen(cad)+1];
    strcpy(estado,cad);
}

void Comanda::GetEstado(char *cad) const{
    if(estado!=nullptr)
        strcpy(cad,estado);
}

void Comanda::cargar(ifstream &arch){
    //Regresar el archivo al inicio
    arch.clear();
    arch.seekg(0,ios::beg);
    
    ProductoComanda prodCom;
    int ident;
    while(1){
        arch>>ident;
        if(arch.eof()) break;
        arch.get();
        if(id==ident){
            prodCom.lee(arch,cantidad_bebidas,cantidad_entradas,
                    cantidad_platos_fondo,tiempo_preparacion);
            cola.encolar(prodCom);
        }else{
            while(arch.get()!='\n');
        }        
    }
}

void Comanda::imprimir(ofstream &arch){
    while(!cola.esColaVacia()){
        ProductoComanda prodCom=cola.desencolar();
        prodCom.imprimir(arch);
    }
}

void Comanda::actualizar(){
    int tiempoPrep;
    tiempoPrep=calcularTiempoPreparacion(hora_atencion,hora_servicio);
    if(tiempo_preparacion>tiempoPrep)
        SetEstado("ATENDIDA CON RETRASO");
    else
        SetEstado("ATENDIDA");
    cola.recorrer(total);
}

int Comanda::calcularTiempoPreparacion(int horaAten,int horaServ){
    //EL tiempo en minutos
    int tiempoPrep;
    int hhAt,mmAt,hhSe,mmSe;
    devolverTiempos(hhAt,mmAt,horaAten,hhSe,mmSe,horaServ);
    if(hhSe==0) hhSe=24;
    tiempoPrep=((hhSe*60)+mmSe)-((hhAt*60)+mmAt);
    return tiempoPrep;
}


ifstream &operator >>(ifstream &arch,Comanda &f){
    int id,hhAt,mmAt,horaAten,hhSe,mmSe,horaServ;
    char c;
    
    arch>>id;
    if(!arch.eof()){
        arch>>c>>hhAt>>c>>mmAt>>c>>hhSe>>c>>mmSe;
        f.SetId(id);
        horaAten=(hhAt*100)+mmAt;
        f.SetHora_atencion(horaAten);
        horaServ=(hhSe*100)+mmSe;
        f.SetHora_servicio(horaServ);
    }
    return arch;
}

void Comanda::devolverTiempos(int &hhAt,int &mmAt,int horaAten,int &hhSe,int &mmSe,
            int horaServ){
    hhAt=horaAten/100;
    mmAt=horaAten%100;
    hhSe=horaServ/100;
    mmSe=horaServ%100;
}

void Comanda::imprimirEstado(ofstream &arch){
    if(estado==nullptr)
        arch<<setw(27)<<"PENDIENTE";
    else
        arch<<setw(27)<<estado;
}

ofstream &operator <<(ofstream &arch,Comanda &f){
    int hhAt,mmAt,hhSe,mmSe;
    //Es el tiempo de preparación real, respecto a las horas de atención y servicio
    f.devolverTiempos(hhAt,mmAt,f.GetHora_atencion(),hhSe,mmSe,
            f.GetHora_servicio());
    arch<<left<<setw(9)<<f.GetId();
    arch<<right<<setfill('0')<<setw(2)<<hhAt<<":"<<setw(2)<<mmAt<<setfill(' ')
        <<setw(15)<<" "<<setfill('0')<<setw(2)<<hhSe<<":"<<setw(2)<<mmSe<<setfill(' ')
        <<setw(12)<<" "<<setw(5)<<f.GetTiempo_preparacion()<<" minutos"<<setw(16)<<f.GetTotal();
    f.imprimirEstado(arch);
    arch<<endl;
    return arch;
}