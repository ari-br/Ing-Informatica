/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Nodo.h
 * Author: Ariana
 *
 * Created on 21 de noviembre de 2024, 09:26 PM
 */

#ifndef NODO_H
#define NODO_H

#include "ProductoComanda.h"


class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Cola;
    void calcularTotal(double &total);
private:
    ProductoComanda unidad;
    Nodo *sig;
};

#endif /* NODO_H */

