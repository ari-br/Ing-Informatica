/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   ProductoComanda.cpp
 * Author: Ariana
 * 
 * Created on 21 de noviembre de 2024, 09:27 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "ProductoComanda.h"
#include "Bebida.h"
#include "Entrada.h"
#include "PlatoFondo.h"

ProductoComanda::ProductoComanda() {
    prod=nullptr;
}

ProductoComanda::ProductoComanda(const ProductoComanda& orig) {
}

ProductoComanda::~ProductoComanda() {
}

void ProductoComanda::lee(ifstream &arch,int &cantidad_bebidas,int &cantidad_entradas,
        int &cantidad_platos_fondo,int &tiempo_preparacion){
    char tipo,c;
    
    arch>>tipo>>c;
    prod=crearEspacio(tipo,cantidad_bebidas,cantidad_entradas,cantidad_platos_fondo,
            tiempo_preparacion);
    prod->lee(arch);
}

Producto *ProductoComanda::crearEspacio(char tipo,int &cantidad_bebidas,
        int &cantidad_entradas,int &cantidad_platos_fondo,int &tiempo_preparacion){
    Producto *aux;
    
    if(tipo=='B'){
        aux=new Bebida;
        cantidad_bebidas++;
        tiempo_preparacion+=10;
    }
    if(tipo=='E'){
        aux=new Entrada;
        cantidad_entradas++;
        tiempo_preparacion+=15;
    }
    if(tipo=='P'){
        aux=new PlatoFondo;
        cantidad_platos_fondo++;
        tiempo_preparacion+=20;
    }
    
    return aux;
}

void ProductoComanda::imprimir(ofstream &arch){
    prod->imprimir(arch);
}

void ProductoComanda::calcularTotal(double &total){
    total+=prod->GetPrecio();
}