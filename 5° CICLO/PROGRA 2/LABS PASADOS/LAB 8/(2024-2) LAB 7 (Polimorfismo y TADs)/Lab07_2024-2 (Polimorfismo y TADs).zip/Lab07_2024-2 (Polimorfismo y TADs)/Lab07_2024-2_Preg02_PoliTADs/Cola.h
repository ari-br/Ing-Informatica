/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Cola.h
 * Author: Ariana
 *
 * Created on 21 de noviembre de 2024, 09:26 PM
 */

#ifndef COLA_H
#define COLA_H

#include "Nodo.h"


class Cola {
public:
    Cola();
    Cola(const Cola& orig);
    virtual ~Cola();
    bool esColaVacia();
    void encolar(const ProductoComanda &prodCom);
    ProductoComanda desencolar();
    void recorrer(double &total);
private:
    Nodo *ini;
    Nodo *fin;
};

#endif /* COLA_H */

