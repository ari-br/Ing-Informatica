/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   NPedido.cpp
 * Author: Ariana
 * 
 * Created on 16 de noviembre de 2024, 10:43 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "NPedido.h"

NPedido::NPedido() {
    codigo=nullptr;
    cantidad=0;
    peso=0;
    sig=nullptr;
}

NPedido::NPedido(const NPedido& orig) {
}

NPedido::~NPedido() {
    if(codigo!=nullptr) delete codigo;
    if(sig!=nullptr) delete sig;
}

void NPedido::SetPeso(double peso) {
    this->peso = peso;
}

double NPedido::GetPeso() const {
    return peso;
}

void NPedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int NPedido::GetCantidad() const {
    return cantidad;
}

void NPedido::SetCodigo(char *cad){
    if(codigo!=nullptr) delete codigo;
    codigo=new char[strlen(cad)+1];
    strcpy(codigo,cad);
}

void NPedido::GetCodigo(char *cad) const{
    if(codigo!=nullptr)
        strcpy(cad,codigo);
}

void NPedido::lee(ifstream &arch){
    char cod[10],c;
    arch.getline(cod,10,',');
    SetCodigo(cod);
    arch>>cantidad>>c>>peso;
}

void NPedido::push(NPedido *cabeza){
    sig=cabeza;
}

void NPedido::recorrer(ofstream &arch,NPedido *cabeza){
    NPedido *recorrido=cabeza;
    while(recorrido!=nullptr){
        recorrido->imprimir(arch);
        recorrido=recorrido->sig;
    }
}

void NPedido::imprimir(ofstream &arch){
    char cod[10];
    GetCodigo(cod);
    arch<<setw(12)<<" "<<setw(10)<<cod<<setw(6)<<cantidad<<setw(10)<<peso<<endl;
}