/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 17 de noviembre de 2024, 01:21 AM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Flota.h"
/*
 * 
 */
int main(int argc, char** argv) {
    Flota transporte;
    
    transporte.cargaflota();
    transporte.cargapedidos();
    transporte.muestracarga();
    
    return 0;
}

