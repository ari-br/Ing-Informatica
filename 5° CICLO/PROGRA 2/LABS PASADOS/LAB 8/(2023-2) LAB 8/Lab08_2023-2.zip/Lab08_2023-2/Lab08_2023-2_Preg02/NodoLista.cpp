/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   NodoLista.cpp
 * Author: Ariana
 * 
 * Created on 16 de noviembre de 2024, 11:23 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "NodoLista.h"
#include "Furgon.h"
#include "Camion.h"

NodoLista::NodoLista() {
    unidad=nullptr;
    sig=nullptr;
}

NodoLista::NodoLista(const NodoLista& orig) {
}

NodoLista::~NodoLista() {
    if(unidad!=nullptr) delete unidad;
    if(sig!=nullptr) delete sig;
}

void NodoLista::lee(ifstream &arch){
    char tipo,pla[10],c;
    int cli;
    double maxCar;
    
    arch>>tipo;
    if(arch.eof()) return;
    arch>>c>>cli>>c;
    arch.getline(pla,10,',');
    arch>>maxCar>>c;
    
    if(tipo=='F') unidad=new Furgon;
    if(tipo=='C') unidad=new Camion;
    
    unidad->lee(arch,cli,pla,maxCar);
}

void NodoLista::cargar(int cli,NPedido *pedido){
    if(cli==unidad->GetCliente()) unidad->cargar(pedido);
}

void NodoLista::imprime(ofstream &arch){
    unidad->imprime(arch,' ',0,0);
    arch<<endl;
}