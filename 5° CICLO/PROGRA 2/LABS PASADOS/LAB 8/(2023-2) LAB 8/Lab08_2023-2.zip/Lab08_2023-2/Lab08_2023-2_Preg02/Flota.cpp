/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Flota.cpp
 * Author: Ariana
 * 
 * Created on 17 de noviembre de 2024, 12:08 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Flota.h"

Flota::Flota() {
}

Flota::Flota(const Flota& orig) {
}

Flota::~Flota() {
}

void Flota::cargaflota(){
    ifstream arch("Vehiculos.csv",ios::in);
    AperturaIf(arch,"Vehiculos.csv");
    
    while(1){
        NodoLista *nodo=new NodoLista;
        nodo->lee(arch);
        if(arch.eof()) break;
        lista.cargar(nodo);
    }
}

void Flota::cargapedidos(){
    ifstream arch("Pedidos3.csv",ios::in);
    AperturaIf(arch,"Pedidos3.csv");
    int cli;
    char c;
    while(1){
        arch>>cli>>c;
        NPedido *pedido=new NPedido;
        pedido->lee(arch);
        if(arch.eof()) break;
        lista.cargar(cli,pedido);
    }
}

void Flota::muestracarga(){
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    
    arch<<setprecision(2)<<fixed;
    arch<<right<<setw(33)<<"REPORTE DE FLOTA"<<endl;
    imprimirLinea(arch,'=');
    
    lista.recorrer(arch);
}

void Flota::imprimirLinea(ofstream &arch,char c){
    for (int i = 0; i < 50; i++) arch<<c;
    arch<<endl;
}

void Flota::AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void Flota::AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}