/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Vehiculo.cpp
 * Author: Ariana
 * 
 * Created on 16 de noviembre de 2024, 10:49 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "Vehiculo.h"

Vehiculo::Vehiculo() {
    cliente=0;
    placa=nullptr;
    maxcarga=0;
    actcarga=0;
    ped=nullptr;
}

Vehiculo::Vehiculo(const Vehiculo& orig) {
}

Vehiculo::~Vehiculo() {
    if(placa!=nullptr) delete placa;
    if(ped!=nullptr) delete ped;
}

void Vehiculo::SetActcarga(double actcarga) {
    this->actcarga = actcarga;
}

double Vehiculo::GetActcarga() const {
    return actcarga;
}

void Vehiculo::SetMaxcarga(double maxcarga) {
    this->maxcarga = maxcarga;
}

double Vehiculo::GetMaxcarga() const {
    return maxcarga;
}

void Vehiculo::SetCliente(int cliente) {
    this->cliente = cliente;
}

int Vehiculo::GetCliente() const {
    return cliente;
}

void Vehiculo::SetPlaca(char *cad){
    if(placa!=nullptr) delete placa;
    placa=new char[strlen(cad)+1];
    strcpy(placa,cad);
}

void Vehiculo::GetPlaca(char *cad) const{
    if(placa!=nullptr)
        strcpy(cad,placa);
}

void Vehiculo::lee(ifstream &arch,int cli,char *pla,double maxCar){
    cliente=cli;
    SetPlaca(pla);
    maxcarga=maxCar;
}

bool Vehiculo::pilavacia(){
    return ped==nullptr;
}

void Vehiculo::push(NPedido *pedido){
    if(!pilavacia()) pedido->push(ped);
    ped=pedido;
}

void Vehiculo::cargar(NPedido *pedido){
    if(maxcarga>=actcarga+pedido->GetPeso()){
        actcarga+=pedido->GetPeso();
        push(pedido);
    }
}

void Vehiculo::imprime(ofstream &arch,char tipo,int a,int b){
    char pla[10];
    GetPlaca(pla);
    arch<<right;
    arch<<setw(12)<<" "<<"Codigo Cliente:"<<setw(11)<<cliente<<endl;
    arch<<setw(12)<<" "<<"Placa:"<<setw(20)<<pla<<endl;
    arch<<setw(12)<<" "<<"Carga Maxima:"<<setw(13)<<maxcarga<<endl;
    arch<<setw(12)<<" "<<"Carga Actual:"<<setw(13)<<actcarga<<endl;
    
    if(tipo=='C'){
        arch<<setw(12)<<" "<<"#Ejes:"<<setw(20)<<a<<endl;
        arch<<setw(12)<<" "<<"#Llantas:"<<setw(17)<<b<<endl;
    }
    if(tipo=='F'){
        arch<<setw(12)<<" "<<"#Filas:"<<setw(19)<<a<<endl;
        arch<<setw(12)<<" "<<"#Puertas:"<<setw(17)<<b<<endl;
    }
    
    if(!pilavacia()) imprimirPedidos(arch);
    else arch<<setw(12)<<" "<<"No hay pedidos para el cliente"<<endl;
}

void Vehiculo::imprimirPedidos(ofstream &arch){
    arch<<setw(12)<<" "<<"Pedidos:"<<endl;
    ped->recorrer(arch,ped);
}