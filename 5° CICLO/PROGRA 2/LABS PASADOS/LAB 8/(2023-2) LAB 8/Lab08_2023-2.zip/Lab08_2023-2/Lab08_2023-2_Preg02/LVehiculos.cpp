/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   LVehiculos.cpp
 * Author: Ariana
 * 
 * Created on 17 de noviembre de 2024, 12:05 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "LVehiculos.h"

LVehiculos::LVehiculos() {
    lini=nullptr;
    lfin=nullptr;
}

LVehiculos::LVehiculos(const LVehiculos& orig) {
}

LVehiculos::~LVehiculos() {
    if(lini!=nullptr) delete lini;
    if(lfin!=nullptr) delete lfin;
}

void LVehiculos::cargar(NodoLista *nodo){
    if(lini==nullptr)
        lini=nodo;
    else
        lfin->sig=nodo;
    lfin=nodo;
}

void LVehiculos::cargar(int cli,NPedido *pedido){
    NodoLista *recorrido=lini;
    
    while(recorrido!=nullptr){
        recorrido->cargar(cli,pedido);
        recorrido=recorrido->sig;
    }
}

void LVehiculos::recorrer(ofstream &arch){
    NodoLista *recorrido=lini;
    
    while(recorrido!=nullptr){
        recorrido->imprime(arch);
        recorrido=recorrido->sig;
    }
}