/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Flota.h
 * Author: Ariana
 *
 * Created on 17 de noviembre de 2024, 12:08 AM
 */

#ifndef FLOTA_H
#define FLOTA_H

#include "LVehiculos.h"


class Flota {
public:
    Flota();
    Flota(const Flota& orig);
    virtual ~Flota();
    void cargaflota();
    void cargapedidos();
    void muestracarga();
private:
    LVehiculos lista;
    void imprimirLinea(ofstream &arch,char c);
    void AperturaIf(ifstream &arch,const char *nomb);
    void AperturaOf(ofstream &arch,const char *nomb);
};

#endif /* FLOTA_H */

