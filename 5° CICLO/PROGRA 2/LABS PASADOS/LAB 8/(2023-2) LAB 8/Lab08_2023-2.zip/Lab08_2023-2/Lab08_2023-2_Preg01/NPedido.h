/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   NPedido.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 10:43 PM
 */

#ifndef NPEDIDO_H
#define NPEDIDO_H

class NPedido {
public:
    NPedido();
    NPedido(const NPedido& orig);
    virtual ~NPedido();
    void SetPeso(double peso);
    double GetPeso() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(char *);
    void GetCodigo(char *) const;
    void recorrer(ofstream &arch,NPedido *cabeza);
private:
    char *codigo;
    int cantidad;
    double peso;
    NPedido *sig;
    void imprimir(ofstream &arch);
};

#endif /* NPEDIDO_H */

