/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Camion.cpp
 * Author: Ariana
 * 
 * Created on 16 de noviembre de 2024, 11:07 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Camion.h"

Camion::Camion() {
    ejes=0;
    llantas=0;
}

Camion::Camion(const Camion& orig) {
}

Camion::~Camion() {
}

void Camion::SetLlantas(int llantas) {
    this->llantas = llantas;
}

int Camion::GetLlantas() const {
    return llantas;
}

void Camion::SetEjes(int ejes) {
    this->ejes = ejes;
}

int Camion::GetEjes() const {
    return ejes;
}

void Camion::lee(ifstream &arch,int cli,char *pla,double maxCar){
    char c;
    arch>>ejes>>c>>llantas;
    Vehiculo::lee(arch,cli,pla,maxCar);
}

void Camion::imprime(ofstream &arch,char tipo,int a,int b){
    Vehiculo::imprime(arch,'C',ejes,llantas);
}