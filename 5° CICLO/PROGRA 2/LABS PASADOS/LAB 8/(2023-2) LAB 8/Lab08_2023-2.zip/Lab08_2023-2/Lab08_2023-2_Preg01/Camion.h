/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Camion.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 11:07 PM
 */

#ifndef CAMION_H
#define CAMION_H

#include "Vehiculo.h"


class Camion:public Vehiculo {
public:
    Camion();
    Camion(const Camion& orig);
    virtual ~Camion();
    void SetLlantas(int llantas);
    int GetLlantas() const;
    void SetEjes(int ejes);
    int GetEjes() const;
    void lee(ifstream &arch,int cli,char *pla,double maxCar); //Método polimórfico
    void imprime(ofstream &arch,char tipo,int a,int b); //Método polimórfico
private:
    int ejes;
    int llantas;
};

#endif /* CAMION_H */

