/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Vehiculo.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 10:49 PM
 */

#ifndef VEHICULO_H
#define VEHICULO_H

#include "NPedido.h"


class Vehiculo {
public:
    Vehiculo();
    Vehiculo(const Vehiculo& orig);
    virtual ~Vehiculo();
    void SetActcarga(double actcarga);
    double GetActcarga() const;
    void SetMaxcarga(double maxcarga);
    double GetMaxcarga() const;
    void SetCliente(int cliente);
    int GetCliente() const;
    void SetPlaca(char *);
    void GetPlaca(char *) const;
    virtual void lee(ifstream &arch,int cli,char *pla,double maxCar); //Método polimórfico
    bool pilavacia();
    virtual void imprime(ofstream &arch,char tipo,int a,int b); //Método polimórfico
    //tipo: Furgon('F')/Camion('C')
    //a: Filas/Ejes
    //b: Puertas/Llantas
private:
    int cliente;
    char *placa;
    double maxcarga;
    double actcarga;
    NPedido *ped; //Cabeza de la pila
    void imprimirPedidos(ofstream &arch);
};

#endif /* VEHICULO_H */

