/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Furgon.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 11:08 PM
 */

#ifndef FURGON_H
#define FURGON_H

#include "Vehiculo.h"


class Furgon:public Vehiculo {
public:
    Furgon();
    Furgon(const Furgon& orig);
    virtual ~Furgon();
    void SetPuertas(int puertas);
    int GetPuertas() const;
    void SetFilas(int filas);
    int GetFilas() const;
    void lee(ifstream &arch,int cli,char *pla,double maxCar); //Método polimórfico
    void imprime(ofstream &arch,char tipo,int a,int b); //Método polimórfico
private:
    int filas;
    int puertas;
};

#endif /* FURGON_H */

