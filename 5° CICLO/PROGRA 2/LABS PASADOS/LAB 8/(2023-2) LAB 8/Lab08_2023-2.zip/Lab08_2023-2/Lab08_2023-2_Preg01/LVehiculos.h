/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   LVehiculos.h
 * Author: Ariana
 *
 * Created on 17 de noviembre de 2024, 12:05 AM
 */

#ifndef LVEHICULOS_H
#define LVEHICULOS_H

#include "NodoLista.h"


class LVehiculos {
public:
    LVehiculos();
    LVehiculos(const LVehiculos& orig);
    virtual ~LVehiculos();
    void cargar(NodoLista *nodo);
    void recorrer(ofstream &arch);
private:
    //Lista simplemente enlazada que simula cola
    NodoLista *lini;
    NodoLista *lfin;
};

#endif /* LVEHICULOS_H */

