/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   NodoLista.h
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 11:23 PM
 */

#ifndef NODOLISTA_H
#define NODOLISTA_H

#include "Vehiculo.h"


class NodoLista {
public:
    NodoLista();
    NodoLista(const NodoLista& orig);
    virtual ~NodoLista();
    friend class LVehiculos;
    void lee(ifstream &arch);
    void imprime(ofstream &arch);
private:
    Vehiculo *unidad;
    NodoLista *sig;
};

#endif /* NODOLISTA_H */

