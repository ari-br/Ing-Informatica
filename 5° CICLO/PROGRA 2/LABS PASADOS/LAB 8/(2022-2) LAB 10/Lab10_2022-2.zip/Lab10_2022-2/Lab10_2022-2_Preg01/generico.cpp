/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   generico.cpp
 * Author: Ariana
 * 
 * Created on 15 de noviembre de 2024, 05:20 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "generico.h"

generico::generico() {
    pais=nullptr;
}

generico::generico(const generico& orig) {
}

generico::~generico() {
    if(pais!=nullptr) delete pais;
}

void generico::SetPais(char *cad){
    if(pais!=nullptr) delete pais;
    pais=new char[strlen(cad)+1];
    strcpy(pais,cad);
}

void generico::GetPais(char *cad) const{
    if(pais!=nullptr)
        strcpy(cad,pais);
}

void generico::lee(ifstream &arch,int cod,char *cad,int stoc,double prec){
    char pa[100];
    arch.getline(pa,100);
    SetPais(pa);
    medicamento::lee(arch,cod,cad,stoc,prec);
}

void generico::imprime(ofstream &arch,char *cad,int lot){
    medicamento::imprime(arch,pais,0);
}