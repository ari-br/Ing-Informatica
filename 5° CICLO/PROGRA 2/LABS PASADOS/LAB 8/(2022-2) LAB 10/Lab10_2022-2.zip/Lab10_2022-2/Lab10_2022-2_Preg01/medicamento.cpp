/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   medicamento.cpp
 * Author: Ariana
 * 
 * Created on 15 de noviembre de 2024, 05:17 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "medicamento.h"

medicamento::medicamento() {
    codigo=0;
    nombre=nullptr;
    stock=0;
    precio=0;
}

medicamento::medicamento(const medicamento& orig) {
}

medicamento::~medicamento() {
    if(nombre!=nullptr) delete nombre;
}

void medicamento::SetPrecio(double precio) {
    this->precio = precio;
}

double medicamento::GetPrecio() const {
    return precio;
}

void medicamento::SetStock(int stock) {
    this->stock = stock;
}

int medicamento::GetStock() const {
    return stock;
}

void medicamento::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int medicamento::GetCodigo() const {
    return codigo;
}

void medicamento::SetNombre(char *cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void medicamento::GetNombre(char *cad) const{
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void medicamento::lee(ifstream &arch,int cod,char *cad,int stoc,double prec){
    codigo=cod;
    SetNombre(cad);
    stock=stoc;
    precio=prec;
}

void medicamento::imprime(ofstream &arch,char *cad,int lot){
    arch<<left<<setw(8)<<codigo<<setw(40)<<nombre<<right<<setw(5)<<stock
        <<setw(10)<<precio<<left<<setw(3)<<" "<<setw(35)<<cad;
    if(lot!=0) arch<<right<<setw(4)<<lot;
    arch<<endl;
}