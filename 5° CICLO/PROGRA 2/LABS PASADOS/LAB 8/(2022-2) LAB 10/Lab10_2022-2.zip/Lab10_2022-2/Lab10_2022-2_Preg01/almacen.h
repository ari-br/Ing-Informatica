/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   almacen.h
 * Author: Ariana
 *
 * Created on 15 de noviembre de 2024, 05:29 PM
 */

#ifndef ALMACEN_H
#define ALMACEN_H

#include "Arbol.h"


class almacen {
public:
    almacen();
    almacen(const almacen& orig);
    virtual ~almacen();
    void carga();
    void actualiza();
    void imprime();
private:
    Arbol arbolalma;
    void imprimirLinea(ofstream &arch,char c);
    void AperturaIf(ifstream &arch,const char *nomb);
    void AperturaOf(ofstream &arch,const char *nomb);
};

#endif /* ALMACEN_H */

