/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   generico.h
 * Author: Ariana
 *
 * Created on 15 de noviembre de 2024, 05:20 PM
 */

#ifndef GENERICO_H
#define GENERICO_H

#include "medicamento.h"


class generico:public medicamento {
public:
    generico();
    generico(const generico& orig);
    virtual ~generico();
    void SetPais(char *);
    void GetPais(char *) const;
    void lee(ifstream &arch,int cod,char *cad,int stoc,double prec); //Método polimórfico
    void imprime(ofstream &arch,char *cad,int lot); //Método polimórfico
private:
    char *pais;
};

#endif /* GENERICO_H */

