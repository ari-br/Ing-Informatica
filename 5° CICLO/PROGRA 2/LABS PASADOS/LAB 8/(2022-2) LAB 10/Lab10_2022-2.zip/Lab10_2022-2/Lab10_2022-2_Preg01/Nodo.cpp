/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Nodo.cpp
 * Author: Ariana
 * 
 * Created on 15 de noviembre de 2024, 05:25 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Nodo.h"
#include "marca.h"
#include "generico.h"

Nodo::Nodo() {
    med=nullptr;
    izq=nullptr;
    der=nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
    if(med!=nullptr) delete med;
    if(izq!=nullptr) delete izq;
    if(der!=nullptr) delete der;
}

void Nodo::lee(ifstream &arch){
    int tipo,cod,stoc;
    char cad[100],c;
    double prec;
    
    arch>>tipo;
    if(arch.eof()) return;
    arch>>c>>cod>>c;
    arch.getline(cad,100,',');
    arch>>stoc>>c>>prec>>c;
    
    if(tipo==1) med=new marca;
    else med=new generico;
    
    med->lee(arch,cod,cad,stoc,prec);    
}

void Nodo::imprime(ofstream &arch){
    med->imprime(arch,nullptr,0);
}