/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Arbol.cpp
 * Author: Ariana
 * 
 * Created on 15 de noviembre de 2024, 05:27 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Arbol.h"

Arbol::Arbol() {
    raiz=nullptr;
}

Arbol::Arbol(const Arbol& orig) {
}

Arbol::~Arbol() {
    if(raiz!=nullptr) delete raiz;
}

void Arbol::insertar(Nodo *nodo){
    raiz=insertar(raiz,nodo->med);
}

Nodo *Arbol::insertar(Nodo *nodo,medicamento *med){
    if(nodo==nullptr){
        Nodo *nuevoNodo=new Nodo;
        nuevoNodo->med=med;
        return nuevoNodo;
    }
    
    if(compara(med,nodo->med)==-1)
        nodo->izq=insertar(nodo->izq,med);
    else
        if(compara(med,nodo->med)==1)
            nodo->der=insertar(nodo->der,med);
        else
            cout<<"El medicamento ya está en el árbol"<<endl;
    
    return nodo;
}

int Arbol::compara(medicamento *a,medicamento *b){
    if(a->GetCodigo()<b->GetCodigo()) return -1;
    if(a->GetCodigo()>b->GetCodigo()) return 1;
    return 0;
}

void Arbol::recorreEnOrden(ofstream &arch){
    recorreEnOrden(raiz,arch);
}

void Arbol::recorreEnOrden(Nodo *nodo,ofstream &arch){
    if(nodo!=nullptr){
        recorreEnOrden(nodo->izq,arch);
        nodo->imprime(arch);
        recorreEnOrden(nodo->der,arch);
    }
    return;
}