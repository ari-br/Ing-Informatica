/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Nodo.h
 * Author: Ariana
 *
 * Created on 15 de noviembre de 2024, 05:25 PM
 */

#ifndef NODO_H
#define NODO_H

#include "medicamento.h"


class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Arbol;
    void lee(ifstream &arch);
    void imprime(ofstream &arch);
private:
    medicamento *med;
    Nodo *izq;
    Nodo *der;
};

#endif /* NODO_H */

