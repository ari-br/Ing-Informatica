/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   marca.h
 * Author: Ariana
 *
 * Created on 15 de noviembre de 2024, 05:22 PM
 */

#ifndef MARCA_H
#define MARCA_H

#include "medicamento.h"


class marca:public medicamento {
public:
    marca();
    marca(const marca& orig);
    virtual ~marca();
    void SetLote(int lote);
    int GetLote() const;
    void SetLaboratorio(char *);
    void GetLaboratorio(char *) const;
    void lee(ifstream &arch,int cod,char *cad,int stoc,double prec); //Método polimórfico
    void imprime(ofstream &arch,char *cad,int lot); //Método polimórfico
private:
    int lote;
    char *laboratorio;
};

#endif /* MARCA_H */

