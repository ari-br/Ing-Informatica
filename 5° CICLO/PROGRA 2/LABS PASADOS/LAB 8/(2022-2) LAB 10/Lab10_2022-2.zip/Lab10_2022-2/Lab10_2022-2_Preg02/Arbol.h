/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Arbol.h
 * Author: Ariana
 *
 * Created on 15 de noviembre de 2024, 05:27 PM
 */

#ifndef ARBOL_H
#define ARBOL_H

#include "Nodo.h"


class Arbol {
public:
    Arbol();
    Arbol(const Arbol& orig);
    virtual ~Arbol();
    void insertar(Nodo *nodo);
    void recorreEnOrden(ofstream &arch); //Impresión
    void recorreEnOrden(int cod,double desc); //Actualizar precio
private:
    Nodo  *raiz;
    Nodo *insertar(Nodo *nodo,medicamento *med);
    int compara(medicamento *a,medicamento *b);
    void recorreEnOrden(Nodo *nodo,ofstream &arch); //Impresión
    void recorreEnOrden(Nodo *nodo,int cod,double desc); //Actualizar precio
    //ABB ordenado por el código del medicamente (asecendente)
};

#endif /* ARBOL_H */

