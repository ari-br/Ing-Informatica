/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   almacen.cpp
 * Author: Ariana
 * 
 * Created on 15 de noviembre de 2024, 05:29 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "almacen.h"

almacen::almacen() {
}

almacen::almacen(const almacen& orig) {
}

almacen::~almacen() {
}

void almacen::carga(){
    ifstream arch("medicamentos.csv",ios::in);
    AperturaIf(arch,"medicamentos.csv");
    
    while(1){
        Nodo *nodo=new Nodo;
        nodo->lee(arch);
        if(arch.eof()) break;
        arbolalma.insertar(nodo);
    }
}

void almacen::actualiza(){
    ifstream arch("recarga.csv",ios::in);
    AperturaIf(arch,"recarga.csv");
    int cod;
    while(1){
        arch>>cod;
        if(arch.eof()) break;
        arbolalma.recorreEnOrden(cod,20);
    }
}

void almacen::imprime(){
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    arch<<setprecision(2)<<fixed;
    arch<<right<<setw(87)<<"REPORTE DE MEDICAMENTOS"<<endl;
    imprimirLinea(arch,'=');
    arch<<left<<setw(8)<<"Codigo"<<setw(40)<<"Nombre del medicamento"
        <<setw(9)<<"Stock"<<setw(9)<<"Precio"<<setw(35)<<"Pais/Laboratorio"
        <<"Lote"<<endl;
    imprimirLinea(arch,'=');
    arbolalma.recorreEnOrden(arch);
}

void almacen::imprimirLinea(ofstream &arch,char c){
    for (int i = 0; i < 150; i++) arch<<c;
    arch<<endl;
}

void almacen::AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void almacen::AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}