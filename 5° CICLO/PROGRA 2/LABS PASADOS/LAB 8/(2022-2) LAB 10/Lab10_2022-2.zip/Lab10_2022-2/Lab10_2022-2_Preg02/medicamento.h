/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   medicamento.h
 * Author: Ariana
 *
 * Created on 15 de noviembre de 2024, 05:17 PM
 */

#ifndef MEDICAMENTO_H
#define MEDICAMENTO_H

class medicamento {
public:
    medicamento();
    medicamento(const medicamento& orig);
    virtual ~medicamento();
    void SetPrecio(double precio);
    double GetPrecio() const;
    void SetStock(int stock);
    int GetStock() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void SetNombre(char *);
    void GetNombre(char *) const;
    virtual void lee(ifstream &arch,int cod,char *cad,int stoc,double prec); //Método polimórfico
    virtual void imprime(ofstream &arch,char *cad,int lot); //Método polimórfico
    virtual void actualiza(int tipo,double desc); //Método polimórfico
private:
    int codigo;
    char *nombre;
    int stock;
    double precio;
};

#endif /* MEDICAMENTO_H */

