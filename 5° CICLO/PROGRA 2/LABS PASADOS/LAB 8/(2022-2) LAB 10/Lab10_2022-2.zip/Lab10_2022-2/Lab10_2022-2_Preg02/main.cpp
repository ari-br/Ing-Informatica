/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 16 de noviembre de 2024, 11:36 AM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "almacen.h"
/*
 * 
 */
int main(int argc, char** argv) {
    almacen alma;
    
    alma.carga();
    alma.actualiza();
    alma.imprime();
    
    return 0;
}

