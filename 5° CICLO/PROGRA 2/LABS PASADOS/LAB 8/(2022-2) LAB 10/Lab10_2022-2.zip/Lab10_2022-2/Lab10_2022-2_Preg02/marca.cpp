/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   marca.cpp
 * Author: Ariana
 * 
 * Created on 15 de noviembre de 2024, 05:22 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "marca.h"

marca::marca() {
    lote=0;
    laboratorio=nullptr;
}

marca::marca(const marca& orig) {
}

marca::~marca() {
    if(laboratorio!=nullptr) delete laboratorio;
}

void marca::SetLote(int lote) {
    this->lote = lote;
}

int marca::GetLote() const {
    return lote;
}

void marca::SetLaboratorio(char *cad){
    if(laboratorio!=nullptr) delete laboratorio;
    laboratorio=new char[strlen(cad)+1];
    strcpy(laboratorio,cad);
}

void marca::GetLaboratorio(char *cad) const{
    if(laboratorio!=nullptr)
        strcpy(cad,laboratorio);
}

void marca::lee(ifstream &arch,int cod,char *cad,int stoc,double prec){
    char lab[100];
    arch.getline(lab,100,',');
    SetLaboratorio(lab);
    arch>>lote;
    medicamento::lee(arch,cod,cad,stoc,prec);
}

void marca::imprime(ofstream &arch,char *cad,int lot){
    medicamento::imprime(arch,laboratorio,lote);
}

void marca::actualiza(int tipo,double desc){
    medicamento::actualiza(1,desc);
}