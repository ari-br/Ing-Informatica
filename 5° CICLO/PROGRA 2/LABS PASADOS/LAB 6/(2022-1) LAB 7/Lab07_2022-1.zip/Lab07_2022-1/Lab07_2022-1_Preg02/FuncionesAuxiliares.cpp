/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   FuncionesAuxiliares.cpp
 * Author: Ariana
 * 
 * Created on 30 de octubre de 2024, 08:06 AM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Cliente.h"
#include "Pedido.h"
#include "FuncionesAuxiliares.h"

void imprimirReporte(Cliente *lcliente,const char *nomb){
    ofstream arch(nomb,ios::out);
    AperturaOf(arch,nomb);
    for (int i = 0; lcliente[i].GetDni(); i++) {
        arch<<lcliente[i];
    }
}

void aplicarDescuento(Cliente *lcliente,double desc,char cat){
    for (int i = 0; lcliente[i].GetDni(); i++) {
        if(lcliente[i].GetCategoria()==cat){
            lcliente[i]/desc;
        }
    }
}

void eliminarPedidos(Cliente *lcliente,const char *nomb){
    ifstream arch(nomb,ios::in);
    AperturaIf(arch,nomb);
    Pedido ped;
    
    while(1){
        arch>>ped;
        if(arch.eof()) break;
        for (int i = 0; lcliente[i].GetDni(); i++) {
            lcliente[i]-=ped;
        }
    }
}

void agregarPedido(Cliente *lcliente,Pedido *lpedido){
    for (int i = 0; lcliente[i].GetDni(); i++) {
        for (int k = 0; lpedido[k].GetCodigo(); k++) {
            if(lcliente[i].GetDni()==lpedido[k].GetDni()){
                lcliente[i]=lpedido[k];
            }
        }
    }
}

void leerPedidos(Pedido *lista,const char *nomb){
    ifstream arch(nomb,ios::in);
    AperturaIf(arch,nomb);
    
    for (int i = 0; 1; i++) {
        arch>>lista[i];
        if(arch.eof()) break;
    }
}

void leerClientes(Cliente *lista,const char *nomb){
    ifstream arch(nomb,ios::in);
    AperturaIf(arch,nomb);
    
    for (int i = 0; 1; i++) {
        arch>>lista[i];
        if(arch.eof()) break;
    }
}

void AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}