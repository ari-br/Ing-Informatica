/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 30 de octubre de 2024, 09:04 AM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Pedido.h"
#include "Cliente.h"
#include "FuncionesAuxiliares.h"
/*
 * 
 */
int main(int argc, char** argv) {
    Cliente lcliente[50];
    Pedido lpedido[200];
    
    leerClientes(lcliente,"clientes2.csv");
    leerPedidos(lpedido,"pedidos2.csv");
    agregarPedido(lcliente,lpedido);
    eliminarPedidos(lcliente,"eliminar2.csv");
    aplicarDescuento(lcliente,10,'A');
    imprimirReporte(lcliente,"Reporte.txt");
    
    return 0;
}

