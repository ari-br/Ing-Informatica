/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 29 de octubre de 2024, 03:37 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Pedido.h"
#include "Cliente.h"
#include "FuncionesAuxiliares.h"
/*
 * 
 */
int main(int argc, char** argv) {
    ifstream archCli("clientes2.csv",ios::in);
    AperturaIf(archCli,"clientes2.csv");
    ifstream archPed("pedidos2.csv",ios::in);
    AperturaIf(archPed,"pedidos2.csv");
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    
    Cliente cli;
    Pedido ped;
    
    archCli>>cli;
    archPed>>ped;
    cli/10;
    
    arch<<cli;
    arch<<ped;
    
    return 0;
}

