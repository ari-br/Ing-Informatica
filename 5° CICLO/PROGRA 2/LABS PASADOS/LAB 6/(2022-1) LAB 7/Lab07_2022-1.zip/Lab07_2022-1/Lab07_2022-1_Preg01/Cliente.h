/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Cliente.h
 * Author: Ariana
 *
 * Created on 29 de octubre de 2024, 03:39 PM
 */

#ifndef CLIENTE_H
#define CLIENTE_H
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Pedido.h"

class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    void SetTotal(double total);
    double GetTotal() const;
    void SetNumped(int numped);
    int GetNumped() const;
    void SetCategoria(char categoria);
    char GetCategoria() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetNombre(char*);
    void GetNombre(char*);
    void operator =(Pedido&);
    void operator -=(Pedido&);
    void operator /(double);
    void imprimePedidos(ofstream&);
private:
    int dni;
    char categoria;
    char *nombre;
    Pedido lped[100];
    int numped;
    double total;
};

ifstream &operator >>(ifstream&,Cliente&);
ofstream &operator <<(ofstream&,Cliente&);

#endif /* CLIENTE_H */

