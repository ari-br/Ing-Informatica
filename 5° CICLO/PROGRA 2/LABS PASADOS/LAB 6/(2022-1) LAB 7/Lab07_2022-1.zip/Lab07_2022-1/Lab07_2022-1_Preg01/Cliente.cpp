/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Cliente.cpp
 * Author: Ariana
 * 
 * Created on 29 de octubre de 2024, 03:39 PM
 */

#include <cstring>
using namespace std;
#include "Cliente.h"
#include "Pedido.h"

Cliente::Cliente() {
    dni=0;
    nombre=nullptr;
    numped=0;
    total=0;
}

Cliente::Cliente(const Cliente& orig) {
}

Cliente::~Cliente() {
    if(nombre!=nullptr) delete nombre;
}

void Cliente::SetTotal(double total) {
    this->total = total;
}

double Cliente::GetTotal() const {
    return total;
}

void Cliente::SetNumped(int numped) {
    this->numped = numped;
}

int Cliente::GetNumped() const {
    return numped;
}

void Cliente::SetCategoria(char categoria) {
    this->categoria = categoria;
}

char Cliente::GetCategoria() const {
    return categoria;
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

void Cliente::SetNombre(char*cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Cliente::GetNombre(char*cad){
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Cliente::operator =(Pedido&ped){
    char cad[100];
    lped[numped].SetCodigo(ped.GetCodigo());
    ped.GetNombre(cad);
    lped[numped].SetNombre(cad);
    lped[numped].SetCantidad(ped.GetCantidad());
    lped[numped].SetPrecio(ped.GetPrecio());
    lped[numped].SetDni(ped.GetDni());
    lped[numped].SetFecha(ped.GetFecha());
    numped++;
    total+=ped.GetPrecio()*ped.GetCantidad();
}

void Cliente::operator -=(Pedido&ped){
    for (int i = 0; i < numped; i++) {
        if(lped[i].GetDni()==ped.GetDni() and lped[i].GetFecha()==ped.GetFecha()
            and lped[i].GetCodigo()==ped.GetCodigo()){
            numped--;
            total-=lped[i].GetPrecio()*lped[i].GetCantidad();
            lped[i]=lped[numped-1];
            lped[numped-1]=lped[numped];
            return;
        }
    }
}

void Cliente::operator /(double desc){
    double porc=(100-desc)/100;
    total=0;
    for (int i = 0; i < numped; i++) {
        lped[i].SetPrecio(lped[i].GetPrecio()*porc);
        total+=lped[i].GetPrecio();
    }
}

ifstream &operator >>(ifstream&arch,Cliente&f){
    int dni;
    char c,cad[100],cat;
    
    arch>>dni>>c;
    if(!arch.eof()){
        arch.getline(cad,100,',');
        arch>>cat;
        f.SetDni(dni);
        f.SetNombre(cad);
        f.SetCategoria(cat);
    }
    return arch;
}

void Cliente::imprimePedidos(ofstream&arch){
    for (int i = 0; i < numped; i++) {
        arch<<lped[i];
    }
}

ofstream &operator <<(ofstream&arch,Cliente&f){
    arch<<setprecision(2)<<fixed;
    char cad[100];
    f.GetNombre(cad);
    arch<<left<<setw(20)<<f.GetDni()<<cad<<endl;
    for (int i = 0; i < 82; i++) arch<<"=";
    arch<<endl;
    if(f.GetNumped()>0){
        f.imprimePedidos(arch);
        arch<<left<<setw(16)<<"# de pedidos:"<<f.GetNumped()<<endl;
        arch<<left<<setw(15)<<"Monto total:"<<f.GetTotal()<<endl;
    }
    arch<<endl;
    return arch;
}