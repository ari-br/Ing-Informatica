/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Pedido.cpp
 * Author: Ariana
 * 
 * Created on 29 de octubre de 2024, 03:46 PM
 */

#include <cstring>

#include "Pedido.h"

Pedido::Pedido() {
    codigo=0;
    nombre=nullptr;
    cantidad=0;
    precio=0;
    dni=0;
    fecha=0;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
    if(nombre!=nullptr) delete nombre;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetPrecio(double precio) {
    this->precio = precio;
}

double Pedido::GetPrecio() const {
    return precio;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

void Pedido::SetNombre(char*cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Pedido::GetNombre(char*cad){
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

ifstream &operator >>(ifstream&arch,Pedido&f){
    int cod,dni,cant,fecha,dd,mm,aa;
    char c,cad[100];
    double precio;
    
    arch>>cod>>c;
    if(!arch.eof()){
        arch.getline(cad,100,',');
        arch>>cant>>c>>precio>>c>>dni>>c>>dd>>c>>mm>>c>>aa;
        fecha=(aa*10000)+(mm*100)+dd;
        f.SetCodigo(cod);
        f.SetNombre(cad);
        f.SetCantidad(cant);
        f.SetPrecio(precio);
        f.SetDni(dni);
        f.SetFecha(fecha);
    }
    return arch;
}

void Pedido::obtenerFecha(int fecha,int&dd,int&mm,int&aa){
    aa=fecha/10000;
    mm=(fecha/100)%100;
    dd=fecha%100;
}


ofstream &operator <<(ofstream&arch,Pedido&f){
    int dd,mm,aa;
    f.obtenerFecha(f.GetFecha(),dd,mm,aa);
    char cad[100];
    f.GetNombre(cad);
    arch<<setfill('0')<<right<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<setfill(' ')
        <<left<<setw(10)<<aa<<setw(50)<<cad<<right<<setw(4)<<f.GetCantidad()
        <<setw(10)<<f.GetPrecio()<<endl;
    return arch;
}