/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   FuncionesAuxiliares.h
 * Author: Ariana
 *
 * Created on 30 de octubre de 2024, 08:06 AM
 */

#ifndef FUNCIONESAUXILIARES_H
#define FUNCIONESAUXILIARES_H

void AperturaIf(ifstream &arch,const char *nomb);
void AperturaOf(ofstream &arch,const char *nomb);

#endif /* FUNCIONESAUXILIARES_H */
