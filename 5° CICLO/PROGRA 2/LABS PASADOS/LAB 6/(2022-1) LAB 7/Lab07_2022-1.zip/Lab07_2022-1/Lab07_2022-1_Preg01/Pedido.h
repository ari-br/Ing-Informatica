/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Pedido.h
 * Author: Ariana
 *
 * Created on 29 de octubre de 2024, 03:46 PM
 */

#ifndef PEDIDO_H
#define PEDIDO_H
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;

class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetPrecio(double precio);
    double GetPrecio() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void SetNombre(char*);
    void GetNombre(char*);
    void obtenerFecha(int,int&,int&,int&);
private:
    int codigo;
    char *nombre;
    int cantidad;
    double precio;
    int dni;
    int fecha;
};

ifstream &operator >>(ifstream&,Pedido&);
ofstream &operator <<(ofstream&arch,Pedido&);

#endif /* PEDIDO_H */

