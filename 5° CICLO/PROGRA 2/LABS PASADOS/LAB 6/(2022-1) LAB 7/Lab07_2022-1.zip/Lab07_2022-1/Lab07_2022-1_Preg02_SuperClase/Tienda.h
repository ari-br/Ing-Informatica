/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Tienda.h
 * Author: Ariana
 *
 * Created on 30 de octubre de 2024, 11:53 AM
 */

#ifndef TIENDA_H
#define TIENDA_H

#include "Pedido.h"
#include "Cliente.h"

class Tienda {
public:
    Tienda();
    Tienda(const Tienda& orig);
    virtual ~Tienda();
    void leerClientes();
    void leerPedidos();
    void agregarPedido();
    void eliminarPedidos();
    void aplicarDescuento(double desc,char cat);
    void imprimirReporte();
private:
    Cliente lcliente[50];
    Pedido lpedido[200];
    void AperturaIf(ifstream &,const char *);
    void AperturaOf(ofstream &,const char *);
};

#endif /* TIENDA_H */

