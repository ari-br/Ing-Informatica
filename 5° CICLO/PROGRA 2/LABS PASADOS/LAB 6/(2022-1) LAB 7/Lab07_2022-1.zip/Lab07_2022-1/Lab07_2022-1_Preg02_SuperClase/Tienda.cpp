/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Tienda.cpp
 * Author: Ariana
 * 
 * Created on 30 de octubre de 2024, 11:53 AM
 */

#include "Tienda.h"

Tienda::Tienda() {
}

Tienda::Tienda(const Tienda& orig) {
}

Tienda::~Tienda() {
    
}

void Tienda::imprimirReporte(){
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    for (int i = 0; lcliente[i].GetDni(); i++) {
        arch<<lcliente[i];
    }
}

void Tienda::aplicarDescuento(double desc,char cat){
    for (int i = 0; lcliente[i].GetDni(); i++) {
        if(lcliente[i].GetCategoria()==cat){
            lcliente[i]/desc;
        }
    }
}

void Tienda::eliminarPedidos(){
    ifstream arch("eliminar2.csv",ios::in);
    AperturaIf(arch,"eliminar2.csv");
    Pedido ped;
    
    while(1){
        arch>>ped;
        if(arch.eof()) break;
        for (int i = 0; lcliente[i].GetDni(); i++) {
            lcliente[i]-=ped;
        }
    }
}

void Tienda::agregarPedido(){
    for (int i = 0; lcliente[i].GetDni(); i++) {
        for (int k = 0; lpedido[k].GetCodigo(); k++) {
            if(lcliente[i].GetDni()==lpedido[k].GetDni()){
                lcliente[i]=lpedido[k];
            }
        }
    }
}

void Tienda::leerPedidos(){
    ifstream arch("pedidos2.csv",ios::in);
    AperturaIf(arch,"pedidos2.csv");
    
    for (int i = 0; 1; i++) {
        arch>>lpedido[i];
        if(arch.eof()) break;
    }
}

void Tienda::leerClientes(){
    ifstream arch("clientes2.csv",ios::in);
    AperturaIf(arch,"clientes2.csv");
    
    for (int i = 0; 1; i++) {
        arch>>lcliente[i];
        if(arch.eof()) break;
    }
}

void Tienda::AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void Tienda::AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}
