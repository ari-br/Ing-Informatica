/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 30 de octubre de 2024, 09:04 AM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Tienda.h"
#include "FuncionesAuxiliares.h"
/*
 * 
 */
int main(int argc, char** argv) {
    Tienda tien;
    
    tien.leerClientes();
    tien.leerPedidos();
    tien.agregarPedido();
    tien.eliminarPedidos();
    tien.aplicarDescuento(10,'A');
    tien.imprimirReporte();
    
    return 0;
}

