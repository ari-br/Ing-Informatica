/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 07:24 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Restaurante.h"
/*
 * 
 */
int main(int argc, char** argv) {
    Restaurante rest;
    
    rest.carga();       //Carga los datos en los arreglos de clientes y platos
    rest.actualiza();   //Actualiza los pedidos en cada cliente
    rest.muestra();     //Muestra el reporte de platos y cliente
    
    return 0;
}

