/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Pedido.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 01:30 PM
 */

#ifndef PEDIDO_H
#define PEDIDO_H

#include "Plato.h"


class Pedido:public Plato {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetNumPed(int numPed);
    int GetNumPed() const;
    void SetTotal(double total);
    double GetTotal() const;
    void operator =(const Pedido &);
    void llena(Pedido);
    void cargar(int,int,Plato &);
private:
    int numPed;
    int cantidad;
    double total;
};

ofstream &operator <<(ofstream &,Pedido &);

#endif /* PEDIDO_H */

