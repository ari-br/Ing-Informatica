/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Plato.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 01:31 PM
 */

#ifndef PLATO_H
#define PLATO_H

#include <fstream>
using namespace std;

class Plato {
public:
    Plato();
    Plato(const Plato& orig);
    virtual ~Plato();
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void SetPreparados(int preparados);
    int GetPreparados() const;
    void SetPrecio(double precio);
    double GetPrecio() const;
    void SetCodigo(char *);
    void GetCodigo(char *) const;
    void SetNombre(char *);
    void GetNombre(char *) const;
    void SetCategoria(char *);
    void GetCategoria(char *) const;
    void operator =(const Plato &);
    void llena(Plato);
    bool existe();
private:
    char *codigo;
    char *nombre;
    double precio;
    char *categoria;
    int preparados;
    double descuento;
};

ifstream &operator >>(ifstream &,Plato &);
ofstream &operator <<(ofstream &,Plato &);

#endif /* PLATO_H */

