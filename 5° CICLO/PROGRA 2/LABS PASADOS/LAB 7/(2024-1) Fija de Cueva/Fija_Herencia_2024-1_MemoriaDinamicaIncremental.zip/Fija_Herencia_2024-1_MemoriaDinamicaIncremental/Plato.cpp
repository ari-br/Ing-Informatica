/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Plato.cpp
 * Author: Ariana
 * 
 * Created on 7 de noviembre de 2024, 01:31 PM
 */

#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Plato.h"

Plato::Plato() {
    codigo=nullptr;
    nombre=nullptr;
    precio=0;
    categoria=nullptr;
    preparados=0;
    descuento=0;
}

Plato::Plato(const Plato& orig) {
    codigo=nullptr;
    nombre=nullptr;
    categoria=nullptr;
    *this=orig;
}

Plato::~Plato() {
    if(codigo!=nullptr) delete codigo;
    if(nombre!=nullptr) delete nombre;
    if(categoria!=nullptr) delete categoria;
}

void Plato::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Plato::GetDescuento() const {
    return descuento;
}

void Plato::SetPreparados(int preparados) {
    this->preparados = preparados;
}

int Plato::GetPreparados() const {
    return preparados;
}

void Plato::SetPrecio(double precio) {
    this->precio = precio;
}

double Plato::GetPrecio() const {
    return precio;
}

void Plato::SetCodigo(char *cad){
    if(codigo!=nullptr) delete codigo;
    codigo=new char[strlen(cad)+1];
    strcpy(codigo,cad);
}

void Plato::GetCodigo(char *cad) const{
    if(codigo!=nullptr)
        strcpy(cad,codigo);
}

void Plato::SetNombre(char *cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Plato::GetNombre(char *cad) const{
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Plato::SetCategoria(char *cad){
    if(categoria!=nullptr) delete categoria;
    categoria=new char[strlen(cad)+1];
    strcpy(categoria,cad);
}

void Plato::GetCategoria(char *cad) const{
    if(categoria!=nullptr)
        strcpy(cad,categoria);
}

void Plato::operator =(const Plato &f){
    char cad[100];
    f.GetCodigo(cad);
    SetCodigo(cad);
    f.GetNombre(cad);
    SetNombre(cad);
    precio=f.GetPrecio();
    f.GetCategoria(cad);
    SetCategoria(cad);
    descuento=f.GetDescuento();
    preparados=f.GetPreparados();
}

void Plato::llena(Plato f){
    char cad[100];
    f.GetCodigo(cad);
    SetCodigo(cad);
    f.GetNombre(cad);
    SetNombre(cad);
    precio=f.GetPrecio();
    f.GetCategoria(cad);
    SetCategoria(cad);
    descuento=f.GetDescuento();
    preparados=f.GetPreparados();
}

bool Plato::existe(){
    if(codigo!=nullptr) return true;
    return false;
}

ifstream &operator >>(ifstream &arch,Plato &f){
    int num;
    char cad[100],c;
    double precio,desc;
    
    arch.getline(cad,100,',');
    if(!arch.eof()){
        f.SetCodigo(cad);
        arch.getline(cad,100,',');
        f.SetNombre(cad);
        arch>>precio>>c;
        f.SetPrecio(precio);
        arch.getline(cad,100,',');
        f.SetCategoria(cad);
        arch>>num;
        f.SetPreparados(num);
        if(arch.get()==','){
            arch>>desc>>c;
            arch.get();
            f.SetDescuento(desc);
        }
    }
    return arch;
}

ofstream &operator <<(ofstream &arch,Plato &f){
    char cad[100];
    f.GetCodigo(cad);
    arch<<left<<setw(10)<<cad;
    f.GetNombre(cad);
    arch<<left<<setw(50)<<cad<<right<<setw(6)<<f.GetPrecio()<<setw(6)<<" "<<left;
    f.GetCategoria(cad);   
    arch<<setw(15)<<cad<<right<<setw(8)<<f.GetDescuento()<<"%"<<setw(12)
        <<f.GetPreparados()<<endl;;
    return arch;
}

