/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Cliente.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 01:29 PM
 */

#ifndef CLIENTE_H
#define CLIENTE_H

#include "Pedido.h"


class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetNombre(char *);
    void GetNombre(char *) const;
    void SetDistrito(char *);
    void GetDistrito(char *) const;
    void SetTotalPagado(double totalPagado);
    double GetTotalPagado() const;
    void operator =(const Cliente &);
    void llena(Cliente);
    bool tienePedidos();
    void imprimirLinea(ofstream &,int,char);
    void cargarPedidos(int,double &);
    void imprimirPedidos(ofstream &);
    void cargar(int,int,Plato &,int);
private:
    int dni;
    char *nombre;
    char *distrito;
    double descuento;
    Pedido *pedidos;    //Memoria dinámica exacta
    double totalPagado;
};

ifstream &operator >>(ifstream &,Cliente &);
ofstream &operator <<(ofstream &,Cliente &);

#endif /* CLIENTE_H */

