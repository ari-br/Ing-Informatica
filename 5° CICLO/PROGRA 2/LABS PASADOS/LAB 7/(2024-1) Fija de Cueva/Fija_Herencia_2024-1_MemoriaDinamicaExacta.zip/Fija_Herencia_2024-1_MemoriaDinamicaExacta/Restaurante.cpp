/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Restaurante.cpp
 * Author: Ariana
 * 
 * Created on 7 de noviembre de 2024, 01:51 PM
 */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "Restaurante.h"

Restaurante::Restaurante() {
    clientes=nullptr;
    platos=nullptr;
}

Restaurante::Restaurante(const Restaurante& orig) {
}

Restaurante::~Restaurante() {
    if(clientes!=nullptr) delete[] clientes;
    if(platos!=nullptr) delete[] platos;
}

void Restaurante::carga(){
    //Clientes
    cargaClientes();
    //Platos
    cargaPlatos();
}

void Restaurante::cargaClientes(){
    ifstream arch("Clientes.csv",ios::in);
    AperturaIf(arch,"Clientes.csv");
    
    Cliente buffer[150];
    int i=0;
    for (i; 1; i++) {
        arch>>buffer[i];
        if(arch.eof()) break;
    }
    clientes=new Cliente[i+1];
    for (int k = 0; k < i; k++) clientes[k].llena(buffer[k]); //Con constructor copia
}

void Restaurante::cargaPlatos(){
    ifstream arch("PlatosOfrecidos.csv",ios::in);
    AperturaIf(arch,"PlatosOfrecidos.csv");
    
    Plato buffer[150];
    int i=0;
    for (i; 1; i++) {
        arch>>buffer[i];
        if(arch.eof()) break;
    }
    platos=new Plato[i+1];
    for (int k = 0; k < i; k++) platos[k].llena(buffer[k]); //Con constructor copia
}

void Restaurante::actualiza(){
    ifstream arch("Pedidos.csv",ios::in);
    AperturaIf(arch,"Pedidos.csv");
    int numPed,dni,cant,posDni,posPla,cantPed[150]{0};
    char cod[10],c;
    while(1){
        arch>>numPed>>c;
        if(arch.eof()) break;
        arch>>dni>>c;
        posDni=buscarCliente(dni);
        while(1){
            arch.getline(cod,10,',');
            arch>>cant;
            posPla=buscarPlato(cod);
            cargarPedidoEnCliente(platos[posPla],clientes[posDni],cantPed[posDni],
                    numPed,cant);
            if(arch.get()=='\n') break;
        }
    }
    for (int i = 0; clientes[i].GetDni(); i++){
        double total=clientes[i].GetTotalPagado();
        clientes[i].cargarPedidos(cantPed[i],total);
        double porc=(100-clientes[i].GetDescuento())/100;
        total*=porc;
        clientes[i].SetTotalPagado(total);
    }
}

void Restaurante::cargarPedidoEnCliente(Plato &plato,Cliente &cli,int &cantPed,
        int numPed,int cant){
    cli.cargar(numPed,cant,plato,cantPed);
    cantPed++;
}

int Restaurante::buscarPlato(char *cod){
    for (int i = 0; platos[i].existe(); i++) {
        char codigo[10];
        platos[i].GetCodigo(codigo);
        if(strcmp(codigo,cod)==0) return i;
    }
}

int Restaurante::buscarCliente(int dni){
    for (int i = 0; clientes[i].GetDni(); i++) {
        if(clientes[i].GetDni()==dni) return i;
    }
}

void Restaurante:: muestra(){
    ofstream arch("Reporte.txt",ios::out);
    AperturaOf(arch,"Reporte.txt");
    arch<<setprecision(2)<<fixed;
    arch<<right<<setw(70)<<"RESTAURANTE 1INF25"<<endl;
    arch<<right<<setw(68)<<"VENTAS DEL DÍA"<<endl;
    imprimirLinea(arch,120,'=');
    mostrarPlatos(arch);
    imprimirLinea(arch,120,'=');
    mostrarClientes(arch);
    imprimirLinea(arch,120,'=');
}

void Restaurante::mostrarPlatos(ofstream &arch){
    arch<<right<<setw(70)<<"RELACION DE PLATOS"<<endl;
    imprimirLinea(arch,120,'-');
    arch<<left<<setw(5)<<"No."<<setw(10)<<"CODIGO"<<setw(50)<<"NOMBRE"<<setw(12)
        <<"PRECIO"<<setw(15)<<"CATEGORIA"<<setw(15)<<"DESCUENTO"<<"PREPARADOS"<<endl;
    imprimirLinea(arch,120,'-');
    for (int i = 0; platos[i].existe(); i++) {
        arch<<right<<setw(3)<<i+1<<") ";
        arch<<platos[i];
    }
}

void Restaurante::mostrarClientes(ofstream &arch){
    arch<<right<<setw(70)<<"RELACION DE CLIENTES"<<endl;
    imprimirLinea(arch,120,'-');
    arch<<left<<setw(5)<<"No."<<setw(10)<<"DNI"<<setw(30)<<"NOMBRE"<<setw(40)
        <<"DISTRITO"<<setw(15)<<"DESCUENTO"<<"TOTAL PAGADO"<<endl;
    imprimirLinea(arch,120,'-');
    for (int i = 0; clientes[i].GetDni(); i++) {
        arch<<right<<setw(3)<<i+1<<") ";
        arch<<clientes[i];
        imprimirLinea(arch,120,'-');
    }
}

void Restaurante::imprimirLinea(ofstream &arch,int max,char c){
    for (int i = 0; i < max; i++) arch<<c;
    arch<<endl;
}

void Restaurante::AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void Restaurante::AperturaOf(ofstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}