/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Pedido.cpp
 * Author: Ariana
 * 
 * Created on 7 de noviembre de 2024, 01:30 PM
 */
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Pedido.h"

Pedido::Pedido() {
    numPed=0;
    cantidad=0;
    total=0;
}

Pedido::Pedido(const Pedido& orig) {
    *this=orig;
}

Pedido::~Pedido() {
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetNumPed(int numPed) {
    this->numPed = numPed;
}

int Pedido::GetNumPed() const {
    return numPed;
}

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::operator =(const Pedido &ped){
    numPed=ped.GetNumPed();
    cantidad=ped.GetCantidad();
    total=ped.GetTotal();
    char cad[100];
    ped.GetCodigo(cad);
    SetCodigo(cad);
    ped.GetNombre(cad);
    SetNombre(cad);
    SetPrecio(ped.GetPrecio());
    SetPreparados(ped.GetPreparados());
    ped.GetCategoria(cad);
    SetCategoria(cad);
    SetDescuento(ped.GetDescuento());
    SetTotal(total);
}

void Pedido::llena(Pedido ped){
    numPed=ped.GetNumPed();
    cantidad=ped.GetCantidad();
    total=ped.GetTotal();
    char cad[100];
    ped.GetCodigo(cad);
    SetCodigo(cad);
    ped.GetNombre(cad);
    SetNombre(cad);
    SetPrecio(ped.GetPrecio());
    SetPreparados(ped.GetPreparados());
    ped.GetCategoria(cad);
    SetCategoria(cad);
    SetDescuento(ped.GetDescuento());
    SetTotal(total);
}

void Pedido::cargar(int num,int cant,Plato &pla){
    numPed=num;
    cantidad=cant;
    char cad[100];
    pla.GetCodigo(cad);
    SetCodigo(cad);
    pla.GetNombre(cad);
    SetNombre(cad);
    SetPrecio(pla.GetPrecio());
    SetPreparados(pla.GetPreparados());
    pla.GetCategoria(cad);
    SetCategoria(cad);
    SetDescuento(pla.GetDescuento());
    double porc=(100-pla.GetDescuento())/100;
    total=(pla.GetPrecio()*cant)*porc;
    SetTotal(total);
}

ofstream &operator <<(ofstream &arch,Pedido &f){
    char cad[100];
    f.GetNombre(cad);
    arch<<right<<setw(9)<<f.GetNumPed()<<setw(6)<<" "<<left<<setw(50)<<cad
        <<right<<setw(6)<<f.GetPrecio()<<setw(4)<<" ";
    f.GetCategoria(cad);
    arch<<left<<setw(15)<<cad<<right<<setw(8)<<f.GetDescuento()<<"%"<<setw(9)
        <<f.GetCantidad()<<setw(12)<<f.GetTotal()<<endl;
    return arch;
}