/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Cliente.cpp
 * Author: Ariana
 * 
 * Created on 7 de noviembre de 2024, 01:29 PM
 */
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Cliente.h"

Cliente::Cliente() {
    dni=0;
    nombre=nullptr;
    distrito=nullptr;
    descuento=0;
    pedidos=nullptr;
    totalPagado=0;
}

Cliente::Cliente(const Cliente& orig) {
    nombre=nullptr;
    distrito=nullptr;
    pedidos=nullptr;
    *this=orig;
}

Cliente::~Cliente() {
    if(nombre!=nullptr) delete nombre;
    if(distrito!=nullptr) delete distrito;
    if(pedidos!=nullptr) delete[] pedidos;
}

void Cliente::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Cliente::GetDescuento() const {
    return descuento;
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

void Cliente::SetNombre(char *cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Cliente::GetNombre(char *cad) const{
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Cliente::SetDistrito(char *cad){
    if(distrito!=nullptr) delete distrito;
    distrito=new char[strlen(cad)+1];
    strcpy(distrito,cad);
}

void Cliente::GetDistrito(char *cad) const{
    if(distrito!=nullptr)
        strcpy(cad,distrito);
}

void Cliente::SetTotalPagado(double totalPagado) {
    this->totalPagado = totalPagado;
}

double Cliente::GetTotalPagado() const {
    return totalPagado;
}

void Cliente::operator =(const Cliente &f){
    dni=f.GetDni();
    char cad[100];
    f.GetNombre(cad);
    SetNombre(cad);
    f.GetDistrito(cad);
    SetDistrito(cad);
    descuento=f.GetDescuento();
}

void Cliente::llena(Cliente f){
    dni=f.GetDni();
    char cad[100];
    f.GetNombre(cad);
    SetNombre(cad);
    f.GetDistrito(cad);
    SetDistrito(cad);
    descuento=f.GetDescuento();
}

bool Cliente:: tienePedidos(){
    if(pedidos!=nullptr) return true;
    return false;
}

void Cliente::cargarPedidos(int cantPed,double &total){
    Pedido *buffPed=new Pedido[cantPed+1];
    for (int i = 0; i < cantPed; i++) {
        buffPed[i].llena(pedidos[i]);
        total+=buffPed[i].GetTotal();
    }
    pedidos=buffPed;
}

void Cliente::imprimirPedidos(ofstream &arch){
    for (int i = 0; pedidos[i].GetNumPed(); i++) {
        arch<<pedidos[i];
    }
}

void Cliente::cargar(int numPed,int cant,Plato &plato,int cantPed){
    if(cantPed==0) pedidos=new Pedido[300];
    pedidos[cantPed].cargar(numPed,cant,plato);
}

ifstream &operator >>(ifstream &arch,Cliente &f){
    int dni;
    char cad[100],c;
    double desc;
    
    arch>>dni>>c;
    if(!arch.eof()){
        f.SetDni(dni);
        arch.getline(cad,100,',');
        f.SetNombre(cad);
        arch.getline(cad,100,',');
        f.SetDistrito(cad);
        arch>>c;
        if(c=='S'){
            arch>>c>>desc>>c;
            f.SetDescuento(desc);
        }
    }
    return arch;
}

ofstream &operator <<(ofstream &arch,Cliente &f){
    char cad[100];
    f.GetNombre(cad);
    arch<<left<<setw(10)<<f.GetDni()<<setw(40)<<cad;
    f.GetDistrito(cad);
    arch<<setw(30)<<cad<<right<<setw(8)<<f.GetDescuento()<<"%"<<setw(18)
        <<f.GetTotalPagado()<<endl;
    f.imprimirLinea(arch,120,'.');
    if(f.tienePedidos()){
        arch<<left<<setw(15)<<"Num. Pedido"<<setw(10)<<setw(50)<<"Plato"<<setw(10)
            <<"Precio"<<setw(15)<<"Categoria"<<setw(15)<<"Descuento"<<setw(10)
            <<"Cant."<<"Total"<<endl;
        f.imprimirLinea(arch,120,'.');
        f.imprimirPedidos(arch);
    }else{
        arch<<"NO REALIZÓ PEDIDOS"<<endl;
    }
    return arch;
}

void Cliente::imprimirLinea(ofstream &arch,int max,char c){
    for (int i = 0; i < max; i++) arch<<c;
    arch<<endl;
}