/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Restaurante.h
 * Author: Ariana
 *
 * Created on 7 de noviembre de 2024, 01:51 PM
 */

#ifndef RESTAURANTE_H
#define RESTAURANTE_H

#include "Cliente.h"


class Restaurante {
public:
    Restaurante();
    Restaurante(const Restaurante& orig);
    virtual ~Restaurante();
    void carga();
    void actualiza();
    void muestra();
private:
    Cliente *clientes;  //Memoria dinámica exacta
    Plato *platos;      //Memoria dinámica exacta
    void cargaClientes();
    void cargaPlatos();
    void mostrarClientes(ofstream &);
    void mostrarPlatos(ofstream &);
    int buscarCliente(int);
    int buscarPlato(char *);
    void cargarPedidoEnCliente(Plato &,Cliente &,int &,int,int);
    void cargarPedidos(Cliente &,Pedido *,int);
    void imprimirLinea(ofstream &,int,char);
    void AperturaIf(ifstream &,const char *);
    void AperturaOf(ofstream &,const char *);
};

#endif /* RESTAURANTE_H */

