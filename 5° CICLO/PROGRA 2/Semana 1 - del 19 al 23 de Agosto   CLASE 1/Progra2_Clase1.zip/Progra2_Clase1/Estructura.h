/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Estructura.h
 * Author: Ariana
 *
 * Created on 20 de agosto de 2024, 11:16 AM
 */

#ifndef ESTRUCTURA_H
#define ESTRUCTURA_H

struct strNotas{
    int lab[10];
    int n; //Contador de notas para no leer todo el arreglo
};

#endif /* ESTRUCTURA_H */

