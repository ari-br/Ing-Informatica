
/* 
 * File:   Cliente.h
 * Author: cueva
 *
 * Created on 5 de noviembre de 2024, 08:24 PM
 */

#ifndef CLIENTE_H
#define CLIENTE_H
#include <fstream>
#include "Pedido.h"

using namespace std;

class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    void SetDni(int dni);
    int GetDni() const;
    void SetNombre(char*);
    void GetNombre( char*)const;
    void operator=(const Cliente&);
    void llena(Cliente);
private:
    int dni;
    char *nombre;
    Pedido *lpedidos;
};
ifstream &operator>>(ifstream&,Cliente &);

#endif /* CLIENTE_H */

