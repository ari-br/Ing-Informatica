/* 
 * File:   Plato.cpp
 * Author: cueva
 * 
 * Created on 5 de noviembre de 2024, 08:24 PM
 */
#include <iostream>
#include <fstream>
#include <cstring>
#include "Plato.h"

using namespace std;


Plato::Plato() {
    codigo=nullptr;
    nombre=nullptr;
    precio=0;
    categoria=nullptr;
    
}

Plato::Plato(const Plato& orig) {
}

Plato::~Plato() {
}

void Plato::SetPrecio(double precio) {
    this->precio = precio;
}

double Plato::GetPrecio() const {
    return precio;
}

void Plato::SetNombre(char*cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}
void Plato::GetNombre(char* cad){
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Plato::SetCodigo(char* cad){
    if(codigo!=nullptr) delete codigo;
    codigo=new char[strlen(cad)+1];
    strcpy(codigo,cad);    
    
}

void Plato::GetCodigo(char* cad){
    if(codigo!=nullptr)
        strcpy(cad,codigo);
}

void Plato::SetCategoria(char* cad){
    if(categoria!=nullptr) delete categoria;
    categoria=new char[strlen(cad)+1];
    strcpy(categoria,cad);    
    
}

void Plato::GetCategoria(char* cad){
    if(categoria!=nullptr)
        strcpy(cad,categoria);
}