/* 
 * File:   main.cpp
 * Author: cueva
 *
 * Created on 5 de noviembre de 2024, 08:23 PM
 */

#include <cstdlib>

#include "Restaurante.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    Restaurante resto;
    
    resto.carga();

    return 0;
}

