/* 
 * File:   Pedido.h
 * Author: cueva
 *
 * Created on 5 de noviembre de 2024, 08:36 PM
 */

#ifndef PEDIDO_H
#define PEDIDO_H

#include "Plato.h"


class Pedido: public Plato {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetNumped(int numped);
    int GetNumped() const;
private:
    int numped;
    int cantidad;
};

#endif /* PEDIDO_H */

