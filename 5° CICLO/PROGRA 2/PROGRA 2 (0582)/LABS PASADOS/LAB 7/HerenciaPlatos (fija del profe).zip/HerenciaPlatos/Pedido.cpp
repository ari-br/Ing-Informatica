
/* 
 * File:   Pedido.cpp
 * Author: cueva
 * 
 * Created on 5 de noviembre de 2024, 08:36 PM
 */

#include "Pedido.h"

Pedido::Pedido() {
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetNumped(int numped) {
    this->numped = numped;
}

int Pedido::GetNumped() const {
    return numped;
}

