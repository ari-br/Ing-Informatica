/* 
 * File:   Restaurante.h
 * Author: cueva
 *
 * Created on 5 de noviembre de 2024, 08:24 PM
 */

#ifndef RESTAURANTE_H
#define RESTAURANTE_H

#include "Cliente.h"
#include "Plato.h"


class Restaurante {
public:
    Restaurante();
    Restaurante(const Restaurante& orig);
    virtual ~Restaurante();
    void carga();
    
private:
    void cargacliente();
    Cliente *clientes;
    Plato *platos;
    
};

#endif /* RESTAURANTE_H */

