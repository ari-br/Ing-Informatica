/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Restaurante.cpp
 * Author: cueva
 * 
 * Created on 5 de noviembre de 2024, 08:24 PM
 */
#include <iostream>
#include <fstream>
#include <cstring>
#include "Restaurante.h"

using namespace std;


Restaurante::Restaurante() {
}

Restaurante::Restaurante(const Restaurante& orig) {
}

Restaurante::~Restaurante() {
}
void Restaurante::carga(){
    
    cargacliente();
}

void Restaurante::cargacliente(){
    Cliente lcliente[150];
    
    int i=0;
    ifstream arch("clientes.csv",ios::in);
    if(!arch){
        cout <<"No se puede abrir el archivo de clientes";
        exit(1);
    }   
    while(1){
        arch >> lcliente[i];
        if(arch.eof()) break;
        i++;
    }
    clientes=new Cliente[i+1];
    for(int j=0;j<=i;j++)
        clientes[j].llena(lcliente[j]);
        //clientes[j]=lcliente[j];
    
}
