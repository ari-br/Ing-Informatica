/* 
 * File:   Plato.h
 * Author: cueva
 *
 * Created on 5 de noviembre de 2024, 08:24 PM
 */

#ifndef PLATO_H
#define PLATO_H

class Plato {
public:
    Plato();
    Plato(const Plato& orig);
    virtual ~Plato();
    void SetPrecio(double precio);
    double GetPrecio() const;
    void SetNombre(char*);
    void GetNombre(char*);
    void SetCodigo(char*);
    void GetCodigo(char*);
    void SetCategoria(char*);
    void GetCategoria(char*);
private:
    char *codigo;
    char *nombre;
    double precio;
    char *categoria;
};

#endif /* PLATO_H */

