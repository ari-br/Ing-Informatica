/* 
 * File:   Cliente.cpp
 * Author: cueva
 * 
 * Created on 5 de noviembre de 2024, 08:24 PM
 */
#include <iostream>
#include <fstream>
#include <cstring>
#include "Cliente.h"

using namespace std;


Cliente::Cliente() {
    dni=0;
    nombre=nullptr;
    lpedidos=nullptr;
    
}

Cliente::Cliente(const Cliente& orig) {
    nombre=nullptr;
    lpedidos=nullptr;
    *this = orig;
}

Cliente::~Cliente() {
    if(nombre!=nullptr) delete nombre;
    if(lpedidos!=nullptr) delete[] lpedidos;
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

void Cliente::SetNombre(char*cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}
void Cliente::GetNombre(char* cad)const{
    if(nombre!=nullptr)
    strcpy(cad,nombre);
}
void Cliente::operator =(const Cliente&dato){
    char cad[100];
    
    dni= dato.GetDni();
    dato.GetNombre(cad);
    SetNombre(cad);
}
void Cliente::llena(Cliente dato){
    char cad[100];
    
    dni= dato.GetDni();
    dato.GetNombre(cad);
    SetNombre(cad);    
    
}

ifstream &operator>>(ifstream &arch,Cliente &f){
    char cad[100],c;
    int coddni;
    
    arch >> coddni;
    if(!arch.eof()){
        arch.get();
        f.SetDni(coddni);
        arch.getline(cad,100,',');
        f.SetNombre(cad);
        arch.getline(cad,100);
    }
    return arch;
}