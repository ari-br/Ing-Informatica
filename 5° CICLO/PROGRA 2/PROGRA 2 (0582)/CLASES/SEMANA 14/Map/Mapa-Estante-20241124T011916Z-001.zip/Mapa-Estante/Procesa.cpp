/* 
 * File:   Procesa.cpp
 * Author: cueva
 * 
 * Created on 15 de noviembre de 2024, 08:59 AM
 */
#include <iostream>
#include <iterator>
#include "Procesa.h"

using namespace std;

Procesa::Procesa() {
}

Procesa::Procesa(const Procesa& orig) {
}

Procesa::~Procesa() {
}

void Procesa::carga(){
    Revista aux;
    ifstream arch("libros3.csv",ios::in);
    if(not arch){
        cout << "No se puede abrir libros";
        exit(1);
    }
    while(1){
        aux.lee(arch);
        if(arch.eof()) break;
        mrevistas[aux.GetISSN()] = aux;
    }
}

void Procesa::muestra(){
    ofstream arch("reporte.txt",ios::out);
    if(not arch){
        cout << "No se puede abrir reportes";
        exit(1);
    }    
    for(map<string,Revista>::iterator it=mrevistas.begin();
            it!=mrevistas.end();it++){
        //arch<<it->first <<" ";
        it->second.imprime(arch);
    }
}

void Procesa::cargaestante(){
    Estante aux;
    ifstream arch("estantes2.csv",ios::in);
    if(not arch){
        cout << "No se puede abrir estantes";
        exit(1);
    }    
    while(1){
        aux.leestante(arch);
        if(arch.eof()) break;
        vector<Libro> vaux;
        mestante[aux]=vaux;
    }
}

void Procesa::cargalibro(){
    Libro aux;
    ifstream arch("libros4.csv",ios::in);
    if(not arch){
        cout << "No se puede abrir libros";
        exit(1);
    }    
    while(1){
        aux.lee(arch);
        if(arch.eof()) break;
        for(map<Estante,vector<Libro>>::iterator it=mestante.begin();
            it!=mestante.end();it++){
            double capa=it->first.getCapacidad();
            double total=0;
            for(int i=0;i<it->second.size();i++)
                total+=it->second[i].GetPeso();
            if(capa>=total+aux.GetPeso()){
                it->second.push_back(aux);
                break;
            }
            
        }
    }
}

void Procesa::muestralibro(){
    ofstream arch("reporte1.txt",ios::out);
    if(not arch){
        cout << "No se puede abrir reportes1";
        exit(1);
    }    
    for(map<Estante,vector<Libro>>::iterator it=mestante.begin();
        it!=mestante.end();it++){
        it->first.imprime(arch);
        for(int i=0;i<it->second.size();i++)
            it->second[i].imprime(arch);
    }
}

