
/* 
 * File:   main.cpp
 * Author: cueva
 *
 * Created on 15 de noviembre de 2024, 08:03 AM
 */

#include "Procesa.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    Procesa pro;
    
    pro.carga();
    pro.muestra();
    pro.cargaestante();
    pro.cargalibro();
    pro.muestralibro();
    
    return 0;
}

