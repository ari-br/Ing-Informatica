/* 
 * File:   Clientes.cpp
 * Author: cueva.r
 * 
 * Created on 9 de octubre de 2024, 02:22 PM
 */

#include "Clientes.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>

using namespace std;


Clientes::Clientes() {
    dni=0;
    nombre=nullptr;
    lped=nullptr;
    numped=0;
    total=0;
}

Clientes::Clientes(const Clientes& orig) {
    
}

Clientes::~Clientes() {
    if(nombre!=nullptr) delete nombre;
}

void Clientes::SetTotal(double total) {
    this->total = total;
}

double Clientes::GetTotal() const {
    return total;
}

void Clientes::SetNumped(int numped) {
    this->numped = numped;
}

int Clientes::GetNumped() const {
    return numped;
}

void Clientes::SetCategoria(char categoria) {
    this->categoria = categoria;
}

char Clientes::GetCategoria() const {
    return categoria;
}

void Clientes::SetDni(int dni) {
    this->dni = dni;
}

int Clientes::GetDni() const {
    return dni;
}

void Clientes::SetNombre(char*cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}
void Clientes::GetNombre(char* cad){
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Clientes::operator =(Pedido&ped){    
    char cad[100];
    
    if(lped==nullptr)
        lped = new Pedido[100];
    
    lped[numped].SetCodigo(ped.GetCodigo());
    lped[numped].SetCantidad(ped.GetCantidad());
    lped[numped].SetFecha(ped.GetFecha());
    lped[numped].SetPrecio(ped.GetPrecio());
    lped[numped].SetDni(ped.GetDni());
    ped.GetNombre(cad);
    lped[numped].SetNombre(cad);
    numped++;
    total+=ped.GetPrecio();
}

void Clientes::imprimepedidos(ofstream&arch){  
    for(int i=0;lped[i].GetCodigo()!=0;i++)
        arch << lped[i];

}

void Clientes::operator /(double desc){
    double precio;
    total=0;
    for(int i=0;lped[i].GetCodigo()!=0;i++){
        precio=lped[i].GetPrecio()*(1-(desc/100));
        lped[i].SetPrecio(precio);
        total+=precio;
    }
}


/*
71984468,IPARRAGUIRRE VILLEGAS NICOLAS EDILBERTO,A
29847168,ALDAVE ZEVALLOS ROSARIO,A */
ifstream &operator >>(ifstream &arch,Clientes&f){
    int dni;
    char cad[100],cat;
    arch >> dni;
    if(not arch.eof()){
        f.SetDni(dni);
        arch.get();
        arch.getline(cad,100,',');
        f.SetNombre(cad);
        arch >> cat;
        f.SetCategoria(cat);
        
    }
    return arch;        
    
}


ofstream &operator <<(ofstream &arch,Clientes&f){
    char cad[100];
    
    f.GetNombre(cad);
    arch <<setw(15)<< f.GetDni() <<setw(50)<< cad <<endl;
    if(f.GetNumped()>0)
        f.imprimepedidos(arch);
    return arch;
}
