/* 
 * File:   Clientes.h
 * Author: cueva.r
 *
 * Created on 9 de octubre de 2024, 02:22 PM
 */

#ifndef CLIENTES_H
#define CLIENTES_H

#include "Pedido.h"
#include <fstream>

using namespace std;

class Clientes {
public:
    Clientes();
    Clientes(const Clientes& orig);
    virtual ~Clientes();
    void SetTotal(double total);
    double GetTotal() const;
    void SetNumped(int numped);
    int GetNumped() const;
    void SetCategoria(char categoria);
    char GetCategoria() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetNombre(char*);
    void GetNombre(char*);
    void operator=(Pedido&);
    void operator/(double);
    void imprimepedidos(ofstream&);
private:
    int dni;
    char categoria;
    char *nombre;
    Pedido *lped;
    int numped;
    double total;
};

ifstream &operator >>(ifstream &,Clientes&);
ofstream &operator <<(ofstream &,Clientes&);

#endif /* CLIENTES_H */

