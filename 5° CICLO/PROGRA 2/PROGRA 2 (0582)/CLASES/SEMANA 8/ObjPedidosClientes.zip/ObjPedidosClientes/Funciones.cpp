/* 
 * File:   Funciones.cpp
 * Author: cueva.r
 * 
 * Created on 9 de octubre de 2024, 03:16 PM
 */
#include <iostream>
#include <fstream>
#include <cstring>
#include "Funciones.h"
#include "Pedido.h"
#include "Clientes.h"
using namespace std;

void leerclientes(Clientes *lista){
    int i=0;
    ifstream arch("clientes2.csv",ios::in);
    if(not arch){
        cout <<"No se puede abrir el archivo de clientes";
        exit(1);
    }
    while(1){
        arch >> lista[i];
        if(arch.eof())break;
        i++;
    }
}

void imprimirclientes(Clientes *lista){
    ofstream arch("repclientes.txt",ios::out);
    if(not arch){
        cout <<"No se puede abrir el archivo de clientes";
        exit(1);
    }    
    for(int i=0;lista[i].GetDni()!=0;i++)
        arch << lista[i];
    
}

void leepedido(Pedido *lista){
    int i=0;
    ifstream arch("pedidos2.csv",ios::in);
    if(not arch){
        cout <<"No se puede abrir el archivo de pedidos";
        exit(1);
    }    
    while(1){
        arch >> lista[i];
        if(arch.eof())break;
        i++;        
    }
}

void cargapedidos(Clientes *lcliente,Pedido *lpedido){
    
    for(int i=0;lcliente[i].GetDni()!=0;i++){
        for(int j=0;lpedido[j].GetCodigo()!=0;j++){
            if(lcliente[i].GetDni()==lpedido[j].GetDni())
                lcliente[i]=lpedido[j];
        }
    }
    
}

void aplicadescuento(Clientes *lcliente,char tipo,double desc){
    
    for(int i=0;lcliente[i].GetDni()!=0;i++){
        if(lcliente[i].GetCategoria()==tipo 
                and lcliente[i].GetNumped()>0)
            lcliente[i]/desc;
    }
}