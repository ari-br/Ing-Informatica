/* 
 * File:   Pedido.cpp
 * Author: cueva.r
 * 
 * Created on 9 de octubre de 2024, 02:26 PM
 */

#include "Pedido.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>

using namespace std;

Pedido::Pedido() {
    codigo=0;
    nombre=nullptr;
    cantidad=0;
    precio=0;
    dni=0;
    fecha=0; 
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
    if(nombre!=nullptr) delete nombre;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetPrecio(double precio) {
    this->precio = precio;
}

double Pedido::GetPrecio() const {
    return precio;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

void Pedido::SetNombre(char*cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}
void Pedido::GetNombre(char* cad){
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

/*
118050,PAPAYA,8,8,79475585,16/12/2019
118050,PAPAYA,5,5,79475585,30/04/2020
*/
ifstream &operator >>(ifstream &arch,Pedido&f){
    int dni,codigo,cant,aa,mm,dd,fecha;
    char cad[100],c;
    double precio;
    
    arch >> codigo;
    if(not arch.eof()){
        arch.get();
        f.SetCodigo(codigo);
        arch.getline(cad,100,',');
        f.SetNombre(cad);
        arch>>cant>>c>>precio>>c>>dni>>c>>dd>>c>>mm>>c>>aa;
        f.SetCantidad(cant);
        f.SetPrecio(precio);
        f.SetDni(dni);
        fecha=aa*10000+mm*100+dd;
        f.SetFecha(fecha);
    }
    return arch;
    
}

ofstream &operator <<(ofstream &arch,Pedido&f){
    char cad[100];
    
    f.GetNombre(cad);
    arch <<setw(10)<<f.GetCodigo()<<setw(50)<<cad;
    arch << setw(10) << f.GetCantidad() << setw(10) << f.GetPrecio() << endl;
    return arch;
}
