/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones.h
 * Author: cueva.r
 *
 * Created on 9 de octubre de 2024, 03:16 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

#include "Clientes.h"

    void leerclientes(Clientes *lista);
    void cargapedidos(Clientes *lcliente,Pedido *lpedido);
    void leepedido(Pedido *lista);
    void imprimirclientes(Clientes *lista);
    void aplicadescuento(Clientes *lcliente,char tipo,double desc);

#endif /* FUNCIONES_H */
