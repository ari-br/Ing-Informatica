/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 9 de octubre de 2024, 02:20 PM
 */
#include <iostream>
#include "Clientes.h"
#include "Funciones.h"

using namespace std;

int main(int argc, char** argv) {
    Clientes lcliente[50];
    Pedido lpedido[200];
    
    leerclientes(lcliente);
    leepedido(lpedido);
    cargapedidos(lcliente,lpedido);
    aplicadescuento(lcliente,'A',10);
    imprimirclientes(lcliente);
    
    return 0;
}

