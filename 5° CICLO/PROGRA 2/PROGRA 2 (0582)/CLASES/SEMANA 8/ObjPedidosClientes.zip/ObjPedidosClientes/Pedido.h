/* 
 * File:   Pedido.h
 * Author: cueva.r
 *
 * Created on 9 de octubre de 2024, 02:26 PM
 */

#ifndef PEDIDO_H
#define PEDIDO_H
#include <fstream>

using namespace std;

class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetPrecio(double precio);
    double GetPrecio() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void SetNombre(char*);
    void GetNombre(char*);
private: 
    int codigo;
    char *nombre;
    int cantidad;
    double precio;
    int dni;
    int fecha; 
};

#endif /* PEDIDO_H */

ifstream &operator >>(ifstream &arch,Pedido&f);
ofstream &operator <<(ofstream &arch,Pedido&f);