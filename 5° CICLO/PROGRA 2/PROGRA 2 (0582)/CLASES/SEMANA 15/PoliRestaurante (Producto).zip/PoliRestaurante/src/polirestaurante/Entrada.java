
package polirestaurante;

import java.util.Scanner;

/**
 *
 * @author cueva.r
 */
public class Entrada extends Producto{
    private boolean picante;

    public boolean isPicante() {
        return picante;
    }

    public void setPicante(boolean picante) {
        this.picante = picante;
    }
    /*161 E Ensalada_Cesar 6 picante*/
    @Override
    public void lee(Scanner arch){
        String sabor;
        super.lee(arch);
        sabor = arch.next();
        
        if(sabor.compareTo("picante")==0)
            picante = true;
        else
            picante = false;
    }
    
    @Override
    public void muestra(){
        super.muestra();
        if(picante)
            System.out.println("Picante");
        else
            System.out.println("Sin picante");
    }
    
}
