package polirestaurante;

import java.util.Scanner;

/**
 *
 * @author cueva.r
 */
public class Producto {
    private String nombre;
    private double precio;

    
    public Producto(){
        precio = 0;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    /*
    142 B Cafe 2 grande
    */
    public void lee(Scanner arch){
        nombre = arch.next();
        precio = arch.nextDouble();
    }
    
    public void muestra(){
        System.out.println("Nombre: "+nombre);
        String resul = String.format("%.2f",precio);
        System.out.println("Precio: "+resul);
    }
    
    
}

