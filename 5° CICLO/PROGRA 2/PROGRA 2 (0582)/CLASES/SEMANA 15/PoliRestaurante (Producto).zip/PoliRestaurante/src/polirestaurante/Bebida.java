/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polirestaurante;

import java.util.Scanner;

/**
 *
 * @author cueva.r
 */
public class Bebida extends Producto{
    private String tamano;

    public String getTamano() {
        return tamano;
    }

    public void setTamano(String tamano) {
        this.tamano = tamano;
    }
    /*142 B Cafe 2 grande*/
    @Override
    public void lee(Scanner arch){
        super.lee(arch);
        tamano = arch.next();
    }
    @Override
    public void muestra(){
        super.muestra();
        System.out.println(tamano);
    }
    
    
    
}
