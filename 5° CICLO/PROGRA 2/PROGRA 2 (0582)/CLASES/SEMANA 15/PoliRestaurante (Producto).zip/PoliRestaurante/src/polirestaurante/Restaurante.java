package polirestaurante;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

/**
 *
 * @author cueva.r
 */
public class Restaurante {
    private ArrayList<Producto>lproductos;
    
    public Restaurante(){
        lproductos = new ArrayList<Producto>();
    }
    
    public void carga()throws Exception{
        int id;
        String tipo;
        Producto aux;
        File archivo = new File("comandas2.txt");
        Scanner arch = new Scanner(archivo);
        /*161 B Coca-Cola 3.5 grande*/
        while(arch.hasNext()){
            id = arch.nextInt();
            tipo = arch.next();
            
            if(tipo.compareTo("E")==0)
                aux = new Entrada();
            else
                if(tipo.compareTo("B")==0)
                    aux = new Bebida();
                else
                    aux = new PlatoFondo();            
            
            aux.lee(arch);
            lproductos.add(aux);
        }
    }
    public void muestra(){
        
        for(Producto lprod:lproductos){
            lprod.muestra();
            System.out.println();
        }
        
    }
    
    
}
