/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package polirestaurante;

/**
 *
 * @author cueva.r
 */
public class PoliRestaurante {

    public static void main(String[] args) {
        Restaurante res;
        res = new Restaurante();
        
        try{
            res.carga();
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        } 
        res.elimina(3);
        res.muestra();
        
    }
    
}
