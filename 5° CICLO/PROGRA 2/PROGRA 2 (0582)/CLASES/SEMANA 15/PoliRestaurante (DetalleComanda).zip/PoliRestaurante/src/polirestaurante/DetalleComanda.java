/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polirestaurante;

import java.util.Scanner;

/**
 *
 * @author cueva.r
 */
public class DetalleComanda {
    private int id;
    private Producto pedido;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public void asignacomanda(String tipo,Scanner arch){
        if(tipo.compareTo("E")==0)
            pedido = new Entrada();
        else
            if(tipo.compareTo("B")==0)
                pedido = new Bebida();
            else
                pedido = new PlatoFondo();            

        pedido.lee(arch);
    }
   
    public void muestracomanda(){
        System.out.println("Id: "+id);
        pedido.muestra();
    }
    
    public int getcomponente(){
        return pedido.getcomponente();
    }
    
    
}
