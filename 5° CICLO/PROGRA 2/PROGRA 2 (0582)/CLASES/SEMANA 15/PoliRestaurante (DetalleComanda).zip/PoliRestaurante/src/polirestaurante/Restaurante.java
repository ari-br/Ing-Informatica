package polirestaurante;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

/**
 *
 * @author cueva.r
 */
public class Restaurante {
    private ArrayList<DetalleComanda>lcomanda;
    
    public Restaurante(){
        lcomanda = new ArrayList<DetalleComanda>();
    }
    
    public void carga()throws Exception{
        int id;
        String tipo;
        DetalleComanda aux;
        File archivo = new File("comandas2.txt");
        Scanner arch = new Scanner(archivo);
        /*161 B Coca-Cola 3.5 grande*/
        while(arch.hasNext()){
            id = arch.nextInt();
            tipo = arch.next();
            aux = new DetalleComanda();
            aux.setId(id);
            aux.asignacomanda(tipo, arch);
            lcomanda.add(aux);
        }
    }
    public void muestra(){
        for(DetalleComanda lprod:lcomanda){
            lprod.muestracomanda();
            System.out.println();
        }
    }
    
    public void elimina(int prod){
        lcomanda.removeIf(s->s.getcomponente() == prod);
        
    }
    
    
}
