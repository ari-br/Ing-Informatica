package polirestaurante;

import java.util.Scanner;

/**
 *
 * @author cueva.r
 */
public class PlatoFondo extends Producto{
    private int proteina;

    public int getProteina() {
        return proteina;
    }

    public void setProteina(int proteina) {
        this.proteina = proteina;
    }
    /*169 P Pasta_Alfredo 10 4*/
    @Override
    public void lee(Scanner arch){
        super.lee(arch);
        proteina = arch.nextInt();
    }
    @Override
    public void muestra(){
        super.muestra();
        if(proteina==1)
            System.out.println("Pollo");
        if(proteina==2)
            System.out.println("Carne");
        if(proteina==3)
            System.out.println("Pescado");
        if(proteina==4)
            System.out.println("Lacteos");

    }
    
    @Override
    public int getcomponente(){
        return proteina;
    }
    
}
