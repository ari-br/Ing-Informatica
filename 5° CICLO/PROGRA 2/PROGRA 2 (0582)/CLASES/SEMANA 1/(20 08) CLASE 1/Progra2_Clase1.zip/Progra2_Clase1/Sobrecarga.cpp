/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   Sobrecarga.cpp
 * Author: Ariana
 * 
 * Created on 20 de agosto de 2024, 11:29 AM
 */

#include <iomanip>
#include <iostream>
#include "Sobrecarga.h"
#include "Estructura.h"
using namespace std;

/* istream: lectura general
 * ifstream: lectura de un archivo
 * ostream: salida
 * ofstream: salida dentro de un archivo
 * 
 * void: datos individuales
 * ostream: devolver datos uno tras otro
*/

ostream & operator <<(ostream &out,strNotas &nota){ 
    for(int i=0;i<nota.n;i++)
        out<<setw(5)<<nota.lab[i];
    out<<endl;
    return out;
}

void operator *=(strNotas &nota,int inc){//Siempre se modifica el primer operando
    for(int i=0;i<nota.n;i++)
        nota.lab[i]+=inc;
}