/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 20 de agosto de 2024, 11:14 AM
 */

#include <iostream>
#include "Sobrecarga.h"
#include "Estructura.h"

using namespace std;

/* Plantillas por aprender:
 * *=, ++a, a++, a+b(-,/,*)
 */
int main(int argc, char** argv) {
    
    strNotas notas={{10,10,5,8,9},5};//{{lab},n}
    strNotas notas2={{20,20,15,20,20},5};
    
    cout<<notas<<notas2<<endl;
    notas*=2;
    cout<<notas;
    
    return 0;
}

