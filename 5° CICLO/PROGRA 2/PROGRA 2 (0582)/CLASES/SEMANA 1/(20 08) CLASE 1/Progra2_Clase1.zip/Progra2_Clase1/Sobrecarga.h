/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   Sobrecarga.h
 * Author: Ariana
 *
 * Created on 20 de agosto de 2024, 11:29 AM
 */

#ifndef SOBRECARGA_H
#define SOBRECARGA_H
#include "Estructura.h"
#include <iostream>
using namespace std;

ostream & operator <<(ostream &out,strNotas &nota);
void operator *=(strNotas &nota,int inc);

#endif /* SOBRECARGA_H */
