/* 
 * File:   Promociones.h
 * Author: cueva.r
 *
 * Created on 5 de noviembre de 2024, 11:42 AM
 */

#ifndef PROMOCIONES_H
#define PROMOCIONES_H

#include "Lista.h"

class Promociones {
public:
    Promociones();
    Promociones(const Promociones& orig);
    virtual ~Promociones();
    void leepedidos();
private:
    Lista Lpedidos;
};

#endif /* PROMOCIONES_H */

