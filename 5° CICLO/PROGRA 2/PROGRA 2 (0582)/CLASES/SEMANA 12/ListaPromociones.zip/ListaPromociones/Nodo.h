/* 
 * File:   Nodo.h
 * Author: cueva.r
 *
 * Created on 5 de noviembre de 2024, 11:35 AM
 */

#ifndef NODO_H
#define NODO_H

#include "Pedido.h"

class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Lista;
    void asigna(int);
    void leenodo(int, ifstream&);
    int compara(Nodo &);
private:
    Pedido *ped;
    Nodo *sig;
    Nodo *ant;
};

#endif /* NODO_H */

