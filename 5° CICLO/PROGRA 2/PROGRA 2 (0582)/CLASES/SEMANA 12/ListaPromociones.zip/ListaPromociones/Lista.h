/* 
 * File:   Lista.h
 * Author: cueva.r
 *
 * Created on 5 de noviembre de 2024, 11:39 AM
 */

#ifndef LISTA_H
#define LISTA_H
#include <fstream>

#include "Nodo.h"

using namespace std;


class Lista {
public:
    Lista();
    Lista(const Lista& orig);
    virtual ~Lista();
    void inserta(ifstream &);
private:    
    Nodo* lini;
    Nodo* lfin;
    
};

#endif /* LISTA_H */

