
/* 
 * File:   PedidoUsual.cpp
 * Author: cueva.r
 * 
 * Created on 5 de junio de 2024, 11:23 AM
 */

#include "PedidoUsual.h"

PedidoUsual::PedidoUsual() {
}

PedidoUsual::PedidoUsual(const PedidoUsual& orig) {
}

PedidoUsual::~PedidoUsual() {
}

void PedidoUsual::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double PedidoUsual::GetDescuento() const {
    return descuento;
}

void PedidoUsual::SetFlete(double flete) {
    this->flete = flete;
}

double PedidoUsual::GetFlete() const {
    return flete;
}

void PedidoUsual::lee(int codigo, ifstream&arch){
    char c;
    
    arch>>descuento>>c>>flete;
    arch.get();
    Pedido::lee(codigo,arch);
}


