/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.cpp
 * Author: cueva.r
 * 
 * Created on 5 de noviembre de 2024, 11:35 AM
 */

#include "Nodo.h"
#include "PedidoEspecial.h"
#include "PedidoUsual.h"
#include "PedidoEventual.h"

Nodo::Nodo() {
    ped=nullptr;
    sig=nullptr;
    ant=nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
}

void Nodo::asigna(int codigo){
    
    if(codigo<400000)
        ped=new PedidoEspecial;
    if(codigo>=400000 and codigo<600000)
        ped= new PedidoUsual;
    if(codigo>=600000)
        ped=new PedidoEventual;
}

void Nodo::leenodo(int codigo, ifstream&arch){
    ped->lee(codigo,arch);
}

int Nodo::compara(Nodo&nuevo){
    if(ped->GetDni()>nuevo.ped->GetDni())
        return 1;
    if(ped->GetDni()==nuevo.ped->GetDni() and
            ped->GetFecha()>nuevo.ped->GetFecha())
        return 1;
    return 0;
}