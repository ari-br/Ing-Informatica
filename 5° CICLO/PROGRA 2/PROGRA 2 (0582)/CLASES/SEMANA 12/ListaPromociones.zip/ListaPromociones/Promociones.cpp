/* 
 * File:   Promociones.cpp
 * Author: cueva.r
 * 
 * Created on 5 de noviembre de 2024, 11:42 AM
 */
#include <iostream>
#include <fstream>
#include "Promociones.h"

using namespace std;

Promociones::Promociones() {
}

Promociones::Promociones(const Promociones& orig) {
}

Promociones::~Promociones() {
}

void Promociones::leepedidos(){
    ifstream arch("pedidos5.csv",ios::in);
    if(!arch){
        cout << "No se pudo abrir las Pedidos";
        exit(1);
    }   
    while(1){
        Lpedidos.inserta(arch);
        if(arch.eof()) break;
    }    
    
    
}