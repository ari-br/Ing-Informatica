/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PedidoEventual.cpp
 * Author: cueva.r
 * 
 * Created on 5 de junio de 2024, 11:23 AM
 */

#include "PedidoEventual.h"

PedidoEventual::PedidoEventual() {
}

PedidoEventual::PedidoEventual(const PedidoEventual& orig) {
}

PedidoEventual::~PedidoEventual() {
}


void PedidoEventual::setFlete(double flete) {
    this->flete = flete;
}

double PedidoEventual::getFlete() const {
    return flete;
}

void PedidoEventual::lee(int codigo, ifstream&arch){
    arch>>flete;
    arch.get();
    Pedido::lee(codigo,arch);
}