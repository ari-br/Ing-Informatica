/* 
 * File:   PedidoUsual.h
 * Author: cueva.r
 *
 * Created on 5 de junio de 2024, 11:23 AM
 */

#ifndef PEDIDOUSUAL_H
#define PEDIDOUSUAL_H

#include "Pedido.h"
#include <fstream>

using namespace std;

class PedidoUsual: public Pedido{
public:
    PedidoUsual();
    PedidoUsual(const PedidoUsual& orig);
    virtual ~PedidoUsual();
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void SetFlete(double flete);
    double GetFlete() const;
    void lee(int,ifstream &);
private:
    double flete;
    double descuento;
};

#endif /* PEDIDOUSUAL_H */

