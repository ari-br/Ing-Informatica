/* 
 * File:   PedidoEventual.h
 * Author: cueva.r
 *
 * Created on 5 de junio de 2024, 11:23 AM
 */

#ifndef PEDIDOEVENTUAL_H
#define PEDIDOEVENTUAL_H
#include <fstream>
#include "Pedido.h"

using namespace std;
class PedidoEventual: public Pedido {
public:
    PedidoEventual();
    PedidoEventual(const PedidoEventual& orig);
    virtual ~PedidoEventual();
    void setFlete(double flete);
    double getFlete() const;
    void lee(int,ifstream &);
private:
    double flete;
};

#endif /* PEDIDOEVENTUAL_H */

