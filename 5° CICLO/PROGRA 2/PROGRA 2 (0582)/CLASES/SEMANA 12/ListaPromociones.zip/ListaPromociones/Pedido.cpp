/* 
 * File:   Pedido.cpp
 * Author: cueva.r
 * 
 * Created on 5 de noviembre de 2024, 11:29 AM
 */
#include <iostream>
#include <cstring>
#include <fstream>
#include "Pedido.h"

using namespace std;

Pedido::Pedido() {
    codigo=0;
    nombre=nullptr;
    cantidad=0;
    dni=0;
    total=0;
    
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
}

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

void Pedido::SetNombre(char*cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}
void Pedido::GetNombre(char* cad){
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

/*
 CHURROMAIS CON LIMON 38GR,9,4.5,32821689,19/10/2021
 */
void Pedido::lee(int cod, ifstream &arch){
    char cad[100],c;
    int dd,mm,aa;
    
    codigo=cod;
    arch.getline(cad,100,',');
    SetNombre(cad);
    arch>>cantidad>>c>>total>>c>>dni>>c>>dd>>c>>mm>>c>>aa;
    fecha=aa*10000+mm*100+dd;
    
}