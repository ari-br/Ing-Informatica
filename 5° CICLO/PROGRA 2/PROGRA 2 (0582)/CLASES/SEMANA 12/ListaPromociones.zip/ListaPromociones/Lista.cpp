
/* 
 * File:   Lista.cpp
 * Author: cueva.r
 * 
 * Created on 5 de noviembre de 2024, 11:39 AM
 */
#include <iostream>
#include <fstream>
#include "Lista.h"

using namespace std;

Lista::Lista() {
    lini=nullptr;
    lfin=nullptr;
}

Lista::Lista(const Lista& orig) {
}

Lista::~Lista() {
}
/*
118050,10,PAPAYA,8,8,79475585,16/12/2019
118050,10,PAPAYA,5,5,79475585,30/04/2020
*/
void Lista::inserta(ifstream&arch){
    int codigo;
    Nodo*nuevo,*ptr=lini,*ant=nullptr;
    
    nuevo = new Nodo;
    arch >> codigo;
    if(arch.eof()) return;
    arch.get();
    nuevo->asigna(codigo);
    nuevo->leenodo(codigo,arch);
    while(ptr){
        if(ptr->compara(*nuevo)) break;
        ant=ptr;
        ptr=ptr->sig;
    }
    nuevo->sig=ptr;
    if(ptr!=nullptr) ptr->ant=nuevo;
    if(ant==nullptr){
        if(ptr==nullptr)lfin=nuevo;
        lini=nuevo;
    }
    else{
        ant->sig = nuevo;
        nuevo->ant =ant;
        if(ant==lfin)lfin=nuevo;
    }
    
    
}