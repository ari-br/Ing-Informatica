
/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 5 de noviembre de 2024, 11:28 AM
 */

#include "Promociones.h"



using namespace std;

int main(int argc, char** argv) {
    Promociones pro;
    
    pro.leepedidos();

    return 0;
}

