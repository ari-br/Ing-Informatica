
/* 
 * File:   Procesa.cpp
 * Author: cueva.r
 * 
 * Created on 29 de octubre de 2024, 10:56 AM
 */
#include <fstream>
#include <iostream>

using namespace std;
#include "Procesa.h"

Procesa::Procesa() {
}

Procesa::Procesa(const Procesa& orig) {
}

Procesa::~Procesa() {
}

void Procesa::carga(){
    int i=0;
    ifstream arch("clientes3.csv",ios::in);
    if(!arch){
        cout <<"No se puede abrir el archivo de clientes";
        exit(1);
    }
    while(1){
        ldeudor[i].leedeudor(arch);
        if(arch.eof()) break;
        i++;
    }
    cargapedidos();
}

void Procesa::cargapedidos(){
    int i;
    ifstream arch("pedidos4.csv",ios::in);
    if(!arch){
        cout << "No se pudo abrir las Pedidos";
        exit(1);
    }   
    i=0;
    while(1){
        arch >> lpedidos[i];
        if(arch.eof()) break;
        i++;
    }      
  
}



void Procesa::muestra(){
    ofstream arch("reporte.txt",ios::out);
    if(!arch){
        cout <<"No se puede abrir el archivo de reporte";
        exit(1);
    }    
    for(int i=0;ldeudor[i].existe();i++)
        ldeudor[i].imprimedeudor(arch);
}

void Procesa::actualiza(){
    
    for(int i=0;ldeudor[i].existe();i++)
        for(int j=0;lpedidos[j].GetCodigo();j++)
            if(lpedidos[j].GetDni()==ldeudor[i].getcoddni())
                ldeudor[i].actualizadeudor(lpedidos[j].getTotal());
  
}