/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ClienteC.cpp
 * Author: cueva.r
 * 
 * Created on 29 de octubre de 2024, 10:47 AM
 */

#include "ClienteC.h"

ClienteC::ClienteC() {
    flete=0;
}

ClienteC::ClienteC(const ClienteC& orig) {
}

ClienteC::~ClienteC() {
}

void ClienteC::SetFlete(double flete) {
    this->flete = flete;
}

double ClienteC::GetFlete() const {
    return flete;
}

void ClienteC::lee(ifstream&arch,char cat){
    arch >>flete;
    arch.get();
    Cliente::lee(arch,cat);  
}

void ClienteC::imprime(ofstream&arch,double flet,double desc){
    Cliente::imprime(arch,flete,0);
}

void ClienteC::calcula(double monto){
    SetTotalped(GetTotalped()+monto*flete/100);
    SetCantped(GetCantped()+1);   
}