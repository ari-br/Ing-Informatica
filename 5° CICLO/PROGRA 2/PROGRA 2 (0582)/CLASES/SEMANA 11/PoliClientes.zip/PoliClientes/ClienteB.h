/* 
 * File:   ClienteB.h
 * Author: cueva.r
 *
 * Created on 29 de octubre de 2024, 10:44 AM
 */

#ifndef CLIENTEB_H
#define CLIENTEB_H

#include "Cliente.h"


class ClienteB: public Cliente {
public:
    ClienteB();
    ClienteB(const ClienteB& orig);
    virtual ~ClienteB();
    void SetFlete(double flete);
    double GetFlete() const;
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void lee(ifstream&,char);
    void imprime(ofstream &,double,double);
    void calcula(double);
private:
    double descuento;
    double flete;
};

#endif /* CLIENTEB_H */

