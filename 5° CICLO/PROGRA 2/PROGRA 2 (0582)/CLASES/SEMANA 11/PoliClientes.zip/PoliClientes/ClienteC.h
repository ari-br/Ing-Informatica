/* 
 * File:   ClienteC.h
 * Author: cueva.r
 *
 * Created on 29 de octubre de 2024, 10:47 AM
 */

#ifndef CLIENTEC_H
#define CLIENTEC_H

#include "Cliente.h"


class ClienteC:public Cliente{
public:
    ClienteC();
    ClienteC(const ClienteC& orig);
    virtual ~ClienteC();
    void SetFlete(double flete);
    double GetFlete() const;
    void lee(ifstream&,char);
    void imprime(ofstream &,double,double);
    void calcula(double);
    
private:
    double flete;
};

#endif /* CLIENTEC_H */

