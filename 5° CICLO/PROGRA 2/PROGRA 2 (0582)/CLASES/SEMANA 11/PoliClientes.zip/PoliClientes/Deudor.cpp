/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Deudor.cpp
 * Author: cueva.r
 * 
 * Created on 29 de octubre de 2024, 10:52 AM
 */

#include "Deudor.h"
#include "ClienteA.h"
#include "ClienteB.h"
#include "ClienteC.h"

Deudor::Deudor() {
    Cdeudor=nullptr;
}

Deudor::Deudor(const Deudor& orig) {
}

Deudor::~Deudor() {
}
/*
 A,25,29847168,ALDAVE ZEVALLOS ROSARIO
 */
void Deudor::leedeudor(ifstream&arch){
    char cat;
    
    arch>>cat;
    if(arch.eof())return;
    arch.get();
    
    if(cat=='A')  
        Cdeudor=new ClienteA;
    if(cat=='B')  
        Cdeudor=new ClienteB;    
    if(cat=='C')  
        Cdeudor=new ClienteC;   
    
    Cdeudor->lee(arch,cat);
}

bool Deudor::existe(){
    if(Cdeudor!=nullptr)
        return true;
    return false;
}

void Deudor::imprimedeudor(ofstream&arch){
    Cdeudor->imprime(arch,0,0);
}

int Deudor::getcoddni(){
    return Cdeudor->GetDni();
}

void Deudor::actualizadeudor(double monto){
    Cdeudor->calcula(monto);
    
}