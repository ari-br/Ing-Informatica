/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.h
 * Author: cueva.r
 *
 * Created on 5 de noviembre de 2024, 09:21 AM
 */

#include <fstream>


using namespace std;

#ifndef PEDIDO_H
#define PEDIDO_H

class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void iniPedido();
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void setTotal(double total);
    double getTotal() const;

private:
    int codigo;
    int cantidad;
    double total;
    int dni;
    int fecha;

};


ifstream &operator >> (ifstream &, Pedido &);
ofstream &operator << (ofstream &, Pedido &);

#endif /* PEDIDO_H */
