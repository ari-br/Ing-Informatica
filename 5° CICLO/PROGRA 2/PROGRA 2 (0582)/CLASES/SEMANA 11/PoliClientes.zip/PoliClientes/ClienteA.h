/* 
 * File:   ClienteA.h
 * Author: cueva.r
 *
 * Created on 29 de octubre de 2024, 10:42 AM
 */

#ifndef CLIENTEA_H
#define CLIENTEA_H

#include "Cliente.h"


class ClienteA: public Cliente {
public:
    ClienteA();
    ClienteA(const ClienteA& orig);
    virtual ~ClienteA();
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void lee(ifstream&,char);
    void imprime(ofstream &,double,double);
    void calcula(double);
private:
    double descuento;
};

#endif /* CLIENTEA_H */

