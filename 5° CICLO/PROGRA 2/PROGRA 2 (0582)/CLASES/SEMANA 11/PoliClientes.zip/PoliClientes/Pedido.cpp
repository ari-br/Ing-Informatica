/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.cpp
 * Author: cueva.r
 * 
 * Created on 5 de noviembre de 2024, 09:21 AM
 */
#include <iostream>
#include <cstring>
#include <iomanip>
#include "Pedido.h"

using namespace std;


Pedido::Pedido() {
    codigo=0;
    cantidad=0;
    dni=0;
    fecha=0;
    total=0;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
}

void Pedido::iniPedido() {
    codigo=0;
    cantidad=0;
    dni=0;
    fecha=0;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

void Pedido::setTotal(double total) {
    this->total = total;
}

double Pedido::getTotal() const {
    return total;
}

/*
118050,8,8,79475585,16/12/2019
118050,5,5,79475585,30/04/2020
118050,11,11,81114108,09/03/2020
*/
ifstream &operator >> (ifstream &arch, Pedido &f){
    char c;
    int  dni,codigo,cant,fecha,dd,mm,aa;
    double total;
    arch >> codigo;
    if(!arch.eof()){
        arch.get();
        f.SetCodigo(codigo);
        arch >> cant;
        arch.get();
        f.SetCantidad(cant);
        arch >> total;
        f.setTotal(total);
        arch.get();
        arch >> dni;
        f.SetDni(dni);
        arch.get();
        arch >> dd >>c>>mm>>c>>aa;
        arch.get();
        fecha=aa*10000+mm*100+dd;
        f.SetFecha(fecha);

    }
    return arch;
}

ofstream &operator << (ofstream &arch, Pedido &f){
    char cad[100],obs[50];
    
    arch <<setw(10)<<f.GetFecha();
    arch <<left<<setw(50)<< cad <<setw(10)<<f.GetCantidad();
    arch <<right<<setprecision(2)<<fixed<<setw(10)<<f.getTotal();
    arch <<setw(10)<<f.getTotal()<<setw(30)<<obs<<endl;
    
    
    return arch;
}