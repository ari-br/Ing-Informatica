/* 
 * File:   Cliente.cpp
 * Author: cueva.r
 * 
 * Created on 22 de octubre de 2024, 10:29 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "Cliente.h"

using namespace std;


Cliente::Cliente() {
    dni=0;
    nombre=nullptr; 
    cantped=0;
    totalped=0;
}

Cliente::Cliente(const Cliente& orig) {
}

Cliente::~Cliente() {
}

void Cliente::SetCategoria(char categoria) {
    this->categoria = categoria;
}

char Cliente::GetCategoria() const {
    return categoria;
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

void Cliente::SetNombre(char*cad){
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}
void Cliente::GetNombre(char* cad){
    if(nombre!=nullptr)
        strcpy(cad,nombre);
}

void Cliente::SetTotalped(double totalped) {
    this->totalped = totalped;
}

double Cliente::GetTotalped() const {
    return totalped;
}

void Cliente::SetCantped(int cantped) {
    this->cantped = cantped;
}

int Cliente::GetCantped() const {
    return cantped;
}
/*
 29847168,ALDAVE ZEVALLOS ROSARIO
 */
void Cliente::lee(ifstream&arch,char cat){
    char cad[100];
    arch >> dni;
    arch.get();
    arch.getline(cad,100);
    SetNombre(cad);   
    categoria=cat;
}

void Cliente::imprime(ofstream&arch,double flet,double desc){
    char cad[100];
    
    arch <<setw(10)<< dni;
    GetNombre(cad);
    arch <<setw(50)<< cad<<endl;
    if(desc>0)
        arch << "Descuento: "<<desc<<endl;
    if(flet>0)
        arch << "Flete: "<<flet<<endl;
    arch << "Total:"<<totalped<<endl;
    arch << "Cantidad de Pedidos:"<<cantped<<endl<<endl;
    
    
}


/*
 71984468,IPARRAGUIRRE VILLEGAS NICOLAS EDILBERTO,A
29847168,ALDAVE ZEVALLOS ROSARIO,A
 */

ifstream &operator>>(ifstream &arch,Cliente &f){
    char cad[100],c;
    int coddni;
    
    arch >> coddni;
    if(!arch.eof()){
        arch.get();
        f.SetDni(coddni);
        arch.getline(cad,100,',');
        f.SetNombre(cad);
        arch >> c;
        f.SetCategoria(c);
    }
    return arch;
}