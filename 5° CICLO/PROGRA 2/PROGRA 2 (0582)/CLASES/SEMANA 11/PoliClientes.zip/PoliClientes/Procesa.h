/* 
 * File:   Procesa.h
 * Author: cueva.r
 *
 * Created on 29 de octubre de 2024, 10:56 AM
 */

#ifndef PROCESA_H
#define PROCESA_H

#include "Deudor.h"
#include "Pedido.h"


class Procesa {
public:
    Procesa();
    Procesa(const Procesa& orig);
    virtual ~Procesa();
    void carga();
    void muestra();
    void actualiza();
private:
    void cargapedidos();
    Deudor ldeudor[100];
    Pedido lpedidos[200];
};

#endif /* PROCESA_H */

