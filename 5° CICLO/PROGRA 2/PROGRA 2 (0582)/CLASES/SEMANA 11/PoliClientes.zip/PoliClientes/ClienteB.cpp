/* 
 * File:   ClienteB.cpp
 * Author: cueva.r
 * 
 * Created on 29 de octubre de 2024, 10:44 AM
 */

#include "ClienteB.h"

ClienteB::ClienteB() {
    descuento=0;
    flete=0;
}

ClienteB::ClienteB(const ClienteB& orig) {
}

ClienteB::~ClienteB() {
}

void ClienteB::SetFlete(double flete) {
    this->flete = flete;
}

double ClienteB::GetFlete() const {
    return flete;
}

void ClienteB::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double ClienteB::GetDescuento() const {
    return descuento;
}
/*
 B,10,5,83236386,RIVERO CORRALES JUAN FERNANDO
 */
void ClienteB::lee(ifstream &arch,char cat){
    char c;
    arch>>descuento>>c>>flete>>c;
    Cliente::lee(arch,cat);            
}

void ClienteB::imprime(ofstream&arch,double flet,double desc){
    Cliente::imprime(arch,flete,descuento);    
}

void ClienteB::calcula(double monto){
    SetTotalped(GetTotalped()+monto*(1-(descuento/100))+ monto*flete/100);
    SetCantped(GetCantped()+1);
}


