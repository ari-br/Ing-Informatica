/* 
 * File:   Deudor.h
 * Author: cueva.r
 *
 * Created on 29 de octubre de 2024, 10:52 AM
 */

#ifndef DEUDOR_H
#define DEUDOR_H
#include <fstream>
#include "Cliente.h"

using namespace std;

class Deudor {
public:
    Deudor();
    Deudor(const Deudor& orig);
    virtual ~Deudor();
    void leedeudor(ifstream&);
    bool existe();
    void imprimedeudor(ofstream&);
    int getcoddni();
    void actualizadeudor(double);
private:
    Cliente *Cdeudor;
};

#endif /* DEUDOR_H */

