/* 
 * File:   Cliente.h
 * Author: cueva.r
 *
 * Created on 22 de octubre de 2024, 10:29 AM
 */

#ifndef CLIENTE_H
#define CLIENTE_H
#include <fstream>

using namespace std;

class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    void SetCategoria(char categoria);
    char GetCategoria() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetNombre(char*);
    void GetNombre(char*);
    void SetTotalped(double totalped);
    double GetTotalped() const;
    void SetCantped(int cantped);
    int GetCantped() const;
    virtual void lee(ifstream&,char);
    virtual void imprime(ofstream &,double,double);
    virtual void calcula(double)=0;
private:
    int dni;
    char categoria;
    char *nombre;
    int cantped;
    double totalped;
    
};
ifstream &operator>>(ifstream&,Cliente &);
#endif /* CLIENTE_H */

