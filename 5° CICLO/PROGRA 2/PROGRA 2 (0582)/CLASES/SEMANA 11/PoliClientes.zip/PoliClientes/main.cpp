/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 29 de octubre de 2024, 10:37 AM
 */

#include "Procesa.h"

using namespace std;

int main(int argc, char** argv) {
    Procesa pro;
    
    pro.carga();
    pro.actualiza();
    pro.muestra();

    return 0;
}

