/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ClienteA.cpp
 * Author: cueva.r
 * 
 * Created on 29 de octubre de 2024, 10:42 AM
 */

#include "ClienteA.h"

ClienteA::ClienteA() {
    descuento=0;
}

ClienteA::ClienteA(const ClienteA& orig) {
}

ClienteA::~ClienteA() {
}

void ClienteA::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double ClienteA::GetDescuento() const {
    return descuento;
}
/*
A,25,71984468,IPARRAGUIRRE VILLEGAS NICOLAS EDILBERTO
A,25,29847168,ALDAVE ZEVALLOS ROSARIO
*/

void ClienteA::lee(ifstream&arch,char cat){
    arch >> descuento;
    arch.get();
    Cliente::lee(arch,cat);
}

void ClienteA::imprime(ofstream&arch,double flet,double desc){
    Cliente::imprime(arch,0,descuento);
}

void ClienteA::calcula(double monto){
    
    SetTotalped(GetTotalped()+monto*(1-(descuento/100)));
    SetCantped(GetCantped()+1);
}
