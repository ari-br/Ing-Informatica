
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "SobreCargas.h"
#include "Estructuras.h"

using namespace std;


/*
 
20211,1260   GORDILLO/CASTRO/RONAL          G2
20211,1397   ZEVALLOS/PRADO/RICARDO   S   50   G2
20211,2598   MORI/ZAVALETA/LUZ-LOURDES   S   20   G1
 
 
 */


bool operator >>(ifstream &arch, struct StAlumno &alu){
    
    char c;
    
    arch>> alu.semestre;
    if(arch.eof()) return false;
    arch>>c;
    arch>>alu.codigo;
    arch>>alu.nombre;
    arch>>c;
    
    alu.porcentaje=0;
    
    
    if(c=='G'){
        strcpy(alu.modalidad,"PRESENCIAL");
    }
    if(c=='S'){
        strcpy(alu.modalidad,"SEMIPRESENCIAL");
        arch>>alu.porcentaje;
        arch>>c; //Eliminar la G 
    }
    if(c=='V'){
        strcpy(alu.modalidad,"VIRTUAL");
        arch>>c; //Eliminar la G 
    }
    
    arch>>alu.escala;
    alu.numeroDeCursos=0;
    alu.costoTotal=0;
    
    return true;
}

void operator<<(ofstream &arch, struct StAlumno alumno){
    
    arch << alumno.semestre << alumno.codigo << setw(30)<< alumno.nombre << endl;
    
    arch<< "Cursos matriculados:"<<endl;
    
    for(int i=0;i<alumno.numeroDeCursos;i++){
        
        arch<< setw(4)<<alumno.cursos[i]<<endl;
        
    }
    
}

void operator +=(struct StAlumno *arralu, struct StAlumno alu){
    
    int i=0;
    for(i=0;arralu[i].semestre!=0;i++);
    arralu[i]=alu;
    arralu[i+1].semestre=0; // No compila por esta parte, volé XDXDDX 
    
}