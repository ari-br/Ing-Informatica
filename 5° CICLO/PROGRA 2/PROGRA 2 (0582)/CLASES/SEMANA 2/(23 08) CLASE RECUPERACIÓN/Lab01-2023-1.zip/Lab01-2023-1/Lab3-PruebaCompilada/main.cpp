#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "SobreCargas.h"
#include "Estructuras.h"
#include "AperturaDeArchivos.h"

using namespace std;


int main(int argc, char** argv) {
    
    struct StAlumno stalu1,arralu1[10];  
    //Prueba de la sobrecarga realizada//
    struct StAlumno alumno;
    ifstream archalu;
    AperturaDeUnArchivoDeTextosParaLeer(archalu,"Alumnos.txt");
    
    //Esto no lo hizo el profe, solo probÃ© XD//
    if(not archalu.is_open()){
        cout<<"El archivo con el nombre de "<<"Alumnos"<<" no se pudo abrir";
        exit(1);
    }
    archalu>>alumno;
    cout<<alumno.nombre<<endl;
    //Impresion : //  
    ofstream repo;
    AperturaDeUnArchivoDeTextosParaEscribir(repo,"Pruebas.txt");
    repo<<alumno;
    arralu1[0].semestre=0;
    arralu1+=stalu1;
    return 0;
}

