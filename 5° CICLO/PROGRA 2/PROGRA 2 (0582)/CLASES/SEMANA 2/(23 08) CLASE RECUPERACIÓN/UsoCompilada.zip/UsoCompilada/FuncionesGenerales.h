/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FuncionesGenerales.h
 * Author: cueva.r
 *
 * Created on 23 de agosto de 2024, 01:28 PM
 */

#ifndef FUNCIONESGENERALES_H
#define FUNCIONESGENERALES_H
    void leealumnos(struct StAlumno *arralu,const char *nom );
    void leealumnosbien(struct StAlumno *arralu,const char *nom );

#endif /* FUNCIONESGENERALES_H */
