

#ifndef SOBRECARGAS_H
#define SOBRECARGAS_H

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "SobreCargas.h"
#include "Estructuras.h"

using namespace std;

bool operator >>(ifstream &arch, struct StAlumno &alu);
void operator<<(ofstream &arch, struct StAlumno alumno);
void operator +=(struct StAlumno *arralu, struct StAlumno alu);

#endif /* SOBRECARGAS_H */

