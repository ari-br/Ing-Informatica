
/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 23 de agosto de 2024, 01:24 PM
 */

#include <iostream>
#include "FuncionesGenerales.h"
#include "Estructuras.h"

using namespace std;

int main(int argc, char** argv) {
    struct StAlumno arralu[100];
    
    leealumnosbien(arralu,"Alumnos.txt");
    
    

    return 0;
}

