/* 
 * File:   FuncionesGenerales.cpp
 * Author: cueva.r
 * 
 * Created on 23 de agosto de 2024, 01:28 PM
 */
#include <fstream>
#include <iostream>
#include "Estructuras.h"
#include "FuncionesGenerales.h"
#include "AperturaDeArchivos.h"
#include "SobreCargas.h"

using namespace std;

void leealumnos(struct StAlumno *arralu,const char *nom ){
    int cont=0;
    bool flag;
    ifstream arch;
    AperturaDeUnArchivoDeTextosParaLeer(arch,nom);
    
    while(1){
        flag=arch>>arralu[cont];
        if(!flag)break;
        cont++;        
    }    
    arralu[cont].semestre = 0;
}

void leealumnosbien(struct StAlumno *arralu,const char *nom ){
    int cont=0;
    bool flag;
    ifstream arch;
    StAlumno aux;
    arralu[0].semestre = 0;
    AperturaDeUnArchivoDeTextosParaLeer(arch,nom);
    while(1){
        flag=arch>>aux;
        if(!flag)break;
        arralu+=aux;
        cont++;        
    }    
    
}