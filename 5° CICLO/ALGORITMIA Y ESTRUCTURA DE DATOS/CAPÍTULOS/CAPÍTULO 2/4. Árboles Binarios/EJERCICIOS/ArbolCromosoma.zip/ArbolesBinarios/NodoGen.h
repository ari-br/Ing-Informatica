/* 
 * File:   NodoGen.h
 * Author: cueva.r
 *
 * Created on 4 de noviembre de 2024, 12:17 PM
 */

#ifndef NODOGEN_H
#define NODOGEN_H

struct NodoGen{
   int cromo; //0 o 1 
   int cantidad; 
};

#endif /* NODOGEN_H */

