/* 
 * File:   main.cpp
 * Author: Ana Roncal
 *
 * Created on 16 de noviembre de 2024, 18:23
 */

#include <iostream>
using namespace std;
#include "ArbolBinario.h"
#include "funcionesArbolesBinarios.h"

/*
 * 
 */
int main(int argc, char** argv) {

    // Declaración de nodos
    ArbolBinario arbol, arbol1, arbol2, arbol3, arbol4, arbol5, arbol6, arbol7,
            arbol8, arbol9, arbol10, arbol11, arbol12, arbol13, arbol14, arbol15,
            arbol16, arbol17, arbol18, arbol19, arbol20;

    // Construcción de las palabras
//    plantarArbolBinario(arbol19, nullptr, 'S', nullptr); // Nodo 'N' de BIEN
//    plantarArbolBinario(arbol20, arbol19, 'E', nullptr); // Nodo 'N' de BIEN

    plantarArbolBinario(arbol1, nullptr, 'N', nullptr); // Nodo 'N' de BIEN
    plantarArbolBinario(arbol2, arbol1, 'E', nullptr); // Nodo 'E' de BIEN

    plantarArbolBinario(arbol3, nullptr, 'O', nullptr); // Nodo 'O' de BILBAO
    plantarArbolBinario(arbol4, arbol3, 'A', nullptr); // Nodo 'A' de BILBAO
    plantarArbolBinario(arbol5, arbol4, 'B', nullptr); // Nodo 'B' de BILBAO
    plantarArbolBinario(arbol6, arbol5, 'L', nullptr); // Nodo 'L' de BILBAO

    plantarArbolBinario(arbol7, nullptr, 'S', nullptr); // Nodo 'S' de BUENAS
    plantarArbolBinario(arbol8, arbol7, 'A', nullptr); // Nodo 'A' de BUENAS

    plantarArbolBinario(arbol9, nullptr, 'O', nullptr); // Nodo 'O' de BUENO

    plantarArbolBinario(arbol10, nullptr, 'A', nullptr); // Nodo 'A' de BURRA

    plantarArbolBinario(arbol11, nullptr, 'S', nullptr); // Nodo 'S' de BURROS
    plantarArbolBinario(arbol12, nullptr, 'O', arbol11); // Nodo 'O' de BURROS

    plantarArbolBinario(arbol13, arbol2, 'I', arbol6); // Nodo 'I' de BILBAO
    plantarArbolBinario(arbol14, arbol8, 'N', arbol9); // Nodo 'N' de BUEN
    plantarArbolBinario(arbol15, arbol10, 'R', arbol12); // Nodo 'R' de BURR

    plantarArbolBinario(arbol16, arbol14, 'E', nullptr); // Nodo 'E' de BUE
    plantarArbolBinario(arbol17, nullptr, 'R', arbol15); // Nodo 'R' de BUR
    plantarArbolBinario(arbol18, arbol16, 'U', arbol17); // Nodo 'U' de BU
    
    plantarArbolBinario(arbol, arbol13, 'B', arbol18); // Nodo raíz 'B'

    recorrerPreOrden(arbol);
    // Recorrido en preorden
    //recorrerPreOrden(arbol);
    
    cout << "La altura del árbol es: " << altura(arbol) << endl;
    cout << "El árbol está equilibrado: " << esEquilibrado(arbol);

    return 0;
}

