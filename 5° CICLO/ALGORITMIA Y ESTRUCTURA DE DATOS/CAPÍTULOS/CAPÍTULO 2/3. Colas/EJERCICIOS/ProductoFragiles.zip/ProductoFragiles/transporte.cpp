#include <cstdlib>
#include <iostream>
#include "Pila.h"
#include "funcionesPila.h"

using namespace std;

void mover(struct Pila &origen,struct Pila &destino){
    int discoOr = desapilar(origen);
    if(not esPilaVacia(destino)){
        int discoDe = desapilar(destino);
        if(discoOr > discoDe){
            apilar(destino,discoOr);
            apilar(destino,discoDe);
        }
        else {
            apilar(destino,discoDe);
            apilar(destino,discoOr);
        }
    }
    else
        apilar(destino,discoOr);
}

void hanoi2(struct Pila &origen,struct Pila &destino,struct Pila &auxiliar,int n){
    if (n==0)  return ;
    hanoi2(origen,auxiliar,destino,n-1);
    if(not esPilaVacia(origen))
        mover(origen, destino);
    hanoi2(auxiliar,destino,origen,n-1);
}

void hanoi1(struct Pila &origen,struct Pila &destino,struct Pila &auxiliar,int n){
    if (n==0)  return ;
    hanoi1(origen,auxiliar,destino,n-1);
    if(not esPilaVacia(origen))
        apilar(destino,desapilar(origen));   
    hanoi1(auxiliar,destino,origen,n-1);
}

int main(int argc, char** argv) {
    int n=5;
    struct Pila principal, aux1, aux2;
    construir(principal);
    construir(aux1);
    construir(aux2);
    //Apilar paquetes en el 
    for (int i=n; i>0; i--){
        apilar(principal,i*2);
    }
    cout << "Pila Principal: ";
    imprimir(principal);
    cout << "Pila Auxiliar 1: ";
    imprimir(aux1);
    cout << "Pila Auxiliar 2: ";
    imprimir(aux2);
    //Paso1: Pasar del principal al aux1
    hanoi1(principal,aux1,aux2,n);    
    //Paso2: Agregar nuevo paquete al aux1
    int nuevo_paquete = 7;
    apilar(principal, nuevo_paquete);
    cout << "Agregar nuevo paquete: "<<nuevo_paquete<<endl;
    //Paso3: regresar el aux1 al principal
    hanoi2(aux1,principal,aux2,n);        
    cout << "Pila Principal: ";
    imprimir(principal);
    cout << "Pila Auxiliar 1: ";
    imprimir(aux1);
    cout << "Pila Auxiliar 2: ";
    imprimir(aux2);
    return 0;
}

