/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 21 de agosto de 2023, 11:57 AM
 */

#include <iostream>
#include "Cola.h"
#include "Pila.h"
#include "Lista.h"

using namespace std;
#include "funcionesCola.h"
#include "funcionesPila.h"
#include "funcionesLista.h"

void DistribuirCola(struct Cola & cola, int longitud){
    struct Pila  pila_aux;
    
    construir(pila_aux);
    int i, valor;
    
    //Eliminamos el lote tipo C, es decir 3#
    for (i=0; i<2*(longitud/3);i++)
        encolar(cola,desencolar (cola));
    for (i=0; i<longitud/3;i++)
        valor=desencolar(cola);
    
    //Pasamos el Lote A de la Cola a la Pila
    for (i=0; i<longitud/3;i++)
        apilar(pila_aux,desencolar(cola));
    
    //Pasamos el Lote A de la Pila a la Cola
    for (i=0; i<longitud/3;i++)
        encolar(cola,desapilar(pila_aux));
    
    //Pasamos el Lote B de la Cola a la Pila
    for (i=0; i<longitud/3;i++)
        apilar(pila_aux,desencolar(cola));
    
    //Pasamos 1 de la Pila a la Cola y luego 1 de la Cola a la Cola
    for (i=0; i<longitud/3;i++){
        encolar(cola,desapilar(pila_aux));
        encolar(cola,desencolar(cola));
    }
    //Pasamos toda la Cola a la Pila
    for (i=0; i<2*(longitud/3);i++)
        apilar(pila_aux,desencolar(cola));
   
    //Pasamos toda la Pila a la Cola
    for (i=0; i<2*(longitud/3);i++)
        encolar(cola,desapilar(pila_aux));
}


int main(int argc, char** argv) {
    struct Cola cola;
    construir(cola);
 
    //Para los lotes utilizamos las equivalencias: A=1, B=2, C=3
    //Para los códigos, se mantienen en números enteros
    
    encolar(cola, 11);
    encolar(cola, 12);
    encolar(cola, 13);
    encolar(cola, 14);
    
    encolar(cola, 21);
    encolar(cola, 22);
    encolar(cola, 23);
    encolar(cola, 24);
    
    encolar(cola, 31);
    encolar(cola, 32);
    encolar(cola, 33);
    encolar(cola, 34);
    
    cout<<"Cola Inicial: ";
    imprime(cola);
    
    DistribuirCola(cola,12);
    cout<<"Cola Distribuida: ";
    imprime(cola);

    
    
    destruirCola(cola);

    return 0;
}

