/* 
 * File:   main.cpp
 * Author: Ana Roncal
 *
 * Created on 1 de setiembre de 2024, 22:58
 */

#include <iostream>
#include <cstdlib>
#include "Cola.h"
#include "funcionesCola.h"
using namespace std;

void mostrarCliente(Cliente cl){
    cout << "(id="<< cl.id << " , tiempo=" << cl.tiempoServicio<< ")";
}

int main(int argc, char** argv) {
    struct Cola cola;   
    construir(cola);
    int n = 10;
    /*Encolamos elementos en la Cola*/
    for(int i=0;i<n;i++) {
        struct Cliente cl;
        cl.id = i + 1;
        cl.tiempoServicio = rand() % 30;
        encolar(cola, cl);
        cout<<"Cliente en espera:";mostrarCliente(cl); cout<<endl;        
    }
    //Atencion de clientes (cajero)
    int tiempoTotal = 0;//tiempo total transcurrido
    int esperaTotal = 0;//tiempo total de espera de todos los clientes 
    while(not esColaVacia(cola)){
        Cliente actual = desencolar(cola);
        cout<<"Atendiendo al cliente ";mostrarCliente(actual); cout<<endl;  
        cout<<"El cliente "<<actual.id<<" espero "<<tiempoTotal<<" minutos \n";
        //Actualizar el tiempo total y la espera
        esperaTotal += tiempoTotal;
        tiempoTotal += actual.tiempoServicio;
    }       
    //Mostrar tiempos finales
    cout<<"Tiempo total de espera de todos los clientes:"<<esperaTotal<<" minutos \n";
    cout<<"Tiempo total transcurrido para atender a todos los clientes:"<<tiempoTotal<<" minutos \n";
    return 0;
}

