/* 
 * File:   Cola.h
 * Author: ANA RONCAL
 *
 * Created on 1 de setiembre de 2024, 23:03
 */

#ifndef COLA_H
#define COLA_H

#include "Lista.h"
struct Cola {
    struct Lista lista;
};

#endif /* COLA_H */