/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 21 de agosto de 2023, 11:57 AM
 */

#include <iostream>
#include "Cola.h"
#include "Pila.h"
#include "Lista.h"
#define N 7
using namespace std;
#include "funcionesCola.h"
#include "funcionesPila.h"
#include "funcionesLista.h"

int red[N][N]={
    {0, 0, 0, 0, 0, 0, 0},
    {10, 0, 20, 30, 0, 20, 40},
    {0, 0, 0, 0, 0, 100, 0},
    {0, 0, 0, 0, 0, 80, 0},
    {50, 10, 5, 10, 0, 100, 4},
    {100, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0}
};

int BuscaSkyNerd(int n){
    int servidorA, servidorB, servidorC;
    struct Pila servidores;
    
    construir (servidores);
    
    //apilamos los servidores: 1, 2, 3....
    for (int i=0; i<n; i++)
        apilar(servidores,i);
    
    while (longitud(servidores)>1){
        servidorA=desapilar(servidores);
        servidorB=desapilar(servidores);
        
        if (red[servidorA][servidorB])
            //Si servidorA envía a servidorB, entonces servidorA es posible SKYNERD
            //descartamos al servidorB, no volviendolo a apilar
            //apilamos a servidorA
            apilar(servidores,servidorA);
        else
            //Si servidorA NO envía a servidorB, entonces servidorA no es SKYNERD
            //descartamos al servidorA, no volviendolo a apilar
            //apilamos a servidorB, porque podría ser SKYNERD ya que no recibe de servidorA
            apilar(servidores,servidorB);
    }
    servidorC = desapilar(servidores); //es el posible SKYNERD
    
    //Analizo si ese posible SKYNERD, is
    
    for (int i=0; i<n; i++){
        //servidorC<>i    red[servidorC][i]    !red[i][servidorC]
        //ni bien detectemos que no cumple con alguna de las condiciones, terminamos
        if ((servidorC!=i) && (!red[servidorC][i] || red[i][servidorC]))
            return -1;
    }
    return servidorC;
}

int main(int argc, char** argv) {

    int n=7;//cantidad de servidores
    int id_servidor=BuscaSkyNerd(n);
    
    if (id_servidor==-1)
        cout<<"SkyNerd no está en la red."<<endl;
    else
        cout<<"SkyNerd ha sido detectado en el servidor "<<id_servidor+1<<endl;
    

    return 0;
}

