/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 21 de agosto de 2023, 11:57 AM
 */

#include <iostream>
#include "Cola.h"
#include "Pila.h"

using namespace std;
#include "funcionesCola.h"
#include "funcionesPila.h"
void pasapila(struct Pila &pila, struct Pila &pila2){
    int valor, n, aux;
    while (!esPilaVacia(pila)){ // Mientras la pila original no esté vacía
        valor = desapilar(pila); // Desapilar el primer elemento
        n=0; // Contador para controlar los elementos movidos
        while (!esPilaVacia(pila)){ // Desapilar todos los elementos restantes
            apilar(pila2,valor); // Apilar el elemento desapilado en la pila destino
            n++; // Incrementar el contador
            valor = desapilar(pila); // Desapilar el siguiente elemento
        }
        while (!esPilaVacia(pila2) && n>0){ // Desapilar los elementos de la pila destino y volverlos a apilar en la original
            aux = desapilar(pila2);
            apilar(pila,aux);
            n--;
        }
        apilar(pila2,valor); // Apilar el último elemento en la pila destino
    }
}

void ordenapilarecursivo(struct Pila & pila, int n){
    int max_original, valor_original;
    int max, valor, aux;
    int i=n;
    
    cout<<"llamada, n="<<n<<endl;
    //CASO BASE: cuando ya no tenemos elemento en la pila
    if (n==0) {
        return;
    }
    
    struct Pila pila_aux;
    construir(pila_aux);
    
    max_original=desapilar(pila);//este es el valor completo del nodo
    max=max_original%100;//para obtener registro de los incidentes (los dos últimos dígitos)
    i--;
    while (i>0){
        valor_original=desapilar(pila);
        valor=valor_original%100;//para obtener registro de los incidentes (los dos últimos dígitos)
        if (max<valor){
            apilar(pila_aux,max_original);
            max_original=valor_original;
        }else
            apilar(pila_aux,valor_original);
        i--;
    }//hasta este punto tenemos el máximo de la pila, entonces lo apilamos.
    apilar(pila, max_original);
    while(!esPilaVacia(pila_aux)){
        aux=desapilar(pila_aux);
        apilar(pila, aux);
    }
    cout<<"Pila: n="<<n<<endl;
    imprimir(pila);
    
    ordenapilarecursivo(pila, n-1);
    cout<<"Vuelva llamada recursiva n="<<n<<endl;
}
void reinicia_cola(struct Cola & cola, int n, struct Pila & pila1, struct Pila & pila2){
    Pila pila_aux1, pila_aux2;
    pila_aux1=pila1;
    pila_aux2=pila2;
    
    int i;
    int valor;//variable auxiliar para encolar/desconlar
    
    //Paso 1: Se pasan los nodos de Pila2 a Pila1.
    cout<<"Pasapila: "<<endl;
    pasapila(pila_aux2,pila_aux1);
    cout<<"Pila 1: "<<endl;
    imprimir(pila_aux1);
    cout<<"Pila 2: "<<endl;
    imprimir(pila_aux2);
    int longitud_pila1=longitud(pila_aux1);
    //Paso 2: Se ordena Pila1.
    cout<<"OrdenaPila: "<<endl;
    ordenapilarecursivo(pila_aux1,longitud_pila1);
    
    
    //Paso 3:
    //En azul: Se desencola y encola longitud Cola – longitud Pila1 espacios
    for (i=0; i<n-longitud_pila1; i++){
        valor=desencolar(cola);
        encolar(cola, valor);
    }//Aquí los azules quedan adelante y los anaranjados quedan atrás
    
    //seguidamente se desencola longitud Pila1 espacios y se apilan en Pila1.
    for (i=0; i<longitud_pila1;i++){
        valor=desencolar(cola);
        apilar(pila_aux2,valor);
    }
    //En verde: Se encola longitud Pila1 espacios desde Pila1
    while (!esPilaVacia(pila_aux1)){
        valor=desapilar(pila_aux1);
        encolar(cola,valor);
    }//en la cola queda lo anaranjado primero y luego lo verde
    //en la pila2 están quedando todos los azules
    
    //En anaranjado: Se desencola y encola longitud Cola – longitud Pila1 espacios.
    for (i=0; i<n-longitud_pila1; i++){
        valor=desencolar(cola);
        encolar(cola, valor);
    }
    pila1=pila_aux1;
    pila2=pila_aux2;
}

void ordenarec(struct Cola & cola, int n){//Recibimos la cola y la longitud de la cola
    int mayor, aux, i=1;
    //CASO BASE:
    if (esColaVacia(cola))
        return;
    //CASO RECURSIVO
    mayor=desencolar(cola);//desencolamos el primer elemento de la cola
    while (i<n){
        aux=desencolar(cola);//desencolamos los demás elementos para encontrar un posible mayor
        if (aux>mayor){//si elemento que hemos desencolado es mayor, tenemos un nuevo mayor
            encolar(cola, mayor);//el mayor (anterior) lo encolamos
            mayor=aux;//"guardamos" el nuevo mayor que hemos encontrado
        }
        else
            encolar(cola, aux);
        i++;
    }
    ordenarec(cola, n-1);//Aquí regresará en algún momento del CASO BASE
    encolar(cola, mayor);//encolamos el mayor de la instancia
}
void reclasifica_pilas(Pila& pilaA, Pila& pilaB) {
    Cola cola;
    Pila auxA, auxB;
    auxA = pilaA;
    auxB = pilaB;//Todos los elementos están en PilaB
    int valor;
    construir(cola);//Creamos una cola auxiliar
    
    while (!esPilaVacia(auxB)) {//Recorremos toda la PilaB
    	//Se desapila de B
        valor = desapilar(auxB);
        if (valor / 100 == 1)//si es código 1, encolamos
            encolar(cola, valor);
        else
            apilar(auxA, valor);//sino, osea es código 2, apilamos en A
    }

    while (!esColaVacia(cola)) {//Recorremos toda la Cola
        valor = desencolar(cola);//Desencolamos los código 1
        apilar(auxB, valor);//Las apilamos en B

    }
    pilaA = auxA;
    pilaB = auxB;
}

int main(int argc, char** argv) {
    struct Cola cola;
    int n=8;//longitud de la cola con espacios definidos (según enunciado)
    struct Pila pila1, pila2;
    
    construir(pila1);
    construir(pila2);
    construir(cola);
    
    apilar(pila1,101);
    apilar(pila1,102);
    apilar(pila2,203);
    apilar(pila2,204);
    apilar(pila1,105);
    
    encolar(cola, 206);
    encolar(cola, 107);
    encolar(cola, 208);
    encolar(cola, 109);
    encolar(cola, 210);
    encolar(cola, 211);
    encolar(cola, 112);
    encolar(cola, 113);
    
    cout<<"INICIAL: "<<endl;
    cout<<"Cola: "<<endl;
    imprime(cola);
    cout<<"Pila 1: "<<endl;
    imprimir(pila1);
    cout<<"Pila 2: "<<endl;
    imprimir(pila2);
    
    reinicia_cola(cola, n, pila1, pila2);
    
    cout<<"REINICIA COLA: "<<endl;
    cout<<"Cola: "<<endl;
    imprime(cola);
    cout<<"Pila 1: "<<endl;
    imprimir(pila1);
    cout<<"Pila 2: "<<endl;
    imprimir(pila2);
    
    
    reclasifica_pilas(pila1, pila2);//se puede usar una cola auxiliar
    
    cout<<"RECLASIFICA PILA: "<<endl;
    cout<<"Cola: "<<endl;
    imprime(cola);
    cout<<"Pila 1: "<<endl;
    imprimir(pila1);
    cout<<"Pila 2: "<<endl;
    imprimir(pila2);
    
    destruirCola(cola);
    

    return 0;
}

