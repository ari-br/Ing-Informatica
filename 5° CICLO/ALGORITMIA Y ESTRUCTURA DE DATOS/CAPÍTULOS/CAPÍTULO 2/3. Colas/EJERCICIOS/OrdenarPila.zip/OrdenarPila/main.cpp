
#include <cstdlib>
#include <iostream>
#include "Pila.h"
#include "funcionesPila.h"

using namespace std;

void ordenarPila(struct Pila& pilaOrigen, struct Pila &pilaDestino){
    while (!esPilaVacia(pilaOrigen)){
        int temp = desapilar(pilaOrigen);
        int n=0;
        // Mover los elementos de la pila destino de vuelta a la pila origen si son mayores que 'temp'
        while (!esPilaVacia(pilaDestino) && cima(pilaDestino) < temp ){
            apilar(pilaOrigen, desapilar(pilaDestino));
            n++; 
        }
        // Colocar el elemento actual en su posicion correcta en la pila destino
        apilar(pilaDestino, temp);
        
        // Volver a pasar los elementos de la pila origen de nuevo a la pila destino
        for (int i=1; i<=n; i++){
            apilar(pilaDestino,desapilar(pilaOrigen));
        }        
    }
}

int main(int argc, char** argv) {
    struct Pila pilaOrigen, pilaDestino;
    construir(pilaOrigen);
    construir(pilaDestino);
    apilar(pilaOrigen,7);
    apilar(pilaOrigen,8);
    apilar(pilaOrigen,2);
    apilar(pilaOrigen,1);
    apilar(pilaOrigen,3);
    cout << "Pila Origen: ";
    imprimir(pilaOrigen);
    cout << "Pila Destino: ";
    imprimir(pilaDestino);
    ordenarPila(pilaOrigen, pilaDestino);
    cout << "Pila Origen: ";
    imprimir(pilaOrigen);
    cout << "Pila Destino: ";
    imprimir(pilaDestino);    
    return 0;
}

