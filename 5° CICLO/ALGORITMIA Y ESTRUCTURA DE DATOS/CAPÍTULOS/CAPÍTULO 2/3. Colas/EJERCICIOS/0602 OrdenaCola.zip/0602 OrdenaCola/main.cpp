/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 21 de agosto de 2023, 11:57 AM
 */

#include <iostream>
#include "Cola.h"

using namespace std;
#include "funcionesCola.h"

void ordenarec(struct Cola & cola, int n){//Recibimos la cola y la longitud de la cola
    int mayor, aux, i=1;
    //CASO BASE:
    if (esColaVacia(cola))
        return;
    //CASO RECURSIVO
    mayor=desencolar(cola);//desencolamos el primer elemento de la cola
    while (i<n){
        aux=desencolar(cola);//desencolamos los demás elementos para encontrar un posible mayor
        if (aux>mayor){//si elemento que hemos desencolado es mayor, tenemos un nuevo mayor
            encolar(cola, mayor);//el mayor (anterior) lo encolamos
            mayor=aux;//"guardamos" el nuevo mayor que hemos encontrado
        }
        else
            encolar(cola, aux);
        i++;
    }
    ordenarec(cola, n-1);//Aquí regresará en algún momento del CASO BASE
    encolar(cola, mayor);//encolamos el mayor de la instancia
}

int main(int argc, char** argv) {
    struct Cola cola;
    construir(cola);
    cout<<"La cola está vacía: "<<esColaVacia(cola)<<endl;
    encolar(cola, 8);
    encolar(cola, 21);
    encolar(cola, 10);
    encolar(cola, 15);
    encolar(cola, 7);
    imprime(cola);
    ordenarec(cola,cola.lista.longitud);
    imprime(cola);
    destruirCola(cola);

    return 0;
}

