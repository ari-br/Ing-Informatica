/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 23 de setiembre de 2024, 10:42
 */

#include <cstdlib>
#include "Cola.h"
#include "funcionesCola.h"

using namespace std;

/*
 * 
 */

void ordenaCola(Cola &cola,int n){
    int i=1, mayor, aux;
    if (esColaVacia(cola)){
        return ;
    }
    mayor = desencolar(cola);
    while (i<n){
        aux = desencolar(cola);
        if (aux>mayor){
            encolar(cola,mayor);
            mayor = aux;
        }
        else{
            encolar(cola,aux);
        }
        i++;
    }
    ordenaCola(cola,longitud(cola));
    encolar(cola,mayor);
}

int main(int argc, char** argv) {
    Cola cola;
    construir(cola);
    encolar(cola,3);
    encolar(cola,2);
    encolar(cola,9);
    encolar(cola,8);
    imprime(cola);
    ordenaCola(cola,longitud(cola));
    imprime(cola);
    return 0;
}

