#include <iostream>
#include "Cola.h"
#include "funcionesCola.h"
using namespace std;


struct Cola crearClave(){
    struct Cola clave;   
    construir(clave);
    encolar(clave, 3);
    encolar(clave, 1);
    encolar(clave, 7);
    encolar(clave, 4);  
    return clave;
}


void cifrar(char* cadena){
  struct Cola clave = crearClave();
  for(int i=0;cadena[i]!='\0';i++){
      int despl = desencolar(clave);//extrae el primer elemento
      encolar(clave, despl);
      cadena[i] = char(cadena[i] + despl);      
  }
  destruirCola(clave);
}

void descifrar(char* cadena){
  struct Cola clave = crearClave();
  for(int i=0;cadena[i]!='\0';i++){
      int despl = desencolar(clave);//extrae el primer elemento
      encolar(clave, despl);
      cadena[i] = char(cadena[i] - despl);
  } 
  destruirCola(clave);
}

int main(int argc, char** argv) {
    char texto[50];
    cout<<"Ingrese texto a codificar:";
    cin.getline(texto, 50);
    cifrar(texto);
    cout<<"Mensaje codificado:"<<texto<<endl;
    descifrar(texto);    
    cout<<"Mensaje original:"<<texto<<endl;
    return 0;
}

