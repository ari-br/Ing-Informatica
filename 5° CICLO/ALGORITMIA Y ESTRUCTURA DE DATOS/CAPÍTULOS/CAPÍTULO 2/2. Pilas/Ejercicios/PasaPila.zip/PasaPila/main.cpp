/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 16 de setiembre de 2024, 10:49
 */

#include <cstdlib>
#include <iostream>
#include "Pila.h"
#include "funcionesPila.h"

using namespace std;

/*
 * 
 */

/*Se le coloca & porque el inicio de las pilas origen y destino van a cambiar*/
void pasaPila(struct Pila& pilaOrigen,struct Pila &pilaDestino){
    while (!esPilaVacia(pilaOrigen)){
        int valor = desapilar(pilaOrigen);
        int n=0;
        while (!esPilaVacia(pilaOrigen)){
            apilar(pilaDestino,valor);
            valor = desapilar(pilaOrigen);
            n++; /*Este valor de n me permite saber cuantos elementos pase de la pila Origen al destino*/
        }
        /*Ahor pasamos de la Pila Destino a la pila Origen*/
        for (int i=1; i<=n; i++){
            apilar(pilaOrigen,desapilar(pilaDestino));
        }
        apilar(pilaDestino,valor);        
    }
}

int main(int argc, char** argv) {
    struct Pila pilaOrigen, pilaDestino;
    construir(pilaOrigen);
    construir(pilaDestino);
    apilar(pilaOrigen,7);
    apilar(pilaOrigen,8);
    apilar(pilaOrigen,2);
    apilar(pilaOrigen,1);
    apilar(pilaOrigen,3);
    cout << "Pila Origen: ";
    imprimir(pilaOrigen);
    cout << "Pila Destino: ";
    imprimir(pilaDestino);
    pasaPila(pilaOrigen,pilaDestino);
    cout << "Pila Origen: ";
    imprimir(pilaOrigen);
    cout << "Pila Destino: ";
    imprimir(pilaDestino);    
    return 0;
}

