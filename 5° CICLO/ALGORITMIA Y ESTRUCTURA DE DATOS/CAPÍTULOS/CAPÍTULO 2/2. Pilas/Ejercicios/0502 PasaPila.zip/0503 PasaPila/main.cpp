/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 21 de agosto de 2023, 11:57 AM
 */

#include <iostream>
#include "Pila.h"

using namespace std;
#include "funcionesPila.h"

/*
 * IMPLEMENTACIÓN DE UNA PILA
 * ALGORITMIA Y ESTRUCTURA DE DATOS 2024-1
 */

// Funci�n `pasaPila`:
// Esta funci�n pasa los elementos de una pila a otra de manera iterativa,
// intercalando los elementos de la pila original en la pila destino.
// La l�gica es la siguiente:
//   1. Se desapila un elemento de la pila original.
//   2. Se desapilan todos los elementos restantes de la pila original y se apilan en la pila destino.
//   3. Se desapilan los elementos de la pila destino y se vuelven a apilar en la pila original,
//      excepto el �ltimo elemento que se queda en la pila destino.
//   4. Se repiten los pasos 1-3 hasta que la pila original est� vac�a.

void pasaPila(struct Pila &pila, struct Pila &pila2){
    int valor, n, aux;
    while (!esPilaVacia(pila)){ // Mientras la pila original no est� vac�a
        valor = desapilar(pila); // Desapilar el primer elemento
        n=0; // Contador para controlar los elementos movidos
        while (!esPilaVacia(pila)){ // Desapilar todos los elementos restantes
            apilar(pila2,valor); // Apilar el elemento desapilado en la pila destino
            n++; // Incrementar el contador
            valor = desapilar(pila); // Desapilar el siguiente elemento
        }
        while (n>0){ // Desapilar los elementos de la pila destino y volverlos a apilar en la original
            aux = desapilar(pila2);
            apilar(pila,aux);
            n--;
        }
        apilar(pila2,valor); // Apilar el �ltimo elemento en la pila destino
    }
}

// Funci�n `pasaPilaRecursivo`:
// Esta funci�n pasa los elementos de una pila a otra de manera recursiva,
// intercalando los elementos de la pila original en la pila destino.
// La l�gica es la siguiente:
//   1. Si la pila original est� vac�a, se termina la recursi�n.
//   2. Se desapila un elemento de la pila original.
//   3. Se llama recursivamente a la funci�n para procesar el resto de los elementos.
//   4. Se apila el elemento desapilado en la pila destino.

void pasaPilaRecursivo(struct Pila &pila,struct Pila &pila2){
    if (esPilaVacia(pila)){
        return ;
    }
    int valor = desapilar(pila);
    pasaPilaRecursivo(pila,pila2);
    apilar(pila2,valor);
}



int main(int argc, char** argv) {

    struct Pila pila;
    struct Pila pila2;
    construir(pila);
    construir(pila2);
    
    /*Apilamos elementos en la pila*/
    apilar(pila, 1);
    apilar(pila, 3);
    apilar(pila, 2);
    apilar(pila, 4);
    cout << "Pila" << endl;
    imprimir(pila);
    cout << "Pila2" << endl;
    imprimir(pila2);
    pasaPila(pila,pila2);
    cout << "Pasa pila iterativo " << endl;
    cout << "Pila" << endl;
    imprimir(pila);
    cout << "Pila2" << endl;
    imprimir(pila2);
    pasaPilaRecursivo(pila2,pila);
    cout << "Pasa pila recursivo " << endl;
    cout << "Pila" << endl;
    imprimir(pila);
    cout << "Pila2" << endl;
    imprimir(pila2);
    return 0;
}

