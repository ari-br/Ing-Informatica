/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 16 de setiembre de 2024, 12:21
 */

#include <cstdlib>
#include <iostream>
#include "Pila.h"
#include "funcionesPila.h"

using namespace std;

/*
 * 
 */

void hanoi(struct Pila &origen,struct Pila &destino,struct Pila &auxiliar,int n){
    if (n==1){
        apilar(destino,desapilar(origen));
        return ;
    }
    hanoi(origen,auxiliar,destino,n-1);
    apilar(destino,desapilar(origen));
    hanoi(auxiliar,destino,origen,n-1);
}

int main(int argc, char** argv) {
    int n=5;
    struct Pila origen, destino, auxiliar;
    construir(origen);
    construir(destino);
    construir(auxiliar);
    for (int i=n; i>0; i--){
        apilar(origen,i);
    }
    cout << "Pila Origen: ";
    imprimir(origen);
    cout << "Pila Destino: ";
    imprimir(destino);
    cout << "Pila Auxiliar: ";
    imprimir(auxiliar);
    hanoi(origen,destino,auxiliar,n);
    cout << "Pila Origen: ";
    imprimir(origen);
    cout << "Pila Destino: ";
    imprimir(destino);
    cout << "Pila Auxiliar: ";
    imprimir(auxiliar);
    return 0;
}

