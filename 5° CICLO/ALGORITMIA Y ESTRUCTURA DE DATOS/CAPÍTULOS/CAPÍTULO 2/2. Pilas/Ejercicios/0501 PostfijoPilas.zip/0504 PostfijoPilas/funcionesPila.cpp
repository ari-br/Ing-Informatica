/* 
 * File:   funcionesPilas.cpp
 * Author: ANA RONCAL
 * Created on 3 de septiembre de 2023, 01:29 AM
 */

#include <iostream>
#include <iomanip>
#include <cstring>//para el strcmp(), comparar 2 cadenas
#include "Nodo.h"
#include "Lista.h"
#include "Pila.h"
using namespace std;
#include "funcionesLista.h"
#include "funcionesPila.h"
#define MAX 10

/*constructor de Pila*/
void construir(struct Pila & pila){
    construir(pila.lista);
}

/*Determina si la pila está vacía*/
bool esPilaVacia(struct Pila pila){
    return esListaVacia(pila.lista);
}

/*Determina el número de elementos de la pila*/
int longitud(struct Pila pila){
    return longitud(pila.lista);
}

/*push, añade un elemento a la parte superior de la pila*/
void apilar(struct Pila & pila, int elemento){
    insertarAlInicio(pila.lista, elemento);
}

/*pop, elimina un elemento de la parte superior de la pila*/
int desapilar(struct Pila & pila){
    if (esPilaVacia(pila)){
        cout<<"La pila está vacía, por lo tanto no se puede desapilar"<<endl;
	exit(11);
    }	
    int elemento = cima(pila);
    eliminaCabeza(pila.lista);
    return elemento;
}

/*examina un elemento situado en la parte superior de la pila*/
int cima(const struct Pila & pila){
    if (esPilaVacia(pila)){
	cout<<"La pila está vacía por lo tanto no posee cima"<<endl;
	exit(12);
    }		
    return retornaCabeza(pila.lista);
}

/*destruye la pila*/
void destruirPila(struct Pila & pila){
    destruir(pila.lista);
}

void imprime(struct Pila pila){
    imprime(pila.lista);
}

/////////////////////////////////////////////
//            FUNCIONES NUEVAS             //
/////////////////////////////////////////////

int esOperador(char * c){//para usar strcmp() a�adimos #include <cstring>
    return (strcmp(c,"+") == 0) or (strcmp(c,"-") == 0) or 
           (strcmp(c,"*") == 0) or (strcmp(c,"/") == 0);
}

int opera(char * c, int operando1, int operando2){
    int resultado = 0;
   
    if (strcmp(c, "+") == 0) //Si es SUMA
        resultado = operando1 + operando2;
    else if (strcmp(c, "-") == 0) //Si es RESTA
        resultado = operando1 - operando2;
    else if (strcmp(c, "*") == 0) //Si es MULTIPLICACION
        resultado = operando1 * operando2;
    else if(strcmp(c, "/") == 0) //Si es DIVISION
        resultado = operando1 / operando2;
    
    return resultado;
}

void notacionPostfija(struct Pila & pila){
    
// Este algoritmo eval�a expresiones aritm�ticas en notaci�n postfija utilizando una pila.
// La notaci�n postfija coloca los operadores despu�s de sus operandos, lo que elimina la necesidad de par�ntesis.
// La l�gica es la siguiente:
//   1. Se lee la expresi�n postfija caracter por caracter.
//   2. Si el caracter es un operando, se apila en la pila.
//   3. Si el caracter es un operador, se desapilan los dos �ltimos operandos de la pila,
//      se realiza la operaci�n correspondiente y el resultado se vuelve a apilar.
//   4. Al final de la expresi�n, el �nico valor que queda en la pila es el resultado final.
    
     // Esta funci�n eval�a una expresi�n en notaci�n postfija utilizando una pila.

    int operando2; // Almacenar� el segundo operando
    int operando1; // Almacenar� el primer operando
    int resultado; // Almacenar� el resultado de la operaci�n

    char elemento[MAX]; // Almacena temporalmente cada elemento de la expresi�n

    cout << "Ingrese expresi�n en postfijo: " << endl;

    while (!cin.eof()) { // Lee la expresi�n hasta encontrar el fin de archivo
        cin >> elemento; // Lee el siguiente elemento de la expresi�n

        if (cin.eof()) break; // Si se lleg� al final, se sale del bucle

        // Si el elemento es un operador:
        if (esOperador(elemento)) {
            // Desapilar los dos operandos (el orden es importante en postfija)
            operando2 = desapilar(pila);
            operando1 = desapilar(pila);

            // Realizar la operaci�n y obtener el resultado
            resultado = opera(elemento, operando1, operando2);

            // Apilar el resultado en la pila
            apilar(pila, resultado);
        } else {
            // Si el elemento es un operando (n�mero), convertirlo a entero y apilarlo
            apilar(pila, atoi(elemento)); // atoi convierte una cadena a entero
        }

        imprime(pila); // Imprimir el estado de la pila en cada iteraci�n (para depuraci�n)
    }
}
