/* 
 * File:   Pila.h
 * Author: ANA RONCAL
 *
 * Created on 1 de setiembre de 2024, 22:27
 */

#ifndef PILA_H
#define PILA_H

#include "Lista.h"
struct Pila{
    struct Lista lista;
};

#endif /* PILA_H */