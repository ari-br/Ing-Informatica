/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 4 de noviembre de 2024, 12:26
 */

#include <cstdlib>
#include <iostream>
#include <cstring>
#include <iomanip>
#include "ArbolBinario.h"
#include "funcionesArbolesBinarios.h"
#define N 10
using namespace std;

/*
 * 
 */

struct NodoArbol * crearNuevoNodoArbol_New(struct NodoArbol * arbolIzquierdo, 
                               int elemento, int valor, struct NodoArbol * arbolDerecho){
    struct NodoArbol * nuevoNodo = new struct NodoArbol;
    nuevoNodo->elemento = elemento;
    nuevoNodo->valor = valor;
    nuevoNodo->izquierda = arbolIzquierdo;
    nuevoNodo->derecha = arbolDerecho;
    return nuevoNodo;
}

void plantarArbolBinario_New(struct NodoArbol *&raiz, struct NodoArbol * arbolIzquierdo,
                         int elemento, int valor, struct NodoArbol * arbolDerecho){
    struct NodoArbol * nuevoNodo = crearNuevoNodoArbol_New(arbolIzquierdo, elemento, valor, arbolDerecho);
    raiz = nuevoNodo;
}

void plantarArbolBinario_New(struct ArbolBinario & arbol, struct NodoArbol * arbolIzquierdo,
                         int elemento, int valor, struct NodoArbol * arbolDerecho){
    struct NodoArbol * nuevoNodo = crearNuevoNodoArbol_New(arbolIzquierdo, elemento, valor, arbolDerecho);
    arbol.raiz = nuevoNodo;
}

void insertaValorArbol(struct NodoArbol * &raiz,int elemento,int valor){
    if (esNodoVacio(raiz)){
        plantarArbolBinario_New(raiz,nullptr,elemento,valor,nullptr);
        return;
    }
    insertaValorArbol(raiz->izquierda,0,valor);
    insertaValorArbol(raiz->derecha,1,valor);
}

void agregarElementoArbol(struct ArbolBinario &arbol,int valor){
    insertaValorArbol(arbol.raiz,0,valor);
}

void imprimeNodoNew(struct NodoArbol * nodo){
    cout<<setw(5)<<nodo->elemento<<"-"<<nodo->valor << " ";
}

void imprimeCromosomaRecursivo(struct NodoArbol *raiz){
    if (not esNodoVacio(raiz)){
        if (not esNodoVacio(raiz->izquierda)){
            imprimeNodoNew(raiz->izquierda);
        }
        if (not esNodoVacio(raiz->derecha)){
            imprimeNodoNew(raiz->derecha);
        }
        imprimeCromosomaRecursivo(raiz->izquierda);
        imprimeCromosomaRecursivo(raiz->derecha);
    }
}

void imprimeCromosoma(struct ArbolBinario &arbol){
    if (not esArbolVacio(arbol)){
        imprimeNodoNew(arbol.raiz); /*La raiz se imprime siempre antes de la recursion*/
        imprimeCromosomaRecursivo(arbol.raiz); /*Voy a imprimir los demás niveles de forma recursiva*/
    }
}

int calcularCombinacionesRecursivo(struct NodoArbol *raiz,int pesoParcial,int peso){
    pesoParcial = pesoParcial + raiz->valor * raiz->elemento;
    if (raiz->izquierda==nullptr && raiz->derecha==nullptr){
        /*Aqui llegue a una hoja*/
        if (pesoParcial == peso){
            return 1;
        }
        return 0;
    }
    return calcularCombinacionesRecursivo(raiz->izquierda,pesoParcial,peso) + calcularCombinacionesRecursivo(raiz->derecha,pesoParcial,peso);
}

int calcularCombinaciones(struct ArbolBinario arbol,int peso){
    int pesoParcial = 0;
    return calcularCombinacionesRecursivo(arbol.raiz,pesoParcial,peso);
}

int main(int argc, char** argv) {
    int arreglo[N] = {10,50,20,30,40};
    int n = 5;
    /*Parte a*/
    ArbolBinario arbol;
    construir(arbol);
    plantarArbolBinario_New(arbol,nullptr,0,0,nullptr);
    for (int i=0; i<n; i++){
        agregarElementoArbol(arbol,arreglo[i]);
    }
    //imprimeCromosoma(arbol);
    /*Parte b*/
    int peso = 40;
    cout << endl << "Cantidad Combinaciones: " << calcularCombinaciones(arbol,peso);
    return 0;
}

