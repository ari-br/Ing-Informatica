/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 18 de septiembre de 2023, 05:39 PM
 */

#include <iostream>
#include "ArbolBinario.h"
using namespace std;
#include "funcionesArbolesBinarios.h"
/*
 * ESTRUCTURA ÁRBOL BINARIO 2024-1
 */

struct NodoArbol * crearNuevoNodoArbolNuevo(struct NodoArbol * arbolIzquierdo, 
                               int elemento,int valor,struct NodoArbol * arbolDerecho){
    struct NodoArbol * nuevoNodo = new struct NodoArbol;
    nuevoNodo->elemento = elemento;
    nuevoNodo->valor = valor;
    nuevoNodo->izquierda = arbolIzquierdo;
    nuevoNodo->derecha = arbolDerecho;
    return nuevoNodo;
}

void plantarArbolBinarioNuevo(struct ArbolBinario & arbol, struct NodoArbol * arbolIzquierdo,
                         int elemento, int valor, struct NodoArbol * arbolDerecho){
    
    struct NodoArbol * nuevoNodo = crearNuevoNodoArbolNuevo(arbolIzquierdo, elemento, valor, arbolDerecho);
    arbol.raiz = nuevoNodo;
}

void plantarArbolBinarioNuevo(struct NodoArbol *& nodo, struct NodoArbol * arbolIzquierdo,
                         int elemento, int valor, struct NodoArbol * arbolDerecho){
    
    struct NodoArbol * nuevoNodo = crearNuevoNodoArbolNuevo(arbolIzquierdo, elemento, valor, arbolDerecho);
    nodo = nuevoNodo;
}

void insertaValorArbolRecursivo(struct NodoArbol *& nodo, int elemento, int valor){
    if (esNodoVacio(nodo)){
        plantarArbolBinarioNuevo(nodo, nullptr, elemento, valor, nullptr);
        return;
    }
    insertaValorArbolRecursivo(nodo->izquierda, 0, valor);  
    insertaValorArbolRecursivo(nodo->derecha, 1, valor);  
}

void insertaValorArbol(struct ArbolBinario & arbol, int valor){
    insertaValorArbolRecursivo(arbol.raiz, 0, valor);  
}
int determinarCantidadCombinacionesRecursivo(struct NodoArbol * nodo , int peso, int pesoParcial){
    pesoParcial+= nodo->valor * nodo->elemento; //si está "activo" (=1) entrará en la acumulación, sino, no lo considera.
    if ( esNodoVacio(nodo->izquierda) && esNodoVacio(nodo->derecha) ){//es hoja, ese decir ya llegó a armar toda la combinación (con todos los paquetes)
        if (pesoParcial==peso)//hemos logrado llenar la mochila con esa combinación
            return 1;
        return 0;//esta combinación no logró llenar la mochila con "peso" o la sobrepasó
    }
    //Sino, seguimos armando la solución de esa combinación
    return determinarCantidadCombinacionesRecursivo(nodo->izquierda, peso, pesoParcial) + determinarCantidadCombinacionesRecursivo(nodo->derecha, peso, pesoParcial); 
    
    
     
    
}
int determinarCantidadCombinaciones(struct ArbolBinario cromosoma, int peso){
    int pesoParcial = 0;
    return determinarCantidadCombinacionesRecursivo(cromosoma.raiz, peso, pesoParcial);
    //pesoParcial ayudará a identificar el caso base que es cuando hemos alcanzado la limitante
}

int main(int argc, char** argv) {
    int cantidad_paquetes=5;
    int arreglo[cantidad_paquetes]={10,50,20,30,40};//arreglo con los paquetes
    
    

    struct ArbolBinario cromosoma;
    construir(cromosoma);
    plantarArbolBinarioNuevo(cromosoma, nullptr, 0, 0, nullptr);//la raiz del arbol cromosoma (0,0)
    //vamos a insertar los paquetes.
    for (int i=0; i<cantidad_paquetes; i++){
        insertaValorArbol(cromosoma, arreglo[i]);//insertarmos cada paquete.
    }
    cout<<"Arbol Cromosoma:"<<endl;
    recorrerEnOrden(cromosoma);
    
    //Realizamos la asignación
    int peso=70;
    cout<<"Combinaciones :" <<determinarCantidadCombinaciones(cromosoma, peso)<<endl;
    
    
    destruirArbolBinario(cromosoma);
    cout<<"Es árbol vacío: "<<esArbolVacio(cromosoma)<<endl;
    
    return 0;
}

