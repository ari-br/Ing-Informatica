// -*- C++ -*-

/* 
 * File:   Grafo.h
 * Author: ANA RONCAL
 *
 * Created on 20 de junio de 2024, 12:52
 */

#ifndef GRAFO_H
#define GRAFO_H

#include "Vertice.h"
struct Grafo{
    struct Vertice listaVertice;
    int longitud;
};

#endif /* GRAFO_H */