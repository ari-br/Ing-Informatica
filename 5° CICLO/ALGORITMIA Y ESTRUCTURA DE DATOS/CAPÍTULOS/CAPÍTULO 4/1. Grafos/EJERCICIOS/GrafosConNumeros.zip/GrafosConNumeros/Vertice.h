// -*- C++ -*-

/* 
 * File:   Vertice.h
 * Author: ANA RONCAL
 *
 * Created on 20 de junio de 2024, 12:52
 */

#ifndef VERTICE_H
#define VERTICE_H

#include "NodoVertice.h"
struct Vertice{
    struct NodoVertice  * cabeza;
    int longitud;
};

#endif /* VERTICE_H */