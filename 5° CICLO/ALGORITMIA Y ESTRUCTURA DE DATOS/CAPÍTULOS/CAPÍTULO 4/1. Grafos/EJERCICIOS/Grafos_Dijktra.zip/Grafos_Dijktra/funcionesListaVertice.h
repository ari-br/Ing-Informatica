/* 
 * File:   funcionesListaVertice.h
 * Author: ANA RONCAL
 * Created on 27 de septiembre de 2023, 09:38 AM
 */

#ifndef FUNCIONESLISTAVERTICE_H
#define FUNCIONESLISTAVERTICE_H

void construirListaVertice(struct ListaVertice & listaVertice);
bool esListaVerticeVacio(struct ListaVertice listaVercice);
bool seEncuentraVerticeLista(struct ListaVertice listaVercice,  int elemento);
struct NodoListaVertice * crearNodoV( int elemento, struct NodoListaVertice * siguiente);
struct NodoListaVertice * obtenerUltimoNodoV( struct ListaVertice listaVertice);
void insertarVerticeAlFinal(struct ListaVertice & listaVertice, const int element);
bool seEncuentraAristaLista(struct ListaVertice listaVertice, const int verticeOrigen,  int verticeDestino);
struct NodoListaVertice * obtenerNodoVertice(struct ListaVertice listaVertice,  int clave);
void insertarListaAristas(struct ListaVertice &, int verticeOrigen, struct Ciudad ciudad);


void eliminarVerticeEnLista(struct ListaVertice & listaVertice,  int vertice);
void eliminarDeListaDeAristas(struct ListaVertice & listaVertice,  int verticeOrigen,  int verticeDestino);
void destruirListaVertice(struct ListaVertice & listaVertice);
#endif /* FUNCIONESLISTAVERTICE_H */

