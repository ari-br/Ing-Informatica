/* 
 * File:   funcionesListaArista.h
 * Author: ANA RONCAL
 * Created on 27 de septiembre de 2023, 11:01 AM
 */

#ifndef FUNCIONESLISTAARISTA_H
#define FUNCIONESLISTAARISTA_H

void construirListaAristas(struct ListaArista & listaArista);
bool seEncuentraAristaEnListaArista(struct ListaArista listaArista,  int llave);
struct NodoListaArista * obtenerUltimoNodoA( struct ListaArista  listaArista);
struct NodoListaArista * crearNodoA(struct Ciudad ciudad, struct NodoListaArista * siguiente);
void insertarAristaAlFinal(struct ListaArista & listaArista, struct Ciudad);

void eliminarAristaEnLista(struct ListaArista & listaArista,  int vertice);
void destruirListaArista(struct ListaArista & listaArista);

#endif /* FUNCIONESLISTAARISTA_H */

