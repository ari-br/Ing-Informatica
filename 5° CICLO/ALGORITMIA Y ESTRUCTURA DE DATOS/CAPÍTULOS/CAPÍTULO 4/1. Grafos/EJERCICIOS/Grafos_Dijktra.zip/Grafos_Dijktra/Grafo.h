/* 
 * File:   Grafo.h
 * Author: ANA RONCAL
 * Created on 27 de septiembre de 2023, 09:17 AM
 */

#ifndef GRAFO_H
#define GRAFO_H

struct Grafo{
    struct ListaVertice listaVertice;
    int longitud;
};

#endif /* GRAFO_H */

