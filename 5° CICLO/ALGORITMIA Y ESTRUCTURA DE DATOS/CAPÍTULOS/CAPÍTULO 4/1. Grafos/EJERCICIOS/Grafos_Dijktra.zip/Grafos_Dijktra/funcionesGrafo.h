/* 
 * File:   funcionesGrafo.h
 * Author: ANA RONCAL
 * Created on 27 de septiembre de 2023, 09:19 AM
 */

#ifndef FUNCIONESGRAFO_H
#define FUNCIONESGRAFO_H
void construirGrafo(struct Grafo & grafo);
void agregarVertice(struct Grafo & grafo,  int );
bool esGrafoVacio(struct Grafo grafo);

void agregarArista(struct Grafo & grafo,  int  vertice1,  int  vertice2, int costo);
void eliminarVertice(struct Grafo & grafo,  int vertice);
int longitudGrafo(struct Grafo grafo);

void mostrarVerticeYAristas(struct Grafo grafo);
int seEncuentraVerticeOrigen(struct Grafo grafo, int  vertice);
bool seEncuentraVertice(struct Grafo grafo, int  elemento);
void eliminarArista(struct Grafo & grafo, int verticeOrigen,  int verticeDestino);
void destruirGrafo(struct Grafo & grafo);

/*implementación añadida*/
void algoritmoDijkstra(struct Grafo & grafo, int );
void almacenaMinimos(int ciudad, int * , int * D, struct Grafo & grafo, int & minimo, int & indice);
void actualizarDistancia(int i, int * NNV, int * D, struct Grafo & grafo, int & minimo, int ciudad, int);
int pertenece(int ciudad, int * arreglo, int);
#endif /* FUNCIONESGRAFO_H */

