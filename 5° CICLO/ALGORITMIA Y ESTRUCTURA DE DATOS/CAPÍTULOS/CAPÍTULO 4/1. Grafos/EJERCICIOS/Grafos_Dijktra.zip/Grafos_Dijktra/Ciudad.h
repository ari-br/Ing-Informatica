/*
 * File:   Ciudad.h
 * Author: ANA RONCAL
 * Created on 3 de octubre de 2023, 04:54 PM
 */

#ifndef CIUDAD_H
#define CIUDAD_H

struct Ciudad{
    int nombre;
    int costo;
};
#endif /* CIUDAD_H */

