/* 
 * File:   ListaVertica.h
 * Author: ANA RONCAL
 * Created on 27 de septiembre de 2023, 09:20 AM
 */

#ifndef LISTAVERTICA_H
#define LISTAVERTICA_H

struct ListaVertice{
    struct NodoListaVertice  * cabeza;
    int longitud;
};

#endif /* LISTAVERTICA_H */

