/* 
 * File:   funcionesGrafo.cpp
 * Author: ANA RONCAL
 * Created on 27 de septiembre de 2023, 09:36 AM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "Ciudad.h"

#include "NodoListaArista.h"
#include "ListaArista.h"
#include "NodoListaVertice.h"
#include "ListaVertice.h"
#include "Grafo.h"

using namespace std;
#include "funcionesListaArista.h"
#include "funcionesListaVertice.h"
#include "funcionesGrafo.h"
#include "Ciudad.h"

void construirGrafo(struct Grafo & grafo) {
    construirListaVertice(grafo.listaVertice);
    grafo.longitud = 0;

}

bool esGrafoVacio(struct Grafo grafo) {
    return esListaVerticeVacio(grafo.listaVertice);
}

bool seEncuentraVertice(struct Grafo grafo, int elemento) {
    return seEncuentraVerticeLista(grafo.listaVertice, elemento);
}

/*Agregar añade un vértice, este puede ser de cualquier tipo de dato*/

/*es decir elemento está representando un tipo VERTICE*/
void agregarVertice(struct Grafo & grafo, int elemento) {
    if (not seEncuentraVertice(grafo, elemento)) {
        insertarVerticeAlFinal(grafo.listaVertice, elemento);
        grafo.longitud++;
    }
}

bool seEncuentraArista(struct Grafo grafo, int verticeOrigen, int verticeDestino) {
    return seEncuentraAristaLista(grafo.listaVertice, verticeOrigen, verticeDestino);
}

void agregarArista(struct Grafo & grafo, int verticeOrigen, int verticeDestino, int costo) {
    bool seEncuentraVerticeOrigen = seEncuentraVertice(grafo, verticeOrigen);
    bool seEncuentraVerticeDestino = seEncuentraVertice(grafo, verticeDestino);
    if ((not seEncuentraVerticeOrigen) or (not seEncuentraVerticeDestino)) {
        cout << "No se ha encontrado algún vértice";
        return;
    }
    if (not seEncuentraArista(grafo, verticeOrigen, verticeDestino)) {
        struct Ciudad ciudad;
        ciudad.nombre = verticeDestino;
        ciudad.costo = costo;
        insertarListaAristas(grafo.listaVertice, verticeOrigen, ciudad);
    }
}

int longitudGrafo(struct Grafo grafo) {
    return grafo.longitud;
}

void eliminarVertice(struct Grafo & grafo, int vertice) {
    if (seEncuentraVertice(grafo, vertice)) {
        eliminarVerticeEnLista(grafo.listaVertice, vertice);
        grafo.longitud--;
    }
}

void eliminarArista(struct Grafo & grafo, int verticeOrigen, int verticeDestino) {
    int seEncuentraVertOrigen = seEncuentraVertice(grafo, verticeOrigen);
    if (seEncuentraVertOrigen)
        eliminarDeListaDeAristas(grafo.listaVertice, verticeOrigen, verticeDestino);
}

void mostrarVerticeYAristas(struct Grafo grafo) {
    struct NodoListaVertice * recorridoG = new struct NodoListaVertice;
    struct NodoListaArista * recorridoA = new struct NodoListaArista;
    recorridoG = grafo.listaVertice.cabeza;

    if (recorridoG == nullptr) {
        cout << "No se puede mostrar, el grafo está vacío" << endl;
        return;
    } else {
        while (recorridoG != nullptr) {
            cout << left << setw(2) << recorridoG->ciudad << ":";
            recorridoA = recorridoG->listaArista.cabeza;
            while (recorridoA != nullptr) {
                cout << '(' << recorridoA->ciudad.nombre << ',';
                cout << right << setw(4) << recorridoA->ciudad.costo << ')';
                recorridoA = recorridoA->siguiente;
            }
            recorridoG = recorridoG->siguiente;
            cout << endl;
        }
        delete recorridoG;
    }
}

//void algoritmoDijkstra(struct Grafo & grafo, int ciudad) {
//    int numCiudades = longitudGrafo(grafo);
//    int S[numCiudades]{};
//    
//    int vertices[numCiudades] = {0, 2, 3, 4, 5};
//    int D[numCiudades] = {999, 999, 999, 999, 999}; // Almacena el costo mínimo encontrado entre el origen y las otras ciudades
//  
//    int minimo = 0;
//    int minIndice;
//
//    cout<<endl<<"Se muestra el paso a paso del camino más corto entre ciudades"<<endl;
//    // Almacenar el vértice origen
//    S[0] = ciudad;
//    D[ciudad-1] = 0;
//   for (int i = 1; i < numCiudades; i++) {
//        almacenaMinimos(ciudad, vertices, D, grafo, minimo, minIndice);
//        S[i] = minIndice;
//        ciudad = minIndice;
//
//        //D es el arreglo que va guardando los mínimos valores
//        for (int i = 0; i < numCiudades; i++) {
//            cout << setw(5) << D[i];
//        }
//        cout << endl;
//    }
//    
//    for(int i=0; i<numCiudades; i++){
//        if(vertices[i]!=0){
//            S[numCiudades-1] = i;
//        }
//    }
//    cout << endl;
//    cout<<"Las ciudades de los menores caminos empezando del origen{";
//    //S es el arreglo que guarda los pasos de las ciudades con los menores caminos
//     for (int i = 0; i < numCiudades; i++) {
//        cout << setw(5) << S[i];
//    }
//    cout<<"}";
//}

void algoritmoDijkstra(struct Grafo & grafo, int ciudad) {
    int numCiudades = longitudGrafo(grafo);

    int vertices[numCiudades] = {0, 2, 3, 4, 5};
    int D[numCiudades] = {999, 999, 999, 999, 999}; // Almacena el costo mínimo encontrado entre el origen y las otras ciudades

    int minimo = 0;
    int minIndice;

    D[ciudad - 1] = 0;
    for (int i = 1; i < numCiudades; i++) {
        almacenaMinimos(ciudad, vertices, D, grafo, minimo, minIndice);
        ciudad = minIndice;
    }

    //D es el arreglo que va guardando los mínimos valores
    for (int i = 0; i < numCiudades; i++) {
        cout << setw(5) << D[i];
    }
    
}

void almacenaMinimos(int ciudad, int * vertices, int * D,
        struct Grafo &grafo, int & minimo, int & minIndice) {

    NodoListaVertice * recorridoG = grafo.listaVertice.cabeza;
    NodoListaArista * recorridoA = nullptr;

    while (recorridoG) {
        if (recorridoG->ciudad == ciudad) {
            recorridoA = recorridoG->listaArista.cabeza;
            break;
        }
        recorridoG = recorridoG->siguiente;
    }

    D[0] = 0;
    int i = -1;
    int nuevoMinimo = 999;
    while (recorridoA != nullptr) {
        i = recorridoA->ciudad.nombre - 1;
        if (vertices[i] != 0 and D[i] > recorridoA->ciudad.costo + minimo) {
            D[i] = recorridoA->ciudad.costo + minimo;
            if (D[i] < nuevoMinimo) {
                nuevoMinimo = D[i];
                minIndice = recorridoA->ciudad.nombre;
            }
        }
        recorridoA = recorridoA->siguiente;
    }
    vertices[minIndice - 1] = 0;
    minimo = nuevoMinimo;
}

void destruirGrafo(struct Grafo & grafo) {
    destruirListaVertice(grafo.listaVertice);

    grafo.longitud = 0;
}