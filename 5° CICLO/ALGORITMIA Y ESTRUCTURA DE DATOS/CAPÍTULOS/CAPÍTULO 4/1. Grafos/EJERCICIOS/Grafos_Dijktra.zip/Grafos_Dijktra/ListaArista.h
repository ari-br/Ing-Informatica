/* 
 * File:   ListaArista.h
 * Author: ANA RONCAL
 * Created on 27 de septiembre de 2023, 09:25 AM
 */

#ifndef LISTAARISTA_H
#define LISTAARISTA_H

struct ListaArista{
    int longitud;
    struct NodoListaArista * cabeza;
};

#endif /* LISTAARISTA_H */

