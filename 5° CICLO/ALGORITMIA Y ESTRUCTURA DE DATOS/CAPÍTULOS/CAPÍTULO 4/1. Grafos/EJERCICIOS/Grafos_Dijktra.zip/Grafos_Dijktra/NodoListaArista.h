/* 
 * File:   NodoListaArista.h
 * Author: ANA RONCAL
 * Created on 27 de septiembre de 2023, 09:25 AM
 */

#ifndef NODOLISTAARISTA_H
#define NODOLISTAARISTA_H

struct NodoListaArista {
    struct Ciudad ciudad;    //ElementoListaArista: ACÁ PUEDE CAMBIAR EL ELEMENTO
    struct NodoListaArista * siguiente;
} ;


#endif /* NODOLISTAARISTA_H */

