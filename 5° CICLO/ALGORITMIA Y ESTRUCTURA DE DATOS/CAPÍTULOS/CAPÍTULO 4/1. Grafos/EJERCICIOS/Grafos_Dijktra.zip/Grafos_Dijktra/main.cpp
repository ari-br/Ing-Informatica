/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 18 de septiembre de 2023, 05:39 PM
 */

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include "ListaArista.h"
#include "ListaVertice.h" //Necesita
#include "Grafo.h"
using namespace std;
#include "funcionesListaVertice.h"
#include "funcionesGrafo.h"
#include "NodoListaVertice.h"

/*
 * IMPLEMENTA GRAFOS
 * Algiritmo de Dijkstra para gráfica dirigida
 */
int main(int argc, char** argv) {

    struct Grafo grafo;
    
    //Construir el Grafo
    construirGrafo(grafo);
    
/*  Agregar los vértices  */
    agregarVertice(grafo, 1); 
    agregarVertice(grafo, 2); 
    agregarVertice(grafo, 3); 
    agregarVertice(grafo, 4); 
    agregarVertice(grafo, 5); 
    
    
/*    Agregar las aristas */
//    Ejemplo clase
    agregarArista(grafo, 1, 2, 4); 
    agregarArista(grafo, 1, 3, 11);
    agregarArista(grafo, 2, 4, 6);
    agregarArista(grafo, 2, 5, 2);
    agregarArista(grafo, 3, 2, 3);
    agregarArista(grafo, 3, 4, 6);
    agregarArista(grafo, 5, 3, 5); 
    agregarArista(grafo, 5, 4, 3);

//    Ejemplo 2
//    agregarArista(grafo, 1, 2, 3); 
//    agregarArista(grafo, 1, 4, 7);
//    agregarArista(grafo, 2, 1, 3);
//    agregarArista(grafo, 2, 3, 4);
//    agregarArista(grafo, 2, 4, 2);
//    agregarArista(grafo, 3, 2, 4);
//    agregarArista(grafo, 3, 4, 5);
//    agregarArista(grafo, 3, 5, 6); 
//    agregarArista(grafo, 4, 1, 7);
//    agregarArista(grafo, 4, 2, 2);
//    agregarArista(grafo, 4, 3, 5);
//    agregarArista(grafo, 4, 5, 4);
//    agregarArista(grafo, 5, 3, 6);
//    agregarArista(grafo, 5, 4, 4);
    

    //  Muestra los resultados
    mostrarVerticeYAristas(grafo);
    
    //Algoritmo que encuentra el menor costo de viajar de un punto origen a todos
    //los destinos
    algoritmoDijkstra(grafo, 1);
     
    destruirGrafo(grafo);
    return 0;
}

