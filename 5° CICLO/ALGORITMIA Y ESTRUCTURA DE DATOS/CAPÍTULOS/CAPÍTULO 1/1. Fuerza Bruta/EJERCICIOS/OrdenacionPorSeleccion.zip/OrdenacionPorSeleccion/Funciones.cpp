/* 
 * File:   Funciones.cpp
 * Author: ANA RONCAL
 * Created on 20 de marzo de 2024, 02:16 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "Funciones.h"
using namespace std;

//Ordena el arreglo buscando el mínimo e intercambiando este valor por el primero
//y así hasta el final
void ordenarSeleccion(int * arreglo, int cantDatos){
    
    int minValor, aux, minIndice;
    //Tiene que recorrer un elemento menos que el arreglo
    for(int i = 0; i <= cantDatos - 2; i++){
        //Se guarda el primer valor con el índice
        minIndice = i;
       
        for(int j= i+1; j <= cantDatos-1; j++){
            //Si lo que estoy encontrando es menor que el min guardo el nuevo índice
            if(arreglo[j] < arreglo[minIndice]) {
                minIndice = j;
            }
        }
        //realizo el intercambio usando un auxiliar
        aux = arreglo[i];
        arreglo[i] = arreglo[minIndice];
        arreglo[minIndice] = aux;
    }
}

void mostrarArreglo(int * arreglo, int cantDatos){
    for(int i = 0; i<cantDatos; i++)
        cout<<arreglo[i]<<" ";
    cout<<endl;

}
