/* 
 * File:   funciones.cpp
 * Author: Ana Roncal
 * 
 * Created on 22 de agosto de 2024, 16:38
 */

#include <iostream>
#include "funciones.h"
using namespace std;
#define NO_ENCONTRADO -1 

void mostrarArreglo(int * arreglo, int cantDatos) {

    for (int i = 0; i < cantDatos; i++)
        cout << arreglo[i] << " ";
    cout << endl;

}

void ordenarSeleccion(int * arreglo, int cantDatos) {
    int minIndice, aux;
    for (int i = 0; i <= cantDatos - 2; i++) {
        minIndice = i;
        for (int j = i + 1; j <= cantDatos - 1; j++) {
            if (arreglo[j] < arreglo[minIndice]) {
                minIndice = j;
            }
        }
        aux = arreglo[i];
        arreglo[i] = arreglo[minIndice];
        arreglo[minIndice] = aux;
    }
}

void ordenarBurbuja(int * arreglo, int cantDatos) {
    int aux;
    for (int i = 0; i <= cantDatos - 2; i++) {
        for (int j = 0; j <= cantDatos - 2 - i; j++) {
            if (arreglo[j + 1] < arreglo[j]) {
                aux = arreglo[j];
                arreglo[j] = arreglo[j + 1];
                arreglo[j + 1] = aux;
            }
        }
    }
}

int busquedaSecuencial(int numBuscar, int arreglo [], int cantDatos) {
    for (int i = 0; i < cantDatos; i++)
        if (arreglo[i] == numBuscar)
            return i;
    return NO_ENCONTRADO;
}

int matchingEstrategia(char * patron, int m, char * texto, int n) {
    int j;
    for (int i = 0; i < n - m; i++) {
        j = 0;
        while ((j < m) and (patron[j] == texto[i + j])) {
            j = j + 1;
        }
        if (j == m) {
            return i;
        }
    }
    return -1;

}