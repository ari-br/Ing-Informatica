// -*- C++ -*-

/* 
 * File:   funciones.h
 * Author: ANA RONCAL
 *
 * Created on 22 de agosto de 2024, 16:37
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void mostrarArreglo(int * arreglo, int MAX_DATOS);
void ordenarSeleccion(int * arreglo, int MAX_DATOS);
void ordenarBurbuja(int * arreglo, int MAX_DATOS);
int busquedaSecuencial(int numBuscar, int arreglo [], int MAX_DATOS);
int matchingEstrategia(char * patron, int m, char * texto, int n);

#endif /* FUNCIONES_H */