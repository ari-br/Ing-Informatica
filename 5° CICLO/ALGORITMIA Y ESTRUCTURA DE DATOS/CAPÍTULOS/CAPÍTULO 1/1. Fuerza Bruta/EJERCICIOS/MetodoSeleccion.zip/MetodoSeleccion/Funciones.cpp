/* 
 * File:   Funciones.cpp
 * Author: ANA RONCAL
 * Created on 21 de marzo de 2024, 04:10 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "Funciones.h"
using namespace std;
#define NO_ENCONTRADO -1

void mostrarArreglo(int * arreglo, int cantDatos){
    for(int i=0; i<cantDatos; i++)
        cout<<arreglo[i]<<" ";
    cout<<endl;
}

/*ordenar el arreglo buscando el mínimo e intercambiándolo*/
void ordenarSeleccion(int * arreglo, int cantDatos){
    
    int minIndice, aux;
    for(int i = 0; i<=cantDatos -2; i++){
        //se guarda el primer valor
        minIndice = i;
        for(int j=i+1; j<=cantDatos-1; j++){
            if(arreglo[j] < arreglo[minIndice]){
                minIndice = j;
            }
        }
        aux = arreglo[i];
        arreglo[i] = arreglo[minIndice];
        arreglo[minIndice] = aux;
    }
        
}

void ordenarBurbuja(int * arreglo, int cantDatos){
    int aux;
    for(int i = 0; i<= cantDatos -2; i++){
        for(int j = 0; j <= cantDatos -2 - i; j++){
            if(arreglo[j+1]<arreglo[j]){
                aux = arreglo[j];
                arreglo[j] = arreglo[j + 1];
                arreglo[j + 1] = aux;
            }
        }
    }
}

int busquedaSecuencial(int numeroABuscar, int * arreglo, int cantDatos){
    
    for(int i = 0; i< cantDatos; i++)
        if(numeroABuscar == arreglo[i])
            return i;
    return NO_ENCONTRADO;
}
