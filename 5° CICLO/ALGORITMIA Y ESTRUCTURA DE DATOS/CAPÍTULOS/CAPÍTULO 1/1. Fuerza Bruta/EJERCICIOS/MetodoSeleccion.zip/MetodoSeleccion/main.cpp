/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 21 de marzo de 2024, 04:09 PM
 */

#include <iostream>
#include "Funciones.h"
using namespace std;
#define MAX_DATOS 7
#define NO_ENCONTRADO -1
/*
 * 
 */
int main(int argc, char** argv) {

    int numeroABuscar, indice;
    int arreglo[MAX_DATOS] = {89, 45, 68, 90, 29, 34, 17};
    cout<<"Arreglo inicial: ";
    mostrarArreglo(arreglo, MAX_DATOS);
    //ordenarSeleccion(arreglo, MAX_DATOS);
    ordenarBurbuja(arreglo, MAX_DATOS);
    cout<<"Arreglo ordenado: ";
    mostrarArreglo(arreglo, MAX_DATOS);
    
    cin>>numeroABuscar;
    indice = busquedaSecuencial(numeroABuscar, arreglo, MAX_DATOS);
    if (indice == -1)
        cout<<"El número: "<<numeroABuscar<<" no se encuentra";
    else
        cout<<"El número se encuentra en la posición: "<<indice +1;
    return 0;
}

