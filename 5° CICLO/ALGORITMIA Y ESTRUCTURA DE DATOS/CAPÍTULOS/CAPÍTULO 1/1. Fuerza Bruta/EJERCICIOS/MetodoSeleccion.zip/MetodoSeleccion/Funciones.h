/* 
 * File:   Funciones.h
 * Author: ANA RONCAL
 * Created on 21 de marzo de 2024, 04:10 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void mostrarArreglo(int * arreglo, int MAX_DATOS);
void ordenarSeleccion(int * arreglo, int MAX_DATOS);
void ordenarBurbuja(int * arreglo, int MAX_DATOS);
int busquedaSecuencial(int numeroABuscar, int * arreglo, int MAX_DATOS);
#endif /* FUNCIONES_H */

