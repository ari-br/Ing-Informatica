/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 26 de agosto de 2024, 10:16
 */

#include <cstdlib>
#include <iostream>

#define N 4
#define M 10
#define P 3

using namespace std;

/*
 * 
 */

void actualizaPalabraAux(char palabra[P],char aux[P],int size){
    for (int i=0; i<size; i++){
        aux[i] = palabra[i];
    }
}

int evaluarSiPertenece(char letra,char aux[P],int size){
    for (int i=0; i<size; i++){
        if (aux[i]==letra){
            aux[i] = ' ';
            return 1;
        }
    }
    return 0;
}

int main(int argc, char** argv) {
    char tablero[N][M] = {{'H','C','H','B','Y','S','O','S','O','H'},
                          {'S','C','S','S','Y','Q','O','S','Z','K'},
                          {'O','P','N','Y','O','K','F','H','C','K'},
                          {'O','B','N','I','Y','S','P','O','O','K'}};
    char palabra[P] = {'H','S','O'};
    char aux[P];
    int size = 3;
    int movimientos[4][2] = {{-1,0},
                             {0,1},
                             {1,0},
                             {0,-1}};
    char letra;
    int pertenece, encontre;
    for (int fila=0; fila<N; fila++){
        for (int columna=0; columna<M; columna++){
            actualizaPalabraAux(palabra,aux,size);
            letra = tablero[fila][columna];
            pertenece = evaluarSiPertenece(letra,aux,size);
            if (pertenece){
                /*Ahora voy a ver si se encuentra en alguno de los movimientos*/
                for (int i=0; i<4; i++){
                    int nuevaFila = fila + movimientos[i][0];
                    int nuevaColumna = columna + movimientos[i][1];
                    /*Verificamos que las posiciones nueva fila y nueva columna esten dentro del tablero*/
                    if (nuevaFila>=0 && nuevaFila<N && nuevaColumna>=0 && nuevaColumna<M){
                        letra = tablero[nuevaFila][nuevaColumna];
                        pertenece = evaluarSiPertenece(letra,aux,size);
                        if (pertenece){
                            encontre = 1;
                            for (int j=2; j<size; j++){
                                nuevaFila = nuevaFila + movimientos[i][0];
                                nuevaColumna = nuevaColumna + movimientos[i][1];
                                if (nuevaFila>=0 && nuevaFila<N && nuevaColumna>=0 && nuevaColumna<M){
                                    letra = tablero[nuevaFila][nuevaColumna];
                                    pertenece = evaluarSiPertenece(letra,aux,size);
                                    if (pertenece==0){
                                        encontre = 0;
                                        break;
                                    }                                    
                                }
                                else{
                                    encontre = 0;
                                    break;
                                }
                            }
                           if (encontre){
                               cout << "(" << fila << "," << columna << ")" << endl;
                               break;
                           } 
                        }
                    }
                }
            }
        }
    }
    return 0;
}

