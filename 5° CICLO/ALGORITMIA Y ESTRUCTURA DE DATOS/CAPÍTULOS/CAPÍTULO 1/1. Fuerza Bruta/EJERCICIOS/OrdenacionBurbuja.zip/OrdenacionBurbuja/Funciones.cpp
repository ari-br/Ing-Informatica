/* 
 * File:   Funciones.cpp
 * Author: ANA RONCAL
 * Created on 20 de marzo de 2024, 02:16 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "Funciones.h"
using namespace std;

void ordenarBurbuja(int * arreglo, int cantDatos){
    int aux;
    for(int i = 0; i<= cantDatos -2; i++){
        for(int j = 0; j <= cantDatos -2 - i; j++){
            if(arreglo[j+1] < arreglo[j]){
                aux = arreglo[j];
                arreglo[j] = arreglo[j+1];
                arreglo[j+1] = aux;
            }
        }
    }
}

void mostrarArreglo(int * arreglo, int cantDatos){
    for(int i = 0; i<cantDatos; i++)
        cout<<arreglo[i]<<" ";
    cout<<endl;

}
