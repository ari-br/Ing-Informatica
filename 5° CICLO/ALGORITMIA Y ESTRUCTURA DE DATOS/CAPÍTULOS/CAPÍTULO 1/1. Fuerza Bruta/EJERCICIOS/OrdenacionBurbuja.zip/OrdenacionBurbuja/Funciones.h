/* 
 * File:   Funciones.h
 * Author: ANA RONCAL
 * Created on 20 de marzo de 2024, 02:16 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void ordenarBurbuja(int * arreglo, int cantDatos);
void mostrarArreglo(int * arreglo, int cantDatos);

#endif /* FUNCIONES_H */

