/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 20 de marzo de 2024, 02:06 PM
 */

#include <iostream>
#include "Funciones.h"
using namespace std;
#define MAX_DATOS 7
/*
 * Método Burbuja
 */
int main(int argc, char** argv) {

    int arreglo[MAX_DATOS] = {89, 45, 68, 90, 29, 34, 17};
    cout<<"Arreglo inicial:  ";
    mostrarArreglo(arreglo, MAX_DATOS);
    ordenarBurbuja(arreglo, MAX_DATOS);
    cout<<"Arreglo ordenado: ";
    mostrarArreglo(arreglo, MAX_DATOS);
    return 0;
}

