/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 21 de octubre de 2024, 11:15
 */

#include <cstdlib>
#include <iostream>
#define N 10

using namespace std;

/*
 * 
 */
int cuentaCeros(int arreglo[N],int inicio,int fin,int cuenta){
    if (inicio>fin){
        return cuenta;
    }
    int medio = (inicio+fin)/2;
    if (arreglo[medio]==0){
        return cuentaCeros(arreglo,inicio,medio-1,cuenta+fin-medio+1);
    }
    else{
        return cuentaCeros(arreglo,medio+1,fin,cuenta);
    }
}


int main(int argc, char** argv) {
    int arreglo[N] = {0,0,0,0,0,0,0};
    int n=7, cuenta=0;
    cout << "Existen " << cuentaCeros(arreglo,0,n-1,cuenta) << " ceros";
    return 0;
}

