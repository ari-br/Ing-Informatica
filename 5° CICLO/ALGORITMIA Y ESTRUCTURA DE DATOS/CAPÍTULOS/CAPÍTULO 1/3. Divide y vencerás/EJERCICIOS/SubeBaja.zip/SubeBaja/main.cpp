/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 21 de octubre de 2024, 12:10 PM
 */

#include <iostream>

using namespace std;

int buscamax(int *arr,int ini,int fin){
    if(ini==fin)return arr[ini];
    
    int med=(ini+fin)/2;
    
    if(arr[med]>arr[med+1])
        return buscamax(arr,ini,med);
    else
        return buscamax(arr,med+1,fin);
    
}


int main(int argc, char** argv) {
    int arr[]={12,19,28,32,42,61};
    int n=sizeof(arr)/sizeof(arr[0]);
    
    cout << buscamax(arr,0,n-1);
}

