/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 21 de octubre de 2024, 12:37
 */

#include <cstdlib>
#include <iostream>
#define N 15

using namespace std;

/*
 * 
 */
int buscaMayor(int arreglo[N],int inicio,int fin){
    if (inicio==fin){
        return arreglo[inicio];
    }
    int medio = (inicio+fin)/2;
    if (arreglo[medio]>arreglo[medio+1]){
        return buscaMayor(arreglo,inicio,medio);
    }
    else{
        return buscaMayor(arreglo,medio+1,fin);
    }
}

int main(int argc, char** argv) {
    int arreglo[N] = {8,10,20,80,100,200,5,4,3,2,1};
    int n = 11;
    cout << "El mayor es: " << buscaMayor(arreglo,0,n-1);
    return 0;
}

