/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 28 de octubre de 2024, 10:37
 */

#include <cstdlib>
#include <iostream>
#define N 4
#define M 5
using namespace std;

/*
 * 
 */

int buscarMenorDV(int calorias[M],int inicio,int fin){
    if (inicio==fin){
        return calorias[inicio];
    }
    int medio = (inicio+fin)/2;
    int menorIzq = buscarMenorDV(calorias,inicio,medio);
    int menorDer = buscarMenorDV(calorias,medio+1,fin);
    if (menorIzq<menorDer){
        return menorIzq;
    }
    return menorDer;
}

void merge(int lonchera[N], int inicio, int medio, int fin){
    int aux[N], p, q, m;
    /*Aqui estamos mezclando los dos arreglos*/
    for (p=inicio, q=medio+1, m=inicio; p<=medio && q<=fin; m++){
        if (lonchera[p]<lonchera[q]){
            aux[m] = lonchera[p];
            p++;
        }
        else{
            aux[m] = lonchera[q];
            q++;
        }
    }
    /*Aqui vamos a pasar el sobrante de los dos arreglos*/
    while (p<=medio){
        aux[m] = lonchera[p];
        p++;
        m++;
    }
    while (q<=fin){
        aux[m] = lonchera[q];
        q++;
        m++;
    }
    /*Voy a pasar todos los elementos ordenados que estan en aux a lonchera*/
    for (int i=inicio; i<=fin; i++){
        lonchera[i] = aux[i];
    }
}

void mergeSort(int lonchera[N],int inicio,int fin){
    if (inicio==fin){
        return ;
    }
    int medio = (inicio+fin)/2;
    mergeSort(lonchera,inicio,medio);
    mergeSort(lonchera,medio+1,fin);
    merge(lonchera,inicio,medio,fin);
}

int main(int argc, char** argv) {
    int calorias[N][M] = {{12,10,7,8,15},
                          {20,13,2,15,18},
                          {17,8,3,2,12},
                          {23,10,12,18,8}};
    int n=4, m = 5;
    int lonchera[N];
    for (int i=0; i<N; i++){
        lonchera[i] = buscarMenorDV(calorias[i],0,m-1);
    }
    cout << "Calorias de la lonchera sin ordenar" << endl;
    for (int i=0; i<N; i++){
        cout << lonchera[i] << " ";
    }
    cout << endl;
    mergeSort(lonchera,0,n-1);
    cout << "Calorias de la lonchera ordenado" << endl;
    for (int i=0; i<N; i++){
        cout << lonchera[i] << " ";
    }
    return 0;
}

