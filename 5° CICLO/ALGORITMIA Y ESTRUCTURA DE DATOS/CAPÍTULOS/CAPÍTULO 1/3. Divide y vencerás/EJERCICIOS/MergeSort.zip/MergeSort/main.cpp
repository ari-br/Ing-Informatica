/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 28 de octubre de 2024, 10:46 AM
 */

#include <iostream>
#include <climits>

using namespace std;

void merge(int *arr,int ini,int med,int fin){
    int l1,l2,p=0,q=0;
    
    l1=med-ini+1;
    l2=fin-med;
    
    int A[l1+1];
    int B[l2+1];
    
    for(int i=ini;i<=med;i++)
        A[i-ini]=arr[i];
    A[l1]=INT_MAX;
    
    for(int i=med+1;i<=fin;i++)
        B[i-med-1]=arr[i];
    B[l2]=INT_MAX;
    //mezcla
    for(int i=ini;i<=fin;i++)
        if(A[p]<B[q]){
            arr[i]=A[p];
            p++; }
        else
            arr[i]=B[q++];

}    



void mergesort(int *arr,int ini,int fin){
    
    if(ini==fin) return;
    int med=(ini+fin)/2;
    
    mergesort(arr,ini,med);
    mergesort(arr,med+1,fin);
    merge(arr,ini,med,fin);
    
}

int main(int argc, char** argv) {
    int arr[]={8,6,18,15,20};
    int n=sizeof(arr)/sizeof(arr[0]);
    
    mergesort(arr,0,n-1);
    for(int i=0;i<n;i++)
        cout <<arr[i]<<" ";
    
    return 0;
}

