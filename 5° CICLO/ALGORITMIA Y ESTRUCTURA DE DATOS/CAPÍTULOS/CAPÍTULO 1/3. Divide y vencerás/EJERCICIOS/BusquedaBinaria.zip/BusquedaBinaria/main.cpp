/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 21 de octubre de 2024, 10:50
 */

#include <cstdlib>
#include <iostream>
#define N 10

using namespace std;

/*
 * 
 */

int busquedaBinaria(int arreglo[N],int inicio,int fin,int buscado){
    /*En el caso que no lo encuentre, el inicio sera mayor que el fin*/
    if (inicio>fin){
        return -1;
    }
    int medio = (inicio+fin)/2;
    /*En el caso que lo encuentre justo en la posición del medio*/
    if (arreglo[medio]==buscado){
        return medio;
    }
    if (arreglo[medio]>buscado){
        return busquedaBinaria(arreglo,inicio,medio-1,buscado);
    }
    else{
        return busquedaBinaria(arreglo,medio+1,fin,buscado);
    }
}

int main(int argc, char** argv) {
    int arreglo[N] = {2,7,10,15,20,32,44,82};
    int n=8, buscado=0;
    int resultado = busquedaBinaria(arreglo,0,n-1,buscado);
    if (resultado!=-1){
        cout << "El número buscado se encuentra en la posición " << resultado;
    }
    else{
        cout << "El número buscado no existe en el arreglo";
    }
    return 0;
}

