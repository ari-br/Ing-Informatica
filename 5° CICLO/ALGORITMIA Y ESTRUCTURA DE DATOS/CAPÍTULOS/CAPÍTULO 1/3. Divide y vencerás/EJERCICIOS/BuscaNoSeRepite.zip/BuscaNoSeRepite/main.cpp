/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 21 de octubre de 2024, 12:04
 */

#include <cstdlib>
#include <iostream>

#define N 15

using namespace std;

/*
 * 
 */

int buscaNoSeRepite(int arreglo[N],int inicio,int fin){
    /*Si el inicio es igual al fin, estoy validando un arreglo de un elemento, el cuál es el que no se repite*/
    if (inicio==fin){
        return arreglo[inicio];
    }
    if (inicio>fin){
        return -1;
    }
    int medio = (inicio+fin)/2;
    if (medio%2==1){
        if (arreglo[medio]==arreglo[medio-1]){
            return buscaNoSeRepite(arreglo,medio+1,fin);
        }
        else{
            return buscaNoSeRepite(arreglo,inicio,medio);
        }
    }
    else{
        if (arreglo[medio]==arreglo[medio+1]){
            return buscaNoSeRepite(arreglo,medio+2,fin);
        }
        else{
            return buscaNoSeRepite(arreglo,inicio,medio);
        }
    }
}

int main(int argc, char** argv) {
    int arreglo[N] = {1,1,3,3,4,4,5,7,7,8,8};
    int n= 11;
    int resultado = buscaNoSeRepite(arreglo,0,n-1);
    if (resultado!=-1){
        cout << "El elemento que no se repite es: " << resultado;
    }
    else{
        cout << "Ningún elemento no se repite";
    }
    return 0;
}

