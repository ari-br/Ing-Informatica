
/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 28 de octubre de 2024, 12:18 PM
 */

#include <iostream>

using namespace std;

int max(int a,int b){
    if(a>b) return a;
    return b;
}
int maxmedio(int *arr,int ini,int med,int fin){
    int contizq=0,contder=0;
    
    for(int i=med;i>ini;i--)
        if(arr[i]>arr[i-1]) contizq++;
        else break;
    for(int i=med;i<fin;i++)
        if(arr[i+1]>arr[i]) contder++;
        else break;
    
    return contder+contizq+1;
            
}

int maxcontagios(int *arr,int ini,int fin){
    if(ini==fin)return 1;
    
    int med=(ini+fin)/2;
    int izq=maxcontagios(arr,ini,med);
    int der=maxcontagios(arr,med+1,fin);
    int cen=maxmedio(arr,ini,med,fin);    
    return max(max(izq,der),cen);
}



int main(int argc, char** argv) {
    int arr[]={10,20,15,10,12,10,13,18};
    int n=sizeof(arr)/sizeof(arr[0]);
    
    cout <<"Maximo de contagios:"<<maxcontagios(arr,0,n-1);
    
    return 0;
}

