/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 21 de octubre de 2024, 10:49 AM
 */
#include <iostream>

using namespace std;

int busbinaria(int *arr,int ini,int fin,int k){
   if(ini>fin)
       return -1;
   int med=(ini+fin)/2;
   
   if(arr[med]==k)
       return med;
   else
       if(arr[med]>k)
           busbinaria(arr,ini,med-1,k);
       else    
           busbinaria(arr,med+1,fin,k);
    
} 

int main(int argc, char** argv) {
    int arr[]={2,3,4,5,6,7,10,11};
    int n=sizeof(arr)/sizeof(arr[0]);
    cout << busbinaria(arr,0,n-1,4); 

    return 0;
}

