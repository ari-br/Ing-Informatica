/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 26 de agosto de 2024, 12:45
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */

void imprimeBinario(int n){
    if (n==0){
        return ;
    }
    int digito = n%2;
    imprimeBinario(n/2);
    cout << digito;    
}

int main(int argc, char** argv) {
    int n = 8;
    imprimeBinario(n);
    return 0;
}

