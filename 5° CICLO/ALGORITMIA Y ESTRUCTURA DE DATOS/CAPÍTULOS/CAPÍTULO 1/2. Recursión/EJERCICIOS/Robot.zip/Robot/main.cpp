/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 2 de septiembre de 2024, 10:40 AM
 */

#include <iostream>
#define N 3

using namespace std;

int robot(int x,int y,int n,int m,int tablero[][N]){
    int der=-999999,aba=-999999;
    
    if(x==n-1 and y==m-1)
        return tablero[x][y];
    if(y+1<m)
        der=robot(x,y+1,n,m,tablero);
    if(x+1<n)
        aba=robot(x+1,y,n,m,tablero);   
    if(aba<der)
        return der+tablero[x][y];
    return aba+tablero[x][y];
    
}



int main(int argc, char** argv) {
    int n=3,m=3;
    
    int tablero[][3]={      {2,5,1},
                            {2,9,1},    
                            {14,3,5}};
    
    cout << "El total es:" << robot(0,0,n,m,tablero);

    return 0;
}

