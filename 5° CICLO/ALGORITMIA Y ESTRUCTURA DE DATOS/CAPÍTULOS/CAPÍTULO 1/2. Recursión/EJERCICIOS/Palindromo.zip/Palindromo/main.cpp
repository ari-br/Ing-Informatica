#include <iostream>
#include <iomanip>
#include <cstring>
#include <cmath>
using namespace std;

bool esPalindromo(char *ptrCadena, int longitud){
    char aux[50];
    if(longitud==1){
        return true;
    } else if(longitud==2){
        if(ptrCadena[0]==ptrCadena[1]) return true;
        return false;
    }
    strcpy(aux, ptrCadena);
    if(ptrCadena[0]!=ptrCadena[longitud-1]) return false;
    //achicar cadena
    ptrCadena = new char[longitud+1-2];
    for(int i=1; i<longitud-1; i++){
        ptrCadena[i-1] = aux[i];
        if(i+1==longitud-1) ptrCadena[i] = '\0';
    }
    return esPalindromo(ptrCadena, longitud-2);
}

int main(int argc, char** argv) {
    char cadena[50] = "LEVEL";
    int longitud = strlen(cadena);
    bool es;
    char *ptrCadena = new char[longitud+1];
    strcpy(ptrCadena, cadena);
    es = esPalindromo(ptrCadena, longitud);
    cout<<(!es?"NO ":"")<<"ES PALINDROMO"<<endl;
    return 0;
}

