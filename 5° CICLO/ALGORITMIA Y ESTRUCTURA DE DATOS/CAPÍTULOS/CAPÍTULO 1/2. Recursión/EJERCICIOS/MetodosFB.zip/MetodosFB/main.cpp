/* 
 * File:   main.cpp
 * Author: Ana Roncal
 *
 * Created on 22 de agosto de 2024, 16:33
 */

#include <iostream>
using namespace std;
#include "funciones.h"
#define MAX_DATOS 7
#define M 3
#define N 14
/*
 * 
 */
int main(int argc, char** argv) {
    
    int arreglo[MAX_DATOS] = {89, 45, 68, 90, 29, 34, 17};
    int  numBuscar, indice;
    cout<<"Arreglo inicial:";
    mostrarArreglo(arreglo, MAX_DATOS);
    //ordenarSeleccion(arreglo, MAX_DATOS);
    ordenarBurbuja(arreglo, MAX_DATOS);
    cout<<"Arreglo ordanado:";
    mostrarArreglo(arreglo, MAX_DATOS);
    numBuscar = 89;
    indice = busquedaSecuencial(numBuscar, arreglo, MAX_DATOS);
    if(indice == -1)
        cout<<"Piña"<< endl;
    else
        cout<<"El número se encuentra en la posición: "<<indice + 1<< endl;
    
    /*Buscar un patrón en un arreglo*/
    char patron[M] = {'N', 'O', 'T'};
    char texto[N] = {'N', 'O', 'B', 'O', 'D', 'Y', '_', 'N', 'O', 'T', 'I', 'C', 'E', 'D'};
    indice = matchingEstrategia(patron, M, texto, N);
    cout<<"El patrón se encuentra en el índice: "<< indice + 1;
    
    return 0; 

}

