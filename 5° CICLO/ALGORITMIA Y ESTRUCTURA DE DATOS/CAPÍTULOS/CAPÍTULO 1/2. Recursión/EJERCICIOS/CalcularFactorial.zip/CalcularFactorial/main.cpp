/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 26 de agosto de 2024, 12:40
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */

int calcularFactorial(int n){
    if (n==0){
        return 1;
    }
    return n * calcularFactorial(n-1);
}

int main(int argc, char** argv) {
    int n = 5;
    cout << "El factorial de " << n << " es: " << calcularFactorial(n) << endl;
    return 0;
}

