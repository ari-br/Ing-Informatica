/* 
 * File:   funciones.cpp
 * Author: ANA RONCAL
 * Created on 2 de septiembre de 2023, 10:44 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>

using namespace std;
#include "funciones.h"
#define PROBADA 3
#define RUTA 7
#define FIL 3
#define COL 7

bool valida(int tablero[][COL], int fil, int col, int maxFil, int maxCol) {
    bool resultado = false;
    /*dentro de los límites de la matriz*/
    if (fil >= 0 and fil < maxFil and col >= 0 and col < maxCol)
        if (tablero[fil][col] == 1) /* no es pared y no ha sido probada*/
            resultado = true;
    return resultado;
}

//bool laberinto(int tablero[][5], int fil, int col){
//    
//    bool terminado = false;
//    
//    if(valida(tablero, fil, col)){
//        tablero[fil][col] = PROBADA; /* ya ha sido probada*/
//        mostrar(tablero);
//        //Caso base
//        if(fil == 2 and col == 4)
//            terminado = true;
//        else{
//            if (not terminado)
//                terminado = laberinto(tablero, fil + 1, col); /*hacia abajo*/
//            if (not terminado)
//                terminado = laberinto(tablero, fil, col + 1); /*hacia la derecha*/
//            if (not terminado)
//                terminado = laberinto(tablero, fil -1, col); /*hacia arriba*/
//            if(not terminado) 
//                terminado = laberinto(tablero, fil, col - 1); /*hacia la izquierda*/  
//        }
//        mostrar(tablero);
//        if(terminado)
//            tablero[fil][col] = RUTA;
//      
//    }
//    return terminado;
//}

bool laberinto(int tablero[][COL], int fil, int col, int maxFil, int maxCol) {

    bool terminado = false;

    if (valida(tablero, fil, col, maxFil, maxCol)) {
        tablero[fil][col] = PROBADA; /* ya ha sido probada, ES MUY IMPORTANTE*/
        mostrar(tablero, maxFil, maxCol);
        //Caso base
        if (fil == 2 and col == COL - 1) {
            terminado = true;
        } else {
            /* se colocan los if para que no siga recorriendo todos los casos
             si se le quita inspecciona todas las rutas válida y no válidas*/
            if (not terminado)
                terminado = laberinto(tablero, fil, col - 1, maxFil, maxCol); /*hacia la izquierda*/
            if (not terminado)
                terminado = laberinto(tablero, fil - 1, col, maxFil, maxCol); /*hacia arriba*/
            if (not terminado)
                terminado = laberinto(tablero, fil, col + 1, maxFil, maxCol); /*hacia la derecha*/
            if (not terminado)
                terminado = laberinto(tablero, fil + 1, col, maxFil, maxCol); /*hacia abajo*/
        }
        mostrar(tablero, maxFil, maxCol);
        /*Se coloca una marca al desapilar la ruta correcta*/
        if (terminado)
            tablero[fil][col] = RUTA;
    }
    return terminado;
}

void mostrar(int tablero[][COL], int maxFil, int maxCol) {

    for (int i = 0; i < maxFil; i++) {
        for (int j = 0; j < maxCol; j++) {
            cout << tablero[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl << endl;
}