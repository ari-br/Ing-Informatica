/* 
 * File:   funciones.cpp
 * Author: ANA RONCAL
 * Created on 14 de abril de 2024, 06:38 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "funciones.h"
#define N 6
#define M 6

// Función recursiva para contar unidades

int contarUnidadesRecursivo(int tablero[M][N], int x, int y, int nivel) {
    int cuenta = 0;
    bool completo = true;
    if (x < 0 or x > 5 or y < 0 or y > 5 or nivel > 5)
        return 0; // Algún punto está fuera del tablero

    cuenta = contarUnidades(tablero, x, y, nivel, completo);
    if (not completo)
        return cuenta;
    else
        return cuenta + contarUnidadesRecursivo(tablero, x - 1, y - 1, nivel + 1);
}

int contarUnidades(int tablero[6][6], int x, int y, int nivel, bool & completo) {
    int unidad = 0;

    int i;
    if (x + nivel * 2 > 5 and y + nivel * 2 > 5) {
        completo = false; //importante para no seguir contando
        return 0;
    }
    //Avanzo derecha, hasta uno menos del final
    for (i = y; i < y + 2 * nivel; i++)
        if (tablero[x][i]) {
            unidad++;
            cout << "X, Y :" << x << " " << i << endl;
        }
    //Avanzo abajo, hasta uno menos del final
    for (i = x; i < x + 2 * nivel; i++)
        if (tablero[i][y + 2 * nivel]) {
            unidad++;
            cout << "X, Y :" << i << " " << y + 2 * nivel << endl;
        }
    //avanzo izquierda, hasta uno menos del final
    for (i = y + 2 * nivel; i > y; i--)
        if (tablero[x + 2 * nivel][i]) {
            unidad++;
            cout << "X, Y :" << x + 2 * nivel << " " << i << endl;
        }
    //Avanzo arriba, hasta uno menos del final
    for (i = x + 2 * nivel; i > x; i--)
        if (tablero[i][y]) {
            unidad++;
            cout << "X, Y :" << i << " " << y << " " << endl;
        }
    return unidad;
}
