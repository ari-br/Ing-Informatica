/* 
 * File:   funciones.cpp
 * Author: ANA RONCAL
 * Created on 30 de enero de 2024, 12:36 AM
 */

#include <iostream>
using namespace std;

void hanoi(int n, char desde, char auxiliar, char hacia) {

    //caso base
    if (n == 1) {
        cout << "Mover disco 1 desde la torre " << desde << " hacia la torre "
                << hacia << endl;
        return;
    }
    //llevo los n-1 discos de A a B
    hanoi(n - 1, desde, hacia, auxiliar);
    cout << "Mover disco " << n << " desde la torre " << desde << " hacia la torre "
            << hacia << endl;
    //llevo los n-1 discos de B a C
    hanoi(n - 1, auxiliar, desde, hacia);
}

void hanoi4T(int n, char desde, char auxiliar1, char auxiliar2, char hacia) {

    //casos base
    if (n == 1) {
        cout << "Mover disco 1 desde la torre " << desde << " hacia la torre "
                << hacia << endl;
        return;
    }

    if (n == 2) {
        cout << "Mover disco 1 desde la torre " << desde << " hacia la torre "
                << auxiliar2 << endl;
        cout << "Mover disco 2 desde la torre " << desde << " hacia la torre "
                << hacia << endl;
        cout << "Mover disco 1 desde la torre " << auxiliar2 << " hacia la torre "
                << hacia << endl;
        return;
    }

    //llevo los n-2 discos de A a auxiliar2
    hanoi4T(n - 2, desde, auxiliar1, hacia, auxiliar2);
    cout << "Mover disco " << n - 1 << " desde la torre " << desde << " hacia la torre "
            << auxiliar1 << endl;
    cout << "Mover disco " << n << " desde la torre " << desde << " hacia la torre "
            << hacia << endl;
    cout << "Mover disco " << n - 1 << " desde la torre " << auxiliar1 << " hacia la torre "
            << hacia << endl;
    //llevo los n-2 discos de auxiliar2 a hacia
    hanoi4T(n - 2, auxiliar2, auxiliar1, desde, hacia);
}

