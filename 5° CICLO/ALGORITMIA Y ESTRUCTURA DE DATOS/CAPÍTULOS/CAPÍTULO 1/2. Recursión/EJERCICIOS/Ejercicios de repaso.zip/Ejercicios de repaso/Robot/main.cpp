/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 13 de abril de 2024, 01:02 AM
 */

#include <iostream>

using namespace std;
#include "funciones.h"
#define FIL 6
#define COL 6

int main() {
    // Definir la tablero de unidades desaparecidas
    int tablero[FIL][COL] = {
        {0, 0, 0, 1, 0, 1},
        {0, 0, 1, 0, 0, 0},
        {0, 1, 0, 0, 0, 1},
        {1, 0, 0, 0, 0, 0},
        {0, 1, 0, 0, 1, 0},
        {0, 0, 0, 0, 1, 0}
    };

    // Definir la posición inicial (X, Y)
    int x = 4; //ojo que representa en el tablero la fila
    int y = 4; //ojo que representa en el tablero la columna
    int nivel = 1;
    // Iniciar la búsqueda de unidades desaparecidas
    cout << "[FIL,COL]:"<< endl;
    int unidadesEncontradas = tablero[x][y] + contarUnidadesRecursivo(tablero, x - 1, y - 1, nivel);

    // Imprimir el resultado
    cout << "El resultado de la búsqueda es: " << unidadesEncontradas << " unidades." << endl;


    return 0;
}
