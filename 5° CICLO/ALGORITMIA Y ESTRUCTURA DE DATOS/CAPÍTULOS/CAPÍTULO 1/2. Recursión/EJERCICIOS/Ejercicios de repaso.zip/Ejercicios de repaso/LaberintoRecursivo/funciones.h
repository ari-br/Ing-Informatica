/* 
 * File:   funciones.h
 * Author: ANA RONCAL
 * Created on 2 de septiembre de 2023, 10:44 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H
#define COL 7
bool valida(int tablero[][COL], int , int , int, int);
bool laberinto(int tablero[][COL], int, int, int, int);
void mostrar(int tablero[][COL], int, int);

#endif /* FUNCIONES_H */

