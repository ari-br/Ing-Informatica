/* 
 * File:   funciones.h
 * Author: ANA RONCAL
 * Created on 30 de enero de 2024, 12:36 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void hanoi(int, char, char , char); 
void hanoi4T(int, char, char , char, char); 

#endif /* FUNCIONES_H */

