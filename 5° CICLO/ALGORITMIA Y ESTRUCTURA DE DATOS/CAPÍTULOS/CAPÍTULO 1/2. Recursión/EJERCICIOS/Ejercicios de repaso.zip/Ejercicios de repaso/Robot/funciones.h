/* 
 * File:   funciones.h
 * Author: ANA RONCAL
 * Created on 14 de abril de 2024, 06:38 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

int contarUnidadesRecursivo(int tablero[6][6], int x, int y, int nivel);
int contarUnidades(int tablero[6][6], int col, int fil, int nivel, bool & completo);

#endif /* FUNCIONES_H */

