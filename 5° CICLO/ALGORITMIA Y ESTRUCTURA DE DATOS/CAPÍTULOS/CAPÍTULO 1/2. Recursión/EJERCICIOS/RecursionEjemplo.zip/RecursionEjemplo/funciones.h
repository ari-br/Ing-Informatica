/* 
 * File:   funciones.h
 * Author: ANA RONCAL
 * Created on 2 de septiembre de 2023, 10:17 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

int suma(int );
int multiplica(int , int );
void mostrar(const char *, int );
int hallarMayorRecursivo(int * arreglo, int cant);
int max(int a, int b);
int buscarNumeroRecursivo(int * arreglo, int cant, int numeroBusco);

#endif /* FUNCIONES_H */

