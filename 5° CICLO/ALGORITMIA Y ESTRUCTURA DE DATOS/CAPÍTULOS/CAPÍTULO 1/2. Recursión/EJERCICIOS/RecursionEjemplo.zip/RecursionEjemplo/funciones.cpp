/* 
 * File:   funciones.cpp
 * Author: ANA RONCAL
 * Created on 2 de septiembre de 2023, 10:17 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>

using namespace std;
#include "funciones.h"
#define NO_ENCONTRADO -1

int suma(int n) {
    int resultado;
    if (n == 1)
        resultado = 1; /* caso base*/
    else
        resultado = n + suma(n - 1); /*caso recursivo*/
    return resultado;
}

int multiplica(int m, int n) {
    int resultado;
    if (n == 1)
        resultado = m;
    else
        resultado = m + multiplica(m, n - 1); /*caso recursivo*/
    return resultado;
}

void mostrar(const char * nombre, int resultado) {
    cout << nombre << " " << resultado << endl << endl;
}

int max(int a, int b) {
    return (a > b) ? a : b;
}

int hallarMayorRecursivo(int * arreglo, int cant) {

    //Tengo un solo elemento
    if (cant == 1)
        return arreglo[cant - 1]; //arreglo en cero
    else {
        //caso recursivo
        return max(hallarMayorRecursivo(arreglo, cant - 1), arreglo[cant - 1]);
    }
}

int buscarNumeroRecursivo(int * arreglo, int cant, int numeroBusco) {

    //Terminé de recorrer el arreglo
    if(cant == 0)  return NO_ENCONTRADO;
    
    if(arreglo[cant-1] == numeroBusco)
        return cant-1;
    else
        buscarNumeroRecursivo(arreglo, cant - 1, numeroBusco);
  
}