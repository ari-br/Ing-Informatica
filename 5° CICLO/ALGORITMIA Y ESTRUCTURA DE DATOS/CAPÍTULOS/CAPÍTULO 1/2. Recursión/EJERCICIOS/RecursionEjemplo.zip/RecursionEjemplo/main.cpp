/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 2 de septiembre de 2023, 10:08 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;
#include "funciones.h"
#define N 8
#define NO_ENCONTRADO -1

/*
 * EJERCICIOS DE RECURSIVIDAD SIMPLES
 */
int main(int argc, char** argv) {

    /*SUMATORIA DE N NÚMEROS NATURALES*/
    int m, n, sumatoria, producto;

    n = 5;
    sumatoria = suma(n);
    mostrar("Sumatoria: ", sumatoria);

    /*CASO DE MULTIPLICAR 7 */
    m = 7;
    n = 4;
    producto = multiplica(m, n);
    mostrar("Producto: ", producto);

    /*Obtener el mayor de un arreglo de N número enteros*/
    int arreglo[N] = {9, 8, 7, 6, 10, 1, 4, 3};
    int mayor = hallarMayorRecursivo(arreglo, N);
    cout << "El mayor es: " << mayor << endl << endl;

    int numeroBusco = 8;
    int indice = buscarNumeroRecursivo(arreglo, N, numeroBusco);
    if (indice == NO_ENCONTRADO)
        cout << "El número no se encuentra";
    else
        cout << "El número está en el índice: " << indice;
    return 0;
}

