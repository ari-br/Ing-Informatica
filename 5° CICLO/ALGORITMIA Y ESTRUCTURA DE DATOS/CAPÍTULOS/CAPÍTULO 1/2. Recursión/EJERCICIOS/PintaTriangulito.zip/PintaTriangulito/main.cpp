/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 26 de agosto de 2024, 12:43 PM
 */

#include <iostream>

using namespace std;

void triangulo(int a, int b){
    
    if(a>b) return;
    for(int i=0;i<a;i++)
        cout <<" * ";
    cout << endl;
    triangulo(a+1,b);
    for(int i=0;i<a;i++)
        cout <<" * ";
    cout << endl;    
}

int main(int argc, char** argv) {

    triangulo(3,5);
    return 0;
}

