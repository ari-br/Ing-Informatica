/* 
 * File:   Guerrero.h
 * Author: ANA RONCAL
 * Created on 16 de abril de 2024, 10:15 PM
 */

#ifndef GUERRERO_H
#define GUERRERO_H

// Estructura para representar guerreros
struct Guerrero {
    int poder;
    int tiposPermitidos[3]; // Máximo 3 tipos permitidos
};

#endif /* GUERRERO_H */

