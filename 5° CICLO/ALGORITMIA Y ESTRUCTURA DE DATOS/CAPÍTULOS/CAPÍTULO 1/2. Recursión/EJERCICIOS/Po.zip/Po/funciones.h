/* 
 * File:   funciones.h
 * Author: ANA RONCAL
 * Created on 16 de abril de 2024, 10:32 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void cargaBase(int i, int * combinaciones, int base);
bool validaSolucion(int * combinaciones, struct Guerrero * guerreros, 
                    int cantGuerreros, int cantArmas, struct Arma * armas );
void imprimeSolucion(int * combinaciones, int cantArmas, struct Arma * armas, 
                     int cantGuerreros, struct Guerrero * guerreros);

#endif /* FUNCIONES_H */

