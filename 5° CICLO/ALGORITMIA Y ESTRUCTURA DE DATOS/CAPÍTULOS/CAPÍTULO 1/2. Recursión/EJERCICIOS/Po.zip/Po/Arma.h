/* 
 * File:   Armas.h
 * Author: ANA RONCAL
 * Created on 16 de abril de 2024, 10:12 PM
 */

#ifndef ARMAS_H
#define ARMAS_H

// Estructura para representar armas
struct Arma {
    char letra;
    int poder;
    int tipo;
    int requisitos[3]; // Máximo 3 requisitos
};

#endif /* ARMAS_H */

