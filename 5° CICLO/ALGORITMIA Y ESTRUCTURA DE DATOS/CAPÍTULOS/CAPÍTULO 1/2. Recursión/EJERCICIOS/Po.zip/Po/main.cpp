/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 12 de abril de 2024, 11:26 PM
 */

#include <iostream>
#include <cmath>
#include "Arma.h"
#include "Guerrero.h"
using namespace std;
#include "funciones.h"

int main() {

    int cantGerreros = 3;
    int cantArmas = 12;
    int base = cantGerreros + 1;
    int combinaciones[cantArmas]{};
    // Definir los guerreros y las armas
    struct Arma armas[12] = {
        {'Z', 60, 3, {}},
        {'P', 80, 1, {1}},
        {'R', 38, 2, {}},
        {'D', 25, 2, {3}},
        {'E', 49, 2, {}},
        {'F', 57, 1, {}},
        {'G', 68, 3, {}},
        {'H', 35, 2, {1, 5}},
        {'I', 62, 2, {3}},
        {'J', 42, 2, {}},
        {'K', 36, 1, {1}},
        {'L', 54, 3, {}}
    };
 
    struct Guerrero guerreros[cantGerreros] = {
        {120, {2}},
        {160, {1, 3}},
        { 80, {3}}
    };

    int cantCombinaciones = (int) pow(base, cantArmas);
    for (int i = 1; i < cantCombinaciones; i++) {
        cargaBase(i, combinaciones, base);
        if( validaSolucion(combinaciones, guerreros, cantGerreros, cantArmas, armas)){
            imprimeSolucion(combinaciones, cantArmas, armas, cantGerreros, guerreros);
            break;
        }
    }

    return 0;
}
