/* 
 * File:   funciones.cpp
 * Author: ANA RONCAL
 * Created on 16 de abril de 2024, 10:32 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "Arma.h"
#include "Guerrero.h"
#include "funciones.h"
using namespace std;
#define SIZE 12
#define COL 5


void cargaBase(int num, int * combinaciones, int base) {
    int i = 0;
    while (num > 0) {
        combinaciones[i++] = num % base;
        num = num / base;
    }
}

bool validaSolucion(int * cromosoma, struct Guerrero * guerreros,
        int cantGuerreros, int cantArmas, struct Arma * armas) {

    int poderes[3]{}; //para acumular los poderes por guerrero

    for (int i = 0; i < cantArmas; i++) {
        if (cromosoma[i] > 0) {//para saber si el arma ha sido elegida
            int indiceGuerrero = cromosoma[i] - 1;
            poderes[indiceGuerrero] += armas[i].poder;

            // Verificar requisitos para cada arma
            //j es el índice del arma requisito
            //i es el índice del arma actual y cromosoma[i] nos dice
            //a qué guerrero está asignada esa arma
             for (int j = 0; armas[i].requisitos[j] > 0; j++)  {
                 //Si la condición se cumple le di las armas al mismo guerrero
                 if (cromosoma[armas[i].requisitos[j] - 1] != cromosoma[i]){
                    return false;
                }
            }

            // Verificar tipo de arma para vencer al guerrero
            bool tipoValido = false;
            for (int j = 0; guerreros[cromosoma[i] - 1].tiposPermitidos[j] > 0; j++) {
                //comparo el tipo de arma con la que el guerrero puede derrotar
                if (armas[i].tipo == guerreros[cromosoma[i] - 1].tiposPermitidos[j]){
                    tipoValido = true;
                    break; //como el tipo es válido se sale del bucle
                }
            }
            if (not tipoValido) {
                return false; //la solución no es válida para esta combinación de armas
            }
        }
    }

    // Verificar que el poder total sea suficiente
    for (int i = 0; i < cantGuerreros; i++) {
        if (poderes[i] < guerreros[i].poder) {
            return false;
        }
    }
    return true;
}

void imprimeSolucion(int * cromosoma, int cantArmas, struct Arma * armas,
        int cantGuerreros, struct Guerrero * guerreros) {

    for (int i = 1; i <= cantGuerreros; i++) {
        /*Imprimimos la mochila para cada guerrero*/
        cout << "Guerrero " << i << endl;
        cout << "Poder: " << guerreros[i - 1].poder << endl;
        cout << "Armas en mochila: ";
        for (int j = 0; j < cantArmas; j++) {
            if (cromosoma[j] == i) { //Debe coincidir con el guerrero
                cout << armas[j].letra << " ";
            }
        }
        cout << endl;
    }
}