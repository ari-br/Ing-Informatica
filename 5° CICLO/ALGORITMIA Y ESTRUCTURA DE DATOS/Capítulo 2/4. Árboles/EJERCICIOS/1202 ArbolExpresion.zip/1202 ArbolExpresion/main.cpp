/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 18 de septiembre de 2023, 05:39 PM
 */
#include <iostream>
#include <cstdlib>
#include "ArbolBinario.h"
#include "Pila.h"
using namespace std;
#include "funcionesArbolesBinarios.h"
#include "funcionesPila.h"
/*
 * ESTRUCTURA ÁRBOL BINARIO 2024-1 CON PILAS Y COLAS
 */
int EjecutarExpresion(struct ArbolBinario arbol);
int EjecutarExpresionRecursiva (struct NodoArbol * nodo);

int Operacion(char operador, int operando1, int operando2){
    if(operador=='+')
        return operando1+operando2;
    if(operador=='-')
        return operando1-operando2;
    if(operador=='*')
        return operando1*operando2;
    if(operador=='/')
        return operando1/operando2;
}

int EsOperador(char c){
    return (c=='+') or  (c=='-') or  (c=='*') or  (c=='/');
}

void OperacionPostFija(struct ArbolBinario & arbol){
    struct NodoArbol * operando1;
    struct NodoArbol * operando2;
    
    char valor[8]={'5','3','-','4','*','9','+','\0'};
    
    struct Pila pila;
    construir(pila);
    int i=0; //indice para recorrer todos los elementos (operadores y operandos)
    while (i<=7){
        if (EsOperador(valor[i])){  //El elemento a analizar es operador
            operando2=desapilar(pila);//obtenemos el nodo arbol que contiene el operando(número)
            operando1=desapilar(pila);//obtenemos el nodo arbol que contiene el operando(número)
            //una vez obtenidos los 2 números a operar, creamos el arbol que contiene como raiz el operador y como hijos los operandos
            plantarArbolBinario(arbol, operando1, valor[i], operando2);
            apilar(pila, arbol.raiz);
            
        }else{//El elemento es un operando (es decir un número)
            struct ArbolBinario arbol;
            construir(arbol);
            plantarArbolBinario(arbol, nullptr, valor[i], nullptr);//creo el nodo para el operando (es decir número)
            apilar(pila, arbol.raiz);//apilamos el nodo que acabamos de crear
        }
        i++;
    }
}

int EjecutarExpresion(struct ArbolBinario arbol){
    return EjecutarExpresionRecursiva (arbol.raiz);
}

int EjecutarExpresionRecursiva (struct NodoArbol * nodo){
    int resultado;
    int operando1, operando2;
    char elemento;
    
    //CASO BASE
    if (esNodoVacio(nodo))//Entonces viene de un nodo hoja.
        resultado = 0;
    else{
    //PARTE RECURSIVA
        elemento=raiz(nodo);//obtenemos el valor del nodo
        if (EsOperador(elemento)){//Si el nodo es un operador +,-,*,/
            operando1=EjecutarExpresionRecursiva(nodo->izquierda);
            operando2=EjecutarExpresionRecursiva(nodo->derecha);
            resultado=Operacion(elemento, operando1, operando2); 
        }else
            resultado=elemento-'0';
    }
    return resultado;
}

int main(int argc, char** argv) {

    /*Post Fijo con Arboles y Pilas*/
    //5 3 – 4 * 9 +
    int resultado;

    struct ArbolBinario arbol;
    construir(arbol);    
    
    OperacionPostFija(arbol);
    recorrerEnOrden(arbol);
    //Hasta aquí hemos creado el arbol de expresión
    //En Orden:   5     -     3     *     4     +     9 
    cout << endl;
    
    resultado= EjecutarExpresion(arbol);
    destruirArbolBinario(arbol);
    cout << "El resultado de la expresión es: " << resultado<<endl;
    return 0;
}

