/* 
 * File:   funcionesLista.h
 * Author: ANA RONCAL
 * Created on 26 de septiembre de 2023, 04:52 PM
 */

#ifndef FUNCIONESLISTA_H
#define FUNCIONESLISTA_H

void construir(struct Lista &);

struct Nodo * crearNodo(struct NodoArbol *, struct Nodo * siguiente);
void insertarAlFinal(struct Lista & lista, struct NodoArbol *);

void insertarEnOrden(struct Lista &, int);
struct NodoArbol * retornaCabeza( struct Lista  lista);
void insertarAlInicio(struct Lista &, struct NodoArbol *);
void eliminaCabeza(struct Lista  & lista);

const bool esListaVacia(const struct Lista &);
int longitud(const struct Lista &);

void destruir(struct Lista &);
void imprimir(const struct Lista &);

#endif /* FUNCIONESLISTA_H */

