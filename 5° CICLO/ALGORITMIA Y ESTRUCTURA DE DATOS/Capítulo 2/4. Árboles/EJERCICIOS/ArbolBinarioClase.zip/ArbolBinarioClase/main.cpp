/* 
 * File:   main.cpp
 * Author: Ana Roncal
 *
 * Created on 7 de noviembre de 2024, 16:00
 */

#include <iostream>
using namespace std;
#include "ArbolB.h"
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    struct ArbolBinario arbol1, arbol2, arbol3, arbol4, arbol5,
            arbol6, arbol7;
    construir(arbol1);

    struct Persona per1 {"Fernando",0},
            per2 {"Fiorella",0},
            per3 {"Pedro",0},
            per4 {"Felipe",0},
            per5 {"Florecia",0},
            per6 {"Patricia",0},
            per7 {"Danitza",0};
    cout <<"Es nodo vacío: " << esArbolVacio(arbol1) << endl;
    /*Como no hay criterios para insertar se planta*/
    plantarArbolBinario(arbol1, nullptr, per1, nullptr);
    plantarArbolBinario(arbol3, nullptr, per2, nullptr);
    plantarArbolBinario(arbol4, nullptr, per4, nullptr);
    plantarArbolBinario(arbol5, nullptr, per5, nullptr);
    plantarArbolBinario(arbol2, arbol1, per3, arbol3);
    plantarArbolBinario(arbol6, arbol4, per6, arbol5);
    plantarArbolBinario(arbol7, arbol2, per7, arbol6);
    
    /*recorrer para imprimir*/
    cout <<"Recorrer en pre orden" << endl;
    recorrerEnPreOrden(arbol7); cout << endl;
    
    cout <<"Recorrer en orden" << endl;
    recorrerEnOrden(arbol7); cout << endl;
    
    cout <<"Recorrer en post orden" << endl;
    recorrerEnPostOrden(arbol7); cout << endl;
    
    cout <<"recorre el árbol po rniveles " << endl;
    recorridoPorNivel(arbol7);
    
    cout << endl <<"Altura árbol: " << altura(arbol7) <<endl;
    cout<<"Número de hojas: "<<numeroHojas(arbol7) <<endl;
//    cout<<"Número de nodos: "<<numeroNodos(arbol7) <<endl;
//    cout<<"Es equilibrado: "<<esEquilibrado(arbol7)<<endl;
    
    return 0;
}

