/* 
 * File:   Persona.h
 * Author: ANA RONCAL
 *
 * Created on 7 de noviembre de 2024, 16:33
 */

#ifndef PERSONA_H
#define PERSONA_H

struct Persona{
    char nombre[50];
    int dni;
};

#endif /* PERSONA_H */