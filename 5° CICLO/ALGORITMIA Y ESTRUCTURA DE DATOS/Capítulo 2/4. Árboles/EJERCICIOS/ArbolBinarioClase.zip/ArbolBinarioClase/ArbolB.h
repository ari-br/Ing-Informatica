/* 
 * File:   ArbolB.h
 * Author: ANA RONCAL
 *
 * Created on 7 de noviembre de 2024, 16:04
 */

#ifndef ARBOLB_H
#define ARBOLB_H
#include "NodoArbol.h"
struct ArbolBinario{
    struct NodoArbol * raiz;
};

#endif /* ARBOLB_H */