/* 
 * File:   funciones.cpp
 * Author: ANA RONCAL
 * 
 * Created on 7 de noviembre de 2024, 16:07
 */

#include <iostream>
#include <iomanip>
#include <memory>
using namespace std;
#include "funciones.h"
#include "Persona.h"
#include "Cola.h"
#include "ArbolB.h"
#include "funcionesCola.h"

void construir(struct ArbolBinario & arbol){
    arbol.raiz = nullptr;
}

bool esNodoVacio(struct NodoArbol * nodo){
    return nodo == nullptr;
}

bool esArbolVacio(const struct ArbolBinario & arbol){
    return esNodoVacio(arbol.raiz);
}

void plantarArbolBinario(struct ArbolBinario & arbol, struct NodoArbol * izquierdo,
        struct Persona persona, struct NodoArbol * derecho){
    
    struct NodoArbol * nuevoNodo = crearNuevoNodo(izquierdo, persona, derecho);
    arbol.raiz = nuevoNodo;
}

struct NodoArbol * crearNuevoNodo(struct NodoArbol * izquierdo,
                             struct Persona persona, struct NodoArbol * derecho){
    struct NodoArbol * nuevoNodo = new struct NodoArbol;
    nuevoNodo->izquierdo = izquierdo;
    nuevoNodo->persona = persona;
    nuevoNodo->derecho = derecho;
    return nuevoNodo;
}

void plantarArbolBinario(struct ArbolBinario & arbol, struct ArbolBinario & izquierdo,
        struct Persona persona, struct ArbolBinario & derecho){
    
    struct NodoArbol * nuevoNodo = crearNuevoNodo(izquierdo.raiz, persona, derecho.raiz);
    arbol.raiz = nuevoNodo;
}

void recorrerEnPreOrden(const struct ArbolBinario & arbol){
    recorrerEnPreOrdenRecursivo(arbol.raiz);
}

void recorrerEnPreOrdenRecursivo(struct NodoArbol * nodo){
    if(not esNodoVacio(nodo)){
        imprimirNodo(nodo);
        recorrerEnPreOrdenRecursivo(nodo->izquierdo);
        recorrerEnPreOrdenRecursivo(nodo->derecho);
    }
}

void recorrerEnOrden(const struct ArbolBinario & arbol){
    recorrerEnOrdenRecursivo(arbol.raiz);
}

void recorrerEnOrdenRecursivo(struct NodoArbol * nodo){
    if(not esNodoVacio(nodo)){
        recorrerEnOrdenRecursivo(nodo->izquierdo);
        imprimirNodo(nodo);
        recorrerEnOrdenRecursivo(nodo->derecho);
    }
}


void recorrerEnPostOrden(const struct ArbolBinario & arbol){
    recorrerEnPostOrdenRecursivo(arbol.raiz);
}

void recorrerEnPostOrdenRecursivo(struct NodoArbol * nodo){
    if(not esNodoVacio(nodo)){
        recorrerEnPostOrdenRecursivo(nodo->izquierdo);
        recorrerEnPostOrdenRecursivo(nodo->derecho);
        imprimirNodo(nodo);
    }
}

void imprimirNodo(struct NodoArbol * nodo){
    cout << left << setw(15) << nodo->persona.nombre;
}

void recorridoPorNivel( struct ArbolBinario & arbol){
    
    struct Cola cola;
    construir(cola);
    if(not esArbolVacio(arbol)){
        encolar(cola, arbol.raiz);
        while(not esColaVacia(cola)){
            struct NodoArbol * nodo = desencolar(cola);
            imprimirNodo(nodo);
            if(not esNodoVacio(nodo->izquierdo)){
                encolar(cola, nodo->izquierdo);
            }
            if(not esNodoVacio(nodo->derecho)){
                encolar(cola, nodo->derecho);
            }  
        }
    }
    
    destruirCola(cola);
}
int maximo(int a, int b){
    return a >= b ? a : b;
}

int altura(const struct ArbolBinario & arbol){
    alturaRecursivo(arbol.raiz);
}
int alturaRecursivo(struct NodoArbol * nodo){
    if(esNodoVacio(nodo))
        return 0;
    else if(esNodoVacio(nodo->izquierdo) and esNodoVacio(nodo->derecho))
        return 0;
    else
        return 1 + maximo(alturaRecursivo(nodo->izquierdo), alturaRecursivo(nodo->derecho));
}

int  numeroHojas(const struct ArbolBinario & arbol){
    numeroHojasRecursivo(arbol.raiz);
}
int numeroHojasRecursivo(struct NodoArbol * nodo){
    if(esNodoVacio(nodo))
        return 0;
    else if(esNodoVacio(nodo->izquierdo) and esNodoVacio(nodo->derecho))
        return 1;
    else return numeroHojasRecursivo(nodo->izquierdo) + numeroHojasRecursivo(nodo->derecho);
    
}