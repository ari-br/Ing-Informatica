/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   funciones.h
 * Author: anaro
 *
 * Created on 7 de noviembre de 2024, 16:07
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void construir(struct ArbolBinario & arbol);
bool esArbolVacio(const struct ArbolBinario & arbol);
bool esNodoVacio(struct NodoArbol * nodo);
void plantarArbolBinario(struct ArbolBinario & arbol, struct NodoArbol * izquierdo,
        struct Persona persona, struct NodoArbol * derecho);
void plantarArbolBinario(struct ArbolBinario & arbol, struct ArbolBinario & izquierdo,
        struct Persona persona, struct ArbolBinario & derecho);
struct NodoArbol * crearNuevoNodo(struct NodoArbol * izquierdo,
                      struct Persona persona, struct NodoArbol * derecho);
void recorrerEnPreOrdenRecursivo(struct NodoArbol * nodo);
void recorrerEnPreOrden(const struct ArbolBinario & arbol);

void recorrerEnOrden(const struct ArbolBinario & arbol);
void recorrerEnOrdenRecursivo(struct NodoArbol * nodo);

void recorrerEnPostOrden(const struct ArbolBinario & arbol);
void recorrerEnPostOrdenRecursivo(struct NodoArbol * nodo);

void recorridoPorNivel( struct ArbolBinario & arbol);

void imprimirNodo(struct NodoArbol * nodo);


int altura(const struct ArbolBinario & arbol);
int alturaRecursivo(struct NodoArbol * nodo);
int maximo(int a, int b);

int  numeroHojas(const struct ArbolBinario & arbol);
int numeroHojasRecursivo(struct NodoArbol * nodo);

//int numeroNodos(const struct ArbolBinario & arbol);
//int numeroNodosRecursivo(struct NodoArbol * nodo);
//
//int esEquilibrado(const struct ArbolBinario & arbol);
//int esEquilibradoRecursivo(struct NodoArbol * nodo);

#endif /* FUNCIONES_H */
