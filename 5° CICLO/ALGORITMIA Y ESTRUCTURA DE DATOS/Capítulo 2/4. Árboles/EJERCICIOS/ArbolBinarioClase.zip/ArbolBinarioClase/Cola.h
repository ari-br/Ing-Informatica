/* 
 * File:   Cola.h
 * Author: ANA RONCAL
 *
 * Created on 26 de setiembre de 2024, 11:05
 */

#ifndef COLA_H
#define COLA_H
#include "Lista.h"
struct Cola{
    struct Lista lista;
};

#endif /* COLA_H */