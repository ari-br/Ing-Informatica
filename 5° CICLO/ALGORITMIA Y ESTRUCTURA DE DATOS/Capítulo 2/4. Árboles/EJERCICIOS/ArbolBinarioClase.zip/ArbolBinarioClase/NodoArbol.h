/* 
 * File:   NodoArbol.h
 * Author: ANA RONCAL
 *
 * Created on 7 de noviembre de 2024, 17:35
 */

#ifndef NODOARBOL_H
#define NODOARBOL_H

#include "Persona.h"
struct NodoArbol{
    struct Persona persona;
    struct NodoArbol * izquierdo;
    struct NodoArbol * derecho;
};

#endif /* NODOARBOL_H */