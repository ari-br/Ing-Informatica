// -*- C++ -*-

/* 
 * File:   Elemento.h
 * Author: ANA RONCAL
 *
 * Created on 31 de mayo de 2024, 20:46
 */

#ifndef ELEMENTO_H
#define ELEMENTO_H

struct Elemento{
    char capitulo[50];
    int relevancia;
};


#endif /* ELEMENTO_H */