/* 
 * File:   main.cpp
 * Author: ANA RONCAL
 * Created on 30 de mayo de 2025, 05:05 PM
 */

#include <iostream>
#include <iomanip>
#include "ArbolBinarioBusqueda.h"
using namespace std;
#include "funcionesABB.h"
#include "funcionesArbolesBinarios.h"

/*
 * ESTRUCTURA ÁRBOL BINARIO 2024-1
 */
//PARTE A: INSERTAR UN NUEVO NODO EN EL ARBOL - INICIO
void imprimeNodoNuevo(struct NodoArbol * nodo){
    cout<<setw(5)<<nodo->elemento<<" - "<<nodo->cantidad<<" ";
}
void recorrerEnOrdenRecursivoNuevo(struct NodoArbol * nodo){
    if(not esNodoVacio(nodo)){
        recorrerEnOrdenRecursivoNuevo(nodo->izquierda);
        imprimeNodoNuevo(nodo);
        recorrerEnOrdenRecursivoNuevo(nodo->derecha);
    }
}

void recorrerEnOrdenNuevo(const struct ArbolBinario & arbol){
    /*Imprime en orden*/
    recorrerEnOrdenRecursivoNuevo(arbol.raiz);
    
}
 void enOrdenNuevo(const struct ArbolBinarioBusqueda & arbol){
     recorrerEnOrdenNuevo(arbol.arbolBinario);
 }

void plantarArbolBBNuevo(struct NodoArbol *& nodo, struct NodoArbol * arbolIzquierdo,
         int elemento, int cantidad, struct NodoArbol * arbolDerecha){
     
     struct NodoArbol * nuevoNodo = new struct NodoArbol;
     nuevoNodo->derecha = arbolDerecha;
     nuevoNodo->elemento = elemento;
     nuevoNodo->cantidad = cantidad;
     nuevoNodo->izquierda = arbolIzquierdo;
     nodo = nuevoNodo;
 }
void insertarRecursivoNuevo(struct NodoArbol *& nodo, int elemento, int cantidad){
    if(esNodoVacio(nodo))
         plantarArbolBBNuevo(nodo, nullptr, elemento, cantidad, nullptr);
     else
         if(elemento > nodo->elemento)
             insertarRecursivoNuevo(nodo->derecha, elemento, cantidad);
         else
             if(elemento < nodo->elemento)
                 insertarRecursivoNuevo(nodo->izquierda, elemento, cantidad);
         
}
void insertarNuevo(struct ArbolBinarioBusqueda & arbol, int elemento, int cantidad){
    insertarRecursivoNuevo(arbol.arbolBinario.raiz, elemento, cantidad);
}
//PARTE A: INSERTAR UN NUEVO NODO EN EL ARBOL - FIN

//PARTE C: ATENDER PEDIDO - INICIO
struct NodoArbol * eliminarNodoRecursivoNuevo(struct NodoArbol * nodo, int elemento){
    if(esNodoVacio(nodo))
        return nodo;
    /*Buscamos el nodo a eliminar*/
    if(elemento < nodo->elemento)
        nodo->izquierda = eliminarNodoRecursivoNuevo(nodo->izquierda, elemento);
    else if(elemento > nodo->elemento)
        nodo->derecha = eliminarNodoRecursivoNuevo(nodo->derecha, elemento);
    else{
        /*encontró el elemento*/
        /*caso de una sola hoja derecha*/
        if(esNodoVacio(nodo->izquierda)){
            struct NodoArbol * hijo = nodo->derecha;
            delete nodo;
            return hijo;
        }
        else if(esNodoVacio(nodo->derecha)){
            struct NodoArbol * hijo = nodo->izquierda;
            delete nodo;
            return hijo;
        }
        else{
            /*el elemento a eliminar tiene dos hijos*/
            struct NodoArbol * minNodo = minimoArbol(nodo->derecha);
            nodo->elemento = minNodo->elemento;
            nodo->derecha = eliminarNodoRecursivoNuevo(nodo->derecha, minNodo->elemento);   
        }
    }
    return nodo;
}
void eliminarNodoNuevo(struct ArbolBinarioBusqueda & arbol, int dato){
    arbol.arbolBinario.raiz = eliminarNodoRecursivoNuevo(arbol.arbolBinario.raiz, dato);
}

//PARTE C: ATENDER PEDIDO - FIN

int main(int argc, char** argv) {

    struct ArbolBinarioBusqueda arbol;

    construir(arbol);

    insertarNuevo(arbol, 20170620, 20);
    insertarNuevo(arbol, 20170810, 20);
    insertarNuevo(arbol, 20180211, 20);
    insertarNuevo(arbol, 20180409, 10);
    
    enOrdenNuevo(arbol);
    
    //Despachar pedido, tomando desde los lotes mas antiguos a los mas recientes.
    int cantidad_productos=70;
    cout<<endl<<endl<<"Cantidad de productos a despachar: "<< cantidad_productos<<endl;
    
    //vamos a ir tomando de los lotes y reduciendo la cantidad de productos a procesar
    while (cantidad_productos>0) {//mientras tengamos productos por despachar
        //referenciamos el lote más antiguo, es decir el nodo menor
        NodoArbol * lote_mas_antiguo = minimoArbol(arbol.arbolBinario.raiz);
        if (lote_mas_antiguo->cantidad <= cantidad_productos){//si la cantidad del lote es suficiente
            cantidad_productos-= lote_mas_antiguo->cantidad;
            eliminarNodoNuevo(arbol, lote_mas_antiguo->elemento);
        }else{
            lote_mas_antiguo->cantidad-=cantidad_productos;//reduzco la cantidad del lote
            cantidad_productos=0;//ya atendí todo el pedido, entonces se vuelve 0
        }
    }
    enOrdenNuevo(arbol);
    
    
}

