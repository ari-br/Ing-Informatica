/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana Burga
 * Código: 20226705
 * Created on 7 de diciembre de 2024, 09:11
 */

#include <iomanip>
#include <iostream>
#include <fstream>
#include "Plato.h"
using namespace std;

/*
 * 
 */
void intercambiar(Plato &a,Plato &b){
    Plato aux=a;
    a=b;
    b=aux;
}


int partir(Plato *arr,int ini,int fin){
    int piv=ini,i=ini;
    for (int k = ini+1; k <= fin; k++) {
        if(arr[k].porcentajeReservas>arr[piv].porcentajeReservas){
            i++;
            intercambiar(arr[i],arr[k]);
        }
    }
    intercambiar(arr[i],arr[piv]);
    return i;
}

void quicksort(Plato *arr,int ini,int fin){
    if(ini>fin) return;
    int piv=partir(arr,ini,fin);
    quicksort(arr,ini,piv-1);
    quicksort(arr,piv+1,fin);
}


int main(int argc, char** argv) {
    Plato arr[10];
    ifstream arch("Platos.txt",ios::in);
    if(!arch){
        cout<<"No se pudo abrir el archivo Platos"<<endl;
        exit(1);
    }
    int n = 0;
    char c;
    for (n; 1; n++) {
        getline(arch,arr[n].nombre,',');
        if(arch.eof()) break;
        arch>>arr[n].cantidadDisponible>>c>>arr[n].cantidadReservada;
        arr[n].porcentajeReservas=((double)arr[n].cantidadReservada/arr[n].cantidadDisponible)*100;
        arch.get();
    }
    
    quicksort(arr,0,n-1);
    
    int top=3;
    cout<<"Top "<<top<<" platos con mayor porcentaje de reservas:"<<endl;
    for (int i = 0; i < top; i++) {
        cout<<arr[i].nombre<<" - "<<arr[i].porcentajeReservas<<"%"<<endl;
    }

    
    return 0;
}

