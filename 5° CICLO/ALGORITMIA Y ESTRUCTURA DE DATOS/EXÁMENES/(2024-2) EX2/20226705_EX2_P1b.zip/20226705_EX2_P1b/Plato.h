/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Plato.h
 * Author: alulab14
 *
 * Created on 7 de diciembre de 2024, 09:12
 */

#ifndef PLATO_H
#define PLATO_H

#include <cstring>
using namespace std;

struct Plato{
    string nombre;
    int cantidadDisponible;
    int cantidadReservada;
    double porcentajeReservas;
};

#endif /* PLATO_H */

