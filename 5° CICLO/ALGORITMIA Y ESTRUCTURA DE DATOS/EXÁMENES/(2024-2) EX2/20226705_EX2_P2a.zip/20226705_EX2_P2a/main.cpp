/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana Burga
 * Código: 20226705
 * Created on 7 de diciembre de 2024, 09:30
 */

#include <iomanip>
#include <iostream>

#include "ArbolB.h"
#include "funcionesAB.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    ArbolBinario arbol;
    
    construir(arbol);
    crearArbol(arbol);
    
    int num=6;
    cout<<"El número "<<num;
    if(buscar(arbol,num))
        cout<<" SÍ ";
    else
        cout<<" NO ";
    cout<<"está en el árbol"<<endl;
    cout<<endl;
    
    recorrerPreOrden(arbol);
    
    //buscar y recorrer usan métodos similares para recorrer el árbol
    
    return 0;
}

