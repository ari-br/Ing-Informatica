/* 
 * File:   funcionesAB.cpp
 * Author: ANA RONCAL
 * 
 * Created on 27 de octubre de 2024, 17:00
 */

#include <iostream>
#include <iomanip>
#include <complex>
#include "ArbolB.h"
using namespace std;
#include "funcionesAB.h"

void construir(struct ArbolBinario & arbol) {
    arbol.raiz = nullptr;
}

void crearArbol(ArbolBinario &arbol){
    plantarArbolBinario(arbol.raiz,nullptr,0,false,nullptr);
    plantarArbolBinario(arbol.raiz->derecha,nullptr,0,true,nullptr);
    plantarArbolBinario(arbol.raiz->izquierda,nullptr,1,true,nullptr);
    plantarArbolBinario(arbol.raiz->izquierda->izquierda,nullptr,1,true,nullptr);
    plantarArbolBinario(arbol.raiz->izquierda->izquierda->izquierda,nullptr,1,false,nullptr);
    plantarArbolBinario(arbol.raiz->izquierda->izquierda->izquierda->derecha,nullptr,0,true,nullptr);
    plantarArbolBinario(arbol.raiz->izquierda->derecha,nullptr,0,false,nullptr);
    plantarArbolBinario(arbol.raiz->izquierda->derecha->izquierda,nullptr,1,true,nullptr);
    plantarArbolBinario(arbol.raiz->izquierda->derecha->derecha,nullptr,false,0,nullptr);
    plantarArbolBinario(arbol.raiz->izquierda->derecha->derecha->izquierda,nullptr,1,true,nullptr);
}

bool esNodoVacio(struct NodoArbol * raiz) {
    return raiz == nullptr;
}

bool esArbolVacio(const struct ArbolBinario & arbol) {
    return esNodoVacio(arbol.raiz);
}

struct NodoArbol * crearNuevoNodo(struct NodoArbol * izquierda, int elemento,
        bool flag, struct NodoArbol * derecha) {

    struct NodoArbol * nuevo = new struct NodoArbol;
    nuevo->derecha = derecha;
    nuevo->izquierda = izquierda;
    nuevo->elemento = elemento;
    nuevo->flag=flag;
    return nuevo;
}

//void plantarArbolBinario(struct ArbolBinario & arbol, struct NodoArbol * izquierda, 
//                         int elemento, struct NodoArbol * derecha) {
//    
//    struct NodoArbol * nuevoNodo = crearNuevoNodo(izquierda, elemento, derecha);
//    arbol.raiz = nuevoNodo;
//
//}

void plantarArbolBinario(struct NodoArbol *& raiz, 
                    struct NodoArbol * izquierda, int elemento, bool flag,
                    struct NodoArbol * derecha){
    
    struct NodoArbol * nuevoNodo = crearNuevoNodo(izquierda, elemento,flag, derecha);
    raiz = nuevoNodo;
}

//void plantarArbolBinario(struct ArbolBinario & arbol, struct ArbolBinario & arbolIzquierda, 
//                         int elemento, struct ArbolBinario & arbolDerecha) {
//    struct NodoArbol * nuevoNodo = crearNuevoNodo(arbolIzquierda.raiz, elemento,
//            arbolDerecha.raiz);
//    arbol.raiz = nuevoNodo;
//
//}

int binarioAdecimal(int *arr,int i){
    int num=0,exp=0;
    for (int k = i; k>0; k--){
        num+=arr[k]*pow(2,exp++);
    }
    return num;
}

void recorrerPreOrdenRecursivo(struct NodoArbol * nodo,int *arr,int i,bool flag){
    if(not esNodoVacio(nodo)){
        arr[i]=nodo->elemento;
        if(nodo->flag){
            for (int k = 1; k<=i; k++)
                cout<<arr[k];
            if(flag) cout<<": "<<binarioAdecimal(arr,i)<<endl;
        }
        recorrerPreOrdenRecursivo(nodo->izquierda,arr,i+1,true);
        recorrerPreOrdenRecursivo(nodo->derecha,arr,i+1,true);
    }
}

void recorrerPreOrden(const struct ArbolBinario & arbol){
    int arr[10]{-1},i=0;
    recorrerPreOrdenRecursivo(arbol.raiz,arr,i,false);
}

bool buscar(const struct ArbolBinario &arbol,int num){
    int arr[10]{-1},i=0;
    return buscarRecursivo(arbol.raiz,arr,i,false,num);
}

bool buscarRecursivo(struct NodoArbol * nodo,int *arr,int i,bool flag,int num){
    if(not esNodoVacio(nodo)){
        arr[i]=nodo->elemento;
        if(nodo->flag){
            if(flag)
                if(binarioAdecimal(arr,i)==num)
                    return true;
        }
        return buscarRecursivo(nodo->izquierda,arr,i+1,true,num) or buscarRecursivo(nodo->derecha,arr,i+1,true,num);
    }
}

void recorrerEnOrden(const struct ArbolBinario & arbol){
    recorrerEnOrdenRecursivo(arbol.raiz);
}
void recorrerEnOrdenRecursivo(struct NodoArbol * nodo){
    if (not esNodoVacio(nodo)){
        recorrerEnOrdenRecursivo(nodo->izquierda);
        imprimirNodo(nodo);
        recorrerEnOrdenRecursivo(nodo->derecha);
    }
}

void recorrerPostOrden(const struct ArbolBinario & arbol){
    recorrerPostOrdenRecursivo(arbol.raiz);
}
void recorrerPostOrdenRecursivo(struct NodoArbol * nodo){
    if(not esNodoVacio(nodo)){
        recorrerPostOrdenRecursivo(nodo->izquierda);
        recorrerPostOrdenRecursivo(nodo->derecha);
        imprimirNodo(nodo);
    }
}

int altura(const struct ArbolBinario & arbol){
    return alturaRecursivo(arbol.raiz);
}

int alturaRecursivo(struct NodoArbol * nodo){
    if(esNodoVacio(nodo))
        return 0;
    else if(esNodoVacio(nodo->izquierda) and esNodoVacio(nodo->derecha))
        return 0;
    else
        return 1 + maximo(alturaRecursivo(nodo->izquierda), alturaRecursivo(nodo->derecha));
}

int maximo(int a, int b){
    return a >= b ? a : b;
}

int  numeroHojas(const struct ArbolBinario & arbol){
    return numeroHojasRecursivo(arbol.raiz);
}

int numeroHojasRecursivo(struct NodoArbol * nodo){
    if(esNodoVacio(nodo))
        return 0;
    else if(esNodoVacio(nodo->izquierda) and esNodoVacio(nodo->derecha))
        return 1;
    else return numeroHojasRecursivo(nodo->izquierda) + numeroHojasRecursivo(nodo->derecha);
}


int numeroNodos(const struct ArbolBinario & arbol){
    return numeroNodosRecursivo(arbol.raiz);
}

int numeroNodosRecursivo(struct NodoArbol * nodo){
    if(esNodoVacio(nodo))
        return 0;
    else
        return 1 + numeroNodosRecursivo(nodo->izquierda) + numeroNodosRecursivo(nodo->derecha);
}

int esEquilibrado(const struct ArbolBinario & arbol){
    return esEquilibradoRecursivo(arbol.raiz);
}

int esEquilibradoRecursivo(struct NodoArbol * nodo){
    //se simula el retornar un booleano
    if(esNodoVacio(nodo))
        return 1;
    else{
        int alturaHijoIzquierdo = alturaRecursivo(nodo->izquierda);
        int alturaHijoDerecho = alturaRecursivo(nodo->derecha);
        int diferencia = abs(alturaHijoIzquierdo - alturaHijoDerecho);
        return diferencia <=1 and esEquilibradoRecursivo(nodo->izquierda) and
                esEquilibradoRecursivo(nodo->derecha);
    }
    
}

void imprimirNodo(struct NodoArbol * raiz){
    cout<<setw(5)<<raiz->elemento;
}

void imprimir(const struct ArbolBinario & arbol){
    imprimirNodo(arbol.raiz);
}

void destruirArbolBinario(struct ArbolBinario & arbol){
    destruirRecursivo(arbol.raiz);
    arbol.raiz = nullptr;
}

void destruirRecursivo(struct NodoArbol * nodo){
    if(not (esNodoVacio(nodo))){
        destruirRecursivo(nodo->izquierda);
        destruirRecursivo(nodo->derecha);
        delete nodo;
    }
}