/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana Burga
 * Código: 20226705
 * Created on 7 de diciembre de 2024, 10:33
 */

#include <iomanip>
#include <iostream>

#include "ArbolBB.h"
#include "funcionesABB.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    ArbolBinarioBusqueda arbol;
    
    construir(arbol);
    
    insertar(arbol,4,'P');
    insertar(arbol,2,'U');
    insertar(arbol,6,'0');
    insertar(arbol,1,'P');
    insertar(arbol,3,'C');
    insertar(arbol,5,'2');
    insertar(arbol,7,'2');
    insertar(arbol,8,'4');
    
    int intentos=3,longitud=8;
    bool flag=false,noacceso=true;
    cout<<"Ingrese el número máximo de intentos: "<<intentos<<endl;
    cout<<endl;
    
    //La lógica er verificar la contraseña ingresada y luego usando un recorrido
    //en orden, verificar cada caracter de esa contrasela con la real
    //no llegué a terminar la lógica
    
    //No se ingresaron datos solo porque estaba probando
    for (int i = 0; i < intentos; i++) {
        char cont[]={'P','U','C','P','2','0','2','4',0};
        cout<<"Intento "<<i+1<<"/"<<intentos<<". Ingrese la contraseña: "<<cont<<endl;
        
        if(longitud!=(sizeof(cont)/sizeof(cont[0]))-1){
            cout<<"Longitud incorrecta. ";
            flag=true;
        }
        if(verificar(cont,arbol)){
            cout<<"Acceso concedido";
            break;
        }
        if(flag)
            cout<<"Intento fallido.";
        
        cout<<endl;
        cout<<endl;
    }
    
    if(noacceso)
        cout<<"Se llegó al número de intentos fallidos permitidos."<<endl;

    
    
    enOrden(arbol);
    
    
    return 0;
}

