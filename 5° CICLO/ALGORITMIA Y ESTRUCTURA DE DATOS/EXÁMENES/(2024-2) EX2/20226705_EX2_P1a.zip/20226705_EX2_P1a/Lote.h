/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Lote.h
 * Author: alulab14
 *
 * Created on 7 de diciembre de 2024, 08:16
 */

#ifndef LOTE_H
#define LOTE_H

struct Lote{
    int num;
    int cant;
};

#endif /* LOTE_H */

