/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana Burga
 * Código: 20226705
 * Created on 7 de diciembre de 2024, 08:11
 */

#include <iomanip>
#include <iostream>
#include <fstream>
#include "Lote.h"
using namespace std;

/*
 * 
 */
int encontrarLoteInicial(Lote *arr,int ini,int fin,int cant){
    if(ini==fin){
        if(arr[ini].cant!=cant) return -1;
        return arr[ini].num;
    }
    int med=(ini+fin)/2;
    
    if(arr[med].cant<cant)
        encontrarLoteInicial(arr,med+1,fin,cant);
    else
        encontrarLoteInicial(arr,ini,med,cant);
}

int encontrarLoteFinal(Lote *arr,int ini,int fin,int cant,int loteIni){
    if(ini==fin){
        if(arr[ini].cant!=cant) return loteIni;
        return arr[ini].num;
    }
    int med=(ini+fin)/2;
    
    if(arr[med].cant>cant)
        encontrarLoteFinal(arr,ini,med,cant,loteIni);
    else
        encontrarLoteFinal(arr,med+1,fin,cant,loteIni);
}


int main(int argc, char** argv) {
    ifstream arch("Lotes.txt",ios::in);
    if(!arch){
        cout<<"No se pudo abrir el archivo Lotes"<<endl;
        exit(1);
    }
    int n=9;
    Lote arr[n];
    for (int i = 0; i < n; i++) {
        arch>>arr[i].num>>arr[i].cant;
        if(arch.eof()) break;
    }
    
    int cant,loteIni;
    
    cant=3;
    loteIni=encontrarLoteInicial(arr,0,n-1,cant);
    cout<<"Lotes de "<<cant<<" productos"<<endl;
    cout<<"Lote Inicial: "<<loteIni<<endl;
    cout<<"Lote Final: "<<encontrarLoteFinal(arr,0,n-1,cant,loteIni)<<endl;
    cout<<endl;
    
    cant=6;
    loteIni=encontrarLoteInicial(arr,0,n-1,cant);
    cout<<"Lotes de "<<cant<<" productos"<<endl;
    cout<<"Lote Inicial: "<<loteIni<<endl;
    cout<<"Lote Final: "<<encontrarLoteFinal(arr,0,n-1,cant,loteIni)<<endl;
    cout<<endl;
    
    cant=8;
    loteIni=encontrarLoteInicial(arr,0,n-1,cant);
    cout<<"Lotes de "<<cant<<" productos"<<endl;
    cout<<"Lote Inicial: "<<loteIni<<endl;
    cout<<"Lote Final: "<<encontrarLoteFinal(arr,0,n-1,cant,loteIni)<<endl;
    cout<<endl;
    
    cant=4;
    loteIni=encontrarLoteInicial(arr,0,n-1,cant);
    cout<<"Lotes de "<<cant<<" productos"<<endl;
    cout<<"Lote Inicial: "<<loteIni<<endl;
    cout<<"Lote Final: "<<encontrarLoteFinal(arr,0,n-1,cant,loteIni)<<endl;
    cout<<endl;
    
    
    return 0;
}

