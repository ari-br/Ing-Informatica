/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 7 de octubre de 2024, 10:37 AM
 */

#include <iostream>
#define N 8
using namespace std;

int matriz[N][N] = {{1,1,1,0,0},
                    {1,1,1,0,1},
                    {0,0,1,0,0},
                    {0,1,1,1,0},
                    {0,0,1,0,1}};
int conoce(int a,int b){
    return matriz[a][b];
}

int buscafamoso(int cand,int ini,int n){
    if(ini==n) return cand;
    if(conoce(cand,ini))
        buscafamoso(ini,ini+1,n);
    else
        buscafamoso(cand,ini+1,n);
}

int famoso(int n){
    int id,conta1=0,conta2=0;
    id = buscafamoso(0,1,n); 
    for(int i=0;i<n;i++){
        if(id!=i){
            conta1+=conoce(id,i);
            conta2+=conoce(i,id);
        }
    }
    if(conta1==0 and conta2==n-1)
        return id;
    return -1;
}

int main(int argc, char** argv) {
    int n=5;
    cout << "El famoso tiene el id="<< famoso(n);

    return 0;
}

