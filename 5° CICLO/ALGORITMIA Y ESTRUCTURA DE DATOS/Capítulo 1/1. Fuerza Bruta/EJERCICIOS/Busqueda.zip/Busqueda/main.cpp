
/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 18 de marzo de 2024, 08:59 AM
 */

#include <iostream>

using namespace std;

int buscasec(int arr[],int n,int valor){
    
    for(int i=0;i<n;i++){
        if(arr[i]==valor)
            return i;
    }
    return -1;
}
        
int main(int argc, char** argv) {
    int arr[]={4,2,9,7,5,1};
    int n=6;
    
    
    cout << buscasec(arr,n,4);
    
    
    return 0;
}

