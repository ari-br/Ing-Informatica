/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 19 de agosto de 2024, 11:34 AM
 */

#include <iostream>
#include <cmath>
#define MAX 20
int solu[MAX];
int cont=0;

using namespace std;

void cargabin(int num,int n,int cromo[]){
    int res,i=0;
    for(int j=0;j<n;j++) cromo[j]=0;
    while(num>0){
        res = num%2;
        num = num/2;
        cromo[i] = res;
        i++;
    }
}



int main(int argc, char** argv) {
    int paq[]={1,2,4,12,1};
    int peso=15,parcial,maxpeso=0,maxcomb;
    int n=5;
    int cromo[n];
    int opcion=(int)pow(2,n);
    
    for(int i=0;i<opcion;i++){
        cargabin(i,n,cromo);
        parcial=0;
        for(int j=0;j<n;j++){
            parcial=paq[j]*cromo[j]+parcial;  
        }    
        if(parcial<=peso && parcial>=maxpeso){
            maxpeso=parcial;
            maxcomb=i;
            if(peso==parcial){
                solu[cont]=i;
                cont++;
            }
        }
    }
    cout << "Solucion:" <<endl;
    cout << maxpeso <<" "<<maxcomb<<endl;
    cout <<"Soluciones optimas:"<<endl;
    for(int i=0;i<cont;i++)
        cout << solu[i]<<endl;
    
    return 0;
}

