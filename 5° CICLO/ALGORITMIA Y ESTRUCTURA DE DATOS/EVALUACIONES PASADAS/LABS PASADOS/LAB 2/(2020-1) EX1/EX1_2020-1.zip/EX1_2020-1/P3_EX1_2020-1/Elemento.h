/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Elemento.h
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 05:55 PM
 */

#ifndef ELEMENTO_H
#define ELEMENTO_H

struct Elemento{
    int hora;
    char* dia;
};

#endif /* ELEMENTO_H */

