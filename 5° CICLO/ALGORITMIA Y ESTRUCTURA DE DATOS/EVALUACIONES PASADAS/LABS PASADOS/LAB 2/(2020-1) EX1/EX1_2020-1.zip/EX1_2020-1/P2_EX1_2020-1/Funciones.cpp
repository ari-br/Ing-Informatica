/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   Funciones.cpp
 * Author: Ariana
 * 
 * Created on 11 de octubre de 2024, 03:36 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Nodo.h"
#include "Pila.h"
#include "Funciones.h"

void fusionarPilas(Pila& pila1, Pila& pila2) {
    Pila aux;
    construirPila(aux);
    int caja1,caja2;
    bool apilado1=true,apilado2=true;
    
    while(!esPilaVacia(pila1) and !esPilaVacia(pila2)){
        if(!esPilaVacia(pila1) and apilado1){
            caja1=desapilar(pila1);
            apilado1=false;
        }
        if(!esPilaVacia(pila2) and apilado2){
            caja2=desapilar(pila2);
            apilado2=false;
        }
        if(caja1<=caja2){
            apilar(aux,caja1);
            apilado1=true;
        }
        if(caja2<=caja1){
            apilar(aux,caja2);
            apilado2=true;
        }
    }
    
    while(!esPilaVacia(aux)){
        apilar(pila2,desapilar(aux));
    }
}

bool esPilaVacia(Pila &pila){
    return (pila.cima==nullptr);
}

void construirPila(Pila &pila){
    pila.cima=nullptr;
    pila.longitud=0;
}

void apilar(Pila &pila,int elemento){
    Nodo *nuevoNodo=crearNuevoNodo(elemento,pila.cima);
    pila.cima=nuevoNodo;
    pila.longitud++;
}

int desapilar(Pila &pila){
    int elemento=pila.cima->elemento;
    pila.cima=pila.cima->siguiente;
    pila.longitud--;
    return elemento;
}

Nodo *crearNuevoNodo(int elemento,Nodo *siguiente){
    Nodo *nuevoNodo=new Nodo;
    nuevoNodo->elemento=elemento;
    nuevoNodo->siguiente=siguiente;
    return nuevoNodo;
}

void imprimirPila(const Pila pila){
    Nodo *recorrido=pila.cima;
    
    if(recorrido==nullptr){
        cout<<"La pila está vacía, no se puede imprimir";
    }else{
        while(recorrido!=nullptr){
            cout<<left<<setw(3)<<recorrido->elemento;
            recorrido=recorrido->siguiente;
        }
    }
    cout<<endl;
}