/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   Funciones.h
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 05:57 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void construirLista(Lista &lista);
void insertarAlFinal(Lista &lista,int hora,const char*dia);
Nodo *crearNuevoNodo(int hora,const char*dia,Nodo *siguiente);
char *devolverPuntChar(const char*dia);
Nodo *devolverUltimoNodo(Lista &lista);
void imprimirLista(const Lista lista);
bool esListaVacia(const Lista lista);
void ordenarLista(Lista &lista);
void fusionarListas(Lista &listaFusionada,Lista &lista);
void AperturaIf(ifstream &arch,const char *nomb);


#endif /* FUNCIONES_H */
