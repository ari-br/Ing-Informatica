/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 05:53 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Elemento.h"
#include "Nodo.h"
#include "Listas.h"
#include "Funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    ifstream arch("Semana.txt",ios::in);
    AperturaIf(arch,"Semana.txt");
    
    Lista lunes,martes,miercoles,jueves,viernes;
    
    //Construir listas
    construirLista(lunes);
    construirLista(martes);
    construirLista(miercoles);
    construirLista(jueves);
    construirLista(viernes);
    
    //Insertar datos
    cout<<"Listas iniciales:"<<endl;
    int hora;
    //Lunes
    while (1) {
        arch>>hora;
        if(hora==0) break;
        insertarAlFinal(lunes,hora,"Lunes");
    }
    imprimirLista(lunes);
    
    //Martes
    while (1) {
        arch>>hora;
        if(hora==0) break;
        insertarAlFinal(martes,hora,"Martes");
    }
    imprimirLista(martes);
    
    //Miercoles
    while (1) {
        arch>>hora;
        if(hora==0) break;
        insertarAlFinal(miercoles,hora,"Miercoles");
    }
    imprimirLista(miercoles);
    
    //Jueves
    while (1) {
        arch>>hora;
        if(hora==0) break;
        insertarAlFinal(jueves,hora,"Jueves");
    }
    imprimirLista(jueves);
    
    //Viernes
    while (1) {
        arch>>hora;
        if(hora==0) break;
        insertarAlFinal(viernes,hora,"Viernes");
    }
    imprimirLista(viernes);
    cout<<endl;
    
    //Ordenar listas
    cout<<"Listas ordenadas:"<<endl;
    
    ordenarLista(lunes);
    ordenarLista(martes);
    ordenarLista(miercoles);
    ordenarLista(jueves);
    ordenarLista(viernes);
    
    imprimirLista(lunes);
    imprimirLista(martes);
    imprimirLista(miercoles);
    imprimirLista(jueves);
    imprimirLista(viernes);
    cout<<endl;
    
    //Lista fusionada
    Lista listaFusionada;
    construirLista(listaFusionada);
    fusionarListas(listaFusionada,lunes);
    fusionarListas(listaFusionada,martes);
    fusionarListas(listaFusionada,miercoles);
    fusionarListas(listaFusionada,jueves);
    fusionarListas(listaFusionada,viernes);
    cout<<"Lista fusionada: ";
    imprimirLista(listaFusionada);
    cout<<endl;
    
    //Lista final
    cout<<"Lista final: ";
    ordenarLista(listaFusionada);
    imprimirLista(listaFusionada);
    
    
    return 0;
}

