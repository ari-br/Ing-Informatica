/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   Funciones.cpp
 * Author: Ariana
 * 
 * Created on 11 de octubre de 2024, 08:58 AM
 */

#include <iostream>
#include <fstream>
using namespace std;
#include "Pila.h"
#include "Funciones.h"

void AperturaIf(ifstream &arch,const char*nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}

void construirPila(Pila &pila){
    pila.cima=nullptr;
    pila.longitud=0;
}

bool esPilaVacia(Pila &pila){
    return (pila.cima==nullptr);
}

int cimaPila(Pila &pila){
    return pila.cima->indice;
}

Nodo *crearNuevoNodo(int indice,Nodo *siguiente){
    Nodo *nuevoNodo=new Nodo;
    nuevoNodo->indice=indice;
    nuevoNodo->siguiente=siguiente;
    return nuevoNodo;
}

void apilar(Pila &pila,int indice){
    Nodo *nuevoNodo=crearNuevoNodo(indice,pila.cima);
    pila.cima=nuevoNodo;
    pila.longitud++;
}

int desapilar(Pila &pila){
    int cima;
    Nodo *nodo=pila.cima;
    cima=nodo->indice;
    pila.cima=nodo->siguiente;
    pila.longitud--;
    return cima;
}

int devolverFrecMax(int *frecuencia,int &durMax,int cantDat){
    int frecMax=0,i=0,cima,frecActual,durActual,areaActual,areaMax=0;
    Pila pilaFrec;
    construirPila(pilaFrec);
    
    while(i<cantDat){
        if(esPilaVacia(pilaFrec) or frecuencia[i]>=frecuencia[cimaPila(pilaFrec)]){
            apilar(pilaFrec,i);
            i++;
        }else{
            cima=desapilar(pilaFrec);
            frecActual=frecuencia[cima];
            if(!esPilaVacia(pilaFrec)){
                durActual=i-cimaPila(pilaFrec)-1;
            }else{
                durActual=i;
            }
            areaActual=frecActual*durActual;
            if(areaActual>areaMax){
                areaMax=areaActual;
                frecMax=frecActual;
                durMax=durActual;
            }
        }
    }
    
    while(!esPilaVacia(pilaFrec)){
        cima=desapilar(pilaFrec);
        frecActual=frecuencia[cima];
        if(!esPilaVacia(pilaFrec)){
            durActual=i-cimaPila(pilaFrec)-1;
        }else{
            durActual=i;
        }
        areaActual=frecActual*durActual;
        if(areaActual>areaMax){
            areaMax=areaActual;
            frecMax=frecActual;
            durMax=durActual;
        }
    }
    
    return frecMax;
}