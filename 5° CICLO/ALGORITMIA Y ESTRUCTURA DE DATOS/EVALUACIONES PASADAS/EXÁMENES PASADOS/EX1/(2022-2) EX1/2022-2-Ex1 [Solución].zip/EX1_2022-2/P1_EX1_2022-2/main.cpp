/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 * Código: 20226705
 * Created on 9 de octubre de 2024, 04:18 PM
 */
#include <iostream>
#include <cstdlib>
using namespace std;
#include "Lista.h"
#include "Funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    Lista lunes,martes,miercoles,jueves,viernes;
    
    //Construir listas
    construirLista(lunes);
    construirLista(martes);
    construirLista(miercoles);
    construirLista(jueves);
    construirLista(viernes);
    
    //Llenar listas
    //Lunes:
    insertarALFinal(lunes,8,6,"Lunes");
    insertarALFinal(lunes,10,14,"Lunes");
    insertarALFinal(lunes,12,1,"Lunes");
    
    //Martes:
    insertarALFinal(martes,9,3,"Martes");
    insertarALFinal(martes,11,8,"Martes");
    //Miercoles:
    insertarALFinal(miercoles,8,2,"Miercoles");
    insertarALFinal(miercoles,9,5,"Miercoles");
    insertarALFinal(miercoles,10,10,"Miercoles");
    //Jueves:
    insertarALFinal(jueves,14,13,"Jueves");
    insertarALFinal(jueves,15,9,"Jueves");
    insertarALFinal(jueves,16,11,"Jueves");
    //Viernes:
    insertarALFinal(viernes,17,4,"Viernes");
    insertarALFinal(viernes,18,12,"Viernes");
    insertarALFinal(viernes,19,7,"Viernes");
    
    //Imprimir listas
    cout<<"Listas iniciales:"<<endl;
    imprimirLista(lunes);
    imprimirLista(martes);
    imprimirLista(miercoles);
    imprimirLista(jueves);
    imprimirLista(viernes);
    cout<<endl;
    
    //Ordenar listas
    ordenarLista(lunes);
    ordenarLista(martes);
    ordenarLista(miercoles);
    ordenarLista(jueves);
    ordenarLista(viernes);
    
    cout<<"Listas ordenadas:"<<endl;
    imprimirLista(lunes);
    imprimirLista(martes);
    imprimirLista(miercoles);
    imprimirLista(jueves);
    imprimirLista(viernes);
    cout<<endl;
    
    //Fusionar listas
    Lista listaFusionada;
    construirLista(listaFusionada);
    fusionarListas(listaFusionada,lunes);
    fusionarListas(listaFusionada,martes);
    fusionarListas(listaFusionada,miercoles);
    fusionarListas(listaFusionada,jueves);
    fusionarListas(listaFusionada,viernes);
    
    cout<<"Lista fusionada:"<<endl;
    imprimirLista(listaFusionada);
    cout<<endl;
    
    //Imprimir lista final
    ordenarLista(listaFusionada);
    cout<<"Lista final:"<<endl;
    imprimirLista(listaFusionada);
    
    return 0;
}

