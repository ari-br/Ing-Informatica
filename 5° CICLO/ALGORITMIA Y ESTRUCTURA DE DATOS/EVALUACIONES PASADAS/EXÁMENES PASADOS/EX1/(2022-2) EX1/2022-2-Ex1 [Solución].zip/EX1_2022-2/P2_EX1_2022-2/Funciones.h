/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   Funciones.h
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 08:58 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H
#include "Pila.h"

void AperturaIf(ifstream &arch,const char*nomb);
int devolverFrecMax(int *frecuencia,int &durMax,int cantDat);
void construirPila(Pila &pila);
bool esPilaVacia(Pila &pila);
int cimaPila(Pila &pila);
void apilar(Pila &pila,int indice);
Nodo *crearNuevoNodo(int indice,Nodo *siguiente);
int desapilar(Pila &pila);

#endif /* FUNCIONES_H */
