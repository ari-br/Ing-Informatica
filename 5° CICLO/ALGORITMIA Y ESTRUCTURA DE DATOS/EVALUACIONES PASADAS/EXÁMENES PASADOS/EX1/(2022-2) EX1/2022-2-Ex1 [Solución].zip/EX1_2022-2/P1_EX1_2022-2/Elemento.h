/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Elemento.h
 * Author: Ariana
 *
 * Created on 9 de octubre de 2024, 04:24 PM
 */

#ifndef ELEMENTO_H
#define ELEMENTO_H

struct Elemento{
    int hora;
    int sucursal;
    char *dia;
};

#endif /* ELEMENTO_H */

