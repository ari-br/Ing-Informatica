/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 08:34 AM
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
using namespace std;
#include "Nodo.h"
#include "Pila.h"
#include "Funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    ifstream arch("Frecuencias.txt",ios::in);
    AperturaIf(arch,"Frecuencias.txt");
    int cantDat,i=0,durMax;
    cout<<"Ingresa la cantidad de datos: "<<endl;;
    arch>>cantDat;
    cout<<cantDat<<endl;
    cout<<"Ingresa las frecuencias: "<<endl;;
    int frecuencia[cantDat];
    while (1) {
        arch>>frecuencia[i];
        if(arch.eof()) break;
        i++;
    }
    for (int i = 0; i < cantDat; i++) cout<<frecuencia[i]<<endl;;
    cout<<endl;
    cout<<"Frecuencia máxima = "<<devolverFrecMax(frecuencia,durMax,cantDat)<<endl;
    cout<<"Duración = "<<durMax<<endl;
    
    return 0;
}

