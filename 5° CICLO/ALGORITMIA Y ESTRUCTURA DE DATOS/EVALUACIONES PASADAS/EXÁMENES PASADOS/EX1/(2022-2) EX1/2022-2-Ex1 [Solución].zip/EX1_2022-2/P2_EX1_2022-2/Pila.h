/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Pila.h
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 08:40 AM
 */

#ifndef PILA_H
#define PILA_H
#include "Nodo.h"

struct Pila{
    Nodo *cima;
    int longitud;
};

#endif /* PILA_H */

