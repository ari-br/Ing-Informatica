/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Nodo.h
 * Author: Ariana
 *
 * Created on 9 de octubre de 2024, 04:25 PM
 */

#ifndef NODO_H
#define NODO_H
#include "Elemento.h"

struct Nodo{
    Elemento elemento;
    Nodo *siguiente;
};

#endif /* NODO_H */

