/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   Funciones.cpp
 * Author: Ariana
 * 
 * Created on 9 de octubre de 2024, 04:30 PM
 */
#include <iostream>
#include <cstring>
using namespace std;
#include "Funciones.h"
#include "Nodo.h"
#include "Lista.h"


void construirLista(Lista &lista){
    lista.cabeza=nullptr;
    lista.longitud=0;
}

void insertarALFinal(Lista &lista,int hora,int sucursal,const char *dia){
    Nodo *ultimoNodo=devolverUltimoNodo(lista);
    Nodo *nuevoNodo=crearNodo(hora,sucursal,dia,nullptr);
    
    if(ultimoNodo==nullptr){
        lista.cabeza=nuevoNodo;
    }else{
        ultimoNodo->siguiente=nuevoNodo;
    }
    lista.longitud++;
}

Nodo *devolverUltimoNodo(Lista &lista){
    Nodo *recorrido=lista.cabeza;
    Nodo *ultimoNodo=recorrido;
    
    while(recorrido!=nullptr){
        ultimoNodo=recorrido;
        recorrido=recorrido->siguiente;
    }
    
    return ultimoNodo;
}

Nodo *crearNodo(int hora,int sucursal,const char *dia,Nodo *siguiente){
    Nodo *nuevoNodo=new struct Nodo;
    nuevoNodo->elemento.hora=hora;
    nuevoNodo->elemento.sucursal=sucursal;
    nuevoNodo->elemento.dia=devolverPuntChar(dia);
    nuevoNodo->siguiente=siguiente;
    return nuevoNodo;
}

char *devolverPuntChar(const char* palabra){
    char *pt;
    pt=new char[strlen(palabra)+1];
    strcpy(pt,palabra);
    return pt;
}

void imprimirLista(const Lista lista){
    Nodo *recorrido=lista.cabeza;
    
    if(recorrido==nullptr){
        cout<<"No se puede imprimir la lista porque está vacía"<<endl;
    }else{
        bool flag=false;
        while(recorrido!=nullptr){
            if(flag) cout<<" -> ";
            flag=true;
            cout<<recorrido->elemento.hora<<"("<<recorrido->elemento.sucursal
                <<")("<<recorrido->elemento.dia<<")";
            recorrido=recorrido->siguiente;
        }
        cout<<endl;
    }
}

void ordenarLista(Lista &lista){
    bool intercambio=true;
    
    if(lista.cabeza==nullptr) intercambio=false;
    
    while(intercambio){
        intercambio=false;
        struct Nodo *recorrido=lista.cabeza;
        while(recorrido->siguiente!=nullptr){
            if(recorrido->elemento.hora > recorrido->siguiente->elemento.hora){
                intercambio=true; //hubo un intercambio
                struct Elemento elemento=recorrido->elemento;
                recorrido->elemento=recorrido->siguiente->elemento;
                recorrido->siguiente->elemento=elemento;
            }
            recorrido=recorrido->siguiente;
        }
    }
}

int devolverDia(char *dia){
    if(strcmp(dia,"Lunes")==0) return 1;
    if(strcmp(dia,"Martes")==0) return 2;
    if(strcmp(dia,"Miercoles")==0) return 3;
    if(strcmp(dia,"Jueves")==0) return 4;
    if(strcmp(dia,"Viernes")==0) return 5;
}

void fusionarListas(Lista &listaFusionada,const Lista lista){
    Nodo *ultimoNodo=devolverUltimoNodo(listaFusionada);
    
    if(listaFusionada.cabeza==nullptr){
        listaFusionada.cabeza=lista.cabeza;
    }else{
        ultimoNodo->siguiente=lista.cabeza;
    }
    listaFusionada.longitud+=lista.longitud;
}