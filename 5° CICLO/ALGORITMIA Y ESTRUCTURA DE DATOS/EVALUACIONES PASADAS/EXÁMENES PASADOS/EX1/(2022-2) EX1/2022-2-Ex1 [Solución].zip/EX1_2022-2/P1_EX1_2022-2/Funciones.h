/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   Funciones.h
 * Author: Ariana
 *
 * Created on 9 de octubre de 2024, 04:30 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H
#include "Lista.h"

void construirLista(Lista &lista);
void llenarALFinal(Lista &lista);
void insertarALFinal(Lista &lista,int hora,int sucursal,const char *dia);
Nodo *devolverUltimoNodo(Lista &lista);
Nodo *crearNodo(int hora,int sucursal,const char *dia,Nodo *siguiente);
char *devolverPuntChar(const char* palabra);
void imprimirLista(const Lista lista);
void ordenarLista(Lista &lista);
void fusionarListas(Lista &listaFusionada,const Lista lista);
int devolverDia(char *dia);

#endif /* FUNCIONES_H */
