/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: RODRIGO
 *
 * Created on 26 de abril de 2024, 19:22
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;
#include "funcionesCola.h"
#include "funcionesLista.h"
#include "funcionesPila.h"
#include "Cola.h"
#include "Pila.h"

void mandarPorHanoi(int n, struct Pila &pila, struct Pila &pila2, 
        struct Pila &pila1){
    if(n==0) return;
    if(n==1){
        apilar(pila2, desapilar(pila));
        return;
    }
    mandarPorHanoi(n-1, pila, pila1, pila2);
    apilar(pila2, desapilar(pila));
    mandarPorHanoi(n-1, pila1, pila2, pila);
}

void mandarPorHanoiCuadruple(int n, struct Pila &pila, struct Pila &pila3, 
         struct Pila &pila2, struct Pila &pila1){
    int cantidad1, cantidad2;
    if(n==0) return;
    if(n==1){
        apilar(pila3, desapilar(pila));
        return;
    }    
    if(n%2!=0){
        cantidad1 = n/2;
        cantidad2 = n/2;
    } else{
        cantidad1 = n/2;
        cantidad2 = cantidad1-1;     
    }
    mandarPorHanoi(cantidad1, pila, pila2, pila1); 
    mandarPorHanoi(cantidad2, pila, pila1, pila2); 
    apilar(pila3, desapilar(pila));
    mandarPorHanoi(cantidad2, pila1, pila3, pila2);
    mandarPorHanoi(cantidad1, pila2, pila3, pila1); 
}

void insertarOrdenadoAux(int elemento, struct Pila &pila, struct Pila &pila1, 
         struct Pila &pila2, struct Pila &pila3,  bool &insertado){
    int anterior, numIte;
    if(insertado) return;
    if(esPilaVacia(pila)){//caso si la pila no tenia elementos
        apilar(pila, elemento);
        insertado = true;
        return;
    }
    numIte = longitud(pila)+1;
    for(int i=0; i<numIte; i++){
        mandarPorHanoiCuadruple(i, pila, pila3, pila1, pila2);
        if(!esPilaVacia(pila)) anterior = desapilar(pila);
        else anterior = 10000;
        if(anterior>elemento){
            if(anterior!=10000)apilar(pila, anterior);
            apilar(pila, elemento);
            insertado = true;
        } else apilar(pila, anterior);
        mandarPorHanoiCuadruple(i, pila3, pila, pila1, pila2);      
        if(insertado) return;
    }
}

void insertarOrdenado(int elemento, struct Pila &pila, struct Pila &pila1, 
        struct Pila &pila2, bool &insertado){
    int anterior, numIte;
    if(insertado) return;
    if(esPilaVacia(pila)){//caso si la pila no tenia elementos
        apilar(pila, elemento);
        insertado = true;
        return;
    }
    numIte = longitud(pila)+1;
    for(int i=0; i<numIte; i++){
        mandarPorHanoi(i, pila, pila2, pila1);
        if(!esPilaVacia(pila)) anterior = desapilar(pila);
        else anterior = 10000;
        if(anterior>elemento){
            if(anterior!=10000)apilar(pila, anterior);
            apilar(pila, elemento);
            insertado = true;
        } else apilar(pila, anterior);
        mandarPorHanoi(i, pila2, pila, pila1);
        if(insertado) return;
    }
}

void organizarProductos(struct Cola &cola, struct Pila &pila){
    struct Pila pila1, pila2, pila3;
    bool insertado;
    construir(pila1);
    construir(pila2);
    construir(pila3);
    int elemento;
    while(!esColaVacia(cola)){
        elemento = desencolar(cola);
        insertado = false;
//        insertarOrdenado(elemento, pila, pila1, pila2, insertado);<HANOI NORMAL
        insertarOrdenadoAux(elemento, pila, pila1, pila2, pila3, insertado);//<<HANOI CON UNO MAS
    }
}

int main(int argc, char** argv) {
    struct Cola cola;
    struct Pila pila;
    construir(pila);
    construir(cola);
    encolar(cola, 2);
    encolar(cola, 8);
    encolar(cola, 10);
    encolar(cola, 8);
    encolar(cola, 5);
    encolar(cola, 4);
    encolar(cola, 3);
    encolar(cola, 7);
    organizarProductos(cola, pila);
    imprimir(pila);
    return 0;
}

