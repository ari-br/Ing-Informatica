/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: RODRIGO
 *
 * Created on 26 de abril de 2024, 19:22
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;
#include "funcionesCola.h"
#include "funcionesLista.h"
#include "funcionesPila.h"
#include "Cola.h"
#include "Pila.h"

void ordenarPila(struct Pila &pila1, struct Pila &pila2, int tamanoPila) {
    int elemento, maximo, elementosApilar = tamanoPila;
    for (int i = 0; i < tamanoPila; i++) {
        maximo = 0;
        for(int j=0; j<elementosApilar; j++) {
            elemento = desapilar(pila1);
            if (elemento%100 > maximo%100) maximo = elemento;
            apilar(pila2, elemento);
        }
        apilar(pila1, maximo);
        while(!esPilaVacia(pila2)){
            elemento = desapilar(pila2);
            if (elemento != maximo) apilar(pila1, elemento);
        }
        elementosApilar--;
    }
}

void reinicia_cola(struct Cola &cola, int tamCola, struct Pila &pila1,
        struct Pila &pila2) {//ya se tienen los 3 elementos
    while (!esPilaVacia(pila2)) apilar(pila1, desapilar(pila2));
    int longitudPila1 = longitud(pila1);
    ordenarPila(pila1, pila2, longitudPila1);
//    imprime(cola);
    for (int i = 0; i < tamCola - longitudPila1; i++) encolar(cola, desencolar(cola));
//    imprime(cola);
    for (int i = 0; i < longitudPila1; i++) apilar(pila2, desencolar(cola)); //indicaciones alternadas segun grafico
//    imprime(cola);
    for (int i = 0; i < longitudPila1; i++) encolar(cola, desapilar(pila1));
//    imprime(cola);
    for (int i = 0; i < tamCola - longitudPila1; i++) encolar(cola, desencolar(cola));
//    imprime(cola);
}

void reclasifica_pilas(struct Pila &pila1, struct Pila &pila2){//supongamos pila2 tiene datos
    struct Pila pilAux;
    int elemento;
    construir(pilAux);
    while(!esPilaVacia(pila2)){
        elemento = desapilar(pila2);
        if(elemento/100 == 1) apilar(pila1, elemento);
        else apilar(pilAux, elemento);
    }
    while(!esPilaVacia(pilAux)) apilar(pila2, desapilar(pilAux));
    destruirPila(pilAux);
}
int main(int argc, char** argv) {
    struct Cola cola;
    struct Pila pila1;
    struct Pila pila2;

    construir(cola);
    construir(pila1);
    construir(pila2);
    
    encolar(cola, 206);
    encolar(cola, 107);
    encolar(cola, 208);
    encolar(cola, 109);
    encolar(cola, 210);
    encolar(cola, 211);
    encolar(cola, 112);
    encolar(cola, 113);
    
    apilar(pila1, 105);
    apilar(pila2, 203);
    apilar(pila2, 204);
    apilar(pila1, 102);
    apilar(pila1, 101);
    
    cout<<"INICIAL:"<<endl<<"Cola: ";
    imprime(cola);
    cout<<"Pila 1: ";
    imprimir(pila1);
    cout<<"Pila 2: ";
    imprimir(pila2);
    cout<<endl<<endl;
    
    reinicia_cola(cola, 8, pila1, pila2);
    
    cout<<"REINICIA COLA:"<<endl<<"Cola: ";
    imprime(cola);
    cout<<"Pila 1: ";
    imprimir(pila1);
    cout<<"Pila 2: ";
    imprimir(pila2);
    cout<<endl<<endl;
    
    reclasifica_pilas(pila1, pila2);
    cout<<"RECLASIFICA PILAS:"<<endl<<"Cola: ";
    imprime(cola);
    cout<<"Pila 1: ";
    imprimir(pila1);
    cout<<"Pila 2: ";
    imprimir(pila2);
    cout<<endl<<endl;
    

    return 0;
}

