/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Listas.h
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 05:56 PM
 */

#ifndef LISTAS_H
#define LISTAS_H
#include "Nodo.h"

struct Lista{
    Nodo *cabeza;
    int longitud;
};

#endif /* LISTAS_H */

