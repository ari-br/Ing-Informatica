/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   Funciones.h
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 03:36 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void construirPila(Pila &pila);
void apilar(Pila &pila,int elemento);
Nodo *crearNuevoNodo(int elemento,Nodo *siguiente);
void imprimirPila(const Pila pila);
bool esPilaVacia(Pila &pila);
void fusionarPilas(Pila& pila1, Pila& pila2);
int desapilar(Pila &pila);

#endif /* FUNCIONES_H */
