/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 03:35 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#include "Nodo.h"
#include "Pila.h"
#include "Funciones.h"

/* 
 * SOLO ESTÁ HECHO LO DE FUSIONAR PILAS
 */

int main(int argc, char** argv) {
    Pila pilaP,pilaU;
    
    construirPila(pilaU);
    apilar(pilaU,6);
    apilar(pilaU,5);
    apilar(pilaU,2);
    
    cout<<"Pila u (inicial): ";
    imprimirPila(pilaU);
    
    construirPila(pilaP);
    apilar(pilaP,5);
    apilar(pilaP,4);
    apilar(pilaP,3);
    apilar(pilaP,1);
    
    cout<<"Pila p (inicial): ";
    imprimirPila(pilaP);
    
    fusionarPilas(pilaP,pilaU);
    
    cout<<"Pila u (final): ";
    imprimirPila(pilaU);
    
    return 0;
}

