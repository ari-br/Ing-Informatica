/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   Funciones.cpp
 * Author: Ariana
 * 
 * Created on 11 de octubre de 2024, 05:57 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "Elemento.h"
#include "Nodo.h"
#include "Listas.h"
#include "Funciones.h"


void construirLista(Lista &lista){
    lista.cabeza=nullptr;
    lista.longitud=0;
}

void insertarAlFinal(Lista &lista,int hora,const char*dia){
    Nodo *nuevoNodo=crearNuevoNodo(hora,dia,nullptr);
    Nodo *ultimoNodo=devolverUltimoNodo(lista);
    
    if(ultimoNodo==nullptr){
        lista.cabeza=nuevoNodo;
    }else{
        ultimoNodo->siguiente=nuevoNodo;
    }
    lista.longitud++;
}

Nodo *devolverUltimoNodo(Lista &lista){
    Nodo *recorrido=lista.cabeza;
    Nodo *ultimoNodo=recorrido;
    
    while (recorrido!=nullptr) {
        ultimoNodo=recorrido;
        recorrido=recorrido->siguiente;
    }
    
    return ultimoNodo;
}

Nodo *crearNuevoNodo(int hora,const char*dia,Nodo *siguiente){
    Nodo *nuevoNodo=new Nodo;
    nuevoNodo->elemento.hora=hora;
    nuevoNodo->elemento.dia=devolverPuntChar(dia);
    nuevoNodo->siguiente=siguiente;
    return nuevoNodo;
}

char *devolverPuntChar(const char*dia){
    char *pt;
    pt=new char[strlen(dia)+1];
    strcpy(pt,dia);
    return pt;
}

bool esListaVacia(const Lista lista){
    return (lista.cabeza==nullptr);
}

void imprimirLista(const Lista lista){
    if(esListaVacia(lista)){
        cout<<"La lista está vacia, no se puede imprimir";
    }else{
        Nodo *recorrido=lista.cabeza;
        bool flag=false;
        while (recorrido!=nullptr) {
            if(flag) cout<<" -> ";
            flag=true;
            cout<<recorrido->elemento.hora<<" ("<<recorrido->elemento.dia<<")";
            recorrido=recorrido->siguiente;
        }
    }
    cout<<endl;
}

void ordenarLista(Lista &lista){
    bool intercambio=true;
    
    if(esListaVacia(lista)) intercambio=false;
    
    while(intercambio){
        intercambio=false;
        struct Nodo *recorrido=lista.cabeza;
        while(recorrido->siguiente!=nullptr){
            if(recorrido->elemento.hora > recorrido->siguiente->elemento.hora){
                intercambio=true; //hubo un intercambio
                struct Elemento elemento=recorrido->elemento;
                recorrido->elemento=recorrido->siguiente->elemento;
                recorrido->siguiente->elemento=elemento;
            }
            recorrido=recorrido->siguiente;
        }
    }
}

void fusionarListas(Lista &listaFusionada,Lista &lista){
    Nodo *ultimoNodo=devolverUltimoNodo(listaFusionada);
    
    if(listaFusionada.cabeza==nullptr){
        listaFusionada.cabeza=lista.cabeza;
    }else{
        ultimoNodo->siguiente=lista.cabeza;
    }
    listaFusionada.longitud+=lista.longitud;
}

void AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}