/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Nodo.h
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 12:40 PM
 */

#ifndef NODO_H
#define NODO_H

struct Nodo{
    int dia;
    Nodo *siguiente;
};

#endif /* NODO_H */

