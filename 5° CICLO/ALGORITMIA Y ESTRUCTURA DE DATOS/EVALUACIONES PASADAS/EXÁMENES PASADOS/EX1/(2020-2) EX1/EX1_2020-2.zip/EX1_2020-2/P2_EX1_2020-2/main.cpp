/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 12:34 PM
 */

#include <fstream>
#include <iostream>
using namespace std;
#include "Nodo.h"
#include "Pila.h"
#include "Funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    ifstream arch("Contagios.txt",ios::in);
    int cantDias,i=0;
    
    arch>>cantDias;
    cout<<"Días analizados: "<<cantDias<<endl;
    int contagios[cantDias],incrementos[cantDias]{};
    for (int i = 0; i < cantDias; i++) arch>>contagios[i];
    cout<<"Contagios por día: ";
    imprimir(contagios,cantDias);
    devolverIncrementos(contagios,incrementos,cantDias);
    cout<<"Incremento por día: ";
    imprimir(incrementos,cantDias);
    
    return 0;
}

