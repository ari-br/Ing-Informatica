/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   Funciones.cpp
 * Author: Ariana
 * 
 * Created on 11 de octubre de 2024, 12:42 PM
 */
#include <fstream>
#include <iostream>
#include <iomanip>
using namespace std;
#include "Nodo.h"
#include "Pila.h"
#include "Funciones.h"

void devolverIncrementos(int *contagios,int *incrementos,int cantDias){
    Pila pilaCont;
    construirPila(pilaCont);
    int i=0,cima;
    
    while(i<cantDias){
        if(esPilaVacia(pilaCont) or contagios[i]<=contagios[cimaPila(pilaCont)]){
            apilar(pilaCont,i);
            i++;
        }else{
            cima=desapilar(pilaCont);
            if(esPilaVacia(pilaCont)){
                incrementos[i]=i;
            }else{
                incrementos[i]=i-cimaPila(pilaCont)-1;
            }
        }
    }
    
    while(!esPilaVacia(pilaCont)){
        cima=desapilar(pilaCont);
        if(esPilaVacia(pilaCont)){
            incrementos[i]=i;
        }else{
            incrementos[i]=i-cimaPila(pilaCont)-1;
        }
    }
    
}

int desapilar(Pila &pila){
    int cima=pila.cima->dia;
    Nodo *nodo=pila.cima;
    pila.cima=nodo->siguiente;
    pila.longitud--;
    delete nodo;
    return cima;
}

int cimaPila(Pila &pila){
    return pila.cima->dia;
}

void apilar(Pila &pila,int dia){
    Nodo *nuevoNodo=crearNuevoNodo(dia,pila.cima);
    pila.cima=nuevoNodo;
    pila.longitud++;
}

Nodo *crearNuevoNodo(int dia,Nodo *siguiente){
    Nodo *nuevoNodo=new Nodo;
    nuevoNodo->dia=dia;
    nuevoNodo->siguiente=siguiente;
    return nuevoNodo;
}

void construirPila(Pila &pila){
    pila.cima=nullptr;
    pila.longitud=0;
}

bool esPilaVacia(Pila &pila){
    return pila.cima==nullptr;
}

void imprimir(int *arreglo,int cantDias){
    bool flag=false;
    cout<<"{";
    for (int i = 0; i < cantDias; i++) {
        if(flag) cout<<",";
        cout<<arreglo[i];
        flag=true;
    }
    cout<<"}"<<endl;
}

void AperturaIf(ifstream &arch,const char *nomb){
    if(!arch){
        cout<<"No se pudo abrir el archivo "<<nomb<<endl;
        exit(1);
    }
}


    

    
