/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   Funciones.h
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 12:42 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void devolverIncrementos(int *contagios,int *incrementos,int cantDias);
void construirPila(Pila &pila);
bool esPilaVacia(Pila &pila);
void apilar(Pila &pila,int dia);
Nodo *crearNuevoNodo(int dia,Nodo *siguiente);
int cimaPila(Pila &pila);
int desapilar(Pila &pila);
void imprimir(int *arreglo,int cantDias);
void AperturaIf(ifstream &arch,const char *nomb);

#endif /* FUNCIONES_H */
