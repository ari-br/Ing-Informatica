
/* 
 * File:   main.cpp
 * Author: RODRIGO
 *
 * Created on 23 de abril de 2024, 20:58
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;
#include "Pilas.h"

int obtenerColumnaCeros(struct Pila pila, int n, int datos[][7]){
    if(pila.cabeza = nullptr) return -1; //lista vacia
    for(int i=0; i<n; i++){
        
    }
}


int main(int argc, char** argv) {
    int n = 7, columna0;
    bool esta;
    int datos[n][n] = {
        {0,0,0,0,0,0,0},
        {10,0,20,30,0,20,40},
        {0,0,0,0,0,100,0},
        {0,0,0,0,0,80,0},
        {50,10,5,10,0,100,4},
        {100,0,0,0,0,0,0},
        {0,0,0,0,0,0,0}
    };
    
    //construyendo pila
    struct Pila pila;
    construir(pila);
    for(int i=0; i<n; i++) apilar(pila, i+);
    //se insertaron todos los servidores
    //buscar columna de ceros
    columna0 = obtenerColumnaCeros(pila, n, datos);
    if(columna0!=-1){ //procede con la busqueda
        
    } esta = false;
    return 0;
}

