/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: RODRIGO
 *
 * Created on 24 de abril de 2024, 23:16
 */

#include <cstdlib>

using namespace std;
#include "Pila.h"
#include "Cola.h"
#include "funcionesCola.h"
#include "funcionesPila.h"

void ordenarCola(struct Pila &pilaAux, struct Cola &primeraCola){
    while(longitud(pilaAux)!=0) encolar(primeraCola, desapilar(pilaAux));
    while(longitud(primeraCola)!=0) apilar(pilaAux, desencolar(primeraCola));
    while(longitud(pilaAux)!=0) encolar(primeraCola, desapilar(pilaAux));
}

void intercalarCola(struct Cola &primeraCola, struct Cola &colaFinal, 
        struct Pila &pilaAux){
    int cantPorTipo, longFinal = longitud(primeraCola);
    struct Nodo *nodoInicial;
    while(longitud(colaFinal)!=longFinal){ //si el numero de elementos es impar?
        cantPorTipo = longitud(primeraCola) / 2;
        encolar(colaFinal, desencolar(primeraCola));
        for(int i=0; i<cantPorTipo-1; i++) apilar(pilaAux, desencolar(primeraCola)); //apila en pila aux mitad de elemetnos
        encolar(colaFinal, desencolar(primeraCola));
        while(longitud(primeraCola)!=0) apilar(pilaAux, desencolar(primeraCola)); // los elementos que quedaro
        ordenarCola(pilaAux, primeraCola);
        
    }
}

void ordenarGrupos(struct Cola &primeraCola, struct Pila &pilaAux){
    int tamano = longitud(primeraCola);
    int primerTipo, tipo, elemento;
    for(int i=0; i<tamano; i++){
        elemento = desencolar(primeraCola);
        if(i==0) primerTipo = elemento/100;
        tipo = elemento/100;
        if(tipo==primerTipo){
            apilar(pilaAux, elemento);
        } else{
            encolar(primeraCola, elemento);
        }
    }
    while(longitud(primeraCola)!=0) apilar(pilaAux, desencolar(primeraCola));
    ordenarCola(pilaAux, primeraCola);
}

int main(int argc, char** argv) {

    struct Cola primeraCola, colaFinal;
    struct Pila pilaAux;
    //constructores
    construir(primeraCola);
    construir(colaFinal);
    construir(pilaAux);
    //encolando elementos
    encolar(primeraCola, 101);
    encolar(primeraCola, 105);
    encolar(primeraCola, 202);
    encolar(primeraCola, 203);
    encolar(primeraCola, 204);
    encolar(primeraCola, 106);
    encolar(primeraCola, 107);
    encolar(primeraCola, 208);
    encolar(primeraCola, 209);
    encolar(primeraCola, 110);
    //intercalando
    ordenarGrupos(primeraCola, pilaAux);
    imprime(primeraCola);
//    intercalarCola(primeraCola, colaFinal, pilaAux);
    //imprimiendo
    imprime(colaFinal); //esto se puede hacer con O(n), sin usar anidadas y con dos colas
    return 0;
}

