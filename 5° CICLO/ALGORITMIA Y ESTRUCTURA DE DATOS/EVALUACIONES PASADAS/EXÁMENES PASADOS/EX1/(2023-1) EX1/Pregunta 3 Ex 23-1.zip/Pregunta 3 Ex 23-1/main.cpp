//14:10
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include "Lista.h"
#include "funcionesLista.h"
using namespace std;

void integrarEjercito(struct Lista &reserva, struct Lista &principal) {
    int valor1, valor2;
    bool esPrimerElemento = true;
    struct Nodo *siguiente = principal.cabeza;
    struct Nodo *recorrido = principal.cabeza;
    struct Nodo *nuevoNodo;
    if(reserva.cabeza == nullptr) return;
    while(longitud(reserva)!=0){
        if(siguiente==nullptr){
            //meter todo lo que queda de reserva en principal
            siguiente = reserva.cabeza;
            principal.cola = reserva.cola;
            reserva.cabeza = nullptr;
            reserva.cola = nullptr;
            break;
        }
        valor1 = reserva.cabeza->elemento; //reserva
        valor2 = siguiente->elemento; //principal
        if(valor1<valor2){
            //meter el valor de la reserva en la principal y borrar elemento de la reserva, mantener siguiente
            if(esPrimerElemento){
                insertarAlInicio(principal, valor1);
                recorrido = principal.cabeza;
                esPrimerElemento = false;
            } else{
                nuevoNodo = crearNodo(valor1, siguiente);
                recorrido->siguiente = nuevoNodo;
                recorrido = nuevoNodo;
            }
            eliminaCabeza(reserva);
        } else { //actualizar el siguiente
            recorrido = siguiente;
            siguiente = siguiente->siguiente;
        }
    }
}

void simularBatalla(struct Lista &ejBowser, struct Lista &ejPeach,
        struct Lista &ejDonk, int nPeleas) { //caso no tiene nadie con quien pelear
    int poder1, poder2;
    struct Nodo *nodoAuxBow, *nodoAuxPea;
    bool integro = true;
    while (true) {
        cout << "Inicia la Batalla" << endl;
        cout << "Ejercito 1 - Bowser: ";
        imprime(ejBowser);
        cout << "Ejercito 2 - Peach: ";
        imprime(ejPeach);
        nodoAuxBow = ejBowser.cabeza;
        nodoAuxPea = ejPeach.cabeza;
        for (int i = 0; i < nPeleas; i++) {
            if (nodoAuxPea == nullptr || nodoAuxBow == nullptr) break;
            cout << "Pelea " << i + 1 << ": ";
            poder1 = nodoAuxBow->elemento;
            poder2 = nodoAuxPea->elemento;
            cout << poder1 << " vs " << poder2 << ", gana ";
            if (poder1 > poder2) {
                nodoAuxPea = nodoAuxPea->siguiente;
                eliminaNodo(ejPeach, poder2);
                nodoAuxBow = nodoAuxBow->siguiente;
                cout << poder1 << endl;
            } else {
                nodoAuxBow = nodoAuxBow->siguiente;
                eliminaNodo(ejBowser, poder1);
                nodoAuxPea = nodoAuxPea->siguiente;
                cout << poder2 << endl;
            }
        }
        cout << "Nivel de Ataque Total del Ejército 1: " << poderLista(ejBowser) << endl;
        cout << "Nivel de Ataque Total del Ejército 2: " << poderLista(ejPeach) << endl;
        if (poderLista(ejBowser) == 0) {
            cout << "Gana la batalla Peach" << ((!integro) ? " y Donkey Kong." : ".") << endl;
            break;
        } else if (poderLista(ejPeach) == 0 && !integro) {
            cout << "Gana la batalla Bowser.";
            break;
        } else if (poderLista(ejBowser) > poderLista(ejPeach) && integro) {
            integrarEjercito(ejDonk, ejPeach);
            integro = false;
            cout << "El ejército de DonKey Kong se une al ejército de Peach.";
        } else if(!integro) cout << "Ya no se puede unir nadie al ejército de Peach.";
        cout << endl << endl;
    }
}

void generarListas(struct Lista &listaGeneral, struct Lista &ejBowser,
        struct Lista &ejPeach, struct Lista &ejDonk) {
    int tipoEj, poder, elemento;
    construir(ejBowser);
    construir(ejPeach);
    construir(ejDonk);
    while (longitud(listaGeneral) != 0) {
        elemento = retornaCabeza(listaGeneral);
        eliminaCabeza(listaGeneral);
        tipoEj = elemento % 10;
        poder = elemento / 10;
        if (tipoEj == 1) insertarEnOrden(ejBowser, poder);
        else if (tipoEj == 2) insertarEnOrden(ejPeach, poder);
        else insertarEnOrden(ejDonk, poder);
    }
}

int main(int argc, char** argv) {
    int nPeleas, guerreros, elemento;
    struct Lista listaGeneral, ejBowser, ejPeach, ejDonk;
    construir(listaGeneral);
    //    cout<<"Ingrese el valor de n: ";
    //    cin>>nPeleas;
    //    cout<<"Ingrese la cantidad total de guerreros:  ";
    //    cin>>guerreros;
    //    cout<<endl<<endl;
    //    
    //    for(int i=0; i<guerreros; i++){
    //        cin>>elemento;
    //        insertarAlFinal(listaGeneral, elemento); 
    //    }
    insertarAlFinal(listaGeneral, 723);
    insertarAlFinal(listaGeneral, 182);
    insertarAlFinal(listaGeneral, 123);
    insertarAlFinal(listaGeneral, 262);
    insertarAlFinal(listaGeneral, 851);
    insertarAlFinal(listaGeneral, 352);
    insertarAlFinal(listaGeneral, 653);
    insertarAlFinal(listaGeneral, 103);
    insertarAlFinal(listaGeneral, 561);
    insertarAlFinal(listaGeneral, 841);
    insertarAlFinal(listaGeneral, 391);
    insertarAlFinal(listaGeneral, 241);
    insertarAlFinal(listaGeneral, 1642);
    insertarAlFinal(listaGeneral, 382);
    insertarAlFinal(listaGeneral, 2442);

    nPeleas = 2;
    guerreros = 12;

    cout << "Lista Guerreros: ";
    imprime(listaGeneral);
    cout << endl;

    generarListas(listaGeneral, ejBowser, ejPeach, ejDonk);
    
    imprime(ejPeach);
    imprime(ejDonk);
    integrarEjercito(ejDonk, ejPeach);
    imprime(ejPeach);
    
//    cout << "Los ejercitos formados son:" << endl;
//    cout << "Ejercito 1 - Bowser: ";
//    imprime(ejBowser);
//    cout << "Nivel de Ataque Total del Ejército 1: " << poderLista(ejBowser) << endl << endl;
//    cout << "Ejercito 2 - Peach: ";
//    imprime(ejPeach);
//    cout << "Nivel de Ataque Total del Ejército 2: " << poderLista(ejPeach) << endl << endl;
//    cout << "Ejercito 3 - Donkey Kong: ";
//    imprime(ejDonk);
//    cout << "Nivel de Ataque Total del Ejército 3: " << poderLista(ejDonk) << endl << endl;

//    simularBatalla(ejBowser, ejPeach, ejDonk, nPeleas);
    return 0;
}

