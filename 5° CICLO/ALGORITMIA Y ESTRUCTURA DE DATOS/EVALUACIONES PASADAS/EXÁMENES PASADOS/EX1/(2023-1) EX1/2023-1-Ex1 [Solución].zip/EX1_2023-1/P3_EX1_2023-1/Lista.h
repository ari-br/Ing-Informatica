/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Lista.h
 * Author: Ariana
 *
 * Created on 11 de octubre de 2024, 11:22 PM
 */

#ifndef LISTA_H
#define LISTA_H
#include "Nodo.h"

struct Lista{
    Nodo *cabeza;
    int longitud;
};

#endif /* LISTA_H */

