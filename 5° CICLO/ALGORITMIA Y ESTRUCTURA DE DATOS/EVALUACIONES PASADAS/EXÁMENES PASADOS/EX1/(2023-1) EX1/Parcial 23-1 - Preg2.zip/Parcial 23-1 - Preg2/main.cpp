/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: RODRIGO
 *
 * Created on 23 de abril de 2024, 22:21
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;
#include "Cola.h"
#include "funcionesCola.h"

void encolar_prioridad(struct Cola &cola, int prioridad, const char*codigo){
    struct Nodo *recorrido = cola.lista.cabeza, *siguiente;
    struct Cola colaAux;
    construir(colaAux);
    if(longitud(cola) == 0){
        encolar(cola, prioridad, codigo); //lista vacia
        return;
    }
    while(!esColaVacia(cola)){
        
    }
    
}

int main(int argc, char** argv) {
    struct Cola cola;
    construir(cola);
    encolar(cola, 2, "ISI001");
    encolar(cola, 1, "ISI002");
    encolar(cola, 1, "ISI003");
    encolar(cola, 3, "ISI004");
    encolar(cola, 2, "ISI005");
    encolar(cola, 3, "ISI006");
    encolar(cola, 1, "ISI007");

    encolar_prioridad(cola, 2, "ISI004");
    
    imprime(cola);
    return 0;
}

