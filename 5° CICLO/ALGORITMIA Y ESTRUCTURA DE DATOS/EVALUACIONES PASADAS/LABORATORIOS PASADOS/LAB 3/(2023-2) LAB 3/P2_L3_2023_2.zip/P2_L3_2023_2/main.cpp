/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 28 de octubre de 2024, 12:12
 */

#include <cstdlib>
#include <iostream>
#define M 8
#define N 11
using namespace std;

/*
 * 
 */

void encuentraError(char bocaditos[N],int inicio,int fin, int i){
    if (bocaditos[inicio]==bocaditos[fin]){
        if (fin-inicio>1){
            cout << "La fila " << i+1 << " tiene un " << bocaditos[inicio] << " adicional" << endl;
        }
        return ;
    }
    int medio = (inicio+fin)/2;
    if (bocaditos[medio]==bocaditos[medio-1] && bocaditos[medio]==bocaditos[medio+1]){
        cout << "La fila " << i+1 << " tiene un " << bocaditos[medio] << " adicional" << endl;
        return;
    }
    if (medio%2==1){
        if (bocaditos[medio]==bocaditos[medio-1]){
            encuentraError(bocaditos,medio+1,fin,i);
        }
        else{
            encuentraError(bocaditos,inicio,medio-1,i);
        }
    }
    else{
        if (bocaditos[medio]==bocaditos[medio+1]){
            encuentraError(bocaditos,medio,fin,i);
        }
        else{
            encuentraError(bocaditos,inicio,medio,i);
        }
    }
}

int main(int argc, char** argv) {
    char bocaditos[M][N] = {{'O','O','C','C','A','A','E','E','R','R','R'},
                            {'C','C','A','A','R','R','E','E','B','B',' '},
                            {'R','R','E','E','C','C','F','F','A','A',' '},
                            {'E','E','F','F','A','A','A','B','B','R','R'},
                            {'C','C','C','A','A','R','R','O','O','E','E'}};
    int m = 5, n=11;
    for (int i=0; i<m; i++){
        encuentraError(bocaditos[i],0,n-1,i);
    }
    return 0;
}

