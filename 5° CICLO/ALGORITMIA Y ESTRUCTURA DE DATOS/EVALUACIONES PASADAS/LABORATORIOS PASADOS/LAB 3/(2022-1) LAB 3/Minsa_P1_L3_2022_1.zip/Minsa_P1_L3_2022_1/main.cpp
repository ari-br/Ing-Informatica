/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 28 de octubre de 2024, 11:16
 */

#include <cstdlib>
#include <iostream>

#define N 10

using namespace std;

/*
 * 
 */

int buscarCentro(int arreglo[N],int inicio,int medio,int fin){
    int cuentaIzq=1;
    for (int i=medio; i>inicio; i--){
        if (arreglo[i]>arreglo[i-1]){
            cuentaIzq++;
        }
        else{
            break;
        }
    }
    int cuentaDer=1;
    for (int i=medio+1; i<fin; i++){
        if (arreglo[i+1]>arreglo[i]){
            cuentaDer++;
        }
        else{
            break;
        }
    }
    if (arreglo[medio]<arreglo[medio+1]){
        return cuentaIzq + cuentaDer;
    }
    return 1;
}

int buscarMaximo(int arreglo[N],int inicio,int fin){
    if (inicio==fin){
        return 1;
    }
    int medio = (inicio+fin)/2;
    int maxIzq = buscarMaximo(arreglo,inicio,medio);
    int maxDer = buscarMaximo(arreglo,medio+1,fin);
    int maxCentro = buscarCentro(arreglo,inicio,medio,fin);
    if (maxIzq>=maxDer && maxIzq>=maxCentro){
        return maxIzq;
    }
    else{
        if (maxDer>=maxIzq && maxDer>=maxCentro){
            return maxDer;
        }
        else{
            return maxCentro;
        }
    }
}

int main(int argc, char** argv) {
    int arreglo[N] = {7,2,9,10,16,10,13,8,2,10};
    int n=10;
    cout << "Máximo Días: " << buscarMaximo(arreglo,0,n-1);
    return 0;
}

