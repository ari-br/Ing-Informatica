
/* 
 * File:   main.cpp
 * Author: RODRIGO
 *
 * Created on 29 de abril de 2024, 12:07
 */

#include <iostream>
#include <iomanip>
using namespace std;

int max(int a, int b){
    if(a>b) return a;
    return b;
}

int maxCentro(int *arr, int ini, int med, int fin){
    int izq=1, der=1;
    if(arr[med]>arr[med+1]) return 1;
    for(int i=med; i>ini; i--){
        if(arr[i] > arr[i-1]){
            izq++;
        } else break;
    }
    for(int i=med+1; i<fin; i++){
        if(arr[i] < arr[i+1]){
            der++;
        } else break;
    }
    return izq + der;
}

int cuentaIncremento(int *arr, int ini, int fin){
    if(ini==fin) return 1;
    int med = (ini+fin)/2;
    int izq = cuentaIncremento(arr, ini, med);
    int der = cuentaIncremento(arr, med+1, fin);
    int cen = maxCentro(arr,ini, med, fin);
    
    return max(max(izq,der), cen);
}

int main(int argc, char** argv) {
    int n=8;
    int arr[] = {10,20,5,10,12,20,13,18};
    cout<<cuentaIncremento(arr, 0, n-1);
    return 0;
}

