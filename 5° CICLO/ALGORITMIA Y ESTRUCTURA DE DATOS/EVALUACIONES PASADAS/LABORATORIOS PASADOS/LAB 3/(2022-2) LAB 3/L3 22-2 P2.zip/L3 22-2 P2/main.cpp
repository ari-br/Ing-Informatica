/* 
 * File:   main.cpp
 * Author: Rodrigo Holguin Huari
 * Codigo: 20221466
 * Created on 6 de mayo de 2024, 22:54   1hra pregunta 1 + idea pregunta2 ¿?
 */

#include <iostream>
#include <iomanip>
using namespace std;

int filaDondeIniciaBomba;

int obtenerFila(int data[][7], int potencia, int columna, int inicio, int fin){
    if(inicio==fin){
        return inicio;
    }
    int medio = (inicio+fin)/2;
    if(data[medio+1][columna] > data[medio-1][columna]) 
        return obtenerFila(data, potencia, columna, medio+1, fin);
    else if(data[medio-1][columna] > data[medio+1][columna])
        return obtenerFila(data, potencia, columna, inicio, medio-1);
    else{//son iguales a ambos lados
        if(data[medio+1][columna]==0)
            return obtenerFila(data, potencia, columna, inicio, medio-1);
        return obtenerFila(data, potencia, columna, medio, medio);
    }
}

int obtenerMayorPorColumna(int data[][7], int columna, int filas){
    int mayor=0;
    bool primerFilaConDato=false;
    for(int i=0; i<filas; i++){
        if(data[i][columna]!=0 && primerFilaConDato==false){
            filaDondeIniciaBomba = i;
            primerFilaConDato = true;
        }
        if(data[i][columna]>mayor){
            mayor = data[i][columna];
        }
    }
    return mayor;
}

int obtenerMayorPotencia(int data[][7], int inicio, int fin, int filas, 
        int &columna){//considerando que la cantidad de columnas siempre va a ser mayor o igual a 3
    if(inicio==fin){
        columna = inicio;
        return obtenerMayorPorColumna(data, inicio, filas);
    }
    int medio = (inicio+fin)/2, mayorIzq, mayorDer;
    mayorIzq = obtenerMayorPorColumna(data, medio-1, filas);
    mayorDer = obtenerMayorPorColumna(data, medio+1, filas);
    if(mayorDer>mayorIzq)
        return obtenerMayorPotencia(data, medio+1, fin, filas, columna);
    else if(mayorIzq>mayorDer)
        return obtenerMayorPotencia(data, inicio, medio-1, filas, columna);
    return obtenerMayorPotencia(data, medio, medio, filas, columna);
}

int main(int argc, char** argv) {
    int n=7, m=10;
    int data[10][7] = {
        {0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0},
        {0,0,0,0,1,1,1},
        {0,0,0,0,1,2,2},
        {0,0,0,0,1,2,3},
        {0,0,0,0,1,2,2},
        {0,0,0,0,1,1,1},
        {0,0,0,0,0,0,0}
    };
//    int n=7, m=8;
//    int data[8][7] = {
//        {0,0,0,0,0,0,0},
//        {0,0,0,0,0,0,0},
//        {0,0,0,0,0,0,0},
//        {0,0,0,0,0,0,0},
//        {0,1,1,1,0,0,0},
//        {0,1,2,1,0,0,0},
//        {0,1,1,1,0,0,0},
//        {0,0,0,0,0,0,0}
//    };
    int columna, fila, potencia;
    potencia = obtenerMayorPotencia(data, 0, n-1, m, columna);
    cout<<"Para este juego de datos la potencia mas alta de bomba es "<<
            potencia<<", y la columna donde se ubica es "<<columna<<". ";
    cout<<"La fila con el mayor impacto es la "<< obtenerFila(data, potencia,
            columna, filaDondeIniciaBomba, m-1)<<". ";
    return 0;
}

