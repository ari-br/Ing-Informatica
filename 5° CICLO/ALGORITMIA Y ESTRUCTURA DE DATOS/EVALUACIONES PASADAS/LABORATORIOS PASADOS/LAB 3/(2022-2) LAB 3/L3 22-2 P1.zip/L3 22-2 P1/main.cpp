/* 
 * File:   main.cpp
 * Author: RODRIGO
 *
 * Created on 6 de mayo de 2024, 21:29 22:39   -> 1:10 min
 */

#include <iostream>
#include <iomanip>
using namespace std;

int mayor(int a, int b){
    if(a>b) return a;
    return b;
}

int menor(int a, int b){
    if(a<b) return a;
    return b;
}

int obtenerCentro(int *dias, int menorPeso, int &diaIni, int &diaFin, int ini, 
        int medio, int fin){
    int izq=0, der=0;
    if(dias[medio]!=menorPeso) return 0;
    diaIni = medio+1;
    diaFin = medio+1;
    for(int i=medio+1; i<=fin; i++){
        if(dias[i]!=menorPeso){
            diaFin=i;
            break;
        }
        der++;
    }
    for(int i=medio-1; i>=ini; i--){
        if(dias[i]!=menorPeso){
            diaIni=i+2;
            break;
        }
        izq++;
    }
    return izq + der + 1;
}

int obtenerDiasConsec(int *dias, int menorPeso, int &diaIni, int &diaFin, 
        int ini, int fin){
    if(ini==fin){
        if(dias[ini]==menorPeso){
            diaIni = ini;
            diaFin = fin;
            return 1;
        }
        return 0;
    }
    int medio = (ini+fin)/2, diaIniAux, diaFinAux, diasA, diasB, diasC, diasAux;
    diasA = obtenerDiasConsec(dias, menorPeso, diaIni, diaFin, ini, medio);
    diaIniAux = diaIni;
    diaFinAux = diaFin;
    diasB = obtenerDiasConsec(dias, menorPeso, diaIni, diaFin, medio+1, fin);
    if(diasB>diasA){
        diaIniAux = diaIni;
        diaFinAux = diaFin;
        diasAux = diasA;
    }
    diasC = obtenerCentro(dias, menorPeso, diaIni, diaFin, ini, medio, fin);
    if(diasC<diasAux){
        diaIni = diaIniAux;
        diaFin = diaFinAux;
    }    
    return mayor(mayor(diasA, diasB), diasC);
}

int obtenerMenorPeso(int *dias, int inicio, int fin){
    if(inicio==fin) return dias[inicio];
    int medio = (inicio+fin)/2;
    return menor(obtenerMenorPeso(dias, inicio, medio), 
            obtenerMenorPeso(dias, medio+1, fin));
}

int main(int argc, char** argv) {
//    int dias[30], cantDias=30, menorPeso;
//    for(int i=0; i<cantDias; i++) cin>>dias[i];
//    for(int i=0; i<cantDias; i++) cout<<dias[i]<<" ";
    int cantDias=30, menorPeso, diaIni, diaFin, diasConsec; 
    int dias[30] = {98,95,87,87,87,87,89,89,92,93,94,92,91,90,88,88,88,89,90,91,
    88,88,90,90,92,89,90,88,90,91};
    menorPeso = obtenerMenorPeso(dias, 0, cantDias-1);
    cout<<"El menor peso fue de "<<menorPeso<<". ";
    diasConsec = obtenerDiasConsec(dias, menorPeso, diaIni, diaFin, 0, 
            cantDias-1);
    cout<<"Se obtuvo por "<<diasConsec<<" días consecutivos. El rango de días "
            "en que lo obtuvo fue del "<<diaIni<<" al "<<diaFin<<"."; 
    return 0;
}

