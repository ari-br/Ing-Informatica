
/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 5 de mayo de 2024, 18:45   19:14   -> 0:29
 */

#include <iostream>
#include <iomanip>
using namespace std;

void analisisProductos(char data[][8], int fila, int inicio, int fin, 
        int &prodLote, int &productosC){
    int medio=(inicio+fin)/2;
    if(inicio==fin){
        if(data[fila][medio]=='C'){
            productosC++;
            prodLote++;
        } else if(data[fila][medio]!=0) prodLote++;
        return;
    }
    analisisProductos(data, fila, inicio, medio, prodLote, productosC);
    analisisProductos(data, fila, medio+1, fin, prodLote, productosC);
}

bool obtenerEstado(char data[][8], int fila, int cantProd, double porcAcep){
    int prodLote=0, productosC=0;
    double porcLote;
    analisisProductos(data, fila, 0, cantProd-1, prodLote, productosC);
    porcLote =  (double)productosC/prodLote;
    if(porcLote>porcAcep) return true;
    return false;
}

void imprimirEstados(char data[][8], int cantLotes, int cantProd, double pAcep){
    bool estado;
    for(int i=0; i<cantLotes; i++){//complejidad M
        estado =  obtenerEstado(data, i, cantProd, pAcep);
        cout<<"Lote "<<i+1<<" - Estado: "<<((estado)?"Aprobado":"Rechazado")<<
                endl;
    }
}

int main(int argc, char** argv) {
    int cantLotes=6;
    int cantProd=8;
    double pAcep=0.7;
//    cout<<"Ingrese la cantidad de lotes a evaluar: ";
//    cin>>cantLotes;
//    cout<<"Ingrese la cantidad de productos por lote: ";
//    cin>>cantProd;
//    cout<<"Ingrese el porcentaje de aceptación de la empresa";
//    cin>>pAcep;
//    cout<<endl<<endl;
//    char data[cantLotes][cantProd];
//    for(int i=0; i<cantLotes; i++){
//        cout<<"Ingrese el estado de los productos en el lote "<<i+1<<endl;
//        for(int j=0; j<cantProd; j++){
//            cout<<"Estado Producto "<<j+1<<": ";
//            cin>>data[i][j];
//        }
//        cout<<endl;
//    }
    char data[cantLotes][8] = {
        {'F','F','F','C','C','F',0,0},
        {'C','F','C','C','C','F','C','F'},
        {'F','C','C','C','C','C','C','C'},
        {'C','C','C','C','C','F','C',0},
        {'C','F','F','F','F','C',0,0},
        {'C','C','F','C','F','C','C',0},
    };
    
    imprimirEstados(data, cantLotes, cantProd, pAcep);
    
    return 0;
}

