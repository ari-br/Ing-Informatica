/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 2 de setiembre de 2024, 11:31
 */

#include <cstdlib>
#include <iostream>
#define N 6
#define M 6

using namespace std;

/*
 * 
 */

int cuentaHorizontal(int tablero[N][M],int posX,int y,int m){
    if (y>=m){
        return 0;
    }
    else{
        return tablero[posX][y] + cuentaHorizontal(tablero,posX,y+1,m);
    }
}

int cuentaVertical(int tablero[N][M],int posY,int x,int n){
    if (x>=n){
        return 0;
    }
    else{
        return tablero[x][posY] + cuentaVertical(tablero,posY,x+1,n);
    }
}

int cuentaMinas(int tablero[N][M],int posX,int posY,int n,int m,int dirX,int dirY){
    int minas;
    if (posX<0 || posX>=n || posY<0 || posY>=m){
        if (dirX==0){
            return cuentaHorizontal(tablero,posX,0,m);
        }
        else{
            return cuentaVertical(tablero,posY,0,n);
        }
    }
    if (dirX==0){
        minas = cuentaVertical(tablero,posY,0,n) - tablero[posX][posY];
    }
    else{
        minas = cuentaHorizontal(tablero,posX,0,m) - tablero[posX][posY];
    }
    return minas + cuentaMinas(tablero,posX+dirX,posY+dirY,n,m,dirX,dirY);
}

int main(int argc, char** argv) {
    int tablero[N][M] = {{0,0,0,1,0,1},
                         {0,0,1,0,0,0},
                         {0,1,0,0,0,1},
                         {1,0,0,0,0,0},
                         {0,1,0,0,0,0},
                         {0,0,0,0,1,0}};
    int n=6, m=6;
    int dirX=0, dirY=-1;
    int posX=3, posY=2;
    cout << "Cuenta Minas: " << cuentaMinas(tablero,posX,posY,n,m,dirX,dirY);
    return 0;
}

