/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 11 de noviembre de 2024, 11:30
 */

#include <cstdlib>
#include <iostream>
#include "ArbolBinario.h"
#include "Cola.h"
#include "funcionesArbolesBinarios.h"
#include "funcionesCola.h"

using namespace std;

/*
 * 
 */

struct NodoArbol * crearNuevoNodoArbol_New(struct NodoArbol * arbolIzquierdo, 
                               int elemento, char servidor, struct NodoArbol * arbolDerecho){
    struct NodoArbol * nuevoNodo = new struct NodoArbol;
    nuevoNodo->elemento = elemento;
    nuevoNodo->servidor = servidor;
    nuevoNodo->izquierda = arbolIzquierdo;
    nuevoNodo->derecha = arbolDerecho;
    return nuevoNodo;
}

void plantarArbolBinario_New(struct NodoArbol *&raiz, struct NodoArbol * arbolIzquierdo,
                         int elemento, char servidor, struct NodoArbol * arbolDerecho){
    struct NodoArbol * nuevoNodo = crearNuevoNodoArbol_New(arbolIzquierdo, elemento, servidor, arbolDerecho);
    raiz = nuevoNodo;
}

int buscaSkynerd(struct ArbolBinario arbol){
    Cola cola;
    construir(cola);
    encolarNew(cola,arbol.raiz);
    while (!esColaVacia(cola)){
        NodoArbol *nodo = desencolarNew(cola);
        /*Aqui el nodo puede ser le papa de Skynerd*/
        if (nodo->elemento==200){
            /*Vamos a evaluar si uno de los hijos es Skynerd*/
            if (!esNodoVacio(nodo->izquierda)){
                if (nodo->izquierda->servidor=='S' && nodo->izquierda->elemento==200){
                    return 1;
                }
                else {
                   encolarNew(cola,nodo->izquierda); 
                }
            }
            if (!esNodoVacio(nodo->derecha)){
                if (nodo->derecha->servidor=='S' && nodo->derecha->elemento==200){
                    return 1;
                }
                else {
                   encolarNew(cola, nodo->derecha); 
                }
            }
        }
        if (!esNodoVacio(nodo->izquierda)){
            encolarNew(cola, nodo->izquierda);
        }
        if (!esNodoVacio(nodo->derecha)){
            encolarNew(cola, nodo->derecha);
        }
    }
    return -1;
}

int main(int argc, char** argv) {
    ArbolBinario arbol;
    construir(arbol);
    /*Inicio - Parte a*/
    plantarArbolBinario_New(arbol.raiz,nullptr,100,'Z',nullptr);
    plantarArbolBinario_New(arbol.raiz->izquierda,nullptr,50,'Z',nullptr);
    plantarArbolBinario_New(arbol.raiz->derecha,nullptr,200,'E',nullptr);
    plantarArbolBinario_New(arbol.raiz->izquierda->izquierda,nullptr,100,'E',nullptr);
    plantarArbolBinario_New(arbol.raiz->izquierda->derecha,nullptr,50,'S',nullptr);
    plantarArbolBinario_New(arbol.raiz->derecha->izquierda,nullptr,200,'S',nullptr);
    plantarArbolBinario_New(arbol.raiz->derecha->derecha,nullptr,150,'S',nullptr);
    plantarArbolBinario_New(arbol.raiz->izquierda->izquierda->izquierda,nullptr,50,'S',nullptr);
    plantarArbolBinario_New(arbol.raiz->izquierda->izquierda->derecha,nullptr,200,'Z',nullptr);
    plantarArbolBinario_New(arbol.raiz->derecha->izquierda->izquierda,nullptr,100,'S',nullptr);
    plantarArbolBinario_New(arbol.raiz->derecha->izquierda->derecha,nullptr,200,'E',nullptr);
    plantarArbolBinario_New(arbol.raiz->izquierda->izquierda->izquierda->izquierda,nullptr,50,'E',nullptr);
    plantarArbolBinario_New(arbol.raiz->izquierda->izquierda->derecha->izquierda,nullptr,100,'E',nullptr);
    //recorrerPreOrden(arbol);
    /*Fin - Parte a*/
    /*Inicio - Parte b*/
    cout << "Se encuentra Skynerd?: " << buscaSkynerd(arbol);
    /*Fin - Parte b*/
    return 0;
}

