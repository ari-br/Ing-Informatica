#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <fstream>
#include <climits>
#include <cstring>
using namespace std;

void cargaBin(int num, int *binario, int n){
    for(int i=0; i<n; i++){
        binario[i] = num % 2;
        num /= 2;
    }
}

int obtenerSuma(int *valores, int *binario, int n){
    int total=0;
    for(int i=0; i<n; i++){
        total += binario[i]*valores[i];
    }
    return total;
}

void imprimirArreglo(int *valores, int *binario, int n){
    int i=0;
    while(i<n*n){
        for(int j=0; j<n; j++){
            cout<<setw(6)<<(valores[i])*binario[i];
            i++;
        }
        cout<<endl<<endl;
    }
    cout<<endl;
    
}

void restablecerCombinacion(char *combinacion){
    combinacion[0] = 'H';
    combinacion[1] = 'S';
    combinacion[2] = 'O';
}

bool perteneceHSO(int x, int y, char *combinacion, char contenedores[][10]){
    int a, b=0;
    bool bandera = false;
    for(int i=0; i<6; i++){
        if(b==3) b = 0;
        if(combinacion[b]==contenedores[y][x]){
            if((b)+1>2) a = 0;
            else a = (b)+1;
            combinacion[b] = combinacion[a];
            bandera = true;
        }
        b++;
    }
    return bandera;
}

void buscarPosiciones(int y, int x, char contenedores[][10], char *combinacion, 
        int *posiciones, int movimientos[][2], int &marcPos){//para un elemento con fila y columna
    int xC = x;
    int yC = y;
    for(int i=0; i<4; i++){
        y = yC;
        x = xC;
        for(int j=0; j<3; j++){ 
            if(x<0||y<0||x>9||y>3||!perteneceHSO(x, y, combinacion, contenedores)){//falta añadir que pasa si el siguiente elemento no es uno de los buscados
                restablecerCombinacion(combinacion);
                break;
            }
            if(j==2){
                posiciones[marcPos] = yC;
                posiciones[marcPos+1] = xC;
                marcPos+=2;
                restablecerCombinacion(combinacion);
            } else{
                y+=movimientos[i][0];
                x+=movimientos[i][1];                
            }
        }
    }
}

void mostrarPosiciones(char contenedores[][10], char *combinacion, int movimientos[][2]){
    int posiciones[40], c=0;
    char elemento;
    for(int i=0; i<4; i++){//filas i 
        for(int j=0; j<10; j++){//columnas j
            elemento = contenedores[i][j];
            if(elemento=='H'||elemento=='S'||elemento=='O')
                buscarPosiciones(i, j, contenedores, combinacion, posiciones, movimientos,c);
        }
    }
    posiciones[c] = -1;
    cout<<"POSICIONES ENCONTRADAS:"<<endl;
    for(int i=0; posiciones[i]!=-1; i+=2){
        cout<<"("<<posiciones[i]<<", "<<posiciones[i+1]<<")"<<endl;
    }
}

int main(int argc, char** argv) {
    int PesoMAX = 100;
    int n = 4, peso, ganancia;
    int gananciaMAX = 0;
    int pesos[n*n] = {
                        20, 20, 20, 20, //0,1,2,3
                        10, 30, 10, 30, //5,6,7,8
                        10, 10, 10, 10, //9,10,11,12
                        15, 15, 15, 15  //13,14,15,16
                      };
    int valores[n*n] = {
                        10, 10, 10, 50,
                        80, 10, 10, 20,
                        20, 20, 20, 20,
                        50, 50, 50, 50
                      };
    int binario[n*n], maximo[n*n];
    
    for(int i=0; i<pow(2, n*n); i++){
        cargaBin(i, binario, n*n);
        peso = obtenerSuma(pesos, binario, n*n);
        if(peso<=PesoMAX){
            ganancia = obtenerSuma(valores, binario, n*n);
            if(ganancia > gananciaMAX){
                gananciaMAX = ganancia;
                for(int j=0; j<n*n; j++) maximo[j] = binario[j];
            }
        }
    }
    cout<<"Valor máximo: "<<gananciaMAX<<endl;
    cout<<"PESOS (Toneladas)"<<endl;
    imprimirArreglo(pesos, maximo, n);
    cout<<"VALORES (Miles de $)"<<endl;
    imprimirArreglo(valores, maximo, n);
    //FIN PRIMERA PARTE
    //INICIO SEGUNDA PARTE
    char contenedores[4][10] = {
                        {'H', 'C', 'H', 'B', 'Y', 'S', 'O', 'S', 'O', 'H'},
                        {'S', 'C', 'S', 'S', 'Y', 'Q', 'O', 'S', 'Z', 'K'},
                        {'O', 'P', 'N', 'Y', 'O', 'K', 'F', 'H', 'C', 'K'},
                        {'O', 'B', 'N', 'I', 'Y', 'S', 'P', 'O', 'O', 'K'}
    };
    char combinacion[3] = {'H', 'S', 'O'};
    int movimientos[4][2]{
        {1, 0},//arriba        
        {0, 1},//derecha
        {-1, 0},//abajo
        {0, -1}//izquierda
    };
    mostrarPosiciones(contenedores, combinacion, movimientos);
    return 0;
}

