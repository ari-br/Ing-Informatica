/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 2 de setiembre de 2024, 11:02
 */

#include <cstdlib>
#include <iostream>

#define N 5
#define M 5

using namespace std;

/*
 * 
 */

int calculaPuntaje(int tablero[N][M],int x,int y,int n,int m){
    int derecha = -99999, abajo = -99999;
    if (x==n-1 && y==m-1){
        return tablero[x][y];
    }
    if (y<m-1){
        derecha = calculaPuntaje(tablero,x,y+1,n,m);
    }
    if (x<n-1){
        abajo = calculaPuntaje(tablero,x+1,y,n,m);
    }
    if (derecha>abajo){
        return derecha + tablero[x][y];
    }
    else{
        return abajo + tablero[x][y];
    }
}

int main(int argc, char** argv) {
    int tablero[N][M] = {{3,-2,4,0,0},
                         {1,-2,3,0,0},
                         {0,0,0,0,0},
                         {0,0,0,0,0},
                         {0,0,0,0,0}};
    int n=2, m=3;
    cout << "Puntaje Máximo: " << calculaPuntaje(tablero,0,0,n,m);
    return 0;
}
