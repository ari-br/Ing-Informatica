/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: david
 *
 * Created on 19 de agosto de 2024, 12:28
 */

#include <cstdlib>
#include <iostream>
#include <cmath>
#define N 12
#define M 3
using namespace std;

/*
 * 
 */

void cargaSolucion(int i,int cromosoma[N],int size){
    for (int j=0; j<size; j++){
        cromosoma[j] = 0;
    }
    int pos=0;
    while (i>0){
        cromosoma[pos++] = i % 2;
        i = i/2;
    }
}

int main(int argc, char** argv) {
    int datos[N][2] = {{80,150},
                       {20,80},
                       {100,300},
                       {100,150},
                       {50,80},
                       {10,50},
                       {50,120},
                       {50,150},
                       {0,0},
                       {0,0},
                       {0,0},
                       {0,0}};
    int predecesores[N][M] = {{-1,-1,-1},
                              {-1,-1,-1},
                              {0,1,-1},
                              {-1,-1,-1},
                              {-1,-1,-1},
                              {1,-1,-1},
                              {5,-1,-1},
                              {5,-1,-1},
                              {-1,-1,-1},
                              {-1,-1,-1},
                              {-1,-1,-1},
                              {-1,-1,-1}};
    int n = 8;
    int presupuesto = 250;
    int cromosoma[N];
    int combinaciones = pow(2,n);
    int gananciaMaxima = 0;
    int solucion;
    for (int i=1; i<combinaciones; i++){
        cargaSolucion(i,cromosoma,n);
        int inversion = 0;
        int ganancia = 0;
        for (int j=0; j<n; j++){
            if (cromosoma[j]==1){
                inversion = inversion + datos[j][0];
                ganancia = ganancia + datos[j][1];
            }
        }
        if (inversion<=presupuesto){
            int cumplePredecesoras = 1;
            for (int j=0; j<n; j++){
                if (cromosoma[j]==1){
                    int k = 0;
                    while (predecesores[j][k]!=-1 && k<M){
                        int predecesor = predecesores[j][k];
                        if (cromosoma[predecesor]==0){
                            cumplePredecesoras = 0;
                            break;
                        }
                        k++;
                    }
                }
            }
            if (cumplePredecesoras){
                if (ganancia>gananciaMaxima){
                    gananciaMaxima = ganancia;
                    solucion = i;
                }
            }
        }
    }
    /*Imprimir la solucion*/
    cout << "Una solucion es: " << endl;
    cout << "Ganancia Maxima: " << gananciaMaxima << endl;
    cargaSolucion(solucion,cromosoma,n);
    cout << "Proyectos: ";
    for (int i=0; i<n; i++){
        if (cromosoma[i]==1){
            cout << i+1 << ", ";
        }
    }
    return 0;
}

