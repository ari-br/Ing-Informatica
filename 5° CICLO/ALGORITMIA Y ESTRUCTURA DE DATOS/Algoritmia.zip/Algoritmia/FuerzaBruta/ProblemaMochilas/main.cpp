#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

void cargabin(int n, int binario[], int tamano){
    int i=0;
    for(int i=0; i<tamano; i++) binario[i] = 0;
    while(n!=0){
        binario[i] = n%2;
        n/=2;
        i++;
    }
}



int main(int argc, char** argv) {
    int binario[5];
    int ladrillos[5] = {1,2,4,12,1};
    int maximo=15, tamano=5, pesoParcial, mayorPeso, mayorCombi;
    
    for(int i=0; i<pow(2, tamano); i++){
        cargabin(i, binario, tamano);
        pesoParcial = 0;
        for(int i=0; i<tamano; i++) cargabin[i]*ladrillos[i];
        if(pesoParcial<=tamano and pesoParcial>=mayorPeso){
            mayorPeso = pesoParcial;
            mayorCombi = i;
        }
    }
    return 0;
}
//tener 2 mochilas -> que cambia?

