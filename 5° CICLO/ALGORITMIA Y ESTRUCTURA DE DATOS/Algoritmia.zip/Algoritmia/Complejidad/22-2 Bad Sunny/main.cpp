/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 10 de junio de 2024, 17:41
 */

#include <iostream>
#include <iomanip>
#include "Pila.h"
#include "funcionesPila.h"
using namespace std;

void procesarBadSunny(int &maxFrec, int &duracion, int *frecuencias, int cant){
    int dato, desapilado;// < nnaaff   - numero / area / filas
    int area, areaActual, areaDiff, datoMayor, datoAnterior, cmp;
    int filas;
    Pila pila;
    construir(pila);
    for(int i=0; i<cant; i++){
        if(esPilaVacia(pila) || frecuencias[i]>(cima(pila))/10000){ //entrando elemento mas grande que el anterior
            dato = ((frecuencias[i]*100) + frecuencias[i])*100 + 1;
            apilar(pila, dato);
        } else{
            areaActual = frecuencias[i];
            areaDiff = 0;
            filas = 1;
            datoAnterior = 0;
            while(true){
                if(esPilaVacia(pila)) break;
                desapilado = desapilar(pila);
                if(frecuencias[i]>desapilado/10000){ //elemento entrante mayor al anterio
                    break;
                } else{
                    areaActual += (desapilado%100)*frecuencias[i];
                    filas++;
                    if(datoAnterior!=0 &&(datoAnterior/10000) > (desapilado/10000))
                        desapilado = ((desapilado/10000)*100 + (desapilado/100)%100+(datoAnterior%100)*(desapilado/10000))*100 + desapilado%100 + 1;
                    cmp = (desapilado/100)%100;
                    if(cmp > areaActual && cmp > areaDiff){
                        areaDiff = cmp;
                        datoMayor = desapilado;
                    }
                }
                datoAnterior = desapilado;
            }
            if(areaActual > areaDiff){
                dato = ((frecuencias[i]*100) + areaActual)*100 + filas;
                apilar(pila, dato);
            } else apilar(pila, datoMayor);                
        }
    }
    dato = desapilar(pila);
    maxFrec = dato/10000;
    duracion = dato%100;
}

int main(int argc, char** argv) {
    
    int maxFrec;
    int duracion;
    int cantFrec = 11;
    int frecuencias[cantFrec] = {1, 2, 1, 4, 5, 6, 4, 5, 2, 2, 1};
    
    procesarBadSunny(maxFrec, duracion, frecuencias, cantFrec);
    cout<<"La frecuencia mas alta que dura mas tiempo es "<<maxFrec<<" y dura "
            <<duracion<<" tiempos"<<endl;
    
    return 0;
}

