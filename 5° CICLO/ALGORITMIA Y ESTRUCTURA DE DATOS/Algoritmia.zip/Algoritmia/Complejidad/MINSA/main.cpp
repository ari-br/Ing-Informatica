#include <iostream>
#include <iomanip>
#include "Pila.h"
#include "funcionesPila.h"
using namespace std;

void procesarDatos(int *data, int cantDatos){
    Pila pila;
    construir(pila);
    int dato, datoPila;
    int arreglo[cantDatos]{};
    for(int i=0; i<cantDatos; i++){
        dato = data[i]*100;
        if(!esPilaVacia(pila) && data[i] > cima(pila)/100){
            while(true){
                if(esPilaVacia(pila)) break;
                datoPila = desapilar(pila);
                if(datoPila/100 > data[i]){
                    apilar(pila, datoPila);
                    break;
                }
                dato += datoPila%100 + 1;
            }
        }
        apilar(pila, dato);
        arreglo[i] = dato%100;
    }
    for(int i=0; i<cantDatos; i++) cout<< arreglo[i]<<' ';
    cout<<endl;
}

int main(int argc, char** argv) {
    
    int data[8] = {10, 20, 15, 10, 12, 10, 13, 18};
    int cantDatos = 8;
    
    procesarDatos(data, cantDatos);
    
    return 0;
}

