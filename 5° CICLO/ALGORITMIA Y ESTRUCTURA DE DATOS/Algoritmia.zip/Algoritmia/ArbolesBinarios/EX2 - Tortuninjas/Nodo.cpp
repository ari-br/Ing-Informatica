#include "Nodo.h"

Nodo::Nodo() {
    siguiente = nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
    if(siguiente!=nullptr) delete siguiente;
}

