#ifndef NODO_H
#define NODO_H

#include "Lista.h"


class Nodo {
private:
    char elemento;
    Nodo *siguiente;
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Lista;
};

#endif /* NODO_H */

