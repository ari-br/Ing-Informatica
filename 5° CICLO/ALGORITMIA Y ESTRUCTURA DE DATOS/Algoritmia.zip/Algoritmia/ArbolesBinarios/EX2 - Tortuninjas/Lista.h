/* 
 * File:   Lista.h
 * Author: RODRIGO
 *
 * Created on 1 de julio de 2024, 21:11
 */

#ifndef LISTA_H
#define LISTA_H

#include "Nodo.h"


class Lista {
private:
    class Nodo *recorrido;
public:
    Lista();
    Lista(const Lista& orig);
    virtual ~Lista();
    
    void insertarAlInicio(char);
    char eliminarCabeza();
    
    bool verificarPalabra(const char *, int);
};

#endif /* LISTA_H */

