/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 1 de julio de 2024, 20:33 -> < Alrededor de 1 hora 30 min
 */

#include <string>
#include <iostream>
#include <iomanip>
#include <cstring>

#include "ArbolBinario.h"
#include "funcionesArbolesBinarios.h"
#include "Lista.h"
using namespace std;

void inicializarArbol(ArbolBinario &arbol){
    ArbolBinario arbol1;
    construir(arbol1);
    plantarArbolBinario(arbol1, nullptr, 'T', nullptr);
    ArbolBinario arbol2;
    construir(arbol2);
    plantarArbolBinario(arbol2, arbol1.raiz, 'G', nullptr);
    ArbolBinario arbol3;
    construir(arbol3);
    plantarArbolBinario(arbol3, nullptr, 'R', nullptr);
    ArbolBinario arbol4;
    construir(arbol4);
    plantarArbolBinario(arbol4, arbol3, 'E', arbol2);
    ArbolBinario arbol5;
    construir(arbol5);
    plantarArbolBinario(arbol5, nullptr, 'E', nullptr);
    ArbolBinario arbol6;
    construir(arbol6);
    plantarArbolBinario(arbol6, arbol5, 'D', arbol4);    // <arbol 6 rama izq
    ArbolBinario arbol7;
    construir(arbol7);
    plantarArbolBinario(arbol7, nullptr, 'O', nullptr);
    ArbolBinario arbol8;
    construir(arbol8);
    plantarArbolBinario(arbol8, arbol7.raiz, 'C', nullptr);
    ArbolBinario arbol9;
    construir(arbol9);
    plantarArbolBinario(arbol9, arbol8.raiz, 'C', nullptr);  // <arbol 9 C
    ArbolBinario arbol10;
    construir(arbol10);
    plantarArbolBinario(arbol10, nullptr, 'F', nullptr);
    ArbolBinario arbol11;
    construir(arbol11);
    plantarArbolBinario(arbol11, nullptr, 'T', nullptr);
    ArbolBinario arbol12;
    construir(arbol12);
    plantarArbolBinario(arbol12, arbol10, 'A', arbol11);
    ArbolBinario arbol13;
    construir(arbol13);
    plantarArbolBinario(arbol13, arbol12.raiz, 'N', nullptr);
    ArbolBinario arbol14;
    construir(arbol14);
    plantarArbolBinario(arbol14, arbol9, 'I', arbol13);
    
    construir(arbol);
    plantarArbolBinario(arbol, arbol6, 'L', arbol14);
}

bool verificarCaracter(const char *palabra, int cantLetras, char car){
    for(int i=0; i<cantLetras; i++){
        if(palabra[i] == car)
            return true;
    }
    return false;
}

bool verificarRec(NodoArbol *arbol, const char *palabra, int cant, Lista &lista){
    if(arbol==nullptr) return lista.verificarPalabra(palabra, cant);
    if(verificarCaracter(palabra, cant, arbol->elemento)){
        lista.insertarAlInicio(arbol->elemento);
        if(lista.verificarPalabra(palabra, cant)) return true;
        else
            return verificarRec(arbol->izquierda, palabra, cant, lista) ||
                    verificarRec(arbol->derecha, palabra, cant, lista);
    } else return false;
}


bool verificarPalabra(ArbolBinario &arbol, const char *palabra, int cantLetras){
    Lista lista;
    return verificarRec(arbol.raiz, palabra, cantLetras, lista);
}

int main(int argc, char** argv) {
    
    const char *palabras[6] = {"HIJO", "FINAL", "MUNDO", "DEL", "DIA", "CICLO"};
    int cantPalabras = 6;
    ArbolBinario arbol;
    inicializarArbol(arbol);
    
    for(int i=0; i<cantPalabras; i++){
        if(verificarPalabra(arbol, palabras[i], strlen(palabras[i])))
            cout<<palabras[i]<<' ';
    }
    cout<<endl;
    
    return 0;
}

