#include "Lista.h"

Lista::Lista() {
    recorrido = nullptr;
}

Lista::Lista(const Lista& orig) {
}

Lista::~Lista() {
    if(recorrido!=nullptr) delete recorrido;
}

void Lista::insertarAlInicio(char elemento){
    Nodo *nuevoNodo = new Nodo();
    nuevoNodo->elemento = elemento;
    nuevoNodo->siguiente = recorrido;
    recorrido = nuevoNodo;
}
char Lista::eliminarCabeza(){
    char dato;
    Nodo *nodoElim = recorrido;
    nodoElim->siguiente = nullptr;
    dato = nodoElim->elemento;
    recorrido = recorrido->siguiente;
    delete nodoElim;
    return dato;
}
    
bool Lista::verificarPalabra(const char *palabra, int cantidad){
    Nodo *nodo = recorrido;
    bool centinela;
    while(nodo!=nullptr){
        centinela = false;
        for(int i=0; i<cantidad; i++){
            if(nodo->elemento == palabra[i]){
                centinela = true;
                break;
            }
        }
        if(!centinela) return false;
        nodo = nodo->siguiente;
    }
    return true;
}