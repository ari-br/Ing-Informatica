/* 
 * File:   main.cpp
 * Author: RODRIGO
 *
 * Created on 27 de mayo de 2024, 21:22
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include "ArbolBinario.h"
#include "funcionesArbolesBinarios.h"
#include "funcionesCola.h"
#include "Cola.h"

void inicializarArbol(ArbolBinario &servidores){
    ArbolBinario a1;
    ArbolBinario a2;
    ArbolBinario a3;
    ArbolBinario a4;
    ArbolBinario a5;
    ArbolBinario a6;
    ArbolBinario a7;
    ArbolBinario a8;
    ArbolBinario a9;
    ArbolBinario a10;
    ArbolBinario a11;
    ArbolBinario a12;
    construir(a1);
    plantarArbolBinario(a1, nullptr, 50, 'E', nullptr);
    construir(a2);
    plantarArbolBinario(a2, nullptr, 200, 'S', nullptr);
    construir(a3);
    plantarArbolBinario(a3, a1.raiz, 50, 'S', nullptr);
    construir(a4);
    plantarArbolBinario(a4, a2.raiz, 200, 'Z', nullptr);
    construir(a5);
    plantarArbolBinario(a5, a3, 100, 'E', a4);
    construir(a6);
    plantarArbolBinario(a6, nullptr, 50, 'S', nullptr);
    construir(a7);
    plantarArbolBinario(a7, a5, 50, 'Z', a6);
    construir(a8);
    plantarArbolBinario(a8, nullptr, 100, 'S', nullptr);
    construir(a9);
    plantarArbolBinario(a9, nullptr, 200, 'E', nullptr);
    construir(a10);
    plantarArbolBinario(a10, a8, 100, 'S', a9);
    construir(a11);
    plantarArbolBinario(a11, nullptr, 150, 'S', nullptr);
    construir(a12);
    plantarArbolBinario(a12, a10, 200, 'E', a11);
    construir(servidores);
    plantarArbolBinario(servidores, a7, 100, 'Z', a12);
}

int main(int argc, char** argv) {
    ArbolBinario servidores;
    NodoArbol *nodo;
    Cola cola;
    inicializarArbol(servidores);
    int h = altura(servidores);
    int contador = 1, valor, nivelFinal;
    bool encontrado = false;
    nodo = servidores.raiz;
    construir(cola);
    encolar(cola, nodo);
    for(int i=0; i<h; i++){
        for(int j=0; j<contador; j++){
            nodo = desencolar(cola);
            if(nodo!=nullptr){
                valor = nodo->elemento;
                if(valor == 200){
                    if((nodo->izquierda!=nullptr && nodo->izquierda->tipo=='S' 
                            && nodo->izquierda->elemento==200) ||
                            (nodo->derecha!=nullptr && nodo->derecha->tipo=='S' 
                            && nodo->derecha->elemento==200)){
                        nivelFinal = i+1;
                        encontrado = true;
                        break;
                    }
                }
                encolar(cola, nodo->derecha);
                encolar(cola, nodo->izquierda);
            } else{
                encolar(cola, nullptr);
                encolar(cola, nullptr);
            }
        }
        contador *= 2;
    }
    if(encontrado) cout<<"SkyNerd se encuentra en la red, en el nivel "<<
            nivelFinal<<endl;
    else cout<<"SkyNerd no se encuentra en la red"<<endl;
    return 0;
}

