/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 28 de mayo de 2024, 21:50 -> 22:43 <0:57 min , verificar en que nodo se está
 */

#include <iostream>
#include <iomanip>
#include "ArbolBinario.h"
#include "funcionesArbolesBinarios.h"
using namespace std;

void insertarElemento(NodoArbol *&arbol, int elemento){
    if(arbol==nullptr){
        arbol = crearNuevoNodoArbol(nullptr, elemento, nullptr);
        return;
    }
    insertarElemento(arbol->izquierda, elemento);
    insertarElemento(arbol->derecha, elemento);
}

void generarArbol(ArbolBinario &arbol, int *arreglo, int cantElementos){
    plantarArbolBinario(arbol, nullptr, 0, nullptr);
    for(int i=0; i<cantElementos; i++){
        insertarElemento(arbol.raiz, arreglo[i]);
    }
}

int calcularSoluciones(NodoArbol *arbol, int peso, int suma){
    if(arbol->derecha==nullptr){
        if(suma==peso) return 1;
        return 0;
    }
    return calcularSoluciones(arbol->izquierda, peso, suma) + 
            calcularSoluciones(arbol->derecha, peso, suma+arbol->derecha->elemento);
}

int main(int argc, char** argv) {
    int arreglo[5] = {10, 50, 20, 30, 40};
    int cantElementos=5;
    ArbolBinario arbol;
    construir(arbol);
    generarArbol(arbol, arreglo, cantElementos);
    cout<<"Cantidad de soluciones encontradas: "<<
            calcularSoluciones(arbol.raiz, 70, 0)<<endl;
    return 0;
}

