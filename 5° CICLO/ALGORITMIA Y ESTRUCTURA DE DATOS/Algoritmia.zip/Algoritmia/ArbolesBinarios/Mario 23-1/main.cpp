/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 27 de mayo de 2024, 23:31
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include "ArbolBinario.h"
#include "funcionesArbolesBinarios.h"
#include "Pila.h"
#include "funcionesPila.h"


void plantarArbolBB(struct NodoArbol *& arbol, 
                    struct NodoArbol * arbolIzquierdo, int elemento, 
                    struct NodoArbol * arbolDerecho){
    
    struct NodoArbol * nuevoNodo = new struct NodoArbol;
    nuevoNodo->elemento = elemento;
    nuevoNodo->izquierda = arbolIzquierdo;
    nuevoNodo->derecha = arbolDerecho;
    arbol = nuevoNodo;
}

void insertarRecursivo(struct NodoArbol *& raiz, int elemento){
    if(esNodoVacio(raiz))
        plantarArbolBB(raiz, nullptr, elemento, nullptr);
    else
        if (raiz->elemento%100 > elemento%100)
            insertarRecursivo(raiz->izquierda, elemento);
        else
            if(raiz->elemento%100 < elemento%100)
                insertarRecursivo(raiz->derecha, elemento);
            else
                cout<<endl<<"El elemento "<< elemento <<" ya se encuentra en el Ã¡rbol"<< endl;
}

int comparaABB(int elementoA, int elementoB ){
    if(elementoA%100 == elementoB%100) return 0;
    else if(elementoA%100 < elementoB%100) return -1;
    else if (elementoA%100 > elementoB%100) return 1;
    return 0;
}

bool buscaArbolRecursivo(struct NodoArbol * nodo, int dato, NodoArbol *&valor){
    if(esNodoVacio(nodo)){
        return false;
    } 
    if(comparaABB(nodo->elemento, dato) == 0){
        valor = nodo;
        return true;
    }
    if(comparaABB(nodo->elemento, dato) == 1)
        return buscaArbolRecursivo(nodo->izquierda, dato, valor);
    else
        if(comparaABB(nodo->elemento, dato) == -1) 
            return buscaArbolRecursivo(nodo->derecha, dato, valor);
    return false;
}

void insertar(struct ArbolBinario & arbol, int elemento){
    insertarRecursivo(arbol.raiz, elemento);
}

void fusionarHojas(ArbolBinario destino, NodoArbol *arbol2){
    NodoArbol *nodo;
    if(arbol2==nullptr) return;
    fusionarHojas(destino, arbol2->derecha);
    fusionarHojas(destino, arbol2->izquierda);
    if(buscaArbolRecursivo(destino.raiz, arbol2->elemento, nodo)) nodo->elemento += 100;
    else insertar(destino, arbol2->elemento);
}

void fusionarEjercitos(ArbolBinario destino, ArbolBinario emisor){
    fusionarHojas(destino, emisor.raiz);
}

void imprimirEjercito(NodoArbol *arbol){
    if(arbol==nullptr) return;
    imprimirEjercito(arbol->izquierda);
    cout<<"("<<arbol->elemento%100<<" - "<<arbol->elemento/100<<") ";
    imprimirEjercito(arbol->derecha);
}

void imprimirIterativo(ArbolBinario peach){
    Pila pila;
    construir(pila);
    NodoArbol *nodo = peach.raiz;
    apilar(pila, nodo);
    while(!esPilaVacia(pila)){
        nodo = desapilar(pila);
        cout<<"("<<nodo->elemento%100<<" - "<<nodo->elemento/100<<") ";
        if(nodo->derecha!=nullptr) apilar(pila, nodo->derecha);
        if(nodo->izquierda!=nullptr) apilar(pila, nodo->izquierda);
    }
}

int main(int argc, char** argv) {
    ArbolBinario peach;
    ArbolBinario donkey;
    construir(peach);
    int num;
    
    //INGRESO DE DATOS
    cout<<"Ingrese los datos del ejercito de Peach: "<<endl;
    while(true){
        cin>>num;
        if(num==0) break;
        insertar(peach, num);
    }
    cout<<"Ingrese los datos del ejercito de Donkey Kong: "<<endl;
    construir(donkey);
    while(true){
        cin>>num;
        if(num==0) break;
        insertar(donkey, num);
    }
    //IMPRESION Y FUSION DE ARBOLES
    imprimirEjercito(peach.raiz);
    cout<<endl;
    fusionarEjercitos(peach, donkey);
    imprimirEjercito(peach.raiz);
    destruirArbolBinario(donkey);
    cout<<endl;
    //IMPRESION PRE ORDEN RECURSIVA
    imprimirIterativo(peach);
    destruirArbolBinario(peach);
    return 0;
}

