#include "Arbol.h"

Arbol::Arbol() {
    raiz = nullptr;
}

Arbol::Arbol(const Arbol& orig) {
}

Arbol::~Arbol() {
    if(raiz!=nullptr) delete raiz;
}

void Arbol::insertaNodo(int index, char car){
    insertaRec(raiz, index, car);
}

void Arbol::insertaRec(Nodo *&arbol, int index, char car){
    if(arbol==nullptr){
        Nodo *nuevo = new Nodo;
        nuevo->indice = index;
        nuevo->letra = car;
        arbol = nuevo;
        return;
    }
    if(arbol->indice > index) insertaRec(arbol->izq, index, car);
    else insertaRec(arbol->der, index, car);
}

bool Arbol::buscarLetra(int index, char letra, int cantLetras){
    int resultado;
    resultado = buscarRec(raiz, index+1, letra);
    if(resultado==0) cout<<" _";
    else if(resultado==1) cout<<" "<<letra;
    else cout<<" "<<letra<<"(x)";
    if(index==cantLetras-1) cout<<endl;
    if(resultado==1) return true;
    return false;
}

int Arbol::buscarRec(Nodo *arbol, int index, char letra){
    int izq, der;
    if(arbol==nullptr) return 0;
    if(arbol->letra==letra && arbol->indice==index) return 1;
    izq = buscarRec(arbol->izq, index, letra);
    der = buscarRec(arbol->der, index, letra);
    if(izq==1 || der==1) return 1;
    if(izq!=0 || der!=0 || arbol->letra==letra) return 2;
    if(izq==0 && der==0) return 0;
}
