#ifndef NODO_H
#define NODO_H

#include "Arbol.h"

class Nodo {
private:
    int indice;
    char letra;
    bool encontrado;
    Nodo *izq;
    Nodo *der;
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Arbol;
};

#endif /* NODO_H */

