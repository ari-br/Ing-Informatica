/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 4 de julio de 2024, 12:08 -> < 13:16
 */

#include <iostream>
#include <iomanip>
#include <string>
#include "Arbol.h"
using namespace std;

void insertarDatos(Arbol &arbol){
    string palabra = "SOBERBIO";
    for(int i=0; i<palabra.size(); i++){
        arbol.insertaNodo(i+1, palabra[i]);
        cout<<" _";
    }
    cout<<endl;
}

bool verificarPalabra(Arbol &arbol, string palabra){
    bool valido = true;
    for(int i=0; i<palabra.size(); i++)
        valido = arbol.buscarLetra(i, palabra[i], palabra.size()) && valido;
    return valido;
}

int main(int argc, char** argv) {
    int tamPalabra=8, intentos=5;
    string palabra;
    bool centinela = false;
    cout<<"BIENVENIDO AL JUEGO DE BALWORD"<<endl;
    cout<<"Descubre la palabra de "<<tamPalabra<<" letras. "
            "Tiene máximo "<<intentos<<" intentos."<<endl;
    Arbol incognita;
    insertarDatos(incognita);
    for(int i=0; i<intentos; i++){
        cout<<"Intento "<<i+1<<": ";
        cin>>palabra;
        if(palabra.size() != tamPalabra){
            cout<<"La longitud de la palabra ingresada no es la correcta. "
                    "Vuelva a intentarlo."<<endl;
            i--;
        } else if(verificarPalabra(incognita, palabra)){
            centinela = true;
            break;
        }
    }
    if(centinela) cout<<"Felicitaciones por haber resuelto el reto."<<endl;
    if(!centinela) cout<<"Lo siento, se agotaron los intentos."<<endl;
    
    return 0;
}

