#ifndef ARBOL_H
#define ARBOL_H

#include <iostream>
#include <iomanip>
#include "Nodo.h"
using namespace std;

class Arbol {
private:
    class Nodo *raiz;
    
    void insertaRec(Nodo *&, int, char);
    int buscarRec(Nodo *, int, char);
public:
    Arbol();
    Arbol(const Arbol& orig);
    virtual ~Arbol();
    
    void insertaNodo(int, char);
    bool buscarLetra(int, char, int);
};

#endif /* ARBOL_H */

