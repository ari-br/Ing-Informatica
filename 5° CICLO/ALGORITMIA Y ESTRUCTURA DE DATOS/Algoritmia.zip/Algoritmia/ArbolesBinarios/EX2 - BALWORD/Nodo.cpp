#include "Nodo.h"

Nodo::Nodo() {
    encontrado = false;
    izq = nullptr;
    der = nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
    if(izq != nullptr) delete izq;
    if(der != nullptr) delete der;
}

