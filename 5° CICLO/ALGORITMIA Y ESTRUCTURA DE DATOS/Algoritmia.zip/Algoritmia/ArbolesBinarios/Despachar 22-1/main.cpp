#include <iostream>
#include <iomanip>

#include "ArbolBinarioBusqueda.h"
#include "funcionesArbolesBB.h"
using namespace std;

bool despachoRec(NodoArbol *&arbol, int &cantidad, ArbolBinarioBusqueda &arbolBB) {
    if (arbol == nullptr) return false;
    if (!despachoRec(arbol->izquierda, cantidad, arbolBB)) {
        if (!despachoRec(arbol->izquierda, cantidad, arbolBB)) {
            if (arbol->cantidad > cantidad) {
                arbol->cantidad -= cantidad;
                return true;
            } else {
                cantidad -= arbol->cantidad;
                eliminarNodo(arbolBB, arbol->elemento);
                return false;
            }
        } else return true;
    } else return true;
    if (!despachoRec(arbol->derecha, cantidad, arbolBB)) {
        if (!despachoRec(arbol->izquierda, cantidad, arbolBB)) {
            if (arbol->cantidad > cantidad) {
                arbol->cantidad -= cantidad;
                return true;
            } else {
                cantidad -= arbol->cantidad;
                eliminarNodo(arbolBB, arbol->elemento);
                return false;
            }
        } else return true;
    } else return true;
}

void despachar(ArbolBinarioBusqueda &arbol, int cantidad) {
    if (!despachoRec(arbol.arbolBinario.raiz, cantidad, arbol))
        cout << "No se ha logrado despachar la diferencia" << endl;
}

void imprimirPreOrden(NodoArbol *nodo) {
    if (nodo == nullptr) return;
    cout << "(" << nodo->elemento << " - " << nodo->cantidad << "), ";
    imprimirPreOrden(nodo->izquierda);
    imprimirPreOrden(nodo->derecha);
}

int main(int argc, char** argv) {

    ArbolBinarioBusqueda arbol;
    construir(arbol);

    insertar(arbol, 20220815, 40);
    insertar(arbol, 20220710, 50);
    insertar(arbol, 20220720, 50);
    insertar(arbol, 20220630, 50);
    insertar(arbol, 20220624, 40);
    insertar(arbol, 20220615, 40);
    insertar(arbol, 20220618, 40);
    insertar(arbol, 20220930, 30);

    despachar(arbol, 20);
    imprimirPreOrden(arbol.arbolBinario.raiz);
    cout << endl << endl;
    despachar(arbol, 40);
    imprimirPreOrden(arbol.arbolBinario.raiz);
    cout << endl << endl;
    despachar(arbol, 200);
    imprimirPreOrden(arbol.arbolBinario.raiz);
    cout << endl << endl;

    
    ArbolBinario arbol;
    
    return 0;
}

