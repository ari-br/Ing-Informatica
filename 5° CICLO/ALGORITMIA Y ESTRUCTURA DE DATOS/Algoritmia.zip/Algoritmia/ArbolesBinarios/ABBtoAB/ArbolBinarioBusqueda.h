/* 
 * File:   ArbolBinarioBusqueda.h
 * Author: ANA RONCAL
 * Created on 24 de septiembre de 2023, 10:33 PM
 */

#ifndef ARBOLBINARIOBUSQUEDA_H
#define ARBOLBINARIOBUSQUEDA_H

#include "ArbolBinario.h"

struct ArbolBinarioBusqueda{
    struct ArbolBinario arbolBinario;
};

#endif /* ARBOLBINARIOBUSQUEDA_H */

