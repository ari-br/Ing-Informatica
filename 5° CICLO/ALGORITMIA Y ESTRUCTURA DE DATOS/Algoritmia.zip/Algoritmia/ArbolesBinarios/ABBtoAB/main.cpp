#include "ArbolBinarioBusqueda.h"
#include "ArbolBinario.h"
#include "funcionesArbolesBB.h"
#include "funcionesArbolesBinarios.h"
using namespace std;


NodoArbol *pasarArbolBB(NodoArbol *&arbolBB){
    if(arbolBB==nullptr) return nullptr;
    NodoArbol *nodo1 = pasarArbolBB(arbolBB->izquierda);
    NodoArbol *nodo2 = pasarArbolBB(arbolBB->derecha);
    NodoArbol *nuevoArbol;
    plantarArbolBB(nuevoArbol, nodo1, arbolBB->elemento, nodo2);
    if(arbolBB!=nullptr) delete arbolBB;
    arbolBB = nullptr;
    return nuevoArbol;
}

int main(int argc, char** argv) {
    
    ArbolBinarioBusqueda arbolBB;
    construir(arbolBB);
    
    ArbolBinario arbolB;
    construir(arbolB);
    
    insertar(arbolBB, 4);
    insertar(arbolBB, 3);
    insertar(arbolBB, 6);
    insertar(arbolBB, 1);
    insertar(arbolBB, 9);
    insertar(arbolBB, 7);
    insertar(arbolBB, 8);
    insertar(arbolBB, 5);
    
    arbolBB;
    arbolB.raiz = pasarArbolBB(arbolBB.arbolBinario.raiz);
    
    return 0;
}

