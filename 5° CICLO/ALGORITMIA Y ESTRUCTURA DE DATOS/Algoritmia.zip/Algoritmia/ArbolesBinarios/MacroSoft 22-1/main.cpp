/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 29 de mayo de 2024, 09:09
 */

#include <iostream>
#include <iomanip>

#include "ArbolBinarioBusqueda.h"
#include "funcionesArbolesBinarios.h"
#include "funcionesArbolesBB.h"
using namespace std;

bool actualizableRec(NodoArbol *arbol, int nuevosCampos){
    if(arbol==nullptr) return true;
    if(arbol->elemento/100 == nuevosCampos/100) return false;
    return actualizableRec(arbol->izquierda, nuevosCampos) && 
            actualizableRec(arbol->derecha, nuevosCampos);
}

bool verificarActualizable(ArbolBinarioBusqueda arbol, int numOg, int campo1,
        int campo2){
    int nuevoNum;
    if(campo1!=-1) nuevoNum = campo1;
    else nuevoNum = numOg/10000;
    if(campo2!=-1) nuevoNum = (nuevoNum*100+campo2)*100;
    else nuevoNum = ((nuevoNum*100)+(numOg/100)%100)*100;
    if(actualizableRec(arbol.arbolBinario.raiz, nuevoNum)){
        cout<<"Ok"<<endl;
        return true;
    } else{
        cout<<"Violation of Primary Key constraint on update"<<endl;
        return false;
    }
}


bool actualizarValorRec(NodoArbol *arbol, int numOg, int campo3){
    if(arbol==nullptr) return false;
    if(arbol->elemento/100 == numOg/100){
        arbol->elemento = (arbol->elemento/100)*100+campo3;
        return true;
    }
    if(actualizableRec(arbol->izquierda, numOg)) return true;
    if(actualizableRec(arbol->derecha, numOg)) return true;
    return false;
}

void actualizarRegistro(ArbolBinarioBusqueda arbol, int numOg, int campo1, 
        int campo2, int campo3){
    if(campo3!=-1 && campo1==-1 && campo2==-1){
        actualizarValorRec(arbol.arbolBinario.raiz, numOg, campo3);
        cout<<"Se ha actualizado el campo 3"<<endl;
    } else{
        eliminarNodo(arbol, numOg);
        int nuevoNum;
        if(campo1!=-1) nuevoNum = campo1;
        else nuevoNum = numOg/10000;
        if(campo2!=-1) nuevoNum = (nuevoNum*100+campo2)*100+campo3;
        else nuevoNum = ((nuevoNum*100)+(numOg/100)%100)*100+campo3;     
        insertar(arbol, nuevoNum);
        cout<<"Se ha actualizado la llave principal"<<endl;
    }
}

int main(int argc, char** argv) {
    
    ArbolBinarioBusqueda arbol;
    construir(arbol);
    
    insertar(arbol, 100805);
    insertar(arbol, 82006);
    insertar(arbol, 151003);
    insertar(arbol, 51003);
    insertar(arbol, 100107);
    insertar(arbol, 160807);
    
    insertar(arbol, 51006);
    insertar(arbol, 51106);
    cout<<endl<<endl;
    
    if(verificarActualizable(arbol, 82006, 6,  15)){
        actualizarRegistro(arbol, 82006, 6, 15, 14);
    }
    
    verificar
    
    arbol;
    
    return 0;
}

