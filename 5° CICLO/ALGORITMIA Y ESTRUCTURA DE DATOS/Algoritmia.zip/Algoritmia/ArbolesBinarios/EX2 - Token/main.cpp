/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 3 de julio de 2024, 22:41
 */

#include <iostream>
#include <iomanip>
#include "Arbol.h"
using namespace std;

int main(int argc, char** argv) {

    int datos[8] = {2, 5, 2, 1, 5, 6, 3, 4};
    Arbol arbolIni;
    for(int i=0; i<8; i++) 
        arbolIni.inserta_nodo(datos[i]);
    arbolIni.balancea_arbol();
    
    Arbol arbolSec;
    int datosSec[8] = {4,1,6,2,5,7,3};
    for(int i=0; i<8; i++) 
        arbolSec.inserta_nodo(datosSec[i]);
    
    if(arbolIni.suma_arboles(arbolSec)) cout<<"Es un ABB"<<endl;
    else cout<<"No es un ABB"<<endl;
    
    return 0;
}
