#ifndef ARBOL_H
#define ARBOL_H

#include "NodoArbol.h"
#include "Lista.h"

class Arbol {
private:
    class NodoArbol *raiz;
    
    void insertarRec(NodoArbol *&, int);
    int obtenerMayor(NodoArbol *);
    void llenarLista(NodoArbol *&, Lista &);
    void insertarBalanceado(NodoArbol *&, Lista, int, int);
    void sumarArbolesRec(NodoArbol *&, NodoArbol *, NodoArbol *);
    bool verificarABB(NodoArbol *);
    bool verificarIzq(NodoArbol *, int);
    bool verificarDer(NodoArbol *, int);
public:
    Arbol();
    Arbol(const Arbol& orig);
    virtual ~Arbol();
    
    void inserta_nodo(int);
    void balancea_arbol();
    int suma_arboles(Arbol &arbolSec);
};

#endif /* ARBOL_H */
