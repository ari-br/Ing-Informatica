#include "NodoArbol.h"

NodoArbol::NodoArbol() {
    izq = nullptr;
    der = nullptr;
}

NodoArbol::NodoArbol(const NodoArbol& orig) {
}

NodoArbol::~NodoArbol() {
    if(izq!=nullptr) delete izq;
    if(der!=nullptr) delete der;
}

