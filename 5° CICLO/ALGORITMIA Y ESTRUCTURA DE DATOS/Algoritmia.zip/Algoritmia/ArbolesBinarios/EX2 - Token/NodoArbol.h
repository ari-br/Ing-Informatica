#ifndef NODOARBOL_H
#define NODOARBOL_H

class NodoArbol {
private:
    int elemento;
    NodoArbol *izq;
    NodoArbol *der;
public:
    NodoArbol();
    NodoArbol(const NodoArbol& orig);
    virtual ~NodoArbol();
    friend class Arbol;
};

#endif /* NODOARBOL_H */

