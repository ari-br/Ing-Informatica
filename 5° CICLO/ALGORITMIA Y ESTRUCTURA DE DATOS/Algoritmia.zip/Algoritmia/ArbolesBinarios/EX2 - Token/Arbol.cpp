#include "Arbol.h"
#include "Lista.h"
#include "funcionesLista.h"

Arbol::Arbol() {
    raiz = nullptr;
}

Arbol::Arbol(const Arbol& orig) {
}

Arbol::~Arbol() {
    if (raiz != nullptr) delete raiz;
}

void Arbol::inserta_nodo(int dato) {
    insertarRec(raiz, dato);
}

void Arbol::insertarRec(NodoArbol *&arbol, int dato) { // <va con aspersan o no?
    if (arbol == nullptr) {
        NodoArbol *nuevoNodo = new NodoArbol;
        nuevoNodo->elemento = dato;
        arbol = nuevoNodo;
        return;
    }
    if (dato < arbol->elemento) insertarRec(arbol->izq, dato);
    else if (dato > arbol->elemento) insertarRec(arbol->der, dato);
    else insertarRec(arbol->der, dato + obtenerMayor(raiz));
}

int Arbol::obtenerMayor(NodoArbol *arbol) {
    if (arbol->der == nullptr) return arbol->elemento;
    return obtenerMayor(arbol->der);
}

void Arbol::balancea_arbol() {
    Lista lista;
    construir(lista);
    llenarLista(raiz, lista);
    insertarBalanceado(raiz, lista, 0, lista.longitud - 1);
    destruir(lista);
}

void Arbol::llenarLista(NodoArbol *&arbol, Lista &lista) {
    if (arbol == nullptr) return;
    llenarLista(arbol->izq, lista);
    insertarEnOrden(lista, arbol->elemento);
    llenarLista(arbol->der, lista);
    delete arbol;
    arbol = nullptr;
}

void Arbol::insertarBalanceado(NodoArbol *&arbol, Lista lista, int ini, int fin) {
    Nodo *recorrido;
    if (ini > fin) return;
    int medio = (ini + fin) / 2;
    recorrido = lista.cabeza;
    for (int i = 0; i < medio; i++) recorrido = recorrido->siguiente;
    NodoArbol *nuevoNodo = new NodoArbol;
    nuevoNodo->elemento = recorrido->elemento;
    arbol = nuevoNodo;
    insertarBalanceado(arbol->izq, lista, ini, medio - 1);
    insertarBalanceado(arbol->der, lista, medio + 1, fin);
}

int Arbol::suma_arboles(Arbol &arbolSec) {
    Arbol nuevoArbol;
    sumarArbolesRec(nuevoArbol.raiz, raiz, arbolSec.raiz);
    if (nuevoArbol.verificarABB(nuevoArbol.raiz)) return 1;
    return 0;
}

void Arbol::sumarArbolesRec(NodoArbol *&nuevo, NodoArbol *arbol1, NodoArbol *arbol2) {
    if (arbol1 == nullptr && arbol2 == nullptr) return;
    int valor;
    if (arbol1 == nullptr) valor = arbol2->elemento;
    else if (arbol2 == nullptr) valor = arbol1->elemento;
    else valor = arbol1->elemento + arbol2->elemento;
    NodoArbol *nuevoNodo = new NodoArbol;
    nuevoNodo->elemento = valor;
    nuevo = nuevoNodo;
    sumarArbolesRec(nuevo->izq, ((arbol1 != nullptr) ? arbol1->izq : arbol1),
            ((arbol2 != nullptr) ? arbol2->izq : arbol2));
    sumarArbolesRec(nuevo->der, ((arbol1 != nullptr) ? arbol1->der : arbol1),
            ((arbol2 != nullptr) ? arbol2->der : arbol2));
}

bool Arbol::verificarABB(NodoArbol *arbol) {
    if (arbol == nullptr) return true;
    if (!(verificarIzq(arbol->izq, arbol->elemento) &&
            verificarDer(arbol->der, arbol->elemento)))
        return false;
    return verificarABB(arbol->izq) && verificarABB(arbol->der);
}
// <Condiciones para verificar que es ABB
//      < El elemento de un nodo no es repetido en todo el arbol
//      < Todos los elementos a la izquierda de un nodo son menores a este
//      < Todos los elementos a la derecha de un nodo son mayores a este

bool Arbol::verificarIzq(NodoArbol *arbol, int dato) {
    if (arbol == nullptr) return true;
    if (dato <= arbol->elemento) return false;
    return verificarIzq(arbol->izq, dato) &&
            verificarIzq(arbol->der, dato);
}

bool Arbol::verificarDer(NodoArbol *arbol, int dato) {
    if (arbol == nullptr) return true;
    if (dato >= arbol->elemento) return false;
    return verificarDer(arbol->izq, dato) &&
            verificarDer(arbol->der, dato);
}
