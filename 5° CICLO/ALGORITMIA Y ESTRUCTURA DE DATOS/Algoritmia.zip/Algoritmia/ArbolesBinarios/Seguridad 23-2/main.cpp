/* 
 * File:   main.cpp
 * Author: Rodrigo Holguin Huari
 * Codigo: 20221466
 * Created on 27 de mayo de 2024, 16:59
 */

#include <iostream>
#include <iomanip>
#include "ArbolBinario.h"
#include "funcionesArbolesBinarios.h"
using namespace std;

bool existeElemento(NodoArbol *raiz, int n){
    if(raiz==nullptr) return false;
    if(raiz->elemento == n) return true;
    if(n<raiz->elemento) return existeElemento(raiz->izquierda, n);
    else return existeElemento(raiz->derecha, n);
}

int busca_primer_ancestro_comun(NodoArbol *raiz, int a, int b){
    if(raiz==nullptr) return -1;
    if((a<raiz->elemento && b>raiz->elemento) ||  (a>raiz->elemento && b<raiz->elemento)
            || (a==raiz->elemento) || (b==raiz->elemento)){
        if(!existeElemento(raiz, a) || !existeElemento(raiz, b)) return -1;
        return raiz->elemento;
    } else if(a<raiz->elemento && b<raiz->elemento) 
        return busca_primer_ancestro_comun(raiz->izquierda, a, b);
    else return busca_primer_ancestro_comun(raiz->derecha, a, b);
}

void iniciarArboles(ArbolBinario &arbol1, ArbolBinario &arbol2){
    ArbolBinario arbol_token1;
    ArbolBinario arbol_token2;
    ArbolBinario arbol_token3;
    ArbolBinario arbol_token4;
    ArbolBinario arbol_token5;
    ArbolBinario arbol_token6;
    ArbolBinario arbol_token7;
    
    construir(arbol_token1);
    plantarArbolBinario(arbol_token1, nullptr, 4, nullptr);
    construir(arbol_token2);
    plantarArbolBinario(arbol_token2, nullptr, 3, arbol_token1.raiz);
    construir(arbol_token3);
    plantarArbolBinario(arbol_token3, nullptr, 1, nullptr);
    construir(arbol_token4);
    plantarArbolBinario(arbol_token4, arbol_token3, 2, arbol_token2);
    construir(arbol_token5);
    plantarArbolBinario(arbol_token5, nullptr, 18, nullptr);
    construir(arbol_token6);
    plantarArbolBinario(arbol_token6, nullptr, 8, nullptr);
    construir(arbol_token7);
    plantarArbolBinario(arbol_token7, arbol_token6, 12, arbol_token5);
    construir(arbol1);
    plantarArbolBinario(arbol1, arbol_token4, 5, arbol_token7);
    
    //caso 1
//    ArbolBinario arbol_token8;
//    ArbolBinario arbol_token9;
//    ArbolBinario arbol_token10;
//    ArbolBinario arbol_token11;
//    ArbolBinario arbol_token12;
//    ArbolBinario arbol_token13;
//    ArbolBinario arbol_token14;
//    
//    construir(arbol_token8);
//    plantarArbolBinario(arbol_token8, nullptr, 2, nullptr);
//    construir(arbol_token9);
//    plantarArbolBinario(arbol_token9, nullptr, 1, arbol_token8.raiz);
//    construir(arbol_token10);
//    plantarArbolBinario(arbol_token10, nullptr, 7, nullptr);
//    construir(arbol_token11);
//    plantarArbolBinario(arbol_token11, nullptr, 6, arbol_token10.raiz);
//    construir(arbol_token12);
//    plantarArbolBinario(arbol_token12, nullptr, 4, nullptr);
//    construir(arbol_token13);
//    plantarArbolBinario(arbol_token13, arbol_token12, 5, arbol_token11);
//    construir(arbol2);
//    plantarArbolBinario(arbol2, arbol_token9, 5, arbol_token13);
    //caso 2
    ArbolBinario arbol_token8;
    ArbolBinario arbol_token9;
    ArbolBinario arbol_token10;
    ArbolBinario arbol_token11;
    ArbolBinario arbol_token12;
    ArbolBinario arbol_token13;
    ArbolBinario arbol_token14;
    
    construir(arbol_token8);
    plantarArbolBinario(arbol_token8, nullptr, 0, nullptr);
    construir(arbol_token9);
    plantarArbolBinario(arbol_token9, nullptr, -1, arbol_token8.raiz);
    construir(arbol_token10);
    plantarArbolBinario(arbol_token10, nullptr, -3, nullptr);
    construir(arbol_token11);
    plantarArbolBinario(arbol_token11, arbol_token10.raiz, -2, arbol_token9.raiz);
    construir(arbol_token12);
    plantarArbolBinario(arbol_token12, nullptr, 5, nullptr);
    construir(arbol_token13);
    plantarArbolBinario(arbol_token13, nullptr, 7, nullptr);
    construir(arbol_token14);
    plantarArbolBinario(arbol_token14, arbol_token12, 6, arbol_token13);
    construir(arbol2);
    plantarArbolBinario(arbol2, arbol_token11, 4, arbol_token14);
}

void ubicarArbol(NodoArbol *&raiz1, NodoArbol *arbol1, 
        NodoArbol *&raiz2, NodoArbol *arbol2, int ancestro){
    if(ancestro==arbol1->elemento) return;
    if(ancestro>arbol1->elemento) {
        ubicarArbol(raiz1, arbol1->derecha, raiz2, arbol2->derecha, ancestro);
        raiz1 = arbol1->derecha;
        raiz2 = arbol2->derecha;
    } else{
        ubicarArbol(raiz1, arbol1->izquierda, raiz2, arbol2->izquierda, ancestro);
        raiz1 = arbol1->izquierda;
        raiz2 = arbol2->izquierda;
    } 
}

void sumarArboles(NodoArbol *arbol1, NodoArbol *arbol2){
    if(arbol1==nullptr) return;
    if(arbol2 !=nullptr){
        arbol1->elemento += arbol2->elemento;
        sumarArboles(arbol1->izquierda, arbol2->izquierda);
        sumarArboles(arbol1->derecha, arbol2->derecha);
    }
}

bool buscar(int elemento, NodoArbol *arbol, bool lado){
    if(arbol == nullptr) return true;
    if(elemento == arbol->elemento) return false;
    if((lado && elemento<arbol->elemento) || (!lado && elemento>arbol->elemento))
        return false;
    return buscar(elemento, arbol->derecha, true) && 
            buscar(elemento, arbol->izquierda, false);
}

bool esABB(NodoArbol *arbol_token){
    if(arbol_token==nullptr) return true;
    if(!buscar(arbol_token->elemento, arbol_token->derecha, true) ||
            !buscar(arbol_token->elemento, arbol_token->izquierda, false)) return false;
    return esABB(arbol_token->derecha) && esABB(arbol_token->izquierda);
}

bool suma_parcial_arboles(ArbolBinario arbol_token, 
        ArbolBinario arbol_sistema, int ancestro){
    NodoArbol *nodo1, *nodo2;
    ubicarArbol(nodo1, arbol_token.raiz, nodo2, arbol_sistema.raiz, ancestro);
    sumarArboles(nodo1, nodo2);
    return esABB(arbol_token.raiz);
}

int main(int argc, char** argv) {
    ArbolBinario arbol_token;
    ArbolBinario arbol_sistema;
    iniciarArboles(arbol_token, arbol_sistema);
    int ancestro = busca_primer_ancestro_comun(arbol_token.raiz, 8, 12);
    if(ancestro!=-1){
        if(suma_parcial_arboles(arbol_token, arbol_sistema, ancestro)) cout<<"Acceso otorgado"<<endl;
        else cout<<"Acceso denegado"<<endl;
    }
    destruirArbolBinario(arbol_token);
    destruirArbolBinario(arbol_sistema);
    return 0;
}

