/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 28 de mayo de 2024, 23:22
 */

#include <iostream>
#include <iomanip>

#include "ArbolBinarioBusqueda.h"
#include "funcionesArbolesBinarios.h"
#include "funcionesArbolesBB.h"
using namespace std;

void fusionarAlmacenes(ArbolBinarioBusqueda destino, NodoArbol *emisor){
    if(emisor==nullptr) return;
    if(!buscaArbol(destino, emisor->elemento)) insertar(destino, emisor->elemento);
    fusionarAlmacenes(destino, emisor->izquierda);
    fusionarAlmacenes(destino, emisor->derecha);
}

void imprimirRec1(NodoArbol *nodo){
    if(nodo==nullptr) return;
    imprimirRec1(nodo->izquierda);
    cout<<"("<<nodo->elemento/100<<" - "<<nodo->elemento%100<<") ";
    imprimirRec1(nodo->derecha);
}

void imprimirEnOrden(ArbolBinarioBusqueda destino){
    imprimirRec1(destino.arbolBinario.raiz);
    cout<<endl<<endl;
}

void imprimirRec2(NodoArbol *nodo){
    if(nodo==nullptr) return;
    cout<<"("<<nodo->elemento/100<<" - "<<nodo->elemento%100<<") ";
    imprimirRec1(nodo->izquierda);
    imprimirRec1(nodo->derecha);
}

void imprimirPreOrden(ArbolBinarioBusqueda destino){
    imprimirRec2(destino.arbolBinario.raiz);
    cout<<endl<<endl;
}

int main(int argc, char** argv) {
    
    ArbolBinarioBusqueda destino;
    ArbolBinarioBusqueda emisor;
    
    construir(destino);
    construir(emisor);
    //INGRESO DE DATOS
    int num;
    while(true){
        cin>>num;
        if(num==0) break;
        insertar(destino, num);
    }
    while(true){
        cin>>num;
        if(num==0) break;
        insertar(emisor, num);
    }
    cout<<"En orden: ";
    imprimirEnOrden(destino);
    cout<<"En pre-orden: ";
    imprimirPreOrden(destino);
    fusionarAlmacenes(destino, emisor.arbolBinario.raiz);
    cout<<"En orden: ";
    imprimirEnOrden(destino);
    cout<<"En pre-orden: ";
    imprimirPreOrden(destino);
    return 0;
}

