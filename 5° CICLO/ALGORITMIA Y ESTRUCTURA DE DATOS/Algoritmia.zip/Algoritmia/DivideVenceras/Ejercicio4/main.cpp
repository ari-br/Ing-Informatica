
/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 10 de mayo de 2024, 20:24
 */

#include <iostream>
#include <iomanip>
using namespace std;

int mayor(int A, int B){
    if(A>B) return A;
    return B;
}

int sumaMaxCentro(int *data, int inicio, int medio, int fin, 
        int &posIni, int &posFin){
    
    posIni = medio;
    posFin = medio;
    int sumaDerecha=0, maxSumaDerecha=-1000;
    for(int i=medio+1; i<=fin; i++){
        sumaDerecha += data[i];
        if(sumaDerecha>maxSumaDerecha){
            maxSumaDerecha = sumaDerecha;
            posFin = i;
        }
    }
    int sumaIzquierda=0, maxSumaIzquierda=-1000;
    for(int i=medio; i>=inicio; i--){
        sumaIzquierda += data[i];
        if(sumaIzquierda>maxSumaIzquierda){
            maxSumaIzquierda = sumaIzquierda;
            posIni = i;
        }
    }
    return maxSumaDerecha + maxSumaIzquierda;
}

int obtenerSumaMax(int *data, int inicio, int fin, int &posIni, int &posFin){
    if(inicio==fin) return data[inicio];
    int medio = (inicio+fin)/2;
    int sumaMaxIzq = obtenerSumaMax(data, inicio, medio, posIni, posFin);
    int sumaMaxDer = obtenerSumaMax(data, medio+1, fin, posIni, posFin);
    int sumaMaxCen = sumaMaxCentro(data, inicio, medio, fin, posIni, posFin);
    return mayor(mayor(sumaMaxIzq, sumaMaxDer), sumaMaxCen);
}

int main(int argc, char** argv) {    
    int data[8] = {-2,-5,6,-2,-3,1,5,-6}, cantDatos=8, posIni, posFin;
    cout<<"Salida: "<<obtenerSumaMax(data, 0, cantDatos-1, posIni, posFin)<<" ("
            "Los elementos que suman el máximo son ";
    for(int i=posIni; i<=posFin; i++){
        cout<<data[i];
        if(i!=posFin) cout<<", ";
    }
    cout<<")";
    return 0;
}

