/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 10 de mayo de 2024, 18:58
 */

#include <iostream>
#include <iomanip>
using namespace std;

int contarCeros(int *data, int inicio, int fin){
    if(inicio==fin){
        if(data[inicio]==0) return inicio;
        else return 6;
    }
    int medio=(inicio+fin)/2;
    if(data[medio]== 0) return contarCeros(data, inicio, medio);
    else return contarCeros(data, medio+1, fin);
}

int main(int argc, char** argv) {
    
    int data[6]={1,1,1,1,1,1}, cantDatos=6;
    cout<<"La cantidad de 0s es: "<<cantDatos - 
            contarCeros(data, 0, cantDatos-1);
    return 0;
}

