/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 10 de mayo de 2024, 18:20
 */

#include <iostream>
#include <iomanip>
using namespace std;

int encontrarUnico(int *data, int ini, int fin){
    if(ini>=fin) return data[ini];
    int medio=(ini+fin)/2;
    if(medio%2!=0){ //revisar a la izquierda
        if(data[medio]==data[medio-1]){//la anormalidad esta despues
            return encontrarUnico(data, medio+1, fin);
        } else{//ya ha ocurrido la anormalidad
            return encontrarUnico(data, ini, medio-1);
        }
    } else{
        if(data[medio]==data[medio+1]){//la anormalidad esta despues
            return encontrarUnico(data, medio+2, fin);
        } else{//ya ha ocurrido la anormalidad
            return encontrarUnico(data, ini, medio-1);
        }        
    }
}

int main(int argc, char** argv) {
    int data[17] = {1,1,2,3,3,3,4,4,5,9,9,7,7,8,8,10,10}, cantElementos=17;
    
    cout<<"El elemento que aparece solo una vez es: "<<
            encontrarUnico(data, 0, cantElementos-1);
    cout<<" ";
    return 0;
}

