/* 
 * File:   main.cpp
 * Author: Rodrigo Holguin HUari
 * Codigo: 20221466
 * Created on 7 de mayo de 2024, 10:18
 */

#include <iostream>
#include <iomanip>
using namespace std;

void actualizarValores(int numReg, int numLin, int *virus, int *cantLineas, 
        int &cantVirus){
    for(int i=0; true; i++){
        if(virus[i]==0){
            virus[i] = numReg;
            cantLineas[i] += numLin;
            return;
        }
        else if(virus[i]==numReg){
            cantLineas[i] += numLin;
            return;
        }
    }
}

void analizarVirus(int *registros, int *instrucciones, int *virus, 
        int *cantLineas, int ini, int fin, int &cantVirus){
    if(ini==fin){//se tiene un unico elemento
        if(registros[ini]>0){
            actualizarValores(registros[ini], instrucciones[ini], virus,
                    cantLineas, cantVirus);
        }
        return;
    }
    int medio=(ini+fin)/2;
    analizarVirus(registros, instrucciones, virus, cantLineas, 
            ini, medio, cantVirus);
    analizarVirus(registros, instrucciones, virus, cantLineas, 
            medio+1, fin, cantVirus);
}

int main(int argc, char** argv) {
    int n=5, m=6;
    int matRegistros[5][6] = {
        {-1,-2,-3,-4,-5,-6},
        {-7,-8,1,-9,2,-10},
        {-11,1,2,-12,-13,-14},
        {-15,-16,-17,1,-18,-19},
        {-20,1,2,-21,-22,-23}
    };
    int matIntruccione[5][6] = {
        {10,5,8,9,8,1},
        {10,5,2,8,2,3},
        {4,2,1,4,8,1},
        {1,2,4,3,5,3},
        {8,3,3,8,5,3}
    };
    int registros[30], instrucciones[30];
    int i=0;
    for(int j=0; j<n; j++){
        for(int k=0; k<m; k++){
            registros[i] = matRegistros[j][k];
            i++;
        }
    }
    i=0;
    for(int j=0; j<n; j++){
        for(int k=0; k<m; k++){
            instrucciones[i] = matIntruccione[j][k];
            i++;
        }
    }
    int virus[m*n]{}, cantLineas[m*n]{}, cantVirus=0;
    analizarVirus(registros, instrucciones, virus, cantLineas, 0, 
            m*n -1, cantVirus);
    for(int i=0; virus[i]!=0; i++){
        cout<<"Para el virus de registro "<<virus[i]<<", se obtienen "<<
                cantLineas[i]<<" coincidencias en total.";
        if(cantLineas[i]>=10){
            cout<<" ARCHIVO INFECTADO CON ESTE VIRUS";
        }
        cout<<endl;
    }
    return 0;
}

