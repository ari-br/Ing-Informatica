/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 *
 * Created on 6 de mayo de 2024, 10:57
 */

#include <iostream>
#include <iomanip>
using namespace std;

int sumarLado(int data[][3][4], int iniAlt, int finAlt, int iniAnc, int finAnc, 
        int iniLar, int finLar){
    
    
    return 0;
}

int obtenerCortes(int data[][3][4], int iniAlt, int maxAlt, int iniAnc,
        int maxAnc, int iniLar, int maxLar){
    int cantA, cantB, cantCorte=0, mitadAlt, mitadAnc, mitadLar;
    bool alturaEst, anchoEst, largoEst;
    if(iniAlt==maxAlt && iniAnc==maxAnc && iniLar==maxLar){
        cout<<"Posición del cubo de vibranio: ("<<iniLar+1<<","<<iniAnc+1<<","
                <<iniLar+1<<")"<<endl;
        return 1;
    }
    alturaEst = iniAlt==maxAlt;
    anchoEst = iniAnc==maxAnc;
    largoEst = iniLar==maxLar;
    if(alturaEst){
        mitadAlt = maxAlt;//altura iguales
        if(anchoEst){
            mitadAnc = maxAnc;//ancho iguales
            if(largoEst) mitadLar = maxLar;//largo iguales
            else mitadLar = (iniLar+maxLar)/2;
        } else mitadAnc = (iniAnc+maxAnc)/2;
    } else mitadAlt = (iniAlt+maxAlt)/2;
    cantA = sumarLado(data, iniAlt, mitadAlt, iniAnc, mitadAnc, iniLar, mitadLar);
    if(alturaEst){
        mitadAlt = maxAlt-1;//altura iguales
        if(anchoEst){
            mitadAnc = maxAnc-1;//ancho iguales
            if(largoEst) mitadLar = maxLar-1;//largo iguales
        }
    }
    cantB = sumarLado(data, mitadAlt+1, maxAlt, mitadAnc+1, maxAnc, mitadLar+1, maxLar);
    if(cantA>cantB) return cantCorte + obtenerCortes(data, iniAlt, mitadAlt, 
            iniAnc, mitadAnc, iniLar, mitadLar);
    else return cantCorte + obtenerCortes(data, mitadAlt+1, maxAlt, 
            mitadAnc+1, maxAnc, mitadLar+1, maxLar);
}

int main(int argc, char** argv) {
    int largo, ancho, altura;
    cout<<"Ingrese el largo: ";
    cin>>largo;
    cout<<"Ingrese el ancho: ";
    cin>>ancho;
    cout<<"Ingrese la altura: ";
    cin>>altura;
    cout<<"Configuración del meteorito: "<<endl;
    int data[2][3][4] = {
        {
            {0,0,0,0},
            {0,0,0,0},
            {0,0,0,0},
        },
        {
            {0,0,0,0},
            {0,0,1,0},
            {0,0,0,0},       
        }
    };
    
    
//    for(int i=0; i<altura; i++){
//        cout<<"Nivel "<<i+1<<": "<<endl;
//        for(int j=0; j<ancho; j++){
//            for(int k=0; k<largo; k++){
//                cin>>data[i][j][k]; 
//            }
//        }
//    }
    for(int i=0; i<altura; i++){
        for(int j=0; j<ancho; j++){
            for(int k=0; k<largo; k++){
                cout<<data[i][j][k]<<"  "; 
            }
            cout<<endl;
        }
        cout<<"--------------"<<endl;
    }
    cout<<"Dinero invertido en cortes (en millones de USD): "<<
            obtenerCortes(data, 0, altura-1, 0, ancho-1, 0, largo-1);
    return 0;
}

