/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 10 de mayo de 2024, 19:27
 */ 

#include <iostream>
#include <iomanip>
using namespace std;

int encontrarMinimo(int *data, int inicio, int fin){
    if(inicio==fin) return fin;
    int medio=(inicio+fin)/2;
    if(data[medio]>data[medio+1]) return medio+1;
    if(data[medio]>=data[fin]) return encontrarMinimo(data, medio+1, fin);
    return encontrarMinimo(data, inicio, medio);
}

int main(int argc, char** argv) {
    int data[6] = {5,6,1,2,3,4}, cantdatos=6;
    cout<<"El elemento mínimo del arreglo es: "<<
            data[encontrarMinimo(data, 0, cantdatos-1)];
    return 0;
}
