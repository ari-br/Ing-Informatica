/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 5 de mayo de 2024, 11:39  -> 12:33  56 min
 */

#include <iostream>
#include <iomanip>
using namespace std;

int obtenerFrecuencia(int data[][10], int mayorNum, int fila, int inicio, int fin){ //complejidad mlog(m)
    int frecuencia=0, medio=(inicio+fin)/2;
    if(inicio==fin && data[fila][medio]==mayorNum) return 1;
    else if(inicio==fin) return 0;
    frecuencia = obtenerFrecuencia(data, mayorNum, fila, inicio, medio) +
            obtenerFrecuencia(data, mayorNum, fila, medio+1, fin);
    return frecuencia;
}

int obtenerEmpresa(int data[][10], int *mayorProd, int cantEmpresas){
    int minimo=999999, frecuencia, empresaFinal;
    for(int i=0; i<cantEmpresas; i++){ //complejidad n
        frecuencia = obtenerFrecuencia(data, mayorProd[i], i, 0, 9); //complejidad mlog(m)
        if(frecuencia<minimo){
            minimo = frecuencia;
            empresaFinal = i;
        }
    }
    return empresaFinal+1;
}

int obtenerMayor(int a, int b){
    if(a>b) return a;
    return b;
}

int mayorValor(int data[][10], int fila, int inicio, int fin){
    int medio = (inicio+fin)/2;
    if(inicio==fin) return data[fila][medio];
    return obtenerMayor(mayorValor(data, fila, inicio, medio), 
            mayorValor(data, fila, medio+1, fin));
}

void calcularMayorProd(int *mayorProd, int data[][10], int cantEmpresas){
    for(int i=0; i<cantEmpresas; i++){
        mayorProd[i] = mayorValor(data, i, 0, 9);
    }
}

int main(int argc, char** argv) {
    int cantEmpresas;
    cout<<"Ingrese la cantidad de empresas que hay: ";
    cin>>cantEmpresas;
    int data[cantEmpresas][10] =  {
        {15,12,10,17,15,2,15,18,12,16},
        {14,17,17,17,17,17,14,14,12,12},
        {16,18,20,20,15,18,16,18,18,16},
        {14,13,12,11,10,19,18,17,19,14}
    };
    int mayorProd[cantEmpresas];
    calcularMayorProd(mayorProd, data, cantEmpresas);
//    for(int i=0; i<cantEmpresas; i++){
//        cout<<endl<<endl<<"EMPRESA "<<i+1<<endl<<"Produccion por hora de atencion: "
//                <<endl;
//        for(int j=0; j<10; j++){
//            cout<<j+2<<" pm: ";
//            cin>>data[i][j];
//        }
//    }
    cout<<endl<<"El maestro Splinter debe comprar en la empresa "<<
            obtenerEmpresa(data, mayorProd, cantEmpresas);
    return 0;
}

