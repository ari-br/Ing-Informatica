/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 10 de mayo de 2024, 20:27
 */

#include <iostream>
#include <iomanip>
using namespace std;

int hallarMaximo(int *data, int inicio, int fin){
    if(inicio==fin) return inicio;
    int medio=(inicio+fin)/2;
    if(data[medio]<data[medio+1]) return hallarMaximo(data, medio+1,fin);
    return hallarMaximo(data, inicio, medio);
}

int main(int argc, char** argv) {
    int data[11] = {8,10,20,80,100,200,400,500,3,2,1}, cantDatos=11;
    cout<<"El mayor elemento en el arreglo es: "<<
            data[hallarMaximo(data, 0, cantDatos-1)];
    return 0;
}

