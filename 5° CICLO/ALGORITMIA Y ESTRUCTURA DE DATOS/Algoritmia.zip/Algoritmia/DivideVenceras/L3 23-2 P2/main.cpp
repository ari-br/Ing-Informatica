
/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 5 de mayo de 2024, 13:00
 */

#include <iostream>
#include <iomanip>
using namespace std;

int obtenerCantidad(char data[][11], int fila, int inicio, int fin, 
        char car){
    int medio = (inicio+fin)/2;
    if(inicio==fin && car == data[fila][medio]) return 1;
    else if(inicio==fin) return 0;
    return obtenerCantidad(data, fila, inicio, medio, car) + 
            obtenerCantidad(data, fila, medio+1, fin, car);
}

char obtenerExtra(char data[][11], int fila, int inicio, int fin){
    int medio = (inicio+fin)/2, der, izq;
    char car1, car2, buscar;
    if(inicio==fin) return '-';
    buscar = data[fila][medio];
    izq = obtenerCantidad(data, fila, inicio, medio, data[fila][medio]);
    der = obtenerCantidad(data, fila, medio+1, fin, data[fila][medio]);
    if(izq+der==3) return data[fila][medio];
    car1 = obtenerExtra(data, fila, inicio, medio);
    car2 = obtenerExtra(data, fila, medio+1, fin);
    if(car1=='-') return car2;
    else if(car2=='-') return car1;    
    return '-';
}

void determinarExtra(char data[][11], int cantFilas){
    char extra;
    cout<<"PREGUNTA 1"<<endl;
    for(int i=0; i<cantFilas; i++){
        extra = obtenerExtra(data, i, 0, 10);
        if(extra!='-'){
            cout<<"La fila "<<i+1<<" tiene un "<<extra<<" adicional."<<endl;
        }
    }
}

void pregunta1(){
    int cantFilas = 8;
    char data[cantFilas][11] = {
        {'O', 'O', 'C', 'C', 'A', 'A', 'E', 'E', 'R', 'R', 'R'},
        {'C', 'C', 'A', 'A', 'R', 'R', 'E', 'E', 'B', 'B', 0},
        {'R', 'R', 'E', 'E', 'C', 'C', 'F', 'F', 'A', 'A', 0},
        {'E', 'E', 'F', 'F', 'A', 'A', 'A', 'B', 'B', 'R', 'R'},
        {'C', 'C', 'C', 'A', 'A', 'R', 'R', 'O', 'O', 'E', 'E'},
        {'O', 'O', 'C', 'C', 'A', 'A', 'R', 'R', 'E', 'E', 0},
        {'A', 'A', 'F', 'F', 'R', 'R', 'E', 'E', 'O', 'O', 0},
        {'E', 'E', 'A', 'A', 'O', 'O', 'B', 'B', 'F', 'F', 0},
    };
    determinarExtra(data, cantFilas);    
}

int mayor(int data[][5], int fila, int posA, int posB){
    if(data[fila][posA]>data[fila][posB]) return posA;
    return posB;
}

int obtenerPasajero(int data[][5], int fila, int inicio, int fin){
    int medio=(inicio+fin)/2, posicion1, posicion2;
    if(inicio==fin) return medio;
    posicion1 = obtenerPasajero(data, fila, inicio, medio);
    posicion2 = obtenerPasajero(data, fila, medio+1, fin);
    return mayor(data, fila, posicion1, posicion2);
}

void determinarCaro(int data[][5], int cantFilas, int cantColumnas){
    cout<<endl<<endl<<"PREGUNTA 2:"<<endl;
    for(int i=0; i<cantFilas; i++){// complejidad m
        cout<<"En la fila "<<i+1<<" el pasajero del asiento "<<
                (obtenerPasajero(data, i, 0, cantColumnas-1))+1
                <<" tiene el""bocadito más caro que sus dos vecinos"<<endl;
    }
}

void pregunta2(){
    int m = 8, n=5;
    int data[m][5] = {
        {1,2,3,2,1},
        {2,3,2,2,1},
        {1,2,2,5,3},
        {2,5,3,3,1},
        {2,2,3,2,1},
        {1,2,3,2,1},
        {3,5,2,1,1},
        {2,3,2,1,1}
    };
    determinarCaro(data, m, n);
}

int main(int argc, char** argv) {
    pregunta1();
    pregunta2();
    return 0;
}

// <Por que a veces va con inicio==fin y otra con inicio>=fin
// <Posiblemente error tuyo en los parametros

