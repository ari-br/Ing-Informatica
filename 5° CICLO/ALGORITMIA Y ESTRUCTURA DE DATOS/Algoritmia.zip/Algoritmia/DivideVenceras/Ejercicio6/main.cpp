/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 11 de mayo de 2024, 00:08
 */

#include <iostream>
#include <iomanip>
using namespace std;

int contarInversionesCentro(int *data, int inicio, int medio, int fin){
    int i=inicio;
    int j=medio+1;
    int k=0;
    int arrTemp[fin-inicio+1];
    int inversiones=0;
    while(i<=medio && j<=fin){
        if(data[i]<=data[j]){
            arrTemp[k]  = data[i]; 
            i++;
        } else{
            inversiones+=(medio-i+1);
            arrTemp[k] = data[j];
            j++;
        }
        k++;
    }
    while(i<=medio){
        arrTemp[k] = data[i];
        i++;
        k++;
    }
    while(j<=fin){
        arrTemp[k] = data[j];
        j++;
        k++;
    }
    for(int i=inicio; i<=fin; i++) data[i] = arrTemp[i-inicio];
    return inversiones;
}

int contarInversiones(int *data, int inicio, int fin){
    if(inicio==fin) return 0;
    int medio = (inicio+fin)/2;
    int invIzq = contarInversiones(data, inicio, medio); 
    int invDer = contarInversiones(data, medio+1, fin);
    int invCen = contarInversionesCentro(data, inicio, medio, fin);
    return invIzq + invDer + invCen;
}

int main(int argc, char** argv) {
    int data[9] = {4,6,1,5,2,3,9,8,7}, cantDatos=9;
    cout<<"El numero de inversiones es: "<<
            contarInversiones(data, 0, cantDatos-1);
    cout<<' ';
    return 0;
}

