/* 
 * File:   main.cpp
 * Author: Rodrigo Holguin Huari
 * Codigo: 20221466
 * Created on 5 de mayo de 2024, 21:16  -> 22:11   ,  0:55
 */

#include <iostream>
#include <iomanip>
using namespace std;

void merge(int data[][7], int fila, int *posiciones, int inicio, 
        int medio, int fin){
    int p1 = medio - inicio+1;
    int p2 = fin - medio;
    int aux1[p1+1];
    int aux2[p2+1];
    for(int i=inicio; i<=medio;i++) aux1[i-inicio] = posiciones[i];
    for(int i=medio+1; i<=fin;i++) aux2[i-(medio+1)] = posiciones[i];
    aux1[p1] = 9999;
    aux2[p2] = 9999;
    int i=0;
    int j=0;
    for(int contador = inicio; contador<=fin; contador++){  
        if(data[fila][aux1[i]] > data[fila][aux2[j]]){
            posiciones[contador] = aux2[j];
            j++;
        } else {
            posiciones[contador] = aux1[i];
            i++;
        }
    }
}

void mergeSort(int data[][7], int fila, int *posiciones, int inicio, int fin){
    if(inicio==fin) return;
    int medio=(inicio+fin)/2;
    mergeSort(data, fila, posiciones, inicio, medio);
    mergeSort(data, fila, posiciones, medio+1, fin);
    merge(data, fila, posiciones, inicio, medio, fin);
}

int calcularMonto(int data[][7], double ibd, int fila, int *posiciones, 
        int &cantPosiciones, bool venta, int inicio, int fin){ //se vende si esta por encima
    int medio=(inicio+fin)/2;
    if(inicio==fin){
        if((venta && data[fila][medio]>ibd) || 
                (!venta && data[fila][medio]<=ibd)){
            posiciones[cantPosiciones] = medio;
            cantPosiciones++;
            return data[fila][medio];
        }
        return 0;
    }
    return calcularMonto(data, ibd, fila, posiciones, cantPosiciones,
            venta, inicio, medio) + calcularMonto(data, ibd, fila, posiciones, 
            cantPosiciones, venta, medio+1, fin);
}

void calcularIBD(int data[][7], int fila, int inicio, int fin, int &suma,
        int &cant){
    int medio=(inicio+fin)/2;
    if(inicio==fin){
        suma += data[fila][medio];
        cant++;
        return;
    }
    calcularIBD(data, fila, inicio, medio, suma, cant);
    calcularIBD(data, fila, medio+1, fin, suma, cant);
}

void calcularCompraYVenta(int data[][7], char *empresas, double ibm, 
        int cantDias, int cantEmp){
    cout<<setprecision(3)<<fixed;
    double ibd;
    int suma, cant, monto, posiciones[cantEmp], cantPosiciones;
    for(int i=0; i<cantDias; i++){
        suma = 0;
        cant = 0;
        calcularIBD(data, i, 0, cantEmp-1, suma, cant);
        ibd = (double)suma/cant;
        cout<<"Día "<<i+1<<"- IBD: "<<ibd<<" - Decisión: ";
        cantPosiciones = 0;
        if(ibd>ibm){
            cout<<"Vende  - ";
            monto = calcularMonto(data, ibd, i, posiciones, cantPosiciones, true,
                    0, cantEmp-1);//venta
        } else{
            cout<<"Compra - ";
            monto = calcularMonto(data, ibd, i, posiciones, cantPosiciones, false,
                    0, cantEmp-1);//compra
        }
        mergeSort(data, i, posiciones, 0, cantPosiciones-1);
        cout<<"Monto que se compra o vende: "<<setw(2)<<monto<<
                " - Acciones de las empresas que se compran o venden: ";
        for(int j=0; j<cantPosiciones; j++) cout<<empresas[posiciones[j]]<<" ";
        cout<<endl;
    }
}

int main(int argc, char** argv) {
//    int cantDias, cantEmpresas;
//    double ibm;
//    cout<<"Ingrese la cantidad de dias: ";
//    cin>>cantDias;
//    cout<<"Ingrese la cantidad de empresas: ";
//    cin>>cantEmpresas;
//    cout<<"Ingrese el IBM: ";
//    cin>>ibm;
//    cout<<endl;
//    char empresas[cantEmpresas];
//    cout<<"Ingrese los nombres de las empresas: "<<endl;
//    for(int i=0; i<cantEmpresas; i++){
//        cout<<"Empresa "<<i+1<<": ";
//        cin>>empresas[i];
//    }
//    cout<<endl;
//    int data[cantDias][cantEmpresas];
//    for(int i=0; i<cantDias; i++){
//        cout<<"Valor de las acciones en el dia "<<i+1<<endl;
//        for(int j=0; j<cantEmpresas; j++){
//            cout<<"Empresa "<<empresas[j]<<": ";
//            cin>>data[i][j];
//        }
//        cout<<endl;
//    }
    
    int cantDias=6, cantEmp=7;
    double ibm=4.2;
    char empresas[cantEmp] = {'A','B','C','D','E','F','G'};
    int data[cantDias][7] = {
        {8,4,5,6,7,1,2},
        {3,4,5,7,1,2,6},
        {5,6,5,2,1,6,8},
        {3,4,5,6,2,1,9},
        {3,4,5,4,5,3,2},
        {3,4,4,8,9,7,6},
    };
    calcularCompraYVenta(data, empresas, ibm, cantDias, cantEmp);
    return 0;
}

