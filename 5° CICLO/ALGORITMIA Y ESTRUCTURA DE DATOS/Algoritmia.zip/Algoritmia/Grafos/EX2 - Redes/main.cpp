/* 
 * File:   main.cpp
 * Author: Rodrigo Alejandro Holguin Huari
 * Codigo: 20221466
 * Created on 1 de julio de 2024, 23:02
 */

#include <iostream>
#include <iomanip>
using namespace std;

int obtenerValor(int datos[][9], int *etiquetas, int cantNodos, int nodo) {
    int tag = 1;
    for (int i = 0; i < cantNodos; i++)
        if (datos[nodo][i] != 0 && etiquetas[i] != 0 && etiquetas[i] <= tag) tag++;
    return tag;
}

void etiquetaractivos(int datos[][9], int *etiquetas, int ini, int fin) {
    if (ini == fin) return;
    for (int i = ini + 1; i <= fin; i++) {
        if (datos[ini][i])
            if (etiquetas[ini] == etiquetas[i])
                etiquetas[i]++;
    }
    etiquetaractivos(datos, etiquetas, ini + 1, fin);
}

bool obtenerEtiquetas(int datos[][9], int *etiquetas, int cantEti, int cantNodos) {
    int tag;
    for (int i = 0; i < cantNodos; i++) {
        tag = 1;
        for (int j = 0; j < cantNodos; j++) {
            if (datos[i][j] != 0 && etiquetas[j] == 0) {//hay conexion
                etiquetas[j] = obtenerValor(datos, etiquetas, cantNodos, j);
                if (etiquetas[j] == cantEti + 1) {
                    cout << "No hay solucion para " << cantEti << " etiquetas" << endl;
                    return false;
                }
                tag++;
            }
        }
    }
    return true;
}

int main(int argc, char** argv) {
    int cantEti = 4;
    int cantNodos = 9;
    int datos[9][9] ={
        {1, 0, 0, 6, 0, 0, 0, 0, 2},
        {0, 1, 5, 2, 0, 0, 0, 0, 7},
        {0, 3, 1, 2, 3, 8, 9, 7, 5},
        {2, 7, 5, 1, 2, 0, 0, 0, 0},
        {0, 0, 5, 3, 1, 4, 0, 0, 0},
        {0, 0, 9, 0, 6, 1, 2, 0, 0},
        {0, 0, 3, 0, 0, 7, 1, 4, 0},
        {0, 0, 4, 0, 0, 0, 9, 1, 9},
        {5, 3, 6, 0, 0, 0, 0, 4, 1}};


    int etiquetas[9]{};

//    etiquetaractivos(datos, etiquetas, 0, cantNodos);
//
//    for (int i = 0; i < cantNodos; i++)
//        cout << etiquetas[i] + 1 << ' ';

        
    if(obtenerEtiquetas(datos, etiquetas, cantEti, cantNodos)){
        for(int i=0; i<cantNodos; i++)
            cout<<etiquetas[i]<<' ';
        cout<<endl;
    }

    return 0;
}

